Pattern Recognition, Chapter 4, KP24: Combining classifiers: product, sum, majority vote and the Bayesian view (English version)

Slides: slides/lec05-kp24-combining-en.html (offline web page, open in a browser); slides/lec05-kp24-combining-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp24-combining-en-lecture.pdf (PDF), lec05-kp24-combining-en-reading.html (offline web page), lectures/lec05-kp24-combining-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
