Pattern Recognition, Chapter 4, KP00: Chapter 4 route map (English version)

Slides: slides/lec05-kp00-overview-en.html (offline web page, open in a browser); slides/lec05-kp00-overview-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp00-overview-en-lecture.pdf (PDF), lec05-kp00-overview-en-reading.html (offline web page), lectures/lec05-kp00-overview-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
