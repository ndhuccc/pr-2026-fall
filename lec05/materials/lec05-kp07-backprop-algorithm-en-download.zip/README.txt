Pattern Recognition, Chapter 4, KP07: The backpropagation algorithm (English version)

Slides: slides/lec05-kp07-backprop-algorithm-en.html (offline web page, open in a browser); slides/lec05-kp07-backprop-algorithm-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp07-backprop-algorithm-en-lecture.pdf (PDF), lec05-kp07-backprop-algorithm-en-reading.html (offline web page), lectures/lec05-kp07-backprop-algorithm-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
