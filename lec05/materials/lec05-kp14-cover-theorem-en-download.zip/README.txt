Pattern Recognition, Chapter 4, KP14: Cover's theorem (English version)

Slides: slides/lec05-kp14-cover-theorem-en.html (offline web page, open in a browser); slides/lec05-kp14-cover-theorem-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp14-cover-theorem-en-lecture.pdf (PDF), lec05-kp14-cover-theorem-en-reading.html (offline web page), lectures/lec05-kp14-cover-theorem-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
