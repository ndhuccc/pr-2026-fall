import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
PTS = [(0, 0), (0, 1), (1, 0), (1, 1)]
LAB = {"OR": {(0, 0): "B", (0, 1): "A", (1, 0): "A", (1, 1): "A"},
       "AND": {(0, 0): "B", (0, 1): "B", (1, 0): "B", (1, 1): "A"},
       "XOR": {(0, 0): "B", (0, 1): "A", (1, 0): "A", (1, 1): "B"}}
LO, HI = -0.4, 1.4
RED = "#e07a70"

def sq(ax, ticks=True):
    ax.set_xlim(LO, HI); ax.set_ylim(LO, HI); ax.set_aspect("equal")
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.set_xticks([0, 1] if ticks else []); ax.set_yticks([0, 1] if ticks else [])
    ax.tick_params(labelsize=fpx(17))
    ax.text(HI - 0.02, LO + 0.04, "$x_1$", fontsize=fpx(19), ha="right", va="bottom", color=TXT)
    ax.text(LO + 0.04, HI - 0.02, "$x_2$", fontsize=fpx(19), ha="left", va="top", color=TXT)
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=MUT, lw=1.2, ls=(0, (3, 3))))

def pt(ax, xy, cls, ms=20, z=5):
    if cls == "A": ax.plot(*xy, "o", ms=ms, color=A_C, mec=BG, mew=1.5, zorder=z)
    else: ax.plot(*xy, "s", ms=ms - 2, color=B_C, mec=BG, mew=1.5, zorder=z)

def tint(ax, w1, w2, w0, color=A_C, alpha=0.22):
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (w1 * X + w2 * Y + w0 > 0).astype(float), levels=[0.5, 1.5], colors=[color], alpha=alpha, zorder=1)

def line(ax, w1, w2, w0, color=LINE, lw=3, ls="-"):
    n = 400; xs = np.linspace(LO, HI, n)
    if abs(w2) > 1e-9:
        ys = -(w1 * xs + w0) / w2; m = (ys >= LO) & (ys <= HI); ax.plot(xs[m], ys[m], color=color, lw=lw, ls=ls, zorder=3)
    else:
        ax.plot([-w0 / w1] * 2, [LO, HI], color=color, lw=lw, ls=ls, zorder=3)

def ring(ax, xy, ms=34):
    ax.plot(*xy, "o", ms=ms, mfc="none", mec=RED, mew=3, zorder=6)

def cap(fig, w, h, x, ytop, text, color=None, fs=20):
    fig.text(x / w, 1 - ytop / h, text, color=color or TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold")

def f_three():
    w, h = 1000, 322
    fig = new_fig(w, h)
    for i, nm in enumerate(["OR", "AND", "XOR"]):
        ax = panel(fig, w, h, 25 + i * 330, 8, 280, 240); sq(ax)
        for p_ in PTS: pt(ax, p_, LAB[nm][p_])
        outs = " ".join("1" if LAB[nm][p_] == "A" else "0" for p_ in PTS)
        cap(fig, w, h, 165 + i * 330, 290, f"{nm}:  {outs}", fs=21)
    fig.text(0.5, 1 - 310 / h, "outputs for (0,0), (0,1), (1,0), (1,1); circle A = 1, square B = 0", color=MUT, fontsize=fpx(17), ha="center", va="center")
    save(fig, "lec05-kp01-three-labels")

def scores(ax, w1, w2, w0, fmt="{:+.1f}", dx=0.12, dy=0.14):
    for (a, b) in PTS:
        g = w1 * a + w2 * b + w0
        ax.text(a + dx * (1 if a == 0 else -1), b + dy * (1 if b == 0 else -1), fmt.format(g), color=TXT, fontsize=fpx(17), ha="center", va="center", zorder=7,
                bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.7))

def f_or_line():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    tint(ax, 1, 1, -0.5); line(ax, 1, 1, -0.5)
    for p_ in PTS: pt(ax, p_, LAB["OR"][p_])
    scores(ax, 1, 1, -0.5)
    ax.annotate("", xy=(0.62, 0.62), xytext=(0.36, 0.36), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.4), zorder=8)
    ax.text(0.66, 0.5, "$g>0$", color=A_C, fontsize=fpx(20), fontweight="bold", va="center", zorder=8)
    ax.text(0.02, 1.28, "$x_1+x_2=0.5$", color=LINE, fontsize=fpx(19), fontweight="bold", va="center")
    cap(fig, w, h, 285, 435, "OR: score $g=x_1+x_2-0.5$", fs=20)
    save(fig, "lec05-kp01-or-line")

def f_xor_check():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    tint(ax, 1, 1, -0.5); line(ax, 1, 1, -0.5)
    for p_ in PTS: pt(ax, p_, LAB["XOR"][p_])
    scores(ax, 1, 1, -0.5); ring(ax, (1, 1))
    ax.text(0.78, 1.28, "wrong", color=RED, fontsize=fpx(20), fontweight="bold", va="center")
    ax.text(0.02, 1.28, "predicted A here", color=A_C, fontsize=fpx(18), va="center")
    cap(fig, w, h, 285, 435, "XOR, same line: 3 of 4 correct", fs=20)
    save(fig, "lec05-kp01-xor-check")

def f_attempts():
    w, h = 1000, 342
    fig = new_fig(w, h)
    spec = [((1, 0, -0.5), "$x_1=0.5$", 2, [(0, 1), (1, 1)]), ((1, 1, -1.5), "$x_1+x_2=1.5$", 3, [(0, 1), (1, 0), (1, 1)]), ((1, -1, 0), "$x_1=x_2$", 1, [(0, 1)])]
    for i, ((w1, w2, w0), nm, errs, wrong) in enumerate(spec):
        ax = panel(fig, w, h, 25 + i * 330, 8, 280, 240); sq(ax)
        tint(ax, w1, w2, w0); line(ax, w1, w2, w0)
        for p_ in PTS: pt(ax, p_, LAB["XOR"][p_], ms=18)
        for p_ in wrong: ring(ax, p_, ms=30)
        cap(fig, w, h, 165 + i * 330, 290, f"{nm}:  errors {errs}", fs=20)
    fig.text(0.5, 1 - 322 / h, "blue tint = predicted A; red ring = wrong prediction", color=MUT, fontsize=fpx(17), ha="center", va="center")
    save(fig, "lec05-kp01-attempts")

def diag(ax, which):
    if "A" in which: ax.plot([0, 1], [1, 0], color=A_C, lw=4, zorder=3)
    if "B" in which: ax.plot([0, 1], [0, 1], color=B_C, lw=4, zorder=3)
    for p_ in PTS: pt(ax, p_, LAB["XOR"][p_], ms=22)
    ax.plot([0.5], [0.5], "*", ms=26, color=STAR, mec=BG, zorder=6)
    ax.text(0.58, 0.43, "M", color=TXT, fontsize=fpx(22), fontweight="bold", zorder=7)

def f_diag_a():
    w, h = 480, 470
    fig = new_fig(w, h); ax = panel(fig, w, h, 60, 25, 360, 320); sq(ax, ticks=False); diag(ax, "A")
    ax.text(0.06, 1.14, "$w_2+w_0$", color=TXT, fontsize=fpx(19), ha="left", va="center")
    ax.text(1.05, -0.12, "$w_1+w_0$", color=TXT, fontsize=fpx(19), ha="left", va="center")
    fig.text(0.5, 1 - 390 / h, "$g(M)=\\dfrac{(w_2+w_0)+(w_1+w_0)}{2}$", color=TXT, fontsize=fpx(22), ha="center", va="center")
    fig.text(0.5, 1 - 445 / h, "$M=(\\frac{1}{2},\\frac{1}{2})$, midpoint of the two A points", color=MUT, fontsize=fpx(18), ha="center", va="center")
    save(fig, "lec05-kp01-diag-a")

def f_diag_both():
    w, h = 480, 470
    fig = new_fig(w, h); ax = panel(fig, w, h, 60, 25, 360, 320); sq(ax, ticks=False); diag(ax, "AB")
    ax.text(0.06, 1.14, "$w_2+w_0$", color=TXT, fontsize=fpx(19), ha="left", va="center")
    ax.text(1.05, -0.12, "$w_1+w_0$", color=TXT, fontsize=fpx(19), ha="left", va="center")
    ax.text(0.06, -0.14, "$w_0$", color=TXT, fontsize=fpx(19), ha="left", va="center")
    ax.text(1.05, 1.12, "$w_1+w_2+w_0$", color=TXT, fontsize=fpx(19), ha="left", va="center")
    fig.text(0.5, 1 - 390 / h, "$g(M)=\\dfrac{w_1+w_2+2w_0}{2}$ for both diagonals", color=TXT, fontsize=fpx(21), ha="center", va="center")
    fig.text(0.5, 1 - 445 / h, "average of A scores  $=$  average of B scores", color=MUT, fontsize=fpx(18), ha="center", va="center")
    save(fig, "lec05-kp01-diag-both")

def f_best():
    w, h = 520, 452
    fig = new_fig(w, h); ax = panel(fig, w, h, 80, 20, 410, 320)
    steps = np.arange(0, 11); err = [3, 3, 2, 2, 1, 1, 1, 1, 1, 1, 1]
    ax.step(steps, err, where="post", color=LINE, lw=3.5)
    ax.axhline(0, color=RED, lw=2.5, ls=(0, (4, 3)))
    ax.set_xlim(0, 10); ax.set_ylim(-0.4, 3.6); ax.set_yticks([0, 1, 2, 3]); ax.set_xticks([0, 5, 10]); ax.tick_params(labelsize=fpx(17))
    ax.set_xlabel("training steps", fontsize=fpx(19)); ax.set_ylabel("errors", fontsize=fpx(19))
    ax.text(5.2, 0.28, "0 is never reached", color=RED, fontsize=fpx(18), ha="center")
    ax.text(7.2, 1.38, "best linear line: 1 error", color=LINE, fontsize=fpx(18), ha="center")
    fig.text(0.5, 1 - 432 / h, "schematic, not an experiment", color=MUT, fontsize=fpx(17), ha="center", va="center")
    save(fig, "lec05-kp01-best")

def f_strip():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs); S = X + Y
    ax.contourf(X, Y, ((S > 0.5) & (S <= 1.5)).astype(float), levels=[0.5, 1.5], colors=[A_C], alpha=0.25, zorder=1)
    line(ax, 1, 1, -0.5); line(ax, 1, 1, -1.5)
    for p_ in PTS: pt(ax, p_, LAB["XOR"][p_])
    ax.text(-0.38, -0.3, "$x_1+x_2=0.5$", color=LINE, fontsize=fpx(18), fontweight="bold", va="center")
    ax.text(0.55, 1.3, "$x_1+x_2=1.5$", color=LINE, fontsize=fpx(18), fontweight="bold", va="center")
    cap(fig, w, h, 285, 435, "A lies between the two lines", fs=20)
    save(fig, "lec05-kp01-strip")

def f_and_xor():
    w, h = 720, 352
    fig = new_fig(w, h)
    for i, nm in enumerate(["AND", "XOR"]):
        ax = panel(fig, w, h, 30 + i * 350, 10, 300, 255); sq(ax)
        tint(ax, 1, 1, -1.5); line(ax, 1, 1, -1.5)
        for p_ in PTS: pt(ax, p_, LAB[nm][p_], ms=19)
        cap(fig, w, h, 180 + i * 350, 300, nm, fs=21)
    fig.text(0.5, 1 - 336 / h, "line $x_1+x_2=1.5$; blue tint = predicted A", color=MUT, fontsize=fpx(17), ha="center", va="center")
    save(fig, "lec05-kp01-and-xor")

def f_and_xor_s():
    w, h = 480, 330
    fig = new_fig(w, h)
    for i, nm in enumerate(["AND", "XOR"]):
        ax = panel(fig, w, h, 15 + i * 235, 8, 210, 200); sq(ax)
        tint(ax, 1, 1, -1.5); line(ax, 1, 1, -1.5)
        for p_ in PTS: pt(ax, p_, LAB[nm][p_], ms=16)
        wrong = [p_ for p_ in PTS if (p_[0] + p_[1] - 1.5 > 0) != (LAB[nm][p_] == "A")]
        for p_ in wrong: ring(ax, p_, ms=26)
        cap(fig, w, h, 120 + i * 235, 250, f"{nm}: errors {len(wrong)}", fs=20)
    fig.text(0.5, 1 - 292 / h, "g = x1 + x2 - 1.5;  g > 0: blue tint", color=MUT, fontsize=fpx(17), ha="center", va="center")
    save(fig, "lec05-kp01-and-xor-s")

def f_ties():
    w, h = 480, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 60, 15, 390, 350); sq(ax)
    line(ax, 1, -1, 0)
    for p_ in PTS: pt(ax, p_, LAB["XOR"][p_])
    for p_ in [(0, 0), (1, 1)]:
        ax.plot(*p_, "o", ms=34, mfc="none", mec=STAR, mew=2.5, zorder=6)
    ax.text(0.5, -0.3, "$g=0$ on the line: predict B", color=TXT, fontsize=fpx(19), ha="center", va="center")
    ax.text(0.02, 1.28, "$x_1=x_2$", color=LINE, fontsize=fpx(19), fontweight="bold", va="center")
    cap(fig, w, h, 255, 410, "points on the boundary", fs=20)
    save(fig, "lec05-kp01-ties")

if __name__ == "__main__":
    for f in [f_three, f_or_line, f_xor_check, f_attempts, f_diag_a, f_diag_both, f_best, f_strip, f_and_xor, f_and_xor_s, f_ties]:
        try: f()
        except Exception as e: print("FAILED", f.__name__, e)
