"""KP01 deck: XOR and the limit of one line. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp01"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:標籤": "term:Label", "term:互斥或": "term:XOR", "term:分數": "term:Score", "term:線性可分": "term:Linearly separable", "term:表達能力": "term:Representational capacity"})
from kp01_text import *

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    P = PAGES
    # ---- 1
    t = P[0]; p = newpage(u, *t["lab"], *t["title"])
    y = bridge(p, *t["bridge"])
    p.figure("lec05-kp01-three-labels", 80, y); y += 322 + 6
    ids = []
    for k, (key, zh, en_, c, x) in enumerate(t["cards"]):
        h = p.need_h(key, 118); ids.append(card(p, key, x, y, 372, h, zh, en_, c=c, size=22))
    step(p, *t["notes"])
    # ---- 2
    t = P[1]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure("lec05-kp01-or-line", 60, y)
    stack(p, 610, y, 610, t["cards"]); step(p, *t["notes"])
    # ---- 3
    t = P[2]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure("lec05-kp01-xor-check", 60, y); stack(p, 610, y, 610, t["cards"]); step(p, *t["notes"])
    # ---- 4
    t = P[3]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure("lec05-kp01-attempts", 80, y); y += 342 + 6
    stack(p, 60, y, 1160, t["cards"]); step(p, *t["notes"])
    # ---- 5, 6 (reveal)
    for i, fig in ((4, "lec05-kp01-diag-a"), (5, "lec05-kp01-diag-both")):
        t = P[i]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
        p.figure(fig, 60, y); _, ids = stack(p, 610, y, 610, t["cards"]); step(p, *t["notes"]); reveal(p, ids)
    # ---- 7, 8
    for i, fig in ((6, "lec05-kp01-best"), (7, "lec05-kp01-strip")):
        t = P[i]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
        p.figure(fig, 60, y); stack(p, 610, y, 610, t["cards"]); step(p, *t["notes"])
    # ---- 9 practice (fig + question + hint)
    t = P[8]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure("lec05-kp01-and-xor", 60, y); stack(p, 800, y, 420, t["cards"]); step(p, *t["notes"])
    # ---- 10 worked solution
    t = P[9]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure("lec05-kp01-and-xor-s", 60, y); _, ids = stack(p, 570, y, 650, t["cards"]); step(p, *t["notes"]); reveal(p, ids)
    # ---- 11 implementation and other practice
    t = P[10]; p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure("lec05-kp01-ties", 60, y); stack(p, 580, y, 640, t["cards"]); step(p, *t["notes"])
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
