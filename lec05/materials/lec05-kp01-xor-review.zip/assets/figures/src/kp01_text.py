from deckcommon import AUX, EDGE, MAIN, OK, REF, WARN, VIO, ROSE
UNIT_ZH, UNIT_EN = "XOR 與一條線的極限", "XOR and one line"
TITLE_ZH = "圖型識別 第四章 KP01：XOR 與一條線的極限（大三・自學）"
TITLE_EN = "Pattern Recognition, Chapter 4, KP01: XOR and the limit of one line (undergraduate, self-study)"
NOTE_ZH = "教材程度：大學三年級（undergrad）。主線 8 頁，另有 3 頁延伸（不計時）；自主學習用，中文版。依 CLARITY.md C12–C18 重做：術語先用白話說、標題講明白、頁與頁以疑問接力、空間內容每頁有圖。備註會隨檔案公開，不含學號、成績或考題。"
NOTE_EN = "Level: undergraduate (year 3). Main line 8 pages plus 3 extension pages (not timed). Self-study deck, English version. Rewritten under CLARITY.md C12 to C18: plain words before terms, titles that state the point, pages linked by questions, a figure on every spatial page. These notes are public with the file and contain no student IDs, grades or exam questions."

P = []
P.append(dict(
 lab=("同樣四點，三種標籤", "Same points, labels"),
 title=("同樣四個點，只換標籤：一條線還分得開嗎？", "Same four points, new labels: is one line enough?"),
 bridge=("上一章讓模型用一條線決定類別。這一章先不換演算法，只換四個點的標籤，看原來的模型還答不答得了。",
         "Chapter 3 let the model decide the class with one line. If only the labels of four points change, can it still answer?"),
 cards=[("term:標籤", "**標籤**：每個點要分到的類別：A（圓點，輸出 1）或 B（方點，輸出 0）。圖中四個點依序是 $(0,0),(0,1),(1,0),(1,1)$。", "**Label**: the class of a point: A (circle, output 1) or B (square, output 0). Points are ordered $(0,0),(0,1),(1,0),(1,1)$.", AUX, 60),
        ("term:互斥或", "**互斥或 XOR**：兩個輸入不同才輸出 1（A），相同輸出 0（B）。", "**XOR (exclusive or)**: output 1 (A) only when the two inputs differ.", EDGE, 454),
        ("q", "**今天要問**：OR、AND 看來能用一條線隔開，XOR 呢？", "**Today**: OR and AND look separable by one line. What about XOR?", MAIN, 848)],
 notes=("第三章我們用一條線決定類別。這一章先不換演算法，只換四個點的標籤。四個點是 (0,0)、(0,1)、(1,0)、(1,1)，兩個輸入各是 0 或 1。OR 是只要有一個輸入為 1 就輸出 1；AND 是兩個都為 1 才輸出 1；XOR 是兩個不同才輸出 1。圖上圓點 A 代表輸出 1，方點 B 代表輸出 0，座標相同，只有標籤不同。請學生先看 OR 與 AND：A、B 看起來能用一條線隔開；XOR 的兩個 A 在對角，不確定。接下來第二頁用分數把「一條線」說清楚。",
        "In Chapter 3 one line decided the class. Here we keep the model and change only the labels of four points: (0,0), (0,1), (1,0) and (1,1), whose two inputs are each 0 or 1. OR outputs 1 when at least one input is 1, AND when both are 1, and XOR when the two inputs differ. In the figure a circle A means output 1 and a square B means output 0; the positions are identical and only the labels change. Ask the students to look at OR and AND first: A and B seem separable by one line, while the two A points of XOR sit on a diagonal and we are not sure. Next, page 2 makes the idea of one line precise with a score.")))
P.append(dict(
 lab=("分數與預測規則", "Score and rule"),
 title=("每個點打一個分數，分數為正就判 A", "Give every point a score: positive means class A"),
 bridge=("OR 的 A 與 B 看起來能用一條線隔開。要怎麼確定？先替每個點打一個分數。", "A and B look separable by one line for OR. How can we be sure? First give every point a score."),
 cards=[("term:分數", "**分數與規則**：$g=w_1x_1+w_2x_2+w_0$，$w_1,w_2$ 是係數，$w_0$ 是常數項。$g>0$ 判 A，否則判 B；$g=0$ 就是圖上的線。",
         "**Score and rule**: $g=w_1x_1+w_2x_2+w_0$ with coefficients $w_1,w_2$ and a constant $w_0$. Class A if $g>0$, otherwise B; the line is $g=0$.", EDGE, 180),
        ("ex", "**OR 的例子**：$g=x_1+x_2-0.5$，四點的分數是 $-0.5,\\ 0.5,\\ 0.5,\\ 1.5$，後三個為正，判 A。",
         "**OR example**: $g=x_1+x_2-0.5$ gives the scores $-0.5, 0.5, 0.5, 1.5$; the last three are positive: class A.", REF, 118),
        ("term:線性可分", "**線性可分**：有一組係數，能把所有點都分對。OR 是。", "**Linearly separable**: some coefficients classify every point correctly. OR is.", OK, 118)],
 notes=("上一頁看到 OR 的 A 與 B 看起來能用一條線隔開，這一頁把「一條線」說成算式：每個點代入 g 得到一個分數，分數為正判 A，否則判 B，剛好等於 0 也判 B，不能看完真實標籤再改規則。w1、w2 是係數，w0 是常數項，會把線上下平移；g 等於 0 就是圖上的那條線。圖上的箭頭指向分數為正的一側。例子取 w1、w2 都是 1，w0 是 −0.5，四個點的分數是 −0.5、0.5、0.5、1.5，後三個為正，所以判 A，剛好是 OR。能找到一組係數把所有點分對，叫線性可分。接下來第三頁把同一條線拿去分 XOR。",
        "On the previous page OR looked separable by one line. Here we turn the line into a formula: substitute each point into g and read the sign; a positive score gives class A and anything else gives B, including exactly 0, and the tie rule must not depend on the true label. The coefficients w1 and w2 and the constant w0, which shifts the line, define the line g = 0 in the figure, and the arrow points to the positive side. With w1 = w2 = 1 and w0 = -0.5 the four scores are -0.5, 0.5, 0.5 and 1.5, so the last three points are class A, exactly OR. When some coefficients classify every point correctly we call the labelling linearly separable. Next, page 3 uses the same line on XOR.")))
P.append(dict(
 lab=("同一條線，XOR 錯 1 點", "Same line, XOR wrong"),
 title=("同一條線，OR 全對，XOR 錯 1 點", "The same line: OR all right, XOR one wrong"),
 bridge=("OR 的分數有正有負，一條線就分開了。把同一條線拿去分 XOR，會怎樣？", "OR is linearly separable with the line $g=0$ above. What happens if we use the same line on XOR?"),
 cards=[("tab", "**逐點代入 $g=x_1+x_2-0.5$**\n$(0,0)$：$g=-0.5$，判 B，真值 B ✓\n$(0,1)$：$g=0.5$，判 A，真值 A ✓\n$(1,0)$：$g=0.5$，判 A，真值 A ✓\n$(1,1)$：$g=1.5$，判 A，真值 B ✗",
         "**Substitute into $g=x_1+x_2-0.5$**\n$(0,0)$: $g=-0.5$, predict B, truth B ✓\n$(0,1)$: $g=0.5$, predict A, truth A ✓\n$(1,0)$: $g=0.5$, predict A, truth A ✓\n$(1,1)$: $g=1.5$, predict A, truth B ✗", REF, 186),
        ("res", "這些預測剛好和 OR 一樣，所以拿去分 XOR，錯 1 點：正確率 $3/4=75\\%$。這只是這一條線的結果。",
         "These predictions are exactly those of OR, so on XOR one point is wrong: accuracy $3/4=75\\%$. This is the result of one line only.", WARN, 118)],
 notes=("上一頁定好了規則，這一頁把同一條線拿去分 XOR：逐點代入同一個 g，前三個點的分數和 OR 一樣，右上角 (1,1) 分數是 1.5，判 A，但它在 XOR 裡是 B，所以錯。圖上藍色是判 A 的那一側，紅圈是錯的點。請學生注意：預測是先算分數、再套門檻得到的，不能直接把真值抄進預測欄。四點對三點，正確率 75%，驗算 75% 加 25% 等於 100%。這只是這一條線的結果，還不能說所有線都不行。接下來第四頁換別條線試試。",
        "The rule is fixed on the previous page, so here we apply the same line to XOR. Substituting each point into the same g, the first three scores equal those of OR, but the point (1,1) has score 1.5 and is predicted A while it is class B in XOR. In the figure the blue side is predicted A and the red ring marks the mistake. Remind the students that predictions come from computing the score and applying the threshold, never from copying the labels. Three of four points are right, an accuracy of 75%, and 75% plus 25% is 100%. This is the result of one line only and does not yet rule out other lines. Next, page 4 tries other lines.")))
P.append(dict(
 lab=("再試三條線", "Three more lines"),
 title=("換三條線看看：分別錯 2、3、1 點", "Three other lines: 2, 3 and 1 errors"),
 bridge=("同一條線分 XOR 錯了 1 點。換別的線，會不會全對？", "The same line misses one XOR point. Would other lines get all four?"),
 cards=[("c", "**試錯不是證明**：沒試到的線呢？要怎麼一次排除所有的線？", "**Trying is not proving.** How can we rule out every line at once?", WARN, 86)],
 notes=("上一頁同一條線錯了 1 點，這一頁換三條線：x1=0.5 錯 2 點，x1+x2=1.5 錯 3 點，x1=x2 錯 1 點，其中 x1=x2 上的兩個點 (0,0) 與 (1,1) 分數是 0，依規則判 B。第二條線只切下右上角，但那一側判 A，所以錯的是兩個 A 加一個 B；不能因為也只切下一個角就說它只錯 1 點。圖上紅圈是錯的點。這三條線都有錯，卻不能證明所有線都有錯，因為沒試到的線太多。接下來第五頁用一個不用試的辦法：假設有一組係數全對，看它必須滿足什麼。",
        "The previous page had one error, so here we try three other lines: x1=0.5 has 2 errors, x1+x2=1.5 has 3 and x1=x2 has 1. On the line x1=x2 the points (0,0) and (1,1) have score 0 and are predicted B by the tie rule. The second line cuts off only the upper-right corner, but that side is predicted A, so the errors are two A points and one B point; cutting off one corner does not mean one error. The red rings mark the mistakes. All three lines fail, yet that proves nothing about the lines we did not try. Next, page 5 uses a method that needs no trying: assume some coefficients are all correct and see what they must satisfy.")))
P.append(dict(
 lab=("兩個 A 相加為正", "A sum is positive"),
 title=("兩個 A 點的分數相加，一定是正的", "The two A scores must add up to a positive number"),
 bridge=("試再多條線也不是證明。要排除所有線，先假設有一組 $w_1,w_2,w_0$ 全部分對，看它必須滿足什麼？", "Trying is not proving. To rule out every line at once, assume some $w_1,w_2,w_0$ classify all four points correctly: what must they satisfy?"),
 cards=[("s1", "**① 兩個 A 點都要為正**：$g(0,1)=w_2+w_0>0$，$g(1,0)=w_1+w_0>0$", "**① Both A points need positive scores**: $g(0,1)=w_2+w_0>0$ and $g(1,0)=w_1+w_0>0$.", REF, 118),
        ("s2", "**② 兩式相加**：$(w_2+w_0)+(w_1+w_0)=w_1+w_2+2w_0>0$（正數加正數仍為正）", "**② Add them**: $(w_2+w_0)+(w_1+w_0)=w_1+w_2+2w_0>0$, since positive plus positive is positive.", REF, 118),
        ("s3", "**③ 幾何意思**：因為 $g$ 是 $x_1,x_2$ 的線性式，兩個 A 點中點 $M=(\\tfrac12,\\tfrac12)$ 的分數 $g(M)=\\tfrac12[g(0,1)+g(1,0)]$ 是兩端分數的平均，所以也是正的。", "**③ Geometric meaning**: because $g$ is linear in $x_1,x_2$, the score at the midpoint $M=(\\frac12,\\frac12)$ of the two A points is the average of the two scores, $g(M)=\\tfrac12[g(0,1)+g(1,0)]$, so it is positive.", AUX, 118)],
 notes=("上一頁說試再多線也不是證明，這一頁換一個不用試的辦法：假設存在一組 w1、w2、w0 能把 XOR 四點全部分對，把它必須滿足的條件寫出來。先看兩個 A 點 (0,1) 與 (1,0)：它們的分數 w2+w0 與 w1+w0 都必須為正，相加得 w1+w2+2w0 大於 0。幾何上，兩個 A 點連成一條對角線，中點 M 是 (1/2,1/2)；g 是線性的，所以 g(M) 剛好是兩個分數的平均，也是正的。請學生指出式子裡每一項對應圖上哪個點。接下來第六頁看另外兩個 B 點。",
        "The previous page said that more trials prove nothing, so here we use a method without trying: assume some w1, w2, w0 classify all four XOR points correctly and write down what they must satisfy. For the A points (0,1) and (1,0) the scores w2+w0 and w1+w0 must both be positive, so their sum w1+w2+2w0 is greater than 0. Geometrically the two A points form a diagonal whose midpoint is M = (1/2, 1/2); because g is linear, g(M) is exactly the average of the two scores and is positive too. Ask the students which point of the figure each term belongs to. Next, page 6 looks at the two B points.")))
P.append(dict(
 lab=("B 相加卻不大於 0", "B sum is nonpositive"),
 title=("兩個 B 點相加卻不大於 0，同一個式子矛盾", "The B scores add up to at most 0: a contradiction"),
 bridge=("兩個 A 點的分數和必為正。那兩個 B 點的分數和呢？", "The two A scores must sum to a positive number. What about the two B scores?"),
 cards=[("s1", "**① 兩個 B 點都要不大於 0**：$g(0,0)=w_0\\le0$，$g(1,1)=w_1+w_2+w_0\\le0$", "**① Both B points need nonpositive scores**: $g(0,0)=w_0\\le0$ and $g(1,1)=w_1+w_2+w_0\\le0$.", MAIN, 118),
        ("s2", "**② 兩式相加**：$w_0+(w_1+w_2+w_0)=w_1+w_2+2w_0\\le0$", "**② Add them**: $w_0+(w_1+w_2+w_0)=w_1+w_2+2w_0\\le0$.", MAIN, 118),
        ("s3", "**③ 矛盾**：同一個式子，A 要求 $>0$，B 要求 $\\le0$。兩條對角線共用中點 $M$，$g(M)$ 不可能兩者都是。", "**③ Contradiction**: the same expression must be $>0$ (A) and $\\le0$ (B). The diagonals share the midpoint $M$, so $g(M)$ cannot be both.", WARN, 148)],
 notes=("上一頁得到兩個 A 點的分數和 w1+w2+2w0 必須大於 0，這一頁看兩個 B 點 (0,0) 與 (1,1)：分數 w0 與 w1+w2+w0 都必須不大於 0，相加是同一個式子 w1+w2+2w0，且必須不大於 0。同一個式子既要大於 0 又要不大於 0，所以不存在任何一組係數，這就證明了所有線都做不到。圖上兩條對角線共用中點 M，g(M) 是 A 兩端分數的平均，也是 B 兩端分數的平均，不可能同時為正又不大於 0。這是這個 KP 的轉折，後面第三個 KP 還會再用到這張圖。接下來第七頁問：那多訓練有用嗎？",
        "The previous page showed that the two A scores sum to w1+w2+2w0 > 0. Here the B points (0,0) and (1,1) have scores w0 and w1+w2+w0, both at most 0, and their sum is the very same expression, which must therefore be at most 0. One expression cannot be both greater than 0 and at most 0, so no coefficients exist and every line fails. In the figure both diagonals meet at the midpoint M, so g(M) would be the average of the A scores and also the average of the B scores, impossible at once. This is the turning point of the KP, and the third KP reuses this figure. Next, page 7 asks whether more training helps.")))
P.append(dict(
 lab=("訓練也補不了", "Training cannot fix"),
 title=("不管怎麼訓練，一條線都無法把 XOR 全分對", "However it is trained, no single line classifies XOR perfectly"),
 bridge=("同一個式子不能既大於 0 又不大於 0，沒有任何係數能全對。那多訓練有用嗎？多跑幾輪、換個學習率（每次改係數的步子大小）呢？", "The same expression cannot be both positive and at most 0, so no coefficients work. Does more training help, with more rounds or another learning rate (the step size of each update)?"),
 cards=[("c1", "**訓練做什麼**：訓練就是自動調整係數，在這一類線（所有係數的組合）裡找錯誤少的線。多跑幾輪、換學習率可能讓錯 3 點降成錯 1 點，但不保證找得到最好的一條。", "**What training does**: it adjusts the coefficients to look for a line with few errors in one family ($w_1,w_2,w_0$). More rounds or another learning rate may bring 3 errors down to 1, with no guarantee of finding the best line.", REF, 180),
        ("c2", "**訓練做不到什麼**：這一類線裡沒有全對的答案，不論訓練得多好，最少仍錯 1 點。", "**What it cannot do**: no line in this family gets all four points right; however well it is trained, the best still has 1 error.", WARN, 118),
        ("term:表達能力", "**表達能力**：這一類邊界能不能表示出答案；和訓練找不找得到答案是兩件事。", "**Representational capacity**: whether this family of boundaries can express the answer at all, which is separate from whether training finds it.", OK, 148)],
 notes=("上一頁證明任何係數都不可能全對，這一頁回應常見的迷思：多跑幾輪、調小學習率或重新初始化，是不是就能全對？這些都只是在同一類直線裡找更好的參數，可以把錯 3 點降成錯 1 點，但是這一類直線裡沒有全對的答案，最低錯誤是 1 點，不是 0。圖是示意，不是真實實驗。訓練有沒有找到最好的線，和最好的線夠不夠用，是兩個不同的問題；後者叫表達能力。接下來第八頁問：既然要改，改什麼？",
        "The previous page proved that no coefficients are all correct; this page answers a common misconception: do more iterations, a smaller learning rate or a new initialization eventually solve XOR? They only search the same family of lines, and can turn 3 errors into 1, but that family has no perfect answer, so the lowest error is 1, not 0. The figure is a schematic, not a real experiment. Whether training finds the best line and whether the best line is good enough are different questions; the second is representational capacity. Next, page 8 asks what should change.")))
P.append(dict(
 lab=("兩條線夾出一條帶", "Two lines, one strip"),
 title=("要改的是邊界的組合：兩條線夾出一條帶", "Change the boundaries: two lines make a strip"),
 bridge=("訓練只能降低錯誤，最好的線也錯 1 點。那要改什麼？", "What training does is lower the error, yet the best line still errs once. So what must change?"),
 cards=[("c1", "**想法**：令 $s=x_1+x_2$。四個點的 $s$ 只會是 0、1、2，A 恰好是 $s=1$。這裡的 0.5 與 1.5，就是前面試過的兩條線。", "**Idea**: let $s=x_1+x_2$. The four points have $s=0,1,2$, and A is exactly $s=1$. The thresholds 0.5 and 1.5 are the two lines tried earlier.", REF, 118),
        ("c2", "**兩個判斷**：$s>0.5$ 而且 $s\\le1.5$，A 就落在兩條線中間。用預測 $\\hat y$（1 代表 A）寫成：$\\hat y=1\\iff 0.5<s\\le1.5$。", "**Two decisions**: $s>0.5$ and $s\\le1.5$ puts A between the two lines. With the prediction $\\hat y$ (1 means A): $\\hat y=1\\iff 0.5<s\\le1.5$.", AUX, 148),
        ("c3", "**留下的問題**：兩個判斷要怎麼做成一個小模型？（下一個 KP）", "**Next**: how can a small model carry out these two decisions? (the next KP)", MAIN, 118)],
 notes=("上一頁說多訓練救不了，所以要改的是模型能用的邊界組合，不是換一組舊係數。令 s 等於 x1+x2，四個點的 s 只會是 0、1、2，A 恰好是 s 等於 1，所以可以用兩個判斷：s 大於 0.5，而且 s 不大於 1.5。圖上兩條平行線夾出一條斜的帶，兩個 A 在帶內，兩個 B 在帶外。這只驗證了四個布林點，沒有規定連續平面上 XOR 的唯一延伸。要把『兩個判斷都成立』做成網路，就是下一個 KP 的隱藏層。這一頁結束主線，後面三頁是延伸的練習。",
        "The previous page said training cannot help, so what must change is the combination of boundaries a model may use, not another choice of old coefficients. Let s = x1+x2: the four points have s = 0, 1 or 2 and A is exactly s = 1, so two decisions suffice: s greater than 0.5 and s at most 1.5. In the figure two parallel lines enclose a slanted strip, with the two A points inside and the two B points outside. This verifies only the four Boolean points and does not define a unique extension of XOR to the continuous plane. Making both decisions true at once is what the hidden layer of the next KP does. The main line ends here; the next three pages are extension practice.")))
P.append(dict(
 lab=("延伸:練習一", "Extension: practice"),
 title=("延伸：練習，用 x1+x2−1.5 分 AND 與 XOR", "Extension: practice with the line x1+x2=1.5"),
 bridge=("兩條線夾出一條帶才分得開 XOR。回頭再驗證只用一條線 $g=x_1+x_2-1.5$，AND 與 XOR 會怎樣？", "Two lines make a strip that separates XOR. Check once more with a single line $g=x_1+x_2-1.5$: what happens on AND and on XOR?"),
 cards=[("q1", "**題 1**：用 $g=x_1+x_2-1.5$ 算四個點，分別核對 AND 與 XOR。", "**Question 1**: compute the four scores of $g=x_1+x_2-1.5$ and check AND and XOR separately.", REF, 118),
        ("h1", "**提示**：先算分數，再用同一個 $g>0$ 規則，最後才對照兩組真值。", "**Hint**: compute the scores first, apply the same rule $g>0$, and only then compare the two sets of labels.", AUX, 118)],
 notes=("上一頁結束了主線，前面八頁證明了一條線分不開 XOR，這一頁讓學生自己再算一次。題 1 用另一條線 g 等於 x1+x2−1.5，分別核對 AND 與 XOR。提示是先算四個分數，再用同一個 g 大於 0 的規則得到預測，最後才對照兩組真值，不要先看答案再填預測。圖上左邊是 AND，右邊是 XOR，藍色是判 A 的一側，紅圈是錯的點，請先自己算，再翻下一頁對照解題示範。",
        "On the previous page the main line ended after eight pages that proved one line cannot separate XOR; here students compute once more themselves. Question 1 uses another line g = x1+x2-1.5 and asks them to check AND and XOR separately. The hint is to compute the four scores, apply the same rule g > 0 to get the predictions, and only then compare the two sets of labels, never fill the predictions from the answers. In the figure AND is on the left and XOR on the right, blue marks the predicted A side and red rings mark the mistakes. Let them calculate first and then compare with the worked solution on the next page.")))
P.append(dict(
 lab=("延伸:解題示範", "Extension: solution"),
 title=("延伸：題 1 的解題示範", "Extension: worked solution of question 1"),
 bridge=("練習一要算 $g=x_1+x_2-1.5$ 的四個分數，分別核對 AND 與 XOR。答案是什麼？", "Practice 1 asked for the four scores of $g=x_1+x_2-1.5$ on AND and XOR. What is the answer?"),
 cards=[("a1", "**① 符號式**：$g=x_1+x_2-1.5$，$g>0$ 判 A。", "**① Formula**: $g=x_1+x_2-1.5$, class A if $g>0$.", REF, 86),
        ("a2", "**② 代入四點**：$(0,0),(0,1),(1,0),(1,1)$ 的分數依序是 $-1.5,\\ -0.5,\\ -0.5,\\ 0.5$。", "**② Substitute**: the scores of $(0,0),(0,1),(1,0),(1,1)$ are $-1.5, -0.5, -0.5, 0.5$.", REF, 118),
        ("a3", "**③ 預測**：只有 $(1,1)$ 為正，預測 B、B、B、A。", "**③ Predictions**: only $(1,1)$ is positive, so B, B, B, A.", REF, 86),
        ("a4", "**④ 核對**：AND 的真值是 B、B、B、A，全對；XOR 的 $(0,1),(1,0)$ 被判 B、$(1,1)$ 被判 A，錯 3 點。", "**④ Check**: AND is B, B, B, A: all correct; for XOR, $(0,1)$ and $(1,0)$ are predicted B and $(1,1)$ A: 3 errors.", WARN, 148)],
 notes=("上一頁出了題 1，這一頁是它的完整解題示範：先寫符號式，再代入四個點得到分數 −1.5、−0.5、−0.5、0.5，只有 (1,1) 為正，所以預測 B、B、B、A。AND 的真值剛好也是 B、B、B、A，所以全對；XOR 的 (0,1) 與 (1,0) 是 A 卻被判 B，(1,1) 是 B 卻被判 A，錯 3 點。這和第四頁的第二條線是同一條，答案一致。同一條線在 AND 全對、在 XOR 卻錯 3 點，再一次說明問題在標籤的配置，不在座標。接下來第十一頁是實作提醒與另外兩題的提示。",
        "The previous page posed question 1 and this page is its full worked solution: write the formula, substitute the four points to get -1.5, -0.5, -0.5 and 0.5, and only (1,1) is positive, so the predictions are B, B, B, A. AND has exactly these labels, so it is all correct; for XOR the points (0,1) and (1,0) are class A but predicted B and (1,1) is class B but predicted A, 3 errors. This is the second line of page 4, so the answers agree. The same line is perfect on AND yet makes 3 errors on XOR, which shows that the trouble lies in the arrangement of labels, not the coordinates. Next, page 11 gives an implementation reminder and hints for two more questions.")))
P.append(dict(
 lab=("延伸:實作與其他練習", "Extension: code"),
 title=("延伸：實作提醒與另外兩題", "Extension: implementation note and two more questions"),
 bridge=("解題示範算出四個分數與預測，分數為 0 的點要判 B。寫成程式時，這個邊界要怎麼處理？另外兩題請自己試。", "The four scores gave predictions for AND and XOR. In code, how is a point with score 0 handled? Try two more questions yourself."),
 cards=[("imp", "**實作**：預測用「score > 0」產生。邊界上的點分數為 0，判 B，例如 $g=x_1-x_2$ 的線上的 $(0,0)$、$(1,1)$；程式裡的不等號要和這裡一致。", "**Code**: predict with 'score > 0'. Points on the boundary have score 0 and are class B, for example $(0,0)$ and $(1,1)$ on the line of $g=x_1-x_2$; the inequality in code must match this text.", AUX, 148),
        ("q2", "**題 2**：XOR 失敗是樣本少、雜訊、學習率，還是邊界形狀受限？提示：矛盾排除了哪一項？", "**Question 2**: is XOR failing because of few samples, noise, learning rate, or the restricted boundary shape? Hint: which does the contradiction rule out?", REF, 148),
        ("q3", "**題 3**：OR、XOR、XNOR 哪個能用一條線分開？XNOR：輸入相同輸出 1。提示：先畫標籤。", "**Question 3**: which of OR, XOR and XNOR is separable by one line? XNOR outputs 1 when the inputs match. Hint: the positions stay the same; draw the labels first.", REF, 148)],
 notes=("上一頁示範了題 1，這一頁先提醒實作：程式用「score 大於 0」產生預測，邊界上的點分數是 0，判 B；圖上 x1 等於 x2 這條線上的 (0,0) 與 (1,1) 就是例子。測試一定要包含邊界上的點，免得程式用大於等於而文字用大於。這裡的半整數可以精確表示，一般實數資料還要注意浮點誤差。再附兩題只給提示：題 2 問 XOR 失敗的原因，答案是邊界形狀受限，不是樣本、雜訊或學習率；題 3 問 OR、XOR、XNOR 哪個可分，答案要先畫標籤再判斷。這是 KP01 的最後一頁，接下來的下一個 KP 回答兩個判斷如何用神經元做出來。",
        "The previous page worked out question 1; this page first gives an implementation reminder: code produces predictions with score > 0, and a point on the boundary has score 0 and is class B; in the figure the points (0,0) and (1,1) on the line x1 = x2 are examples. Tests must include boundary points so that code and text use the same inequality. The half-integers here are exactly representable, while general real data need care with floating-point errors. Two more questions come with hints only: question 2 asks why XOR fails, and the answer is the restricted boundary shape, not sample size, noise or learning rate; question 3 asks which of OR, XOR and XNOR is separable, and you must draw the labels first. This is the last page of KP01; the next KP shows how neurons carry out the two decisions.")))
PAGES = P
