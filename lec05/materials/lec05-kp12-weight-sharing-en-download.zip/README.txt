KP12 Weight sharing and transformation invariance

Extract first and open index.html. PDF: pdf/. Offline reading: reading/. Offline slides and editable JBD: slides/. Markdown: lectures/. This is a self-study review draft.
Use arrow keys for slides; N opens public speaker notes. No audio was created. Keep extracted directories together. No server or network is required.
