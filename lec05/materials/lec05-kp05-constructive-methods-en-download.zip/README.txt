Pattern Recognition, Chapter 4, KP05: Growing a network from training points (English version)

Slides: slides/lec05-kp05-constructive-methods-en.html (offline web page, open in a browser); slides/lec05-kp05-constructive-methods-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp05-constructive-methods-en-lecture.pdf (PDF), lec05-kp05-constructive-methods-en-reading.html (offline web page), lectures/lec05-kp05-constructive-methods-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
