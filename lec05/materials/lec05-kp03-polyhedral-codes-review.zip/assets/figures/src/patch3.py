s=open('deck_kp03.py',encoding='utf-8').read()
def rep(a,b):
    global s
    assert a in s, a[:70]
    s=s.replace(a,b,1)
rep('T("**輸出分數**：位元 $y_1,y_2,y_3$ 各乘一個票數 $a_i$，加起始分 $a_0$：$q=a_1y_1+a_2y_2+a_3y_3+a_0$。$q>0$ 判類別 A，否則判類別 B。", en("Score q: each bit times a vote a_i plus a start a0; q > 0 means class A, else class B."))','T("**輸出分數**：$q=a_1y_1+a_2y_2+a_3y_3+a_0$，$y_i$ 是位元，$a_i$ 是票數，$a_0$ 是起始分。$q>0$ 判 A 類，否則 B 類。", en("If q > 0 the point is class A, otherwise class B."))')
rep('en("A vertex is a corner; the code gives its coordinates.")','en("Vertex: a corner of the cube, named by its code.")')
rep('T("A 區的 $P(-0.15,-1)$ 與 $Q(-0.15,2)$，連線卻穿過 B 塊的 $R$：A 區**不是凸的**。所以最後一層能切出有缺口的區域。", en("The segment PQ crosses B at R, so region A is not convex: the output layer can carve a region with a notch."))','T("$P$、$Q$ 都在 A 區，連線卻穿過 B 塊的 $R$：A 區**不是凸的**。最後一層能切出有缺口的區域。", en("Segment PQ crosses B at R, so A is not convex: the output layer can carve a notch."))')
rep('"只看底面 $y_3=0$：四個角都是實際碼，A 在一條對角、B 在另一條對角，和 KP01 學過的 XOR 一樣。這組標籤**不可分**：它就是一個**反例**。"','"只看底面 $y_3=0$：四個角都是實際碼，A 在一條對角、B 在另一條對角，和 KP01 的 XOR 一樣：這組標籤**不可分**（**反例**）。"')
rep('en("Its four corners are realized codes and form an XOR pattern, so no plane separates A from B: a counterexample.")','en("Its four realized corners form an XOR pattern, so no plane separates A from B.")')
rep('T("**兩層網路**＝一排線（隱藏層）＋一個輸出平面。被擋住的只是這組線加這一刀，換一組線，反例就變。", en("Two layers: a row of lines and one output plane; the limit belongs to these lines."))','T("**兩層網路**＝一排線（隱藏層）＋一個輸出平面。切不開，只是這組線的限制。", en("Two layers: a row of lines plus an output plane."))')
rep('T("**補救**：任何一個角都能單獨切下來（右圖切下 110）。對 000、110、111 各切一刀，再併起來，就是 A。", en("Any one corner can be cut off; cut 000, 110 and 111 separately and merge them to get A."))','T("**補救**：任何一個角都能單獨切下來（右圖切下 110）。三個目標角各切一刀再併起來，就是 A。", en("Cut 000, 110 and 111 one by one and merge them to get A."))')
open('deck_kp03.py','w',encoding='utf-8').write(s)
