#!/bin/bash
# build the KP03 review package and copy deliverables into the repo draft area (lec05/materials)
set -e
W=$(cd "$(dirname "$0")" && pwd); R=/home/user/pr-2026-fall; N=lec05-kp03-polyhedral-codes
export KATEX_DIR=$R/.agents/skills/slides-to-html/node_modules/katex
cd $W
python3 -W ignore figs.py >/dev/null; LIGHT=1 python3 -W ignore figs.py >/dev/null
rm -rf assets/figures_png; mkdir -p assets/figures_png; cp assets/light/*.png assets/figures_png/
node md2html.mjs lectures/$N.md reading.html assets/figures_png
python3 - <<'PY'
from playwright.sync_api import sync_playwright
import os
W=os.getcwd()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); pg.goto("file://"+W+"/reading.html")
    pg.pdf(path="lecture.pdf", format="A4", margin={"top":"15mm","bottom":"15mm","left":"15mm","right":"15mm"}, print_background=True); b.close()
PY
rm -rf html; mkdir html; cp draft.jbd.json $N.jbd.json
node $R/.agents/skills/slides-to-html/scripts/jbd_to_html.mjs --out-dir html --strict $N.jbd.json
python3 -W ignore $R/.agents/skills/view-from-text/tools/audit_deck.py $N.jbd.json --lecture lectures/$N.md --source lectures/$N.md --speaker-notes --level undergrad --narrative --terms terms.json --minutes 36 --kps 1 --outline > audit.txt 2>&1 || true
python3 $R/scripts/check_slides.py $N.jbd.json > structure.txt 2>&1 || true
python3 -W ignore $R/.agents/skills/textbook-lecture-notes/scripts/audit_lecture.py lectures/$N.md > lecture-audit.txt 2>&1 || true
rm -rf zip; mkdir -p zip/lectures zip/assets/figures/src zip/slides zip/.agents
cp lectures/$N.md zip/lectures/; cp assets/figures_png/*.png zip/assets/figures/; cp assets/figures/*.svg zip/assets/figures/
cp figs.py zip/assets/figures/src/lec05-kp03-figures.py; cp deck_kp03.py terms.json md2html.mjs zip/assets/figures/src/
cp $N.jbd.json zip/slides/; cp html/$N.html zip/slides/; cp audit.txt structure.txt lecture-audit.txt zip/
[ -f COLD_READER.md ] && cp COLD_READER.md zip/
cp $R/.agents/skills/view-from-text/jbd_figure.py zip/assets/figures/src/
(cd zip && rm -f ../review.zip && zip -qr ../review.zip .)
echo packed; ls -la review.zip reading.html lecture.pdf html/$N.html
