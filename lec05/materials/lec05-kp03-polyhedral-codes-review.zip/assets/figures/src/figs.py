"""KP03 figures (dark skin). All coordinates computed from the lecture's three lines g1=x1, g2=x2, g3=-x1+x2-1."""
import itertools, os, sys
import numpy as np
sys.path.insert(0, "/home/user/pr-2026-fall/.agents/skills/view-from-text")
from jbd_figure import *
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle, Rectangle, ConnectionPatch, FancyArrowPatch

use_jbd_style(18)
LIGHT = os.environ.get("LIGHT") == "1"
BG, CUBE_EDGE, STAR = ("#ffffff", "#4a443b", "#1c1712") if LIGHT else ("#1c1712", "#cfc8bb", "#ffffff")
if LIGHT:
    plt.rcParams.update({"text.color": BG, "axes.labelcolor": BG, "axes.edgecolor": "#6b645a", "xtick.color": "#4a443b", "ytick.color": "#4a443b"})
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures")
TXT, MUT = (("#1c1712", "#6b645a") if LIGHT else (PALETTE["text"], PALETTE["muted"]))
A_C, B_C = "#6a9fd6", "#d97757"          # class A (circle) blue, class B (square) orange
LINE = "#e0995f"
TINT = {"000": "#5fb8a8", "001": "#a98bd0", "010": "#b9a35e", "011": "#d08bb0",
        "100": "#7dbb8c", "101": "#888888", "110": "#8fa7b8", "111": "#c9a27a"}
CODES = ["".join(map(str, b)) for b in itertools.product([0, 1], repeat=3)]
A1 = {"000", "001", "011"}                 # first labelling (succeeds)
A2 = {"000", "110", "111"}                 # second labelling (fails)
REAL = [c for c in CODES if c != "101"]
Q = lambda y: -y[0] - y[1] + y[2] + 0.5

def code_of(x1, x2):
    return "".join("1" if g > 0 else "0" for g in (x1, x2, -x1 + x2 - 1))

def fpx(px): return px_to_pt(px)

def save(fig, name):
    CUR[0] = name
    if LIGHT:
        bad = check_not_clipped(fig)
        if bad: raise ValueError("; ".join(bad))
        os.makedirs(os.path.join(os.path.dirname(OUT), "light"), exist_ok=True)
        fig.savefig(os.path.join(os.path.dirname(OUT), "light", name + ".png"), dpi=150, facecolor="white", transparent=False)
        plt.close(fig); print("light", name); return
    svg = svg_text_checked(fig)
    open(os.path.join(OUT, name + ".svg"), "w", encoding="utf-8").write(svg)
    print(name, len(svg) // 1024, "KB")

CUR = [""]
def svg_text_checked(fig):
    bad = check_not_clipped(fig)
    if bad: raise ValueError("; ".join(bad))
    import io
    fig.savefig(os.path.join(os.path.dirname(OUT), "..", "prevfig", CUR[0] + ".png"), dpi=100, facecolor=BG, transparent=False)
    svg = svg_text(fig)
    pr = check_svg(svg)
    if pr: raise ValueError("; ".join(pr))
    return svg

def new_fig(w, h):
    fig = plt.figure(figsize=(w / 100, h / 100))
    return fig

def panel(fig, w, h, x, y, pw, ph):
    """axes at pixel box (x,y from top-left)."""
    return fig.add_axes([x / w, 1 - (y + ph) / h, pw / w, ph / h])

# ------------------------------------------------------------------ plane
LIM = 2.6
def draw_plane(ax, tint=True, classes=None, show_codes=True, show_lines=True, signs=True, lim=LIM, codefs=18, dashed_g3=False):
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_aspect("equal"); ax.axis("off")
    n = 400
    xs = np.linspace(-lim, lim, n); X, Y = np.meshgrid(xs, xs)
    code = (X > 0) * 4 + (Y > 0) * 2 + ((-X + Y - 1) > 0) * 1
    for k, c in enumerate(CODES):
        mask = (code == k).astype(float)
        if mask.sum() == 0: continue
        if classes is None: col, al = TINT[c], 0.40
        else: col, al = (A_C if c in classes else B_C), 0.55
        ax.contourf(X, Y, mask, levels=[0.5, 1.5], colors=[col], alpha=al, antialiased=True)
    ax.add_patch(Rectangle((-lim, -lim), 2 * lim, 2 * lim, fill=False, ec=MUT, lw=1.4))
    if show_lines:
        ax.plot([0, 0], [-lim, lim], color=LINE, lw=3)
        ax.plot([-lim, lim], [0, 0], color=LINE, lw=3)
        ax.plot([-lim, lim - 1], [-lim + 1, lim], color=LINE, lw=3, ls="--" if dashed_g3 else "-")
    if show_codes:
        pos = {"000": (-1.2, -1.1), "001": (-2.0, -0.3), "010": (-0.55, 0.2), "011": (-1.6, 1.5),
               "100": (1.6, -0.7), "110": (1.9, 0.5), "111": (0.4, 1.85)}
        for c, (px, py) in pos.items():
            ax.text(px, py, c, color=TXT, fontsize=fpx(codefs), ha="center", va="center", fontweight="bold")
    return ax

def line_labels(ax, fs=20):
    ax.text(0.12, 2.36, "$g_1=0$", color=LINE, fontsize=fpx(fs), ha="left", fontweight="bold")
    ax.text(2.45, -0.3, "$g_2=0$", color=LINE, fontsize=fpx(fs), ha="right")
    ax.text(-2.5, -2.3, "$g_3=0$", color=LINE, fontsize=fpx(fs), ha="left", rotation=0)

def plus_arrows(ax, fs=18):
    # '+' side of each line (score > 0)
    for (x, y, dx, dy) in [(0.0, -2.0, 0.55, 0), (-1.9, 0.0, 0, 0.55), (1.2, 2.2, -0.35, 0.35)]:
        pass
    ax.annotate("", xy=(0.75, -2.15), xytext=(0.05, -2.15), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(0.85, -2.15, "+", color=TXT, fontsize=fpx(fs), va="center", fontweight="bold")
    ax.annotate("", xy=(-2.15, 0.75), xytext=(-2.15, 0.05), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(-2.15, 0.9, "+", color=TXT, fontsize=fpx(fs), ha="center", fontweight="bold")
    ax.annotate("", xy=(-2.0, -0.12), xytext=(-1.55, -0.57), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(-2.2, -0.0, "+", color=TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold")

def mark(ax, x, y, text, fs=18, dx=0.12, dy=0.18, shape="*", col=None, ms=16):
    col = col or STAR
    ax.plot([x], [y], marker=shape, color=col, ms=ms, mec=BG, mew=1.2, zorder=6)
    ax.text(x + dx, y + dy, text, color=TXT, fontsize=fpx(fs), zorder=7,
            bbox=dict(boxstyle="round,pad=0.15", fc=BG, ec="none", alpha=0.75))

# ------------------------------------------------------------------ cube (oblique projection)
def P(y):
    return (y[0] + 0.5 * y[1], y[2] + 0.4 * y[1])

def draw_cube(ax, pad=0.55, edge=CUBE_EDGE, lw=2.2, fill_faces=None):
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-pad, 1.5 + pad); ax.set_ylim(-pad, 1.4 + pad)
    V = {c: tuple(int(b) for b in c) for c in CODES}
    hidden = {("010", "110"), ("010", "011"), ("000", "010")}
    for a, b in itertools.combinations(CODES, 2):
        if sum(x != y for x, y in zip(a, b)) != 1: continue
        (x0, y0), (x1, y1) = P(V[a]), P(V[b])
        dash = (a, b) in hidden or (b, a) in hidden
        ax.plot([x0, x1], [y0, y1], color=edge, lw=lw, ls=(0, (4, 3)) if dash else "-", alpha=0.55 if dash else 0.95, zorder=1)
    return V

LBL_OFF = {"000": (-0.20, -0.16), "100": (0.18, -0.16), "010": (-0.24, 0.0), "110": (0.28, 0.0),
           "001": (-0.20, 0.16), "101": (-0.22, 0.16), "011": (-0.28, 0.14), "111": (0.26, 0.14)}
def corner(ax, c, kind="tint", lab=True, fs=18, ms=18, extra=None, vfs=None):
    x, y = P(tuple(int(b) for b in c))
    if kind == "tint":
        ax.plot([x], [y], "o", ms=ms, color=TINT[c] if c != "101" else "none", mec=TXT if c != "101" else MUT, mew=2.2 if c != "101" else 2.2,
                ls="none", zorder=5)
        if c == "101": ax.plot([x], [y], "o", ms=ms, mfc="none", mec=MUT, mew=2.2, zorder=5)
    elif kind == "A":
        ax.plot([x], [y], "o", ms=ms, color=A_C, mec=BG, mew=1.5, zorder=5)
    elif kind == "B":
        ax.plot([x], [y], "s", ms=ms - 2, color=B_C, mec=BG, mew=1.5, zorder=5)
    elif kind == "none":
        ax.plot([x], [y], "o", ms=ms, mfc="none", mec=MUT, mew=2.4, zorder=5)
    if lab:
        dx, dy = LBL_OFF[c]
        ax.text(x + dx, y + dy, extra if extra is not None else c, color=TXT, fontsize=fpx(vfs or fs), ha="center", va="center", fontweight="bold",
                zorder=7, bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.6))

def axes_arrows(ax, fs=18):
    for (y, name, off) in [((1.28, 0, 0), "$y_1$", (0.04, -0.17)), ((0, 1.28, 0), "$y_2$", (0.0, 0.1)), ((0, 0, 1.28), "$y_3$", (0, 0.1))]:
        pass

def cut_polygon(coef, b):
    """polygon where  coef.y + b = 0 meets the unit cube (list of 3D points, ordered)."""
    pts = []
    for a, c in itertools.combinations(CODES, 2):
        if sum(x != y for x, y in zip(a, c)) != 1: continue
        ya, yc = np.array([int(t) for t in a], float), np.array([int(t) for t in c], float)
        fa, fc = coef @ ya + b, coef @ yc + b
        if fa * fc < 0:
            t = fa / (fa - fc); pts.append(ya + t * (yc - ya))
        elif fa == 0: pts.append(ya)
    uniq = []
    for p in pts:
        if not any(np.allclose(p, u) for u in uniq): uniq.append(p)
    pts2 = np.array([P(p) for p in uniq]); cen = pts2.mean(0)
    order = np.argsort(np.arctan2(pts2[:, 1] - cen[1], pts2[:, 0] - cen[0]))
    return [tuple(pts2[i]) for i in order]

def draw_cut(ax, coef, b, fc=LINE, alpha=0.30):
    poly = cut_polygon(np.array(coef, float), b)
    ax.add_patch(Polygon(poly, closed=True, fc=fc, ec=fc, alpha=alpha, lw=0, zorder=3))
    ax.add_patch(Polygon(poly, closed=True, fc="none", ec=fc, lw=2.6, zorder=4))

def legend_ab(ax, x, y, fs=18, dx=0.55, tx=0.12):
    ax.plot([x], [y], "o", ms=14, color=A_C, mec=BG); ax.text(x + tx, y, "A", color=TXT, fontsize=fpx(fs), va="center")
    ax.plot([x + dx], [y], "s", ms=12, color=B_C, mec=BG); ax.text(x + dx + tx, y, "B", color=TXT, fontsize=fpx(fs), va="center")


# ================================================================== figures
def fig_two_spaces():
    w, h = 1000, 262
    fig = new_fig(w, h)
    axp = panel(fig, w, h, 10, 4, 232, 232); draw_plane(axp, codefs=15)
    axp.text(0, -2.68, "$x_1$-$x_2$ plane", color=MUT, fontsize=fpx(18), ha="center", va="top")
    axc = panel(fig, w, h, 520, 2, 470, 256); draw_cube(axc, pad=0.5)
    for c in CODES: corner(axc, c, "tint", fs=18)
    for (x, y), c in [((1, 1), "110"), ((-1, 0.9), "011"), ((0.9, -1.5), "100")]:
        axp.plot([x], [y], "*", ms=18, color=STAR, mec=BG, zorder=6)
        fig.add_artist(ConnectionPatch(xyA=(x, y), coordsA="data", axesA=axp, xyB=P(tuple(int(b) for b in c)), coordsB="data", axesB=axc,
                       arrowstyle="-|>", mutation_scale=22, color=TXT, lw=2.4, connectionstyle="arc3,rad=-0.12", zorder=1))
    save(fig, "lec05-kp03-two-spaces")

def fig_regions():
    w, h = 520, 440
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 30, 8, 460, 424); draw_plane(ax, codefs=19)
    line_labels(ax, 18); plus_arrows(ax, 20)
    mark(ax, 1, 1, "(1,1)", dx=0.14, dy=0.2); mark(ax, -1, 1, "(-1,1)", dx=-0.1, dy=0.22)
    save(fig, "lec05-kp03-regions")

def fig_no101():
    w, h = 480, 470
    fig = new_fig(w, h)
    cols = ["#5fb8a8", "#a98bd0", "#d08bb0"]
    tl = ["$y_1=1:\\ x_1>0$", "$y_2=0:\\ x_2\\leq0$", "$y_3=1:\\ x_2>x_1+1$", "$y=101$: no overlap"]
    L = 2.6
    polys = [[(0, -L), (L, -L), (L, L), (0, L)], [(-L, -L), (L, -L), (L, 0), (-L, 0)], [(-L, -L + 1), (L - 1, L), (-L, L)]]
    for i in range(4):
        cx, cy = 10 + (i % 2) * 235, (i // 2) * 235
        ax = panel(fig, w, h, cx, cy, 215, 200)
        ax.set_xlim(-L, L); ax.set_ylim(-L, L); ax.set_aspect("equal"); ax.axis("off")
        ax.add_patch(Rectangle((-L, -L), 2 * L, 2 * L, fill=False, ec=MUT, lw=1.4))
        ax.plot([0, 0], [-L, L], color=MUT, lw=1, alpha=0.5); ax.plot([-L, L], [0, 0], color=MUT, lw=1, alpha=0.5)
        if i < 3:
            ax.add_patch(Polygon(polys[i], fc=cols[i], ec=cols[i], alpha=0.45, lw=2.5))
            col = cols[i]
        else:
            for j in range(3): ax.add_patch(Polygon(polys[j], fc=cols[j], ec=cols[j], alpha=0.28, lw=2.5))
            ax.text(0.0, 0.0, "$\\varnothing$", color=TXT, fontsize=fpx(48), ha="center", va="center", zorder=6)
            col = TXT
        fig.text((cx + 107) / w, 1 - (cy + 218) / h, tl[i], color=col, fontsize=fpx(18), ha="center", va="center")
    save(fig, "lec05-kp03-no101")

def fig_cube():
    w, h = 560, 420
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 5, 0, 550, 415); draw_cube(ax, pad=0.45); ax.set_xlim(-0.8, 2.0)
    draw_cut(ax, (-1, -1, 1), 0.5)
    for c in CODES: corner(ax, c, "tint", fs=18, ms=20)
    ax.text(-0.62, 0.62, "$q=0$", color=LINE, fontsize=fpx(20), va="center", fontweight="bold")
    ox, oy = -0.66, -0.30
    for (dx, dy, t, tx, ty) in [(0.38, 0, "$y_1$", 0.42, -0.05), (0.19, 0.152, "$y_2$", 0.2, 0.2), (0, 0.4, "$y_3$", -0.02, 0.46)]:
        ax.annotate("", xy=(ox + dx, oy + dy), xytext=(ox, oy), arrowprops=dict(arrowstyle="-|>", color=MUT, lw=2.2))
        ax.text(ox + tx, oy + ty, t, color=TXT, fontsize=fpx(20), ha="left", va="center")
    save(fig, "lec05-kp03-cube")

def cube_scores(ax, kind_map, vals=True, vfs=17, k=1.35):
    for c in CODES:
        x, y = P(tuple(int(b) for b in c))
        if c == "101":
            corner(ax, c, "none", fs=17, ms=20, extra="101")
        else:
            corner(ax, c, kind_map[c], lab=False, ms=21)
            dx, dy = LBL_OFF[c]
            s = f"{c}\n{Q([int(b) for b in c]):+.1f}" if vals else c
            ax.text(x + dx * k, y + dy * k, s, color=TXT, fontsize=fpx(vfs), ha="center", va="center", fontweight="bold",
                    zorder=7, linespacing=1.05, bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.6))

def fig_cube_cut():
    w, h = 600, 430
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 5, 0, 590, 425); draw_cube(ax, pad=0.5)
    draw_cut(ax, (-1, -1, 1), 0.5)
    cube_scores(ax, {c: ("A" if c in A1 else "B") for c in REAL})
    legend_ab(ax, -0.45, -0.52, 18)
    ax.text(0.5, -0.52, "$q=0$", color=LINE, fontsize=fpx(20), va="center")
    ax.set_ylim(-0.72, 1.82); ax.set_xlim(-0.6, 2.1)
    save(fig, "lec05-kp03-cube-cut")

def fig_union_gap():
    w, h = 1160, 255
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 10, 4, 247, 247); draw_plane(ax, classes=A1, codefs=15)
    p1, p2, pm = (-0.15, -1.0), (-0.15, 2.0), (-0.15, 0.62)
    ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color=TXT, lw=2.6, ls=(0, (4, 3)), zorder=5)
    ax.plot(*p1, "o", ms=15, color=A_C, mec=STAR, mew=2, zorder=6); ax.plot(*p2, "o", ms=15, color=A_C, mec=STAR, mew=2, zorder=6)
    ax.plot(*pm, "s", ms=13, color=B_C, mec=STAR, mew=2, zorder=6)
    legend_ab(ax, 0.2, -2.25, 16, dx=1.0, tx=0.2)
    for (pt, nm, dx_, dy_) in [(p1, "P", -0.45, -0.1), (p2, "Q", -0.45, -0.1), (pm, "R", 0.25, -0.1)]:
        ax.text(pt[0] + dx_, pt[1] + dy_, nm, color=STAR, fontsize=fpx(20), fontweight="bold", zorder=8, bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.7))
    axc = panel(fig, w, h, 330, 0, 640, 253); draw_cube(axc, pad=0.5)
    draw_cut(axc, (-1, -1, 1), 0.5)
    cube_scores(axc, {c: ("A" if c in A1 else "B") for c in REAL}, vals=False, vfs=17, k=1.1)
    axc.set_ylim(-0.5, 1.75); axc.set_xlim(-0.5, 2.0)
    for pt, c in [(p1, "000"), (p2, "011"), (pm, "010")]:
        fig.add_artist(ConnectionPatch(xyA=pt, coordsA="data", axesA=ax, xyB=P(tuple(int(b) for b in c)), coordsB="data", axesB=axc, arrowstyle="-|>", mutation_scale=18, color=MUT, lw=1.8, ls=(0, (3, 3)), connectionstyle="arc3,rad=-0.08", zorder=1))
    save(fig, "lec05-kp03-union-gap")

def fig_plane_to_face():
    w, h = 700, 300
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 5, 4, 290, 290)
    ax.set_xlim(-LIM, LIM); ax.set_ylim(-LIM, LIM); ax.set_aspect("equal"); ax.axis("off")
    n = 400; xs = np.linspace(-LIM, LIM, n); X, Y = np.meshgrid(xs, xs)
    code = (X > 0) * 4 + (Y > 0) * 2 + ((-X + Y - 1) > 0) * 1
    for k, c in enumerate(CODES):
        m = (code == k).astype(float)
        if not m.sum(): continue
        ax.contourf(X, Y, m, levels=[0.5, 1.5], colors=[A_C if c in A2 else B_C], alpha=0.55 if c[2] == "0" else 0.35)
    ax.add_patch(Rectangle((-LIM, -LIM), 2 * LIM, 2 * LIM, fill=False, ec=MUT, lw=1.4))
    ax.plot([0, 0], [-LIM, LIM], color=LINE, lw=3); ax.plot([-LIM, LIM], [0, 0], color=LINE, lw=3)
    ax.plot([-LIM, LIM - 1], [-LIM + 1, LIM], color=LINE, lw=4)
    for c, (px, py) in {"000": (-1.0, -0.9), "010": (-0.55, 0.2), "100": (1.4, -1.0), "110": (1.5, 0.9)}.items():
        ax.text(px, py, c, color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    for c, (px, py) in {"001": (-2.0, -0.3), "011": (-1.6, 1.6), "111": (0.45, 2.2)}.items():
        ax.text(px, py, c, color=MUT, fontsize=fpx(16), ha="center", va="center")
    axc = panel(fig, w, h, 330, 0, 365, 298); draw_cube(axc, pad=0.5)
    face = [P((0, 0, 0)), P((1, 0, 0)), P((1, 1, 0)), P((0, 1, 0))]
    axc.add_patch(Polygon(face, closed=True, fc=LINE, alpha=0.22, ec=LINE, lw=3.2, zorder=2))
    for c in REAL: corner(axc, c, "A" if c in A2 else "B", lab=True, ms=18, fs=16)
    corner(axc, "101", "none", lab=True, ms=18, fs=16)
    axc.set_ylim(-0.6, 1.7); axc.set_xlim(-0.5, 2.0)
    legend_ab(axc, -0.4, -0.42, 17)
    save(fig, "lec05-kp03-plane-to-face")

def fig_face():
    w, h = 340, 330
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 60, 25, 255, 240)
    ax.set_xlim(-0.3, 1.3); ax.set_ylim(-0.3, 1.3); ax.set_aspect("equal")
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1]); ax.tick_params(labelsize=fpx(18))
    ax.set_xlabel("$y_1$", fontsize=fpx(20)); ax.set_ylabel("$y_2$", fontsize=fpx(20), rotation=0, labelpad=14)
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=MUT, lw=1.6))
    for c in ["000", "110"]: ax.plot(int(c[0]), int(c[1]), "o", ms=22, color=A_C, mec=BG, mew=1.5, zorder=5)
    for c in ["010", "100"]: ax.plot(int(c[0]), int(c[1]), "s", ms=20, color=B_C, mec=BG, mew=1.5, zorder=5)
    for c, (dx, dy) in {"000": (0.0, -0.17), "110": (0.0, 0.17), "010": (0.0, 0.17), "100": (0.0, -0.17)}.items():
        ax.text(int(c[0]) + dx, int(c[1]) + dy, c, color=TXT, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
    fig.text(0.5, 0.965, "$y_3=0$", color=LINE, fontsize=fpx(20), ha="center", va="center")
    save(fig, "lec05-kp03-obstruction")

def fig_midpoint():
    w, h = 440, 470
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 60, 40, 260, 250)
    ax.set_xlim(-0.32, 1.32); ax.set_ylim(-0.32, 1.32); ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=MUT, lw=1.6))
    ax.plot([0, 1], [0, 1], color=A_C, lw=4, zorder=3); ax.plot([0, 1], [1, 0], color=B_C, lw=4, zorder=3)
    for c in ["000", "110"]: ax.plot(int(c[0]), int(c[1]), "o", ms=22, color=A_C, mec=BG, mew=1.5, zorder=5)
    for c in ["010", "100"]: ax.plot(int(c[0]), int(c[1]), "s", ms=20, color=B_C, mec=BG, mew=1.5, zorder=5)
    ax.plot([0.5], [0.5], "*", ms=26, color=STAR, mec=BG, zorder=6)
    ax.text(0.58, 0.43, "M", color=TXT, fontsize=fpx(22), fontweight="bold")
    lab = {"000": ("000: $a_0$", -0.05, -0.17, "right"), "110": ("110: $a_1+a_2+a_0$", 1.06, 1.15, "left"),
           "010": ("010: $a_2+a_0$", -0.05, 1.15, "right"), "100": ("100: $a_1+a_0$", 1.06, -0.17, "left")}
    for c, (t, x, y, ha) in lab.items(): ax.text(x, y, t, color=TXT, fontsize=fpx(18), ha=ha, va="center")
    fig.text(0.5, 1 - 365 / h, "$q(M)=\\dfrac{a_1+a_2+2a_0}{2}$", color=TXT, fontsize=fpx(24), ha="center", va="center")
    fig.text(0.5, 1 - 425 / h, "$M=(\\frac{1}{2},\\frac{1}{2},0)$", color=MUT, fontsize=fpx(20), ha="center", va="center")
    save(fig, "lec05-kp03-midpoint")

def fig_slice_corner():
    w, h = 600, 440
    fig = new_fig(w, h)
    ax = panel(fig, w, h, 5, 0, 590, 435); draw_cube(ax, pad=0.5)
    for coef, b_, col_ in [((1, 1, -1), -1.5, TINT["110"]), ((1, 1, 1), -2.5, TINT["111"]), ((-1, -1, -1), 0.5, TINT["000"])]:
        draw_cut(ax, coef, b_, fc=col_, alpha=0.45)
    for c in CODES: corner(ax, c, "none" if c == "101" else ("A" if c in A2 else "B"), lab=True, ms=21, fs=18)
    legend_ab(ax, -0.45, -0.52, 18)
    ax.set_ylim(-0.72, 1.62); ax.set_xlim(-0.6, 2.1)
    save(fig, "lec05-kp03-slice-corner")

def fig_hypercubes():
    w, h = 1000, 215
    fig = new_fig(w, h)
    ax1 = panel(fig, w, h, 10, 2, 300, 160); ax1.set_xlim(-0.3, 1.3); ax1.set_ylim(-0.6, 0.6); ax1.axis("off"); ax1.set_aspect("equal")
    ax1.plot([0, 1], [0, 0], color=CUBE_EDGE, lw=3)
    for x in (0, 1):
        ax1.plot([x], [0], "o", ms=20, color=TINT["000" if x == 0 else "100"], mec=TXT, mew=2)
        ax1.text(x, 0.25, str(x), color=TXT, fontsize=fpx(22), ha="center", fontweight="bold")
    ax2 = panel(fig, w, h, 350, 2, 250, 160); ax2.set_xlim(-0.35, 1.35); ax2.set_ylim(-0.35, 1.35); ax2.axis("off"); ax2.set_aspect("equal")
    ax2.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=CUBE_EDGE, lw=3))
    for c in ["00", "01", "10", "11"]:
        x, y = int(c[0]), int(c[1])
        ax2.plot([x], [y], "o", ms=20, color=TINT[c + "0"], mec=TXT, mew=2)
        ax2.text(x + (0.24 if x else -0.24), y + (0.22 if y else -0.22), c, color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    ax3 = panel(fig, w, h, 660, 0, 330, 175); draw_cube(ax3, pad=0.45)
    for c in CODES: corner(ax3, c, "tint", lab=False, ms=16)
    for (x, t) in [(160, "$p=1$:  $2^1=2$ corners"), (475, "$p=2$:  $2^2=4$ corners"), (830, "$p=3$:  $2^3=8$ corners")]:
        fig.text(x / w, 1 - 195 / h, t, color=TXT, fontsize=fpx(20), ha="center", va="center")
    save(fig, "lec05-kp03-hypercubes")

if __name__ == "__main__":
    for f in [fig_two_spaces, fig_regions, fig_no101, fig_cube, fig_cube_cut, fig_union_gap, fig_plane_to_face, fig_face, fig_midpoint, fig_slice_corner, fig_hypercubes]:
        try:
            f()
        except Exception as e:
            print("FAILED", f.__name__, e)
