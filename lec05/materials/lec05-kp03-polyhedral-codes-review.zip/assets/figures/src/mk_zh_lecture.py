import re
src=open('lectures/lec05-kp03-polyhedral-codes.md',encoding='utf-8').read()
CJK=re.compile(r'[㐀-鿿]')
LAT=re.compile(r'[A-Za-z]')
def strip_paren(line):
    # drop a trailing full-width parenthesis that holds English
    return re.sub(r'（[^（）\n]*[A-Za-z][^（）\n]*）\s*$','',line.rstrip()) if CJK.search(line) else line
blocks=src.split("\n\n")
out=[]
for b in blocks:
    lines=b.split("\n")
    if b.startswith("```") or b.startswith("$$") or b.startswith("|") or b.startswith("!["):
        if b.startswith("!["):
            b=re.sub(r'!\[([^\]]*?)（[^（）\]]*[A-Za-z][^（）\]]*）\]',r'![\1]',b)
        out.append(b); continue
    if b.startswith("#"):
        out.append("\n".join(strip_paren(l) for l in lines)); continue
    if b.startswith(">"):
        ls=[re.sub(r'／Level:.*$','',re.sub(r'（undergrad）','',l)).rstrip() for l in lines]
        ls=[re.sub(r'｜Pattern Recognition.*$','',l).rstrip() for l in ls]
        out.append("\n".join(ls)); continue
    if not CJK.search(b):
        continue   # English-only paragraph
    # keep; strip trailing English parentheticals in list items
    new=[]
    for l in lines:
        if l.startswith("- ") and CJK.search(l):
            l=re.sub(r'（[A-Z][^（）]*[a-z][^（）]*[.。]?）\s*$','',l.rstrip())
        new.append(l)
    out.append("\n".join(new))
md="\n\n".join(out)
md=md.replace("[簡報閱讀與下載（Slides）](../slides/lec05-kp03-polyhedral-codes.html)","[簡報閱讀與下載](../slides/lec05-kp03-polyhedral-codes-zh.html)")
md=md.replace("[簡報閱讀與下載(Slides)]","[簡報閱讀與下載]")
md=re.sub(r'\n{3,}','\n\n',md)
open('lectures/lec05-kp03-polyhedral-codes-zh.md','w',encoding='utf-8').write(md)
print(len(md))
