"""KP03 deck: codes of several lines and the limit of one output (undergrad, bilingual, self-study, storybook rules C12-C18)."""
import json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
os.environ.setdefault("DECK_WORK", HERE); os.environ.setdefault("DECK_PFX", "lec05kp03")
sys.path.insert(0, "/home/user/pr-2026-fall/.agents/skills/view-from-text/tools/deckkit")
import kit
from kit import AUX, EDGE, MAIN, OK, REF, WARN
KP_LANG = os.environ.get("KP_LANG", "bi")      # bi (bilingual) | zh | en
CJK_RE = re.compile(r"[\u3400-\u9fff]")
def en(t):
    return "\n".join("*" + ln + "*" if ln.strip() else ln for ln in t.split("\n"))
def T(*lines):
    if KP_LANG == "bi":
        return "\n".join(lines)
    if KP_LANG == "zh":
        return "\n".join(ln for ln in lines if not (ln.startswith("*") and not ln.startswith("**")))
    out = []
    for ln in lines:
        if ln.startswith("*") and not ln.startswith("**"):
            out.append(ln.strip("*"))
        elif not CJK_RE.search(ln):
            out.append(ln)
    txt = "\n".join(out).replace("：", ": ")
    return txt
VIO, ROSE = "#a98bd0", "#d08bb0"
kit.RGB[VIO] = (169, 139, 208); kit.RGB[ROSE] = (208, 139, 176)
TEAL = AUX
sys.path.insert(0, HERE)
from i18n_data import TITLE_EN, LABEL_EN, TERM_EN, UNIT_TITLE_EN, DECK_TITLE_EN, LEVEL_NOTE_EN, OVR as OVR_EN, NOTES_EN
BOLD_PREFIX = re.compile(r"^([A-Z][A-Za-z\- ()]{2,40}?):(?= )")

def ovr(p, key, text):
    if KP_LANG != "en":
        return text
    text = OVR_EN.get((p.idx + 1, key), text)
    if key != "bridge" and not text.startswith("**"):
        text = BOLD_PREFIX.sub(lambda m: "**" + m.group(1) + "**:", text)
    return text

def card(p, key, x, y, w, h, text, **kw):
    return p.card(key, x, y, w, h, ovr(p, key, text), **kw)

def newpage(u, label, zh, en_):
    idx = len(u.pages)
    if KP_LANG == "bi":
        return u.page(label, zh, en_)
    if KP_LANG == "zh":
        return u.page(label, zh, "")
    return u.page(LABEL_EN[idx], TITLE_EN[idx], "")

_orig_step = kit.Page.step
def _step(self, notes):
    return _orig_step(self, NOTES_EN[self.idx] if KP_LANG == "en" else notes)
kit.Page.step = _step
LEVEL_NOTE = ("教材程度：大學三年級（undergrad）。簡報時長：主線 9 頁約 34 分鐘，另有 2 頁延伸（不計時）；自主學習用，中英對照。"
              "本檔依 CLARITY.md C12–C18 重做：術語先用白話說、標題講明白、頁與頁以疑問接力、空間內容每頁有圖。"
              "備註會隨檔案公開下載，不含學號、成績或考題。")
RENAME = {}            # node id -> name (term:xxx)

def bridge(p, zh, en_):
    h = p.need_h("bridge", 70)
    card(p, "bridge", 60, 134, 1160, h, T(zh, en(en_)), c=None, size=22)
    return 134 + h + 10

def stack(p, x, y, w, items, gap=10):
    """items: (key, text, color, min_h); returns the y after the last card and the node ids."""
    ids = []
    for key, text, c, mh in items:
        h = p.need_h(key, mh)
        ids.append(card(p, key, x, y, w, h, text, c=c, size=22))
        if key.startswith("term:"): RENAME[ids[-1]] = key
        y += h + gap
    return y, ids

def reveal(p, ids, start=500, every=1400):
    for k, nid in enumerate(ids):
        kit.nodes[nid]["initiallyHidden"] = True
    kit.steps[-1]["reveal"] = {"timing": "after-camera", "exitNodeIds": [],
                               "enter": [{"nodeId": nid, "effect": "fade", "delayMs": start + k * every, "durationMs": 500} for k, nid in enumerate(ids)]}

def build():
    u = kit.Unit("u01", UNIT_TITLE_EN if KP_LANG == "en" else "編碼與兩層網路的極限", 0, 0)

    # ---------------------------------------------------------------- 1
    p = newpage(u, "多放幾條線，最後一條線夠嗎", "兩條線救了 XOR，線再多，最後一層還夠用嗎？",
               "Two lines rescued XOR; with more lines, is the final layer still enough?")
    y = bridge(p, "**上一單元（KP02）留下**：線再多放幾條，會切出什麼？最後一層還能分開任意標籤嗎？",
               "KP02 left two questions: what do more lines cut, and can the last layer still separate any labelling?")
    p.figure("lec05-kp03-two-spaces", 80, y)
    y += 262 + 6
    ids = []
    for k, (key, tx, c, x) in enumerate([
        ("term:位元", T("**位元**：點在線的正側（分數 $>0$）記 1，否則記 0。", en("Bit: 1 on the positive side of a line, otherwise 0.")), AUX, 60),
        ("term:階梯規則", T("**階梯規則**：分數大於 0 記 1，其餘記 0。", en("Step rule: a positive score gives 1, else 0.")), EDGE, 454),
        ("q", T("**今天要問**：三條線切出什麼？最後一層（輸出層）能做什麼？", en("Today: what do three lines cut, and what can the output layer do?")), MAIN, 848)]):
        h = p.need_h(key, 140)
        ids.append(card(p, key, x, y, 372, h, tx, c=c, size=22))
        if key.startswith("term:"): RENAME[ids[-1]] = key
    p.conn(ids[0], 4, ids[1], 12); p.conn(ids[1], 4, ids[2], 12)
    p.step("前面的 KP02 用兩條線把 XOR 變成三個位置，再用一條線分開。這一頁先把工具擺好：每條線給點一個分數，分數大於 0 記 1，否則記 0，這個 0 或 1 叫位元。"
           "「正側」就是分數為正的那一側，數學書叫它半空間，現在先不用背。圖左是輸入平面，右是一個立方體，三個星號先預告一件事：平面上每個點，最後都會住進立方體的一個角。"
           "今天要弄清楚兩件事：三條線切出什麼？最後一層（輸出層，也就是最後那個平面）能做什麼？接下來第二頁先算三條線切出幾塊地。來源：第四章 §4.3.1。")

    # ---------------------------------------------------------------- 2
    p = newpage(u, "三條線切出七塊地", "三條線切出七塊地，每塊有自己的編碼", "Three lines cut the plane into seven cells, and each cell has its own code")
    y = bridge(p, "每條線都能給點一個位元。那三條線一起用，平面會被切成什麼樣子？",
               "Each line gives a point one bit. So what does the plane look like when three lines work together?")
    p.figure("lec05-kp03-regions", 60, y)
    stack(p, 610, y, 610, [
        ("term:編碼", T("**編碼**：一個點的三個位元 $y_1y_2y_3$ 連起來，像它的門牌。", en("Code: the three bits of a point, like a house number.")), AUX, 80),
        ("term:區域", T("**區域**：拿到同一個編碼的點，合起來是一塊地。", en("Cell: all points sharing one code.")), EDGE, 90),
        ("ex", T("**算一個點 (1,1)**：三條線的分數 $g_1=x_1,\\ g_2=x_2,\\ g_3=-x_1+x_2-1$ 依序是 $1,\\ 1,\\ -1$，位元 $1,\\ 1,\\ 0$，編碼 **110**。",
                 en("At (1,1) the scores are 1, 1 and −1, so the bits are 1, 1, 0.")), REF, 150),
        ("q", T("三位元能寫 8 種編碼，圖上只有 7 塊：少了哪一個？", en("Eight codes, seven cells: which one is missing?")), WARN, 90)])
    p.step("上一頁只有一條線的位元，這一頁把三條線疊在一起看。三條線把平面切成七塊地，同一塊地的點得到同一組三位元，叫編碼，像門牌。圖上每塊地都標了它的編碼；線上的點依階梯規則記 0，所以邊界歸入記 0 的那一側。"
           "示範點 (1,1)：g1=1、g2=1、g3=−1+1−1=−1，所以位元是 1、1、0。圖上的箭頭標出每條線的正側，請對著算式找一遍。三位元能寫八種編碼，圖上只有七塊，接下來第三頁追問少的那一個。")

    # ---------------------------------------------------------------- 3
    p = newpage(u, "編碼 101 沒有人拿得到", "101 沒人拿得到：三個條件互相矛盾", "No point receives code 101: its three conditions contradict each other")
    y = bridge(p, "三位元有 8 種編碼，圖上卻只有 7 塊。少的那個 101，為什麼沒有人拿得到？",
               "Eight codes are possible but only seven cells appear. Why can no point receive 101?")
    p.figure("lec05-kp03-no101", 760, y)
    y2, ids = stack(p, 60, y, 680, [
        ("c1", T("**① 第 1 位是 1**：要 $x_1>0$（在豎線右側）。", en("Bit 1 is 1: the point lies right of the vertical line.")), TEAL, 86),
        ("c2", T("**② 第 2 位是 0**：要 $x_2\\leq0$（在橫線下方或線上）。", en("Bit 2 is 0: the point lies on or below the horizontal line.")), VIO, 86),
        ("c3", T("**③ 第 3 位是 1**：要 $x_2>x_1+1$（斜線上方），可是 ①② 已讓 $x_2\\leq0<x_1+1$。", en("Bit 3 needs x2 > x1+1, but 1 and 2 force x2 ≤ 0 < x1+1.")), ROSE, 130)])
    stack(p, 60, y2, 680, [
        ("term:虛擬碼", T("三塊地沒有共同的點：101 是**虛擬碼**，沒有點得到；有點得到的 7 個是**實際碼**。", en("101 is an unrealized code; the other seven are realized.")), OK, 90)])
    p.step("上一頁留下的問題是：八種編碼為什麼只有七塊？請看三個條件。第一位是 1 要求 x1 大於 0，第二位是 0 要求 x2 不大於 0，這兩條合起來，點只能在右下角，那裡 x2 不大於 0、而 x1+1 大於 1，所以第三位要求的「x2 大於 x1+1」永遠不成立。"
           "右邊四格圖把三個條件各畫成一塊陰影，第四格疊起來沒有共同的部分。這和「資料還沒蒐集到」不同：不管蒐集多少點，101 都不會出現。學生常把兩者混在一起，請特別點出。接下來第四頁問：既然只有七個實際碼，最後一層到底在這些編碼上做什麼？")
    reveal(p, ids)

    # ---------------------------------------------------------------- 4
    p = newpage(u, "編碼是立方體的角", "把編碼看成立方體的角，最後一層是切一刀", "Read each code as a corner of a cube; the last layer is one cut through the cube")
    y = bridge(p, "既然只有 7 個實際碼、101 是虛擬碼，最後一層到底拿這些編碼做什麼？",
               "Only seven codes are realized and 101 is not. So what does the last layer do with these codes?")
    p.figure("lec05-kp03-cube", 60, y)
    stack(p, 650, y, 570, [
        ("term:頂點", T("**頂點**：立方體的角。3 位編碼就是角的座標 $(y_1,y_2,y_3)$，共 8 個。", en("Vertex: a corner of the cube, named by its code.")), AUX, 130),
        ("term:輸出分數", T("**輸出分數**：$q=a_1y_1+a_2y_2+a_3y_3+a_0$。$q>0$ 判 A，否則判 B（A、B 是兩種標籤）。", en("A and B are the two class labels.")), EDGE, 130),
        ("cut", T("最後一層是平面 $q=0$（圖中的例子）：**切一刀**。", en("The output layer is the plane q = 0; it splits the corners in two.")), MAIN, 130)])
    p.step("上一頁證明了 101 沒有人拿得到，所以最後一層只需要管七個實際碼。這一頁把三位元的編碼換成立方體：000 到 111 剛好是立方體的八個角，座標就是 (y1,y2,y3)。"
           "圖上顏色和第二頁平面上的區域一一相同，例如 011 那個粉紅色的角，對應平面左上方那一塊。101 畫成空心圓，因為沒有任何點會住進去。"
           "最後一層做的事很簡單：給每個角打一個分數 q，正分判 A，否則判 B。q=0 在立方體裡是一個平面，圖上橘色半透明的是一個示範的切面（下一頁才給具體係數），所以這一層就是在立方體上切一刀。A、B 是我們要分的兩種標籤。接下來第五頁問：這一刀分得開七個實際的角嗎？（立方體圖為補充。）")

    # ---------------------------------------------------------------- 5
    p = newpage(u, "逐角計分，切得開", "逐角計分：A 的三個角為正，B 的四個角非正", "Score every corner: three A corners are positive and four B corners are not")
    y = bridge(p, "最後一層是平面，每個角用輸出分數 $q$ 打分。取具體係數 $q=-y_1-y_2+y_3+0.5$，分得開七個角嗎？",
               "The output plane scores every corner. With these coefficients, are the seven corners separated?")
    p.figure("lec05-kp03-cube-cut", 620, y)
    stack(p, 60, y, 540, [
        ("A", T("**A 類（藍，$q>0$）**", "000：$-0-0+0+0.5=0.5$", "001：$-0-0+1+0.5=1.5$", "011：$-0-1+1+0.5=0.5$"), REF, 150),
        ("B", T("**B 類（橘，$q\\leq0$）**", "010：$-0-1+0+0.5=-0.5$", "100：$-1-0+0+0.5=-0.5$", "110：$-1-1+0+0.5=-1.5$", "111：$-1-1+1+0.5=-0.5$"), MAIN, 180),
        ("term:線性可分", T("A、B 各在平面一側：**線性可分**。", en("Linearly separable: one plane splits A from B.")), OK, 86)])
    p.step("上一頁說最後一層是在立方體上切一刀，這一頁用講義給的輸出分數 q 等於負 y1 減 y2 加 y3 再加 0.5，一個角一個角代入。左邊兩張卡是算式，右邊的圖把每個角的分數標在角旁邊，請對照著看：正分的三個角在切面上方，負分的四個角在切面下方。"
           "101 的分數雖然是正的 0.5，但沒有任何輸入會得到它，所以不影響分類。能用一個平面把兩類分開，叫線性可分。接下來第六頁要把這一刀翻回輸入平面，看 A 那一邊到底長什麼樣子。")

    # ---------------------------------------------------------------- 6
    p = newpage(u, "A 區是三塊併成的", "翻回平面：A 區是三塊併成的，中間有缺口", "Back in the plane: region A is three cells joined, with a notch in the middle")
    y = bridge(p, "逐角計分顯示一刀分開了 A、B 的角。翻回輸入平面，A 區會長什麼樣子？",
               "By the corner scores one cut separates A from B. Back in the plane, what does region A look like?")
    p.figure("lec05-kp03-union-gap", 60, y)
    y += 255 + 6
    ids = []
    for key, tx, c, x, w_ in [("term:凸", T("**凸**：區域內任取兩點，連線都不跑出區域。", en("Convex: segments between points stay inside.")), AUX, 60, 570),
                              ("term:聯集", T("**聯集**：把幾塊區域併成一塊。", en("Union: several cells merged into one region.")), EDGE, 650, 570)]:
        h = p.need_h(key, 86)
        ids.append(card(p, key, x, y, w_, h, tx, c=c, size=22)); RENAME[ids[-1]] = key
    y += max(kit.nodes[i]["height"] for i in ids) + 6
    h = p.need_h("end", 86)
    card(p, "end", 60, y, 1160, h, T("$P$、$Q$ 都在 A 區，連線卻穿過 B 塊的 $R$：A 區**不是凸的**。那任意幾塊都能併嗎？", en("Segment PQ crosses B at R, so A is not convex. But can any cells be merged?")), c=MAIN, size=22)
    p.step("上一頁看到立方體上的一刀分開了 A、B。這一頁把同一刀翻回輸入平面：A 類是 000、001、011 三塊地併起來，B 類是其餘四塊。左圖藍色是 A 區，橘色是 B 區，右圖是同一刀。"
           "請看虛線：從 (−0.15,−1) 到 (−0.15,2) 是兩個 A 點的連線，中間穿過橘色的 010 小三角形，那個方點 (−0.15,0.62) 是 B。連線跑出了 A 區，所以 A 區不是凸的。"
           "很多人以為兩層網路只會分「沒有凹洞」的區域，其實單一編碼的區域是凸的，但最後一層可以把好幾塊併起來，併出凹洞。這是本 KP 的轉折點。接下來第七頁問：是不是想怎麼併都行？（本頁缺口圖為補充，座標已程式驗算。）")

    # ---------------------------------------------------------------- 7
    p = newpage(u, "底面四角 A、B 交錯", "換一組標籤，底面四個角 A、B 交錯又是 XOR", "With a second labelling, the bottom face alternates A and B: XOR again")
    y = bridge(p, "A 區可以是好幾塊併成的。那是不是任意幾塊都能併？來試試 A＝{000, 110, 111}。",
               "Region A can be several cells joined. Can any cells be joined? Try A = {000, 110, 111}.")
    p.figure("lec05-kp03-plane-to-face", 60, y)
    p.figure("lec05-kp03-obstruction", 840, y)
    y += 330 + 8
    h = p.need_h("end", 130)
    i = card(p, "end", 60, y, 1160, h, T("只看底面 $y_3=0$：四個角都是實際碼，A 在一條對角、B 在另一條對角，和 KP01 的 XOR 一樣：這組標籤**不可分**（**反例**）。",
                                      en("Its four realized corners form an XOR pattern, so no plane separates A from B.")), c=WARN, size=22)
    RENAME[i] = "term:不可分"
    p.step("上一頁看到最後一刀可以併出缺口，這一頁試另一組標籤：A 是 000、110、111。左圖把輸入平面依這組標籤上色，被斜線截出的四塊（000、010、100、110）在左下方，右圖立方體的底面 y3=0 正好是這四個角。"
           "右下的小圖把底面攤平：A 在 000 和 110，B 在 010 和 100，沿對角交錯，就是 KP01 學過的 XOR。底面的標籤既然已經切不開，整個立方體當然也切不開，所以這組標籤沒有任何一刀做得到。反例的意思是：舉出一個例子說明規則不成立。"
           "請問學生：在平面上，哪四塊地在左下角？答案是被兩條座標軸切出的四個象限。接下來第八頁用算式證明，不靠眼睛。")

    # ---------------------------------------------------------------- 8
    p = newpage(u, "兩個和是同一個式子", "兩條對角線共用中點，這一點的分數矛盾了", "The two diagonals share a midpoint, and the score at that point is contradictory")
    y = bridge(p, "底面四個角 A、B 交錯。底面的 $y_3=0$，所以 $a_3$ 不出現：不論 $a_0,a_1,a_2$ 取什麼，都切不開嗎？",
               "The bottom face alternates A and B. Since y3 = 0, a3 plays no role: can any a0, a1, a2 separate them?")
    p.figure("lec05-kp03-midpoint", 780, y)
    y2, ids = stack(p, 60, y, 690, [
        ("s1", T("**① A 角相加**：$q(000)+q(110)=a_0+(a_1+a_2+a_0)$", "$=a_1+a_2+2a_0>0$", en("Two positive scores add up to a positive sum.")), REF, 118),
        ("s2", T("**② B 角相加**：$q(010)+q(100)=(a_2+a_0)+(a_1+a_0)$", "$=a_1+a_2+2a_0\\leq0$", en("Two nonpositive scores add up to a nonpositive sum.")), MAIN, 118),
        ("s3", T("**③ 矛盾**：同一個式子不能既 $>0$ 又 $\\leq0$。$q$ 是線性的，所以中點 $M$ 的分數是兩端分數的平均，兩邊的要求互相衝突。",
                 en("Since q is linear, the score at M is the average of both pairs, so the two demands conflict.")), WARN, 148)])
    p.step("上一頁看出底面像 XOR，這一頁把它證明出來。先提醒底面的 y3 都是 0，所以 a3 乘 0 消失，式子裡不會出現 a3，這也是練習題 2 的答案線索。第一步把兩個 A 角的分數相加：q(000) 是 a0，q(110) 是 a1 加 a2 加 a0，相加得 a1+a2+2a0，兩個正數相加仍為正。"
           "第二步把兩個 B 角相加，得到完全相同的式子 a1+a2+2a0，兩個非正數相加仍非正。同一個式子被要求既大於 0 又不大於 0，所以不存在任何 a0、a1、a2。幾何的意思看右圖：A 的對角線和 B 的對角線交在同一個中點 M，"
           "q 是線性的，所以 M 的分數是兩個 A 分數的平均，也是兩個 B 分數的平均，一個點的分數不能同時為正又非正。請學生指出式子裡每一項對應圖上哪個角。接下來第九頁問：這是兩層網路的死刑嗎？")
    reveal(p, ids)

    # ---------------------------------------------------------------- 9
    p = newpage(u, "再加一層來補救", "不是網路不行，是這一刀不夠：再加一層就行", "The network is not hopeless; one cut is not enough, and one more layer can pick out any corners")
    y = bridge(p, "同一個和被要求既 $>0$ 又 $\\leq0$。那一個輸出平面就此沒救了嗎，還有補救的辦法嗎？",
               "One sum had to be both positive and not positive. Is a single output plane hopeless, or can it be repaired?")
    p.figure("lec05-kp03-slice-corner", 620, y)
    y2, ids = stack(p, 60, y, 540, [
        ("c1", T("**回答第 1 頁**：一個輸出平面（兩層網路＝一排線＋一個輸出平面）不能分開所有標籤。", en("Answer: one output plane cannot separate every labelling, because two layers are a row of lines plus one plane.")), WARN, 118),
        ("c2", T("**但有救**：任何一個角都能單獨切下來。三個目標角各切一刀（右圖），再併起來，就是 A。", en("Cut 000, 110 and 111 one by one and merge them to get A.")), OK, 150),
        ("c3", T("**下一個 KP**：再加一層，怎麼專門認出某幾個角？", en("Next: how can one more layer pick out chosen corners?")), MAIN, 100)])
    p.conn(ids[0], 8, ids[1], 0); p.conn(ids[1], 8, ids[2], 0)
    p.step("上一頁證明了這組線加一刀切不開底面的 XOR。這一頁要把話說準：被擋住的是「這組固定的線，加上一條輸出線」，不是所有兩層網路。換一組線，編碼不同，反例也會不同。"
           "先把名詞說清楚：兩層網路是一排線（隱藏層）加一個輸出平面（輸出層）。補救的直覺在右圖：立方體的任何一個角，都能用一個平面單獨切下來，圖上用三個綠色切面分別切下 000、110、111。目標 A 就是這三個角，各切一刀、再把三個結果併起來，這就是多加一層的意思，怎麼設計留給下一個 KP。"
           "今天的收穫有三個：七個實際碼、立方體上的一刀、以及底面 XOR 的反例。接下來進入 KP04：再加一層，具體怎麼設計。")

    # ---------------------------------------------------------------- 10 (extension)
    p = newpage(u, "延伸:練習，改 a3 或 101", "延伸：練習，改 a3 或改 101 的標籤會怎樣？", "Extension: what happens if we change a3, or relabel 101?")
    y = bridge(p, "限制來自這組線加一個輸出平面。改係數或改 101 的標籤，能繞過它嗎？",
               "Can changing a coefficient, or relabeling 101, get around the limit of these lines plus one plane?")
    y1, _ = stack(p, 60, y, 560, [
        ("q1", T("**題 1**：把虛擬碼 101 標成 A 或 B，輸入上的預測會變嗎？", en("Question 1: does labeling 101 as A or B change any prediction?")), REF, 100),
        ("q2", T("**題 2**：換成 A＝000、110、111，只改 $a_3$ 能消除矛盾嗎？", en("Question 2: can changing only a3 remove the contradiction?")), MAIN, 100)])
    stack(p, 650, y, 570, [
        ("h1", T("**提示 1**：先問，有沒有輸入點會得到 101？", en("Hint 1: does any input receive code 101?")), AUX, 90),
        ("h2", T("**提示 2**：底面四個點的 $y_3$ 都是 0。", en("Hint 2: all four bottom-face points have y3 = 0.")), AUX, 90)])
    stack(p, 60, max(y1, y + 190) + 4, 1160, [
        ("sol", T("**題 2 解題示範**：① 兩個和都是 $a_1+a_2+2a_0$。② $y_3=0$，$a_3$ 乘 0 消失。③ 兩個和與 $a_3$ 無關，矛盾依舊。④ 驗算：$a_3=100$ 時，兩個和不變。",
                  en("Because y3 = 0, a3 disappears from both sums, so no choice of a3 removes the contradiction.")), OK, 150)])
    p.step("前面九頁的內容到這裡可以自己驗證。題 1 的關鍵是 101 沒有原像，不論標成 A 或 B，沒有任何輸入受影響。題 2 給完整示範：先寫兩個和的符號式，再代入底面四點的 y3 等於 0，a3 乘以 0 就消失，兩個和與 a3 無關，所以矛盾還在。"
           "最後用 a1、a2 取 0、a0 取 1 驗算：四個角分數都是 1，B 全被判成 A。請學生先自己做題 1 再看提示，題 2 先試改 a3 看看結果再對照。接下來是延伸的最後一頁：把三條線推廣到 p 條線。")

    # ---------------------------------------------------------------- 11 (extension)
    p = newpage(u, "延伸:p 條線、d 維輸入", "延伸：p 條線、d 維輸入的一般寫法", "Extension: the general form for p lines and d-dimensional inputs")
    y = bridge(p, "練習裡改 $a_3$、改 101 的標籤都繞不過限制。線數和維度一般化時，編碼怎麼寫？",
               "Changing a3 or relabeling 101 did not help. How is the code written for p lines and d dimensions?")
    h = p.need_h("f", 110)
    card(p, "f", 60, y, 1160, h, T("$g_i(\\mathbf x)=\\mathbf w_i^T\\mathbf x+b_i,\\quad \\mathbf y=[f(g_1(\\mathbf x)),\\ldots,f(g_p(\\mathbf x))]^T\\in\\{0,1\\}^p$",
                                 "$\\mathbf x$ 有 $d$ 個座標；$\\mathbf w_i$ 是第 $i$ 條線的係數，$b_i$ 是常數項；$f$ 是階梯規則。", en("Each of the p lines gives one bit, so a code is a corner of the unit hypercube.")), c=EDGE, size=22)
    y += h + 8
    p.figure("lec05-kp03-hypercubes", 110, y)
    y += 215 + 4
    h = p.need_h("term:超立方體", 80)
    i = card(p, "term:超立方體", 60, y, 1160, h, T("**超立方體**：$p$ 位編碼共 $2^p$ 個，是「$p$ 維立方體」的角。", en("Hypercube: a cube in p dimensions; its corners are the 2^p codes.")), c=AUX, size=22)
    RENAME[i] = "term:超立方體"
    p.step("前面三條線是最簡單的例子，一般的隱藏層有 p 個神經元，輸入有 d 個座標。每條線的分數是 w 乘 x 加 b，經過階梯規則得到一個位元，p 個位元連起來是一個 p 位編碼，也就是 p 維立方體的一個角。"
           "圖用 p 等於 1、2、3 說明：p 為 1 是線段的兩個端點，p 為 2 是正方形的四個角，p 為 3 是立方體的八個角，角的個數是 2 的 p 次方。立方體本身包含連續的點，但階梯規則只會輸出角，不會填滿內部。"
           "這是前面各頁的一般化，主線不需要它。接下來可以回到 KP04 看再加一層的設計。")
    return [u]

if __name__ == "__main__":
    U = build()
    title = DECK_TITLE_EN if KP_LANG == "en" else "圖型識別 第四章 KP03：編碼與兩層網路的極限（大三・自學）"
    doc = kit.assemble(U, title, [], {"x": 200, "y": 100, "zoom": 1.2, "rotation": 0})
    for nid, nm in RENAME.items(): doc["nodes"][nid]["name"] = TERM_EN[nm] if KP_LANG == "en" else nm
    doc["steps"][0]["speakerNotes"] = LEVEL_NOTE_EN if KP_LANG == "en" else LEVEL_NOTE.replace("中英對照", "中文版" if KP_LANG == "zh" else "中英對照")
    if KP_LANG != "bi":
        for nid in [k for k, n in doc["nodes"].items() if k.endswith("-sub") and not (n.get("text") or "").strip()]:
            sc = doc["nodes"][nid]["sceneId"]; doc["scenes"][sc]["nodeIds"].remove(nid); del doc["nodes"][nid]
    out = os.path.join(HERE, "draft.jbd.json")
    json.dump(doc, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("pages", sum(1 for s in doc["steps"] if s["target"]["sceneId"] != "scene-root"), "KB", os.path.getsize(out) // 1024)
