#!/bin/bash
# build the separate Chinese and English download packages for KP03
set -e
W=$(cd "$(dirname "$0")" && pwd); R=/home/user/pr-2026-fall; B=lec05-kp03-polyhedral-codes
export KATEX_DIR=$R/.agents/skills/slides-to-html/node_modules/katex
cd $W
for L in zh en; do
  N=$B-$L
  [ $L = zh ] && LANGATTR=zh-Hant && TITLE="KP03 講義（中文版）" && TF=terms.json || { LANGATTR=en; TITLE="KP03 Lecture (English)"; TF=terms_en.json; }
  mkdir -p out_$L; rm -rf out_$L/*
  node md2html.mjs lectures/$N.md out_$L/$N-reading.html assets/figures_png $LANGATTR "$TITLE"
  python3 - "$W/out_$L/$N-reading.html" "$W/out_$L/$N-lecture.pdf" <<'PY'
import sys
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); pg.goto("file://"+sys.argv[1])
    pg.pdf(path=sys.argv[2], format="A4", margin={"top":"15mm","bottom":"15mm","left":"15mm","right":"15mm"}, print_background=True); b.close()
PY
  cp W_$L/draft.jbd.json out_$L/$N.jbd.json
  node $R/.agents/skills/slides-to-html/scripts/jbd_to_html.mjs --out-dir out_$L --strict out_$L/$N.jbd.json
  python3 -W ignore $R/.agents/skills/view-from-text/tools/audit_deck.py out_$L/$N.jbd.json --monolingual --speaker-notes --level undergrad --narrative --terms $TF --minutes 36 --kps 1 --outline > out_$L/audit-$L.txt 2>&1 || true
  python3 $R/scripts/check_slides.py out_$L/$N.jbd.json > out_$L/structure-$L.txt 2>&1 || true
  python3 -W ignore $R/.agents/skills/textbook-lecture-notes/scripts/audit_lecture.py --lang $L lectures/$N.md > out_$L/lecture-audit-$L.txt 2>&1 || true
  # download package
  D=dl_$L; rm -rf $D; mkdir -p $D/slides $D/lectures $D/assets/figures
  cp out_$L/$N.html out_$L/$N.jbd.json $D/slides/; cp lectures/$N.md $D/lectures/; cp out_$L/$N-reading.html out_$L/$N-lecture.pdf $D/; cp assets/figures_png/*.png $D/assets/figures/
  if [ $L = zh ]; then
    printf '圖型識別 第四章 KP03：編碼與兩層網路的極限（中文版）\n\n簡報：slides/%s.html（離線網頁，用瀏覽器開啟）；slides/%s.jbd.json 為 JianBauDau 可編輯原檔。\n講義：%s-lecture.pdf（PDF）、%s-reading.html（離線網頁）、lectures/%s.md（Markdown 原文）。\n英文版為另一個下載包（-en）。草稿，待教師驗收。\n' $N $N $N $N $N > $D/README.txt
  else
    printf 'Pattern Recognition, Chapter 4, KP03: Codes of several lines and the limit of two layers (English version)\n\nSlides: slides/%s.html (offline web page, open in a browser); slides/%s.jbd.json is the editable JianBauDau file.\nLecture: %s-lecture.pdf (PDF), %s-reading.html (offline web page), lectures/%s.md (Markdown source).\nThe Chinese version is a separate download package (-zh). Draft, pending the instructor review.\n' $N $N $N $N $N > $D/README.txt
  fi
  (cd $D && rm -f ../out_$L/$N-download.zip && zip -qr ../out_$L/$N-download.zip .)
  echo "== $L"; ls -la out_$L | grep -v "^total"
done
