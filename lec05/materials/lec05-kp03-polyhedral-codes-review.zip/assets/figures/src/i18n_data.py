# English content for the monolingual English deck
LABEL_EN = ["More lines: enough?", "Seven cells", "Why 101 never occurs", "Codes are corners", "Score every corner", "Region A has a notch",
            "Bottom face is XOR", "Shared midpoint", "One more layer helps", "Extension: practice", "Extension: general"]
TERM_EN = {"term:位元": "term:Bit", "term:階梯規則": "term:Step rule", "term:編碼": "term:Code", "term:區域": "term:Cell",
           "term:虛擬碼": "term:Unrealized code", "term:頂點": "term:Vertex", "term:輸出分數": "term:Output score",
           "term:線性可分": "term:Linearly separable", "term:凸": "term:Convex", "term:聯集": "term:Union", "term:不可分": "term:Nonseparable",
           "term:超立方體": "term:Hypercube"}
UNIT_TITLE_EN = "Codes and limits"
DECK_TITLE_EN = "Pattern Recognition, Chapter 4, KP03: Codes of several lines and the limit of two layers (undergraduate, self-study)"
LEVEL_NOTE_EN = ("Level: undergraduate (year 3). Main line 9 pages, about 36 minutes, plus 2 extension pages (not timed). Self-study deck, English version. "
                 "Rewritten under CLARITY.md C12 to C18: plain words before terms, titles that state the point, pages linked by questions, a figure on every spatial page. "
                 "These notes are public with the file and contain no student IDs, grades or exam questions.")
OVR = {
 (1, "term:位元"): "**Bit**: a point on the positive side of a line (score $>0$) gets 1, otherwise 0.",
 (1, "term:階梯規則"): "**Step rule**: a positive score gives 1, otherwise 0.",
 (1, "q"): "**Today**: what do three lines cut, and what can the last layer (the output layer) do?",
 (2, "term:編碼"): "**Code**: the three bits $y_1y_2y_3$ of a point, written in a row like a house number.",
 (2, "term:區域"): "**Cell**: all points that share one code form one piece of the plane.",
 (2, "ex"): "**Take the point (1,1)**: the scores $g_1=x_1,\\ g_2=x_2,\\ g_3=-x_1+x_2-1$ are $1,\\ 1,\\ -1$, so the bits are $1,\\ 1,\\ 0$ and the code is **110**.",
 (2, "q"): "Three bits allow 8 codes, but the plane shows only 7 cells: which one is missing?",
 (2, "bridge"): "A point on the positive side of a line gets one bit. So what does the plane look like when three lines cut it together?",
 (3, "bridge"): "Three bits allow eight codes, yet the plane shows only seven cells. Why can no point receive 101?",
 (6, "bridge"): "By the corner scores, one plane puts all of A on one side and all of B on the other. Back in the input plane, what does region A look like?",
 (11, "bridge"): "Changing only a3 did not remove the contradiction, and relabeling 101 changed nothing. How is the code written for p lines and d dimensions?",
 (3, "c1"): "**① Bit 1 is 1**: we need $x_1>0$ (right of the vertical line).",
 (3, "c2"): "**② Bit 2 is 0**: we need $x_2\\leq0$ (on or below the horizontal line).",
 (3, "c3"): "**③ Bit 3 is 1**: we need $x_2>x_1+1$ (above the slanted line), but ① and ② already force $x_2\\leq0<x_1+1$.",
 (3, "term:虛擬碼"): "The three regions share no point: **101** is an **unrealized code**, writable but received by no input. The other seven are **realized codes**.",
 (4, "term:頂點"): "**Vertex**: a corner of the cube. A 3-bit code gives its coordinates $(y_1,y_2,y_3)$; there are 8 of them.",
 (4, "term:輸出分數"): "**Output score**: $q=a_1y_1+a_2y_2+a_3y_3+a_0$. $q>0$ means class A, otherwise class B (A and B are the two class labels).",
 (4, "cut"): "The output layer is the plane $q=0$ (an example in the figure): **one cut** that splits the corners into two sides.",
 (5, "bridge"): "The output plane scores every corner with $q$. With $q=-y_1-y_2+y_3+0.5$, are the seven realized corners separated?",
 (5, "A"): "**Class A (blue, $q>0$)**\n000: $-0-0+0+0.5=0.5$\n001: $-0-0+1+0.5=1.5$\n011: $-0-1+1+0.5=0.5$",
 (5, "B"): "**Class B (orange, $q\\leq0$)**\n010: $-0-1+0+0.5=-0.5$\n100: $-1-0+0+0.5=-0.5$\n110: $-1-1+0+0.5=-1.5$\n111: $-1-1+1+0.5=-0.5$",
 (5, "term:線性可分"): "**Linearly separable**: one plane puts all of A on one side and all of B on the other.",
 (6, "term:凸"): "**Convex**: for any two points of the region, the segment between them stays inside.",
 (6, "term:聯集"): "**Union**: several cells merged into one region.",
 (6, "end"): "$P(-0.15,-1)$ and $Q(-0.15,2)$ both lie in region A, yet segment $PQ$ passes through the B cell at $R$: region A is **not convex**. But can any cells be merged?",
 (7, "end"): "Look at the bottom face $y_3=0$ only: its four corners are realized codes, with A on one diagonal and B on the other, just like the XOR of KP01. This labelling is **nonseparable**: it is a **counterexample**.",
 (8, "bridge"): "The bottom face alternates A and B. Since $y_3=0$, $a_3$ plays no role: can any $a_0,a_1,a_2$ separate them?",
 (8, "s1"): "**① Add the A corners**: $q(000)+q(110)=a_0+(a_1+a_2+a_0)$\n$=a_1+a_2+2a_0>0$\nTwo positive scores add up to a positive sum.",
 (8, "s2"): "**② Add the B corners**: $q(010)+q(100)=(a_2+a_0)+(a_1+a_0)$\n$=a_1+a_2+2a_0\\leq0$\nTwo nonpositive scores add up to a nonpositive sum.",
 (8, "s3"): "**③ Contradiction**: one sum cannot be both $>0$ and $\\leq0$. Since $q$ is linear, the score at the midpoint $M$ is the average of both pairs, so the two demands conflict.",
 (9, "bridge"): "One sum had to be both $>0$ and $\\leq0$. Is a single output plane hopeless, or can it be repaired?",
 (9, "c1"): "**Answer to page 1**: one output plane cannot separate every labelling (a two-layer network is a row of lines plus one output plane).",
 (9, "c2"): "**But it can be repaired**: any single corner can be cut off. Cut 000, 110 and 111 one by one (right figure) and merge the results to get A.",
 (9, "c3"): "**Next KP**: how can one more layer pick out chosen corners?",
 (10, "q1"): "**Question 1**: does labeling the unrealized code 101 as A or B change any prediction?",
 (10, "q2"): "**Question 2**: with A = {000, 110, 111}, can changing only $a_3$ remove the contradiction?",
 (10, "h1"): "**Hint 1**: does any input receive code 101?",
 (10, "h2"): "**Hint 2**: all four bottom-face points have $y_3=0$.",
 (10, "sol"): "**Worked solution (Question 2)**: ① Both sums equal $a_1+a_2+2a_0$. ② With $y_3=0$, the term $a_3\\cdot0$ vanishes. ③ So both sums are independent of $a_3$ and the contradiction remains. ④ Check: for $a_3=100$ both sums are unchanged.",
 (11, "f"): "$g_i(\\mathbf x)=\\mathbf w_i^T\\mathbf x+b_i,\\quad \\mathbf y=[f(g_1(\\mathbf x)),\\ldots,f(g_p(\\mathbf x))]^T\\in\\{0,1\\}^p$\n$\\mathbf x$ has $d$ coordinates; $\\mathbf w_i$ is the coefficient vector and $b_i$ the constant of line $i$; $f$ is the step rule. Each of the $p$ lines gives one bit, so a code is a corner of the unit hypercube.",
 (11, "term:超立方體"): "**Hypercube**: a cube in $p$ dimensions; its corners are the $2^p$ codes.",
}
NOTES_EN = [
 "In KP02 two lines turned XOR into three locations, and one more line separated them. This page sets out the tools. Every line gives a point a score; a positive score gives 1 and anything else gives 0, and that 0 or 1 is a bit. "
 "The positive side is simply the side where the score is positive; textbooks call it a half-space, but you need not memorize that now. On the left is the input plane and on the right a cube, and the three stars preview one idea: every point of the plane ends up at one corner of the cube. "
 "Today we settle two questions: what do three lines cut, and what can the last layer do? Next, page 2 counts how many cells three lines make. Source: Chapter 4, section 4.3.1.",
 "On the previous page we had the bit of a single line; here we lay three lines on top of each other. They cut the plane into seven cells, and the points of one cell share the same three bits, which we call the code, like a house number. "
 "Every cell is labelled with its code; points on a line follow the step rule and get 0, so a boundary belongs to the side that gets 0. Worked example at (1,1): g1 = 1, g2 = 1, g3 = -1 + 1 - 1 = -1, so the bits are 1, 1, 0. "
 "The arrows mark the positive side of each line; please find them against the formulas. Three bits allow eight codes but the plane shows seven cells, so next, page 3 chases the missing one.",
 "The previous page left us with a puzzle: eight codes, seven cells. Look at the three conditions. Bit 1 equal to 1 needs x1 > 0 and bit 2 equal to 0 needs x2 <= 0; together they put the point in the lower right, where x2 <= 0 while x1 + 1 > 1, "
 "so the third condition x2 > x1 + 1 can never hold. The four small panels draw each condition as a shaded region, and the fourth panel stacks them with no common part. This is different from data not yet collected: however many points you gather, 101 never appears. "
 "Students often mix the two up, so say it explicitly. Next, page 4 asks what the last layer does with the seven realized codes.",
 "The previous page showed that nobody gets 101, so the last layer only has to handle seven realized codes. Here we turn the three bits into a cube: 000 to 111 are exactly the eight corners, with coordinates (y1, y2, y3). "
 "The colors match the cells of page 2, for example the pink corner 011 corresponds to the upper-left cell of the plane. 101 is a hollow circle because no point lands there. "
 "The last layer is simple: it gives every corner a score q, positive means class A and otherwise class B, and q = 0 is a plane in the cube. The translucent orange plane is only an example; concrete coefficients come on the next page. A and B are the two class labels we want to separate. "
 "So the last layer is one cut through the cube. Next, page 5 asks whether one cut can separate the seven realized corners. (The cube figure is an added figure.)",
 "On the previous page we said the last layer is one cut through the cube. Here we take the source's output score q = -y1 - y2 + y3 + 0.5 and substitute corner by corner. The two cards are the arithmetic, and the figure puts every score beside its corner: "
 "the three positive corners lie above the plane and the four nonpositive ones below it. The score at 101 is a positive 0.5, but no input receives it, so it does not affect the classification. "
 "When one plane puts one class on one side and the other class on the other side, we call the labelling linearly separable. Next, page 6 turns this cut back into the input plane to see what region A looks like.",
 "The previous page's corner scores showed that one cut separates A from B. Now we bring the same cut back to the input plane: class A is the union of the cells 000, 001 and 011, class B the other four. "
 "In the left figure blue is region A and orange region B, and the right figure is the same cut. Look at the dashed line: P(-0.15,-1) and Q(-0.15,2) are both in region A, and the segment between them crosses the small orange cell 010, where the square point R(-0.15,0.62) is B. "
 "The segment leaves region A, so A is not convex. Many people think a two-layer network only classifies regions without dents; one code cell is convex, but the last layer may merge several cells and create dents. This is the turning point of the KP. "
 "Next, page 7 asks: can we merge any cells we like? (The notch figure is an added figure; its coordinates are checked by program.)",
 "The previous page showed that region A may be several cells merged together. Here we try another labelling: A = {000, 110, 111}. The left figure colors the input plane with this labelling; the four cells cut by the slanted line (000, 010, 100, 110) are at lower left, "
 "and the bottom face y3 = 0 of the cube on the right is exactly those four corners. The small figure flattens the bottom face: A at 000 and 110, B at 010 and 100, alternating along the diagonals, which is the XOR of KP01. "
 "Since the bottom face is already not separable, the whole cube cannot be separated either, so no cut works for this labelling. A counterexample is an example showing that a claim fails. "
 "Ask the students which four cells those are in the plane. Next, page 8 proves it with algebra instead of by eye.",
 "On the previous page the bottom face looked like XOR; here we prove it. Step one adds the two A corners: q(000) is a0 and q(110) is a1 + a2 + a0, so the sum is a1 + a2 + 2a0, and two positive numbers add up to a positive number. "
 "First recall that y3 = 0 on the bottom face, so a3 times 0 vanishes and a3 never appears; this is also the clue for practice question 2. Step two adds the two B corners and gets exactly the same expression a1 + a2 + 2a0, and two nonpositive numbers add up to a nonpositive number. "
 "One expression cannot be both greater than 0 and at most 0, so no a0, a1, a2 exist. Geometrically, the diagonal of A and the diagonal of B meet at the same midpoint M; q is linear, so its score at M is the average of the two A scores and also the average of the two B scores. "
 "Ask students to point at the corner that each term belongs to. Next, page 9 asks whether this ends two-layer networks.",
 "The previous page proved that one output plane cannot separate the bottom-face XOR. This page states the lesson precisely: a two-layer network is a row of lines (the hidden layer) plus one output plane (the output layer), and what was blocked is this one plane, not every network. "
 "The repair is in the right figure: any single corner can be cut off by a plane, and the three green planes cut off 000, 110 and 111. Target A is those three corners, so we cut each one and merge the three results, which is what adding a layer means; how to design it is left to the next KP. "
 "Today's gains: seven realized codes, one cut through the cube, and the XOR counterexample on the bottom face. Next we move on to KP04 and the design of the extra layer.",
 "The previous page said the limit comes from these lines plus one output plane. Here you check it yourself. For question 1 the key is that 101 has no preimage, so labelling it A or B changes no prediction on inputs. "
 "Question 2 comes with a full worked solution: write the two sums symbolically, put y3 = 0 on the bottom face so a3 times 0 vanishes, hence both sums are independent of a3 and the contradiction remains; then check with a3 = 100, where both sums do not change. "
 "Let students try question 1 first and then read the hint; for question 2 let them change a3 and see what happens before comparing. Next comes the last extension page, which generalizes three lines to p lines.",
 "Three lines were the simplest example. A general hidden layer has p neurons and the input has d coordinates. Each line's score is w times x plus b, the step rule turns it into a bit, and p bits form a p-bit code, a corner of a p-dimensional cube. "
 "The figure shows p = 1, 2, 3: two end points of a segment, four corners of a square, eight corners of a cube, and the number of corners is 2 to the power p. The cube contains continuous points, but the step rule only outputs corners and never fills the inside. "
 "This generalizes the earlier pages and the main line does not need it. Next you can go to KP04 to see how the extra layer is designed.",
]
ALT_EN = {
 "two-spaces": "Left: the input plane cut into seven cells by three lines, each cell labelled with a 3-bit code. Right: the eight corners of the cube of codes. Three stars show points of the plane mapped to the corners with the same code.",
 "regions": "The three lines g1 = x1 = 0, g2 = x2 = 0 and g3 = -x1 + x2 - 1 = 0 cut the plane into seven cells labelled with their 3-bit codes; arrows mark the positive side of each line; stars mark the points (1,1) and (-1,1).",
 "no101": "Four panels: the region y1 = 1 (x1 > 0), the region y2 = 0 (x2 <= 0), the region y3 = 1 (x2 > x1 + 1), and the three stacked, with no common overlap, so code 101 never occurs.",
 "cube": "The cube of codes: eight corners colored by their 3-bit codes 000 to 111 with axes y1, y2, y3; a translucent orange plane q = 0 is an example cut; 101 is a hollow circle because no input receives it.",
 "cube-cut": "The cube with the cut q = 0: class A (circles) at 000, 001 and 011 with scores 0.5, 1.5 and 0.5 on one side; class B (squares) with scores not above 0 on the other; 101 is a hollow corner.",
 "union-gap": "Left: the input plane with region A (cells 000, 001, 011, blue) and region B (the rest, orange); the segment between the A points P(-0.15,-1) and Q(-0.15,2) crosses the B point R(-0.15,0.62); dashed arrows point to corners 000, 011 and 010. Right: the same cut in the cube.",
 "plane-to-face": "Left: the input plane colored by the second labelling; the four cells 000, 010, 100, 110 cut by the slanted line alternate A and B. Right: the cube whose bottom face y3 = 0 has the same four corners, A at 000 and 110, B at 010 and 100.",
 "obstruction": "The four points of the bottom face y3 = 0: A (circles) at 000 and 110, B (squares) at 010 and 100, alternating along the diagonals.",
 "midpoint": "The two diagonals of the bottom face: the A diagonal 000-110 and the B diagonal 010-100 meet at the same midpoint M = (1/2, 1/2, 0); the four corners carry their codes and scores a0, a1 + a2 + a0, a2 + a0, a1 + a0.",
 "slice-corner": "The cube with three cut planes that put the corners 110, 111 and 000 (class A, circles) on one side and the other realized corners and 101 (class B, squares) on the other.",
 "hypercubes": "From a segment to a cube: p = 1 gives two end points, p = 2 the four corners of a square, p = 3 the eight corners of a cube; the number of codes is 2 to the power p.",
}
TITLE_EN = ["Two lines saved XOR. Is the last layer enough?", "Three lines cut seven cells, each with a code", "No point gets 101: its conditions contradict",
            "Read codes as cube corners; the output is one cut", "Score each corner: 3 A's positive, 4 B's not", "Back in the plane, region A has a notch",
            "A second labelling: XOR returns on the bottom face", "The diagonals share a midpoint: a contradiction", "Not hopeless: one cut is not enough, add a layer",
            "Extension: practice with a3 and the label 101", "Extension: p lines and d-dimensional inputs"]
