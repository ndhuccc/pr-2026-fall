# KP03 多條線的編碼與兩層網路的極限（Codes of several lines and the limit of two layers）

> 程度：大學三年級（undergrad）／Level: Undergraduate (undergrad)
>
> 圖型識別｜第四章 §4.3.1｜Pattern Recognition, Chapter 4, Section 4.3.1

[簡報閱讀與下載（Slides）](../slides/lec05-kp03-polyhedral-codes.html)

## 學習目標（Learning objectives）

- 能把三條線的正負判斷，寫成每個點的三位元編碼，並在輸入平面與立方體上找到同一個編碼。（Turn the sign decisions of three lines into a 3-bit code and find the same code in the input plane and on the cube.）
- 能說明虛擬碼為什麼沒有任何輸入，並只對實際碼檢查輸出層的可分性。（Explain why an unrealized code has no input and check separability on realized codes only.）
- 能用兩條對角線共用中點，說明一組固定的線為什麼切不開 XOR 型標籤。（Use the shared midpoint of two diagonals to explain why a fixed set of lines cannot separate an XOR-type labelling.）

## KP03 多條線的編碼與兩層網路的極限（Codes of several lines and the limit of two layers）

**一句話重點**：每個點在三條線上得到三個位元，連起來是編碼；最後一層（輸出層）是在立方體的角上切一刀，所以只要這組線讓某些編碼的標籤交錯成 XOR，這一刀就切不開。

**One-sentence summary**: Each point gets three bits from three lines, and the bits form its code. The last layer is one cut through the cube of codes, so any labelling that alternates like XOR on a face cannot be separated by it.

### 1. 兩條線救了 XOR，線再多，最後一層還夠用嗎？（Is the final layer still enough?）

**白話說明**：KP02 用兩條線把 XOR 變成三個位置，再用最後一層（輸出層，一條線或一個平面）分開。這一節先把工具擺好。

**Plain explanation**: KP02 turned XOR into three locations with two lines and separated them with one more line. We first set out the tools.

- **分數（score）**：把點代入第 $i$ 條線的式子 $g_i(\mathbf x)=\mathbf w_i^T\mathbf x+b_i$ 得到的數。
- **階梯規則（step rule）**：分數大於 0 記 1，其餘記 0（剛好等於 0 也記 0）。
- **位元（bit）**：點在線的**正側**（分數大於 0 的一側，數學上叫半空間）記 1，否則記 0。

圖解 `lec05-kp03-two-spaces`：左邊是輸入平面，右邊是三位元編碼的立方體。每個點最後都會住進立方體的一個角，三個星號示範這個對應。

![輸入平面與編碼立方體（The input plane and the code cube）](../assets/figures/lec05-kp03-two-spaces.png)

Figure `lec05-kp03-two-spaces`: The input plane is on the left and the cube of 3-bit codes on the right. Every point ends up at one corner of the cube; the three stars show this mapping.

### 2. 三條線切出七塊地，每塊有自己的編碼（Seven cells, each with its own code）

**正式定義與例子［補充］**：輸入維度 $d$，隱藏層有 $p$ 條線（一般寫法見延伸）。這裡用三條線，係數為教學選擇，非原圖方程式：

$$
g_1=x_1,\qquad g_2=x_2,\qquad g_3=-x_1+x_2-1.
$$

- **編碼（code）**：一個點的三個位元連起來，像它的門牌。
- **區域（cell）**：拿到同一個編碼的所有點，合起來是一塊地。

**例子**：點 $(1,1)$ 的分數依序是 $g_1=1$、$g_2=1$、$g_3=-1+1-1=-1$，位元是 $1,1,0$（$-1\le0$ 記 0），所以編碼是 **110**。

**Example**: At $(1,1)$ the scores are $1$, $1$ and $-1$, so the bits are $1,1,0$ and the code is **110**.

![三條線形成七個實際編碼（Three boundaries produce seven realized codes）](../assets/figures/lec05-kp03-regions.png)

圖說 `lec05-kp03-regions`：先看三條橘色邊界和旁邊的箭頭（箭頭指向分數為正的一側），再讀每一塊的三位元編碼。七種編碼出現，101 不出現。線上的點依階梯規則記 0。

Figure `lec05-kp03-regions`: Read the three orange boundaries and the arrows toward the positive sides, then the code of each cell. Seven codes occur and 101 does not. Points on a line follow the step rule and receive 0.

### 3. 101 沒人拿得到：三個條件互相矛盾（Why no point receives 101）

三位元能寫 8 種編碼，圖上只有 7 塊。編碼 101 要求同時滿足：

1. 第 1 位是 1：$x_1>0$。
2. 第 2 位是 0：$x_2\le0$。
3. 第 3 位是 1：$x_2>x_1+1$。

①② 讓 $x_1>0$、$x_2\le0$，所以 $x_2\le0<x_1+1$，③ 不可能成立。

Conditions 1 and 2 give $x_2\le0<x_1+1$, so condition 3 cannot hold.

![三個條件沒有共同部分（The three conditions do not overlap）](../assets/figures/lec05-kp03-no101.png)

圖說 `lec05-kp03-no101`：前三格各畫出一個條件的區域，第四格把三塊疊起來，沒有共同的部分。

- **實際碼（realized code）**：至少有一個輸入點會得到的編碼（7 個）。
- **虛擬碼（unrealized code）**：寫得出來，卻沒有任何輸入點得到的編碼（101）。

這**不是**「資料還沒蒐集到」：不論蒐集多少點，101 都不會出現。

This is **not** "data not yet collected": no amount of data produces 101.

### 4. 把編碼看成立方體的角，最後一層是切一刀（Codes are corners; the last layer is a cut）

三位元的 8 種編碼，正好是立方體 8 個角的座標 $(y_1,y_2,y_3)$。位元更多時，就是更高維的立方體（超立方體）。立方體裡有連續的點，但階梯規則只會輸出角，不會填滿內部。

![編碼立方體（The code cube）](../assets/figures/lec05-kp03-cube.png)

圖說 `lec05-kp03-cube`：顏色與第 2 節平面上各區域相同；101 是空心圓，沒有輸入會到達。［補充圖］

**輸出分數（output score）**：

$$
q(\mathbf y)=a_1y_1+a_2y_2+a_3y_3+a_0,
$$

$q>0$ 判 A，否則判 B。$a_i$ 是每一位的票數，$a_0$ 是起始分。$q=0$ 是立方體裡的一個**平面**：把角分成兩邊，這就是切一刀。條件只需對實際碼成立；對虛擬碼的標籤不會改變任何輸入的預測。

### 5. 逐角計分：這一刀切得開（The cut separates the first labelling）

沿用講義的輸出式 $q=-y_1-y_2+y_3+0.5$，一個角一個角代入：

| 角 | 代入 | $q$ | 類別 |
|---|---|---:|---|
| 000 | $-0-0+0+0.5$ | 0.5 | A |
| 001 | $-0-0+1+0.5$ | 1.5 | A |
| 011 | $-0-1+1+0.5$ | 0.5 | A |
| 010 | $-0-1+0+0.5$ | −0.5 | B |
| 100 | $-1-0+0+0.5$ | −0.5 | B |
| 110 | $-1-1+0+0.5$ | −1.5 | B |
| 111 | $-1-1+1+0.5$ | −0.5 | B |

101 的分數是 $-1-0+1+0.5=0.5$，但沒有輸入會得到它，不影響分類。A 全在平面一側、B 全在另一側，叫**線性可分**。

![切面 q=0 與各角分數（The cut q=0 and the corner scores）](../assets/figures/lec05-kp03-cube-cut.png)

圖說 `lec05-kp03-cube-cut`：A（圓點）在切面上方，B（方點）在下方；每個角旁標出編碼與分數。

### 6. 翻回平面：A 區是三塊併成的，中間有缺口（Back in the plane: a notch）

A 類是 000、001、011 三塊地的**聯集**（把幾塊區域併成一塊）。**凸**的意思是：區域內任取兩點，連線都不跑出區域。取 $P(-0.15,-1)$ 與 $Q(-0.15,2)$，兩點都在 A 區，連線 $PQ$ 卻經過 B 塊的點 $R(-0.15,0.62)$：A 區**不是凸的**［補充］。

Take the A points $P(-0.15,-1)$ and $Q(-0.15,2)$: the segment $PQ$ crosses the B point $R(-0.15,0.62)$, so region A is not convex [Added].

![A 區是三塊併成的（Region A is three cells joined）](../assets/figures/lec05-kp03-union-gap.png)

圖說 `lec05-kp03-union-gap`：左邊藍色是 A 區、橘色是 B 區，虛線是兩個 A 點的連線；右邊是同一刀切過的立方體。

**常見迷思**：單一編碼的區域是凸的，所以兩層網路只會分類凸區域。前半句成立，後半句不成立：最後一層可以接受多個編碼，其區域是多塊的聯集，可以有缺口，甚至不連通。

### 7. 換一組標籤：底面四個角 A、B 交錯，XOR 又出現了（A second labelling fails）

改成 A＝{000, 110, 111}，其餘為 B。立方體底面（$y_3=0$）的四個角：A 在 000 與 110，B 在 010 與 100，沿對角交錯。在輸入平面上，這四個角就是兩條座標軸切出的四個象限，和 KP01 的 XOR 一樣：**不可分**，也是一個**反例**。

![平面與立方體底面（The plane and the bottom face）](../assets/figures/lec05-kp03-plane-to-face.png)

![底面四個角（The four bottom corners）](../assets/figures/lec05-kp03-obstruction.png)

圖說 `lec05-kp03-plane-to-face`、`lec05-kp03-obstruction`：左圖依第二組標籤上色；右上是立方體，底面四個角塗成同樣的顏色；右下把底面攤平，A 在 000、110，B 在 010、100。

### 8. 證明：兩條對角線共用中點（Proof by the shared midpoint）

1. 兩個 A 角相加：$q(000)+q(110)=a_0+(a_1+a_2+a_0)=a_1+a_2+2a_0>0$。
2. 兩個 B 角相加：$q(010)+q(100)=(a_2+a_0)+(a_1+a_0)=a_1+a_2+2a_0\le0$。
3. 同一個式子既要 $>0$ 又要 $\le0$，矛盾，所以任何 $a_0,a_1,a_2$ 都切不開。

幾何意思：A 的對角線（000—110）與 B 的對角線（010—100）交於中點 $M=(\tfrac12,\tfrac12,0)$。$q$ 是線性的，所以 $q(M)=\frac{a_1+a_2+2a_0}{2}$ 既是兩個 A 分數的平均（正），也是兩個 B 分數的平均（非正）。

![兩條對角線共用中點（The diagonals share a midpoint）](../assets/figures/lec05-kp03-midpoint.png)

### 9. 不是網路不行，是這一刀不夠：再加一層就行（Not hopeless: one more layer）

**兩層網路**＝一排線（隱藏層）＋一個輸出平面（輸出層）。被擋住的是「這組固定的線，加上這一刀」，不是所有兩層網路：換一組線，編碼不同，反例也會不同。補救的直覺：任何一個角都能用一個平面單獨切下來，所以對每個目標角各切一刀、再把結果併起來，就能認出任何一組目標角，這就是再加一層。

![切下單一個角（Cutting off a single corner）](../assets/figures/lec05-kp03-slice-corner.png)

圖說 `lec05-kp03-slice-corner`：平面 $y_1+y_2-y_3=1.5$ 只把角 110 切到一側。［補充圖］

### 延伸：一般寫法（General form）

輸入有 $d$ 個座標，有 $p$ 條線：

$$
\mathbf y=[f(g_1(\mathbf x)),\ldots,f(g_p(\mathbf x))]^T\in\{0,1\}^p,\qquad f(t)=\begin{cases}1,&t>0,\\0,&t\le0.\end{cases}
$$

$\{0,1\}^p$ 有 $2^p$ 個角，是 $p$ 維**超立方體**的角。

![從線段到立方體（From a segment to a cube）](../assets/figures/lec05-kp03-hypercubes.png)

### 小練習（Practice）

**小練習**：

1. 把虛擬碼 101 指定為 A 或 B，輸入上的預測會變嗎？提示：先問有沒有輸入點會得到 101。
2. 第二組標籤中，只改 $a_3$，能消除底面四點的矛盾嗎？提示：底面四個點的 $y_3$ 都是 0。

**題 2 解題示範**：①符號式：兩個和都是 $a_1+a_2+2a_0$。② 代入 $y_3=0$：$a_3\cdot0=0$，$a_3$ 消失。③ 結果：兩個和與 $a_3$ 無關，矛盾依舊。④ 檢查：取 $a_1=a_2=0,\ a_0=1$，四個角的分數都是 1，B 被判成 A，與 $a_3$ 無關。

Hint and worked solution (Q2): $y_3=0$ removes $a_3$ from both sums, so changing $a_3$ cannot remove the contradiction.

## 術語與來源（Terminology and source）

| 中文 | English |
|---|---|
| 位元（半空間＝直線的正側） | Bit (half-space = positive side of a line) |
| 階梯規則 | Step rule |
| 編碼、區域 | Code, cell |
| 實際碼、虛擬碼 | Realized code, unrealized code |
| 頂點（超立方體的角） | Vertex (corner of a hypercube) |
| 輸出分數、線性可分 | Output score, linearly separable |
| 凸、聯集 | Convex, union |
| 不可分、反例 | Nonseparable, counterexample |

來源：第四章 KP03，§4.3.1（2026-10-24 讀取）。輸出式與兩組標籤保留來源設定；三條具體輸入邊界、立方體圖、缺口圖與切角圖、中點證明為［補充］，用於驗證原主張。

Source: Chapter 4, KP03, Section 4.3.1, accessed 2026-10-24. The output score and both label sets follow the source; the explicit input boundaries, the cube, notch and corner-cut figures, and the midpoint proof are [Added] checks of its claims.
