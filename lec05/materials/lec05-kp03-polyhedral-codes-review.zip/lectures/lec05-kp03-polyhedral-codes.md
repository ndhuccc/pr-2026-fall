# KP03 多面體編碼與兩層網路的能力邊界（Polyhedral codes and the limits of two-layer networks）

> 程度：大學三年級（undergrad）／Level: Undergraduate (undergrad)
>
> 圖型識別｜第四章 §4.3.1｜Pattern Recognition, Chapter 4, Section 4.3.1

[簡報閱讀與下載（Slides）](../slides/lec05-kp03-polyhedral-codes.html)

## 學習目標（Learning objectives）

- 能把半空間的正負組合轉成二元編碼。（Convert half-space sign patterns into binary codes.）
- 能辨認虛擬頂點，檢查輸出層的可分條件。（Identify unrealized vertices and check output separability.）
- 能用具體反例說明固定隱藏表示的限制。（Explain a fixed hidden representation's limitation with a concrete counterexample.）

## KP03 多個邊界先編碼，單一輸出仍有極限（Multiple boundaries encode regions, but one output still has limits）

**一句話重點**：隱藏層把每個輸入區域映到一個二元頂點；輸出層能否完成分類，取決於實際出現的頂點能否線性分開。

**One-sentence summary**: The hidden layer maps each input cell to a binary vertex. Classification succeeds only if the realized labeled vertices are linearly separable at the output.

### 從兩條線推廣到多個半空間（From two lines to several half-spaces）

**白話說明**：KP02 的每個隱藏輸出只記錄一個正負判斷。增加隱藏神經元，就是增加這類判斷。一個區域中的點若對所有判斷都回答相同，就得到同一編碼。

**Plain explanation**: Each hidden output in KP02 retained one sign decision. More hidden neurons add more such decisions. Points that answer every decision identically receive the same code.

**正式定義**：輸入維度為 $l$，隱藏層有 $p$ 個神經元；分數為 $g_i(\mathbf{x})=\mathbf{w}_i^T\mathbf{x}+b_i$。採 $f(t)=1$ 當 $t>0$，其餘為 $0$。

**Formal definition**: Inputs have dimension $l$, and there are $p$ hidden neurons with scores $g_i(\mathbf{x})=\mathbf{w}_i^T\mathbf{x}+b_i$. The step function is 1 for positive arguments and 0 otherwise.

$$
\mathbf{y}=[f(g_1(\mathbf{x})),\ldots,f(g_p(\mathbf{x}))]^T\in\{0,1\}^p.
$$

來源以單位超立方體描述編碼空間。整個立方體包含連續值，但階梯輸出只落在頂點，不會填滿內部。

The source describes the code space using the unit hypercube. The cube contains continuous points, but step outputs occupy only its vertices.

$$
H_p=[0,1]^p,\qquad \operatorname{Vert}(H_p)=\{0,1\}^p.
$$

| 符號 | 中文意義 | English meaning |
|---|---|---|
| $l,p,i$ | 輸入維度、隱藏節點數、節點索引 | Input dimension, hidden width, and neuron index |
| $\mathbf{w}_i,b_i$ | 第 $i$ 個超平面的權重向量與偏置 | Weight vector and bias of hyperplane $i$ |
| $\mathbf{y},H_p$ | 二元編碼與單位超立方體 | Binary code and unit hypercube |
| $\mathcal{C}(\mathbf{v})$ | 具有編碼 $\mathbf{v}$ 的輸入區域 | Input cell with code $\mathbf{v}$ |

每個編碼對應若干半空間的交集。因此，單一編碼的原像是凸的多面體區域，也可能是空集合。邊界用固定的零分規則分配；幾何示範主要看邊界外的區域。

Each code corresponds to an intersection of half-spaces. Its preimage is a convex polyhedral cell or the empty set. Boundaries follow the fixed tie rule; the geometric illustrations focus on points away from them.

### 實際區域與虛擬頂點（Realized cells and virtual vertices）

**例子［補充］**：為把來源的「101 可能不出現」具體化，選擇下列三個分數。這些係數是教學補充，不冒稱原圖的精確方程式。

**Example [Added]**: To make the source's missing code 101 concrete, use the following scores. These coefficients are an instructional construction, not a reconstruction of the original figure's exact equations.

$$
g_1=x_1,\qquad g_2=x_2,\qquad g_3=-x_1+x_2-1.
$$

編碼 101 要求 $x_1>0$、$x_2\leq0$，卻又要求 $-x_1+x_2-1>0$。前兩條已使第三個分數嚴格小於零，所以 101 沒有實際輸入。它是虛擬頂點，不是「資料還沒蒐集到」的區域。

Code 101 requires $x_1>0$ and $x_2\leq0$, yet also requires $-x_1+x_2-1>0$. The first two conditions force the third score to be negative. Thus 101 is unrealized, not merely missing from a finite dataset.

![三條邊界形成七個實際編碼（Three boundaries produce seven realized codes）](../assets/figures/lec05-kp03-regions.png)

圖說 `lec05-kp03-regions`：先看三條橘色邊界，再逐區讀三位元標籤。七種碼出現在不同區域，101 不出現。線上點依階梯的平手規則處理。

Figure `lec05-kp03-regions`: Inspect the three orange boundaries before reading each cell's three-bit label. Seven codes occur; 101 does not. Points on boundaries follow the step tie rule.

### 在頂點空間再做一次線性分類（Another linear decision in vertex space）

輸出分數可寫成 $q(\mathbf{y})=a_1y_1+\cdots+a_py_p+a_0$，正分判 A，其餘判 B。條件只需對實際頂點成立；對空集合的標籤不會改變任何輸入的預測。

The output score is $q(\mathbf{y})=a_1y_1+\cdots+a_py_p+a_0$, with positive scores assigned to A. Only realized vertices impose classification constraints. Labeling an empty preimage changes no input prediction.

沿用來源的輸出式：

Use the source's output score:

$$
q(\mathbf{y})=-y_1-y_2+y_3+0.5.
$$

| 頂點 Vertex | 代入 Substitution | 分類 Class |
|---|---|---|
| 000 | $-0-0+0+0.5=0.5$ | A |
| 001 | $-0-0+1+0.5=1.5$ | A |
| 011 | $-0-1+1+0.5=0.5$ | A |
| 010 | $-0-1+0+0.5=-0.5$ | B |
| 100 | $-1-0+0+0.5=-0.5$ | B |
| 110 | $-1-1+0+0.5=-1.5$ | B |
| 111 | $-1-1+1+0.5=-0.5$ | B |

101 的分數是 $-1-0+1+0.5=0.5$，但它沒有原像，所以不影響上述區域的分類。這正是區分整個超立方體與實際編碼集合的用途。

The score at 101 is $-1-0+1+0.5=0.5$, but its preimage is empty, so it does not affect the realized-region classification. This is why the full hypercube must be distinguished from realized codes.

### 為什麼某些聯集仍然做不到（Why some unions remain impossible）

將 A 類改為來源另一組標籤 $\{000,110,111\}$，其餘實際頂點為 B。只看 $y_3=0$ 的四個頂點就能證明輸出不可分。

Change class A to the source's alternative set $\{000,110,111\}$, assigning other realized vertices to B. Four vertices on the face $y_3=0$ already prove nonseparability.

![立方體一個面上的交錯標籤（Alternating labels on one face of the cube）](../assets/figures/lec05-kp03-obstruction.png)

圖說 `lec05-kp03-obstruction`：橫縱軸是 $y_1,y_2$，所有點的 $y_3=0$。A 位於 000 與 110，B 位於 010 與 100；這個四點子問題已產生衝突。

Figure `lec05-kp03-obstruction`: Axes are $y_1,y_2$, with $y_3=0$ for all points. A occupies 000 and 110; B occupies 010 and 100. This four-point subproblem already creates a conflict.

1. A 的分數需滿足 $q(000)+q(110)=a_1+a_2+2a_0>0$。（The sum of the two A scores must be positive.）
2. B 的分數需滿足 $q(010)+q(100)=a_1+a_2+2a_0\leq0$。（The sum of the two B scores must be nonpositive.）
3. 同一個和被要求同時為正與非正，所以單一輸出不可能完成這組標籤。（The identical sum cannot satisfy both requirements, ruling out one linear output.）

這個限制針對已固定的隱藏映射；不表示換一組隱藏邊界、改變寬度後，任何兩層模型仍必定失敗。

This limitation concerns the fixed hidden mapping. It does not say that all alternative hidden boundaries or widths must fail on the same original-input task.

### 不要把 AND 構造誤當成全部能力（Do not confuse an AND construction with the whole model class）

**常見迷思**：單一編碼區域是凸的，所以兩層網路只會分類凸區域。前半句不代表後半句；輸出可以接受多個編碼，其原像是多個區域的聯集。

**Common misconception**: Because one code cell is convex, a two-layer network can classify only convex regions. The conclusion does not follow: the output may accept multiple codes, whose preimage is a union of cells.

來源互動說明將 AND 的凸區域構造寫得過於一般。正確說法是：用 AND 檢查所有半空間，只會得到一個凸交集；一般加權輸出不限定為 AND。兩層網路能表示某些非凸或不連通聯集，但對固定編碼不保證任意聯集都可分。

The source's interactive explanation overgeneralizes the convex AND construction. An AND of half-space tests produces one convex intersection, but a general weighted output need not be AND. Some nonconvex or disconnected unions are representable; arbitrary unions of fixed codes are not guaranteed.

**小練習**：若將虛擬頂點 101 指定為 A 或 B，輸入上的預測有何差別？提示：先問其原像是否為空。另一題：在反例中只改 $a_3$，能解決四點矛盾嗎？提示：四點的 $y_3$ 都是零。

**Practice**: Does assigning virtual vertex 101 to A or B change input predictions? Hint: examine its preimage. Can changing only $a_3$ resolve the four-point contradiction? Hint: all four points have $y_3=0$.

下一步不是強迫同一個輸出找到不存在的直線，而是增加能辨認個別頂點的層。

The next step is to add a layer that recognizes individual vertices, rather than force one output to find a nonexistent separator.

## 術語與來源（Terminology and source）

| 中文 | English |
|---|---|
| 半空間 | Half-space |
| 多面體區域 | Polyhedral cell |
| 單位超立方體 | Unit hypercube |
| 虛擬頂點／虛擬多面體 | Unrealized vertex / virtual polyhedron |
| 原像 | Preimage |

來源：[第四章 KP03，§4.3.1](https://ndhuccc.github.io/CCC-LNS/PR_115/Ch04-nonlinear-classifiers/index.html#kp3)，2026-10-24 讀取。輸出式與兩組標籤保留來源設定；三條具體輸入邊界與四點矛盾的展開為［補充］，用於驗證原主張。

Source: Chapter 4, KP03, Section 4.3.1, accessed 2026-10-24. Output scores and label sets follow the source. The explicit input boundaries and expanded four-point proof are [Added] checks of its claims.
