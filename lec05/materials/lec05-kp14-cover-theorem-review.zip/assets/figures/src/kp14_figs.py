import os, sys, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums14 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")

def f_dichotomy():
    w, h = 540, 470
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    sq = [(0, 0), (0, 1), (1, 0), (1, 1)]; bad = {(1, -1, -1, 1), (-1, 1, 1, -1)}
    for i, lab in enumerate(itertools.product([1, -1], repeat=4)):
        r, c = divmod(i, 4); x0 = 12 + c * 132; y0 = 12 + r * 108; ok = lab not in bad
        ax.add_patch(Rectangle((x0, y0), 120, 96, fc="none", ec=GRN if ok else RED, lw=2.8 if not ok else 1.8))
        for (px, py), l in zip(sq, lab):
            cx = x0 + 32 + px * 56; cy = y0 + 22 + py * 52
            ax.plot([cx], [cy], "o" if l > 0 else "s", color=A_C if l > 0 else B_C, ms=11)
    ax.text(270, 448, "green: one line separates · red: no line (XOR, XNOR)", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    save(fig, "lec05-kp14-dichotomy")

def f_count():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    for x, t in zip((60, 220, 400), ("N", "O(N, 2)", "2^N  (all labelings)")): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center")
    for i, n in enumerate(range(1, 9)):
        y = 70 + i * 44; o = N.O(n, 2); a = 2 ** n
        for x, t, c in zip((60, 220, 400), (str(n), str(o), str(a)), (TXT, GRN if o == a else RED, MUT)): ax.text(x, y, t, color=c, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
    ax.text(270, 428, "green: every labeling separable (N ≤ l + 1 = 3)", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp14-count")

def f_prob():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 232); axstyle(ax)
    ns = np.arange(1, 11); ps = [N.P(int(n), 2) for n in ns]
    ax.bar(ns, ps, color=[GRN if n <= 3 else A_C for n in ns], width=0.65)
    for n, p in zip(ns, ps): ax.text(n, p + 0.02, f"{p:.3f}".rstrip("0").rstrip(".") if p < 1 else "1", color=TXT, fontsize=fpx(13), ha="center", fontweight="bold")
    ax.set_xticks(ns); ax.set_ylim(0, 1.15); ax.set_xlabel("number of points N  (l = 2)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("P", color=TXT, fontsize=fpx(16), rotation=0, labelpad=12)
    cap(fig, h, [(345, "P = O(N, 2) / 2^N  for random labels", TXT, 18, True), (385, "N = 4: 0.875,   N = 6: exactly 0.5", RED, 18, True)])
    save(fig, "lec05-kp14-prob")

def f_curves():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 232); axstyle(ax)
    cols = [MUT, A_C, TEAL2, VIO2, RED]
    for l, c in zip((1, 3, 7, 19, 99), cols):
        Ns = np.arange(1, int(3.2 * (l + 1)) + 1); ax.plot(Ns / (l + 1), [N.P(int(n), l) for n in Ns], color=c, lw=2.6, label=f"l = {l}")
    ax.plot([2], [0.5], "o", color=TXT, ms=11, zorder=5); ax.axvline(2, color=MUT, ls=(0, (4, 3)), lw=1.2)
    ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlim(0.1, 3.2); ax.set_ylim(-0.03, 1.05)
    ax.set_xlabel("r = N / (l + 1)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("P", color=TXT, fontsize=fpx(16), rotation=0, labelpad=12)
    cap(fig, h, [(350, "every curve passes through (r, P) = (2, 1/2)", TXT, 18, True), (388, "r = 2.5:  l = 1 → 0.31,   l = 19 → 0.08,   l = 99 → 0.0007", MUT, 15, False)])
    save(fig, "lec05-kp14-curves")

def f_mc():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 80, 25, 430, 255); axstyle(ax)
    th = [0.875, 0.5]; mc = [0.865, 0.503]; x = np.arange(2)
    ax.bar(x - 0.2, th, width=0.36, color=A_C, label="formula"); ax.bar(x + 0.2, mc, width=0.36, color=RED, label="simulation (1500 runs)")
    for i in range(2): ax.text(i - 0.2, th[i] + 0.03, f"{th[i]:.3f}", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold"); ax.text(i + 0.2, mc[i] + 0.03, f"{mc[i]:.3f}", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.set_xticks(x); ax.set_xticklabels(["N = 4", "N = 6"], fontsize=fpx(17)); ax.set_ylim(0, 1.2); ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper right")
    ax.set_ylabel("P (separable)", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "random 2-D points, random ± labels", TXT, 18, True), (382, "an LP checks whether a separating line exists", MUT, 16, False)])
    save(fig, "lec05-kp14-mc")

def f_lift():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 80, 25, 430, 255); axstyle(ax)
    v = [0.494, 1.0]; ax.bar([0, 1], v, color=[RED, GRN], width=0.5)
    for i in range(2): ax.text(i, v[i] + 0.03, f"{v[i]:.3f}", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.set_xticks([0, 1]); ax.set_xticklabels(["original\n(x₁, x₂)  l = 2", "quadratic\nl = 5"], fontsize=fpx(16)); ax.set_ylim(0, 1.2); ax.set_ylabel("P (separable)", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(355, "N = 6 random points, random labels, 1500 runs", TXT, 17, True), (392, "formula: N ≤ l + 1 = 6, so P = 1", GRN, 18, True)])
    save(fig, "lec05-kp14-lift")

def f_need():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 232); axstyle(ax)
    ls = np.arange(20, 90); ax.plot(ls, [N.P(100, int(l)) for l in ls], color=A_C, lw=3)
    for l in (40, 49, 56, 60, 68): ax.plot([l], [N.P(100, l)], "o", color=RED, ms=9)
    ax.axvline(49, color=MUT, ls=(0, (4, 3)), lw=1.2); ax.text(50, 0.08, "l = 49", color=MUT, fontsize=fpx(15))
    ax.text(60.5, 0.93, "0.987 at l = 60", color=RED, fontsize=fpx(15))
    ax.set_xlabel("dimension l  (N = 100 points)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("P", color=TXT, fontsize=fpx(16), rotation=0, labelpad=12); ax.set_ylim(-0.03, 1.05)
    cap(fig, h, [(350, "N = 100:  l = 40 → 0.035,  48 → 0.42,  56 → 0.92", TXT, 16, True), (388, "l = 49 is exactly 0.5  (N = 2(l + 1))", RED, 18, True)])
    save(fig, "lec05-kp14-need")

def f_gen():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 80, 25, 430, 255); axstyle(ax)
    v = [1.0, 0.504]; ax.bar([0, 1], v, color=[GRN, RED], width=0.5)
    for i in range(2): ax.text(i, v[i] + 0.03, f"{v[i]*100:.1f}%".replace(".0%", "%"), color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.set_xticks([0, 1]); ax.set_xticklabels(["training points\n(5 points)", "new points\n(200 points)"], fontsize=fpx(16)); ax.set_ylim(0, 1.2); ax.set_ylabel("accuracy", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(355, "5 random points + random labels, quadratic features", TXT, 17, True), (392, "300 runs: always separated, new points = guessing", RED, 18, True)])
    save(fig, "lec05-kp14-gen")

def f_proof():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    for x, t in zip((60, 230, 430), ("l", "N = 2(l+1)", "O(N, l)  =  2^(2l+1)")): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center")
    for i, l in enumerate(range(1, 6)):
        y = 80 + i * 52; n = 2 * l + 2
        for x, t, c in zip((60, 230, 430), (str(l), str(n), f"{N.O(n, l)}  = 2^{2*l+1}"), (TXT, TXT, GRN)): ax.text(x, y, t, color=c, fontsize=fpx(21), ha="center", va="center", fontweight="bold")
    ax.text(270, 375, "C(2l+1, i) = C(2l+1, 2l+1−i):  the half with i ≤ l", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 410, "is exactly half of 2^(2l+1), so P = 1/2", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    save(fig, "lec05-kp14-proof")

def f_practice():
    w, h = 540, 330
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    ax.text(270, 40, "N = 5 points in general position", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 105, "O(N, l) = 2 · Σ C(N−1, i),  i = 0..l", color=TXT, fontsize=fpx(19), ha="center")
    ax.text(270, 165, "C(4, i) = 1, 4, 6, 4, 1", color=MUT, fontsize=fpx(19), ha="center")
    ax.text(270, 235, "find O and P for l = 2, then for l = 3", color=RED, fontsize=fpx(21), ha="center", fontweight="bold")
    save(fig, "lec05-kp14-practice")

def f_practice_sol():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    L = [("l = 2:  2(1 + 4 + 6)", f"= {N.O(5,2)}", TXT), ("P = 22 / 32", f"= {N.P(5,2):.4f}", A_C), ("l = 3:  2(1 + 4 + 6 + 4)", f"= {N.O(5,3)}", TXT), ("P = 30 / 32", f"= {N.P(5,3):.4f}", GRN)]
    for i, (a, b, c) in enumerate(L):
        y = 55 + i * 75; ax.text(20, y, a, color=c, fontsize=fpx(20), va="center", fontweight="bold"); ax.text(400, y, b, color=c, fontsize=fpx(22), va="center", fontweight="bold")
    ax.text(270, 365, "one more dimension: 0.6875 → 0.9375", color=MUT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp14-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try: fn()
            except Exception as e: print("FAILED", n, e)
