"""KP14 deck: from the step to the backpropagation gradient. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp14"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:二分":"term:Dichotomy","term:一般位置":"term:General position","term:相變":"term:Phase transition"})
from kp14_text import *

def side_page(u, t, fig, fx=60, cx=640, cw=580, rev=False):
    p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure(fig, fx, y); _, ids = stack(p, cx, y, cw, t["cards"]); step(p, *t["notes"])
    if rev: reveal(p, ids)
    return p

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    figs = ["dichotomy","count","prob","curves","mc","lift","need","gen","proof","practice","practice-sol"]
    for i, t in enumerate(PAGES):
        side_page(u, t, "lec05-kp14-" + figs[i], rev=(i in (9, 10)))
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
