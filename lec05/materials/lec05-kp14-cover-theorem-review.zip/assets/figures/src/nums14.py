import numpy as np, itertools
from math import comb
from scipy.optimize import linprog
def O(N, l): return 2 * sum(comb(N - 1, i) for i in range(l + 1))
def P(N, l): return 1.0 if N <= l + 1 else O(N, l) / 2 ** N
def sep_lp(F, lab):
    N, d = F.shape; A = -(lab[:, None] * np.c_[F, np.ones(N)])
    return linprog(np.zeros(d + 1), A_ub=A, b_ub=-np.ones(N), bounds=[(None, None)] * (d + 1), method="highs")
def separable(F, lab): return sep_lp(F, lab).status == 0
def count_dichotomies(F):
    N = len(F); c = 0; sep = []
    for lab in itertools.product([1, -1], repeat=N):
        ok = separable(F, np.array(lab, float)); c += ok; sep.append((lab, ok))
    return c, sep
def quad(X): return np.c_[X, X[:, 0] ** 2, X[:, 1] ** 2, X[:, 0] * X[:, 1]]
if __name__ == "__main__":
    A = np.array([[0, 0.], [0, 1], [1, 0], [1, 1]]); c, sep = count_dichotomies(A); print("square N=4 l=2:", c, "of 16, not separable:", [s for s, ok in sep if not ok])
    A3 = np.array([[0, 0.], [1, 0], [0, 1]]); print("N=3:", count_dichotomies(A3)[0], "of 8")
    print("O(N,2):", [O(N, 2) for N in range(1, 9)], "2^N", [2 ** N for N in range(1, 9)])
    print("P(N,2):", [round(P(N, 2), 4) for N in range(1, 11)])
    for l in (1, 2, 5, 20, 100): print(l, "P at r=2:", P(2 * (l + 1), l), "r=1.5:", round(P(int(1.5 * (l + 1)), l), 4), "r=2.5:", round(P(int(2.5 * (l + 1)), l), 4))
    print([O(2 * l + 2, l) == 2 ** (2 * l + 1) for l in range(1, 8)], [O(2 * l + 2, l) for l in range(1, 6)])
    rng = np.random.default_rng(1)
    for N in (4, 6):
        ok = 0; T = 1500
        for t in range(T):
            X = rng.normal(size=(N, 2)); lab = rng.choice([1., -1.], N); ok += separable(X, lab)
        print("MC l=2 N=", N, ok / T, "theory", P(N, 2))
    ok1 = ok2 = 0; T = 1500
    for t in range(T):
        X = rng.normal(size=(6, 2)); lab = rng.choice([1., -1.], 6); ok1 += separable(X, lab); ok2 += separable(quad(X), lab)
    print("lift N=6: original", ok1 / T, "quadratic", ok2 / T)
    for l in range(40, 80, 4): print("N=100 l=", l, round(P(100, l), 4))
    tr = 0; te = 0; T = 300
    for t in range(T):
        X = rng.normal(size=(5, 2)); lab = rng.choice([1., -1.], 5); r = sep_lp(quad(X), lab)
        if r.status != 0: continue
        w = r.x; Xt = rng.normal(size=(200, 2)); lt = rng.choice([1., -1.], 200); pt = np.sign(np.c_[quad(Xt), np.ones(200)] @ w)
        tr += 1; te += (pt == lt).mean()
    print("lifted separable trials", tr, "of", T, "test acc on random labels", te / tr)
