ALT = {
 "dichotomy": ("正方形四角四個點的 16 種標法：14 種綠框可用一條線分開，對角同類的 2 種紅框（XOR 與 XNOR）不行。", "The 16 labelings of the four corners of a square: 14 green boxes are separable by one line and the 2 red boxes with diagonal pairs (XOR and XNOR) are not."),
 "count": ("l=2 時 N=1 到 8 的 O(N,2) 與 2^N：2、4、8 相同；之後 14 對 16、22 對 32、32 對 64、44 對 128、58 對 256。", "O(N,2) against 2^N for l=2 and N=1 to 8: equal at 2, 4, 8; then 14 against 16, 22 against 32, 32 against 64, 44 against 128 and 58 against 256."),
 "prob": ("l=2 時 N=1 到 10 的可分機率長條圖：前三個為 1，N=4 為 0.875，N=5 為 0.688，N=6 恰為 0.5，之後降到 0.09。", "Bar chart of the probability of separable for l=2 and N=1 to 10: 1 for the first three, 0.875 at N=4, 0.688 at N=5, exactly 0.5 at N=6, down to 0.09."),
 "curves": ("l=1、3、7、19、99 的可分機率對 r=N/(l+1) 的曲線：全部通過 (2, 0.5)，維度越高轉折越陡。", "Probability of separable against r=N/(l+1) for l=1, 3, 7, 19 and 99: all pass through (2, 0.5) and the turn gets steeper with dimension."),
 "mc": ("公式與 1500 次隨機實測的比較：N=4 為 0.875 對 0.865，N=6 為 0.500 對 0.503。", "Formula against the 1500-run simulation: 0.875 against 0.865 at N=4 and 0.500 against 0.503 at N=6."),
 "lift": ("N=6 個隨機點隨機標籤的可分比例：原本二維 0.494，升到二次特徵（5 維）為 1.000。", "Fraction of separable random labelings of N=6 random points: 0.494 in the original two dimensions and 1.000 with quadratic features (5 dimensions)."),
 "need": ("N=100 時可分機率對維度 l 的 S 形曲線：l=40 為 0.035，l=49 恰為 0.5，l=60 為 0.987。", "S-shaped curve of the probability of separable against dimension l for N=100: 0.035 at l=40, exactly 0.5 at l=49 and 0.987 at l=60."),
 "gen": ("隨機標籤實驗：訓練的 5 個點 100% 分對，新的 200 個點只對 50.4%。", "Random-label experiment: the 5 training points are 100% right while 200 new points are only 50.4% right."),
 "proof": ("l=1 到 5 時 N=2(l+1) 的 O 值：8、32、128、512、2048，都等於 2^(2l+1)，並說明組合數的對稱性。", "O at N=2(l+1) for l=1 to 5: 8, 32, 128, 512, 2048, each equal to 2^(2l+1), with the symmetry of binomial coefficients explained."),
 "practice": ("練習圖：N=5 個一般位置的點，公式 O 與 C(4,i)=1,4,6,4,1，求 l=2 與 l=3 的 O 與 P。", "Practice figure: N=5 points in general position, the formula for O and C(4,i)=1,4,6,4,1; find O and P for l=2 and l=3."),
 "practice-sol": ("l=2：O=22、P=0.6875；l=3：O=30、P=0.9375。", "l=2: O=22 and P=0.6875; l=3: O=30 and P=0.9375."),
}
