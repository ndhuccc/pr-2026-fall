Pattern Recognition, Chapter 4, KP01: XOR and the limit of one line (English version)

Slides: slides/lec05-kp01-xor-en.html (offline web page, open in a browser); slides/lec05-kp01-xor-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp01-xor-en-lecture.pdf (PDF), lec05-kp01-xor-en-reading.html (offline web page), lectures/lec05-kp01-xor-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
