Pattern Recognition, Chapter 4, KP17: The universal approximation theorem (English version)

Slides: slides/lec05-kp17-universal-approx-en.html (offline web page, open in a browser); slides/lec05-kp17-universal-approx-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp17-universal-approx-en-lecture.pdf (PDF), lec05-kp17-universal-approx-en-reading.html (offline web page), lectures/lec05-kp17-universal-approx-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
