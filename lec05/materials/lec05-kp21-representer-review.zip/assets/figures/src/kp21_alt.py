ALT = {
 "sparse": ("同心環 120 個訓練點：左為 Parzen 的 120 個核，右為 SVM 只保留 19 個核（灰點係數為 0）。", "The 120 ring training points: on the left the 120 Parzen kernels, on the right the SVM keeping only 19 (grey dots have coefficient 0)."),
 "rep": ("Representer 定理：最小化資料項加 Ω(‖g‖)，最小解必為 g(x)=Σⱼ aⱼ K(x,xⱼ)，只有 N 個係數。", "The representer theorem: the minimizer of the data term plus Ω(‖g‖) is g(x)=Σⱼ aⱼ K(x,xⱼ) with only N coefficients."),
 "repcheck": ("二次核的 6 維驗證：w 與 Φᵀa 最大差 1.9e-14，預測最大差 2.2e-14。", "The 6-D check with the quadratic kernel: w and Φᵀa differ by at most 1.9e-14 and predictions by at most 2.2e-14."),
 "hand": ("兩個訓練點的核最小平方：C=0 時 g=1−2x 穿過兩個目標，C=1 時 g=0.2−0.6x 被壓向 0。", "Kernel least squares on two training points: g=1−2x passes through both targets at C=0, while g=0.2−0.6x is pulled toward 0 at C=1."),
 "sin": ("9 個有雜訊的點與 sin x：C=0 穿過每個點，C=0.1 最接近 sin，C=10 被壓平。", "Nine noisy points and sin x: C=0 passes through every point, C=0.1 is closest to sin and C=10 is flattened."),
 "csweep": ("訓練誤差與對 sin 的誤差對 C：C=0.1 對 sin 的誤差最小 0.033，C≥10 壓得太平。", "Training error and error against sin versus C: the smallest error against sin is 0.033 at C=0.1 and C≥10 flattens the curve."),
 "svcount": ("同心環上支撐向量數對 C，γ=0.01、0.5、50：γ=0.5、C=10 時 19 個；γ=50 時約 116 個。", "Support vectors against C on the rings for γ=0.01, 0.5 and 50: 19 at γ=0.5, C=10 and about 116 at γ=50."),
 "dict": ("字典法：同心環 120 點，門檻 0.7 留下 17 個（圓圈）；門檻 0.99、0.9、0.7、0.5 依序留 90、38、17、9 個。", "The dictionary method on 120 ring points: 17 kept at threshold 0.7 (circles); thresholds 0.99, 0.9, 0.7 and 0.5 keep 90, 38, 17 and 9."),
 "dense": ("支撐向量數與新點準確率表：19 個 96.9%、13 個 95.4%、120 個 94.3%、39 個 97.3%、116 個 86.8%。", "Table of support-vector counts and new-point accuracy: 19 with 96.9%, 13 with 95.4%, 120 with 94.3%, 39 with 97.3% and 116 with 86.8%."),
 "practice": ("練習圖：訓練點 x=0、1，目標 +1、−1，核 xz+1；題 1 求 C=1 的 a 與 g，題 2 與 C=0 比較。", "Practice figure: training points x=0 and 1, targets +1 and −1, kernel xz+1; question 1 finds a and g for C=1 and question 2 compares with C=0."),
 "practice-sol": ("a=(0.8,−0.6)，g(0)=0.2，g(1)=−0.4；C=0 時為 1 與 −1，C=1 把解壓向 0。", "a=(0.8,−0.6), g(0)=0.2 and g(1)=−0.4; they are 1 and −1 at C=0, so C=1 pulls the solution toward 0."),
}
