import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums21 as N
from nums21 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
Xtr, ytr = rings(60, 1, sd=0.25); Xte, yte = rings(500, 2, sd=0.25)
Kr = lambda A, B: K_rbf(A, B, 0.5)
X1, y1 = sin_data(); Xg = np.linspace(0, 2 * np.pi, 200)[:, None]; K1 = lambda A, B: gauss(A, B, 0.8)

def f_sparse():
    w, h = 540, 440; fig = new_fig(w, h); m = fit(Kr, Xtr, ytr); sv = np.zeros(len(ytr), bool); sv[m.support_] = True
    for i, x0 in enumerate((15, 280)):
        a = panel(fig, w, h, x0, 40, 245, 245); a.set_aspect("equal"); a.set_xlim(-3.2, 3.2); a.set_ylim(-3.2, 3.2); a.set_xticks([]); a.set_yticks([])
        for k in range(len(ytr)):
            col = A_C if ytr[k] < 0 else B_C
            if i == 0 or sv[k]: a.plot(Xtr[k, 0], Xtr[k, 1], "o", mfc="none", mec=col, ms=11, mew=1.6); a.plot(Xtr[k, 0], Xtr[k, 1], "o", color=col, ms=3.5)
            else: a.plot(Xtr[k, 0], Xtr[k, 1], ".", color=MUT, ms=4, alpha=0.6)
    fig.text(0.25, 1 - 22 / h, f"Parzen: all {len(ytr)} kernels", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold"); fig.text(0.75, 1 - 22 / h, f"SVM: {len(m.support_)} kernels", color=GRN, fontsize=fpx(17), ha="center", fontweight="bold")
    cap(fig, h, [(325, "same 120 centres, rings with sd 0.25 (C = 10, γ = 0.5)", TXT, 16, True), (362, "grey dots: coefficient exactly zero", MUT, 16, False), (400, f"SVM keeps {len(m.support_)} of {len(ytr)}, {acc(m, Kr, Xtr, Xte, yte)*100:.1f}% on new points", RED, 18, True)])
    save(fig, "lec05-kp21-sparse"); return len(m.support_)

def f_rep():
    fig, ax = blank(540, 400)
    T(ax, 270, 35, "minimize  Σᵢ L(g(xᵢ), yᵢ) + Ω(‖g‖)  over g in H", TXT, 17)
    T(ax, 270, 80, "L: any non-negative loss,  Ω: strictly increasing", MUT, 15, False)
    T(ax, 270, 150, "the minimizer always has the form", GRN, 18)
    T(ax, 270, 205, "g(x) = Σⱼ aⱼ K(x, xⱼ),   j = 1 … N", RED, 24)
    T(ax, 270, 275, "H may be infinite-dimensional", MUT, 17, False)
    T(ax, 270, 320, "the answer needs only N coefficients", TXT, 18)
    T(ax, 270, 365, "(one kernel centred on each training point)", MUT, 15, False)
    save(fig, "lec05-kp21-rep")

def f_repcheck():
    fig, ax = blank(540, 400)
    rng = np.random.default_rng(3); X = rng.normal(size=(30, 2)); y = rng.normal(size=30); C = 0.7
    F = phi6(X); w = np.linalg.solve(F.T @ F + C * np.eye(6), F.T @ y); a = kr_fit(K_poly, X, y, C); d1 = float(np.abs(w - F.T @ a).max()); Xs = rng.normal(size=(5, 2)); d2 = float(np.abs(phi6(Xs) @ w - kr_pred(K_poly, X, a, Xs)).max())
    T(ax, 270, 30, "quadratic kernel (xᵀz + 1)² = 6 explicit features", TXT, 16)
    T(ax, 270, 65, "30 random points, random targets, C = 0.7", MUT, 15, False)
    T(ax, 270, 130, "w  = (ΦᵀΦ + C·I)⁻¹ Φᵀ y     (in 6-D)", A_C, 17)
    T(ax, 270, 180, "a  = (K + C·I)⁻¹ y     (30 numbers)", B_C, 17)
    T(ax, 270, 245, f"max | w − Φᵀa | = {d1:.1e}", GRN, 20)
    T(ax, 270, 295, f"max | prediction gap | = {d2:.1e}", GRN, 20)
    T(ax, 270, 355, "w lies in the span of the training features", RED, 17)
    save(fig, "lec05-kp21-repcheck"); return d1, d2

def f_hand():
    w, h = 540, 420; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    x = np.linspace(-0.3, 1.3, 50); ax.plot(x, 1 - 2 * x, color=A_C, lw=3, label="C = 0:  g = 1 − 2x"); ax.plot(x, 0.2 - 0.6 * x, color=RED, lw=3, label="C = 1:  g = 0.2 − 0.6x")
    ax.plot([0, 1], [1, -1], "o", color=TXT, ms=11, label="targets"); ax.axhline(0, color=MUT, lw=1); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlabel("x", color=TXT, fontsize=fpx(16)); ax.set_ylim(-1.6, 1.6)
    cap(fig, h, [(348, "kernel K = xz + 1, two training points", TXT, 16, True), (381, "C = 0 passes through both targets (a = 3, −2)", A_C, 16, True), (410, "C = 1 shrinks toward 0 (a = 0.8, −0.6)", RED, 16, True)])
    save(fig, "lec05-kp21-hand")

def f_sin():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 255); axstyle(ax)
    ax.plot(Xg[:, 0], np.sin(Xg[:, 0]), color=MUT, lw=2, ls="--", label="true sin x")
    for C, c, nm in ((0, RED, "C = 0"), (0.1, GRN, "C = 0.1"), (10, VIO2, "C = 10")):
        a = kr_fit(K1, X1, y1, C); ax.plot(Xg[:, 0], kr_pred(K1, X1, a, Xg), color=c, lw=2.6, label=nm)
    ax.plot(X1[:, 0], y1, "o", color=TXT, ms=9); ax.legend(fontsize=fpx(13), frameon=False, labelcolor=TXT, loc="upper right", ncol=2); ax.set_ylim(-1.5, 2.0); ax.set_xlabel("x", color=TXT, fontsize=fpx(16))
    a0 = kr_fit(K1, X1, y1, 0)
    cap(fig, h, [(360, "9 noisy points (dots), Gaussian kernel σ = 0.8", TXT, 16, True), (394, f"C = 0 passes through every point: nonzero a = {int((abs(a0)>1e-9).sum())} of 9", RED, 17, True), (425, "error against the true sin: 0.047 (C = 0), 0.033 (C = 0.1)", MUT, 15, False)])
    save(fig, "lec05-kp21-sin")

def f_csweep():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    Cs = [1e-3, 1e-2, 1e-1, 1, 10, 100]; tr, te = [], []
    for C in Cs:
        a = kr_fit(K1, X1, y1, C); tr.append(np.mean((kr_pred(K1, X1, a, X1) - y1) ** 2)); te.append(np.mean((kr_pred(K1, X1, a, Xg) - np.sin(Xg[:, 0])) ** 2))
    ax.plot(range(6), tr, "o-", color=A_C, lw=2.8, ms=9, label="training error"); ax.plot(range(6), te, "s-", color=RED, lw=2.8, ms=9, label="error against sin x")
    ax.set_xticks(range(6)); ax.set_xticklabels(["0.001", "0.01", "0.1", "1", "10", "100"], fontsize=fpx(16)); ax.set_xlabel("C", color=TXT, fontsize=fpx(16)); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper left")
    j = int(np.argmin(te)); ax.text(j, te[j] + 0.05, f"{te[j]:.3f}", color=TXT, fontsize=fpx(14), ha="center", fontweight="bold")
    cap(fig, h, [(352, f"best C = {Cs[j]}: error {te[j]:.3f}", GRN, 17, True), (386, "C ≥ 10 flattens the curve (underfit)", RED, 17, True), (420, "all 9 coefficients stay nonzero for every C", MUT, 16, False)])
    save(fig, "lec05-kp21-csweep"); return [round(float(v), 4) for v in te], [round(float(v), 4) for v in tr]

def f_svcount():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    Cs = [0.01, 1, 10, 1000]; res = {}
    for g, c in ((0.01, VIO2), (0.5, GRN), (50, RED)):
        v = []
        for C in Cs:
            Kg = lambda A, B, g=g: K_rbf(A, B, g); v.append(len(fit(Kg, Xtr, ytr, C).support_))
        res[g] = v; ax.plot(range(4), v, "o-", color=c, lw=2.8, ms=9, label=f"γ = {g}")
    ax.axhline(120, color=MUT, lw=1.2, ls="--"); ax.text(3.0, 124, "all 120", color=MUT, fontsize=fpx(14), ha="right")
    ax.set_xticks(range(4)); ax.set_xticklabels([str(c) for c in Cs], fontsize=fpx(16)); ax.set_xlabel("C", color=TXT, fontsize=fpx(16)); ax.set_ylabel("support vectors", color=TXT, fontsize=fpx(15)); ax.set_ylim(0, 135); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="lower left")
    cap(fig, h, [(352, "sparsity needs a large enough C and a moderate γ", TXT, 16, True), (386, "γ = 50: about 116 of 120 whatever C", RED, 17, True), (420, "γ = 0.5, C = 10: 19 of 120", GRN, 17, True)])
    save(fig, "lec05-kp21-svcount"); return res

def f_dict():
    w, h = 540, 440; fig = new_fig(w, h); a = panel(fig, w, h, 20, 15, 250, 250); rng = np.random.default_rng(0); S = Xtr[rng.permutation(120)]
    D = dictionary(S, Kr, 0.7); a.plot(S[:, 0], S[:, 1], ".", color=MUT, ms=5); a.plot(S[D, 0], S[D, 1], "o", mfc="none", mec=GRN, ms=11, mew=2.2); a.set_aspect("equal"); a.set_xticks([]); a.set_yticks([]); a.set_xlim(-3.2, 3.2); a.set_ylim(-3.2, 3.2)
    ax = panel(fig, w, h, 300, 25, 220, 230); ax.axis("off"); ax.set_xlim(0, 220); ax.set_ylim(230, 0)
    sizes = [(0.99, 90), (0.9, 38), (0.7, 17), (0.5, 9)]
    T(ax, 110, 12, "threshold: kernels kept", MUT, 14, False)
    for i, (m0, n) in enumerate(sizes): T(ax, 40, 60 + i * 50, f"{m0}", TXT, 20); T(ax, 150, 60 + i * 50, f"{n} of 120", GRN if m0 == 0.7 else TXT, 20)
    cap(fig, h, [(325, "dictionary method: keep a new point only if its largest", TXT, 16, True), (355, "kernel value to the dictionary is at most the threshold", TXT, 16, True), (395, "circles: the 17 kept at threshold 0.7", GRN, 17, True), (425, "(points arrive in random order)", MUT, 14, False)])
    save(fig, "lec05-kp21-dict"); return [len(dictionary(S, Kr, m0)) for m0, _ in sizes]

def f_dense():
    fig, ax = blank(540, 400)
    for x, t in zip((90, 190, 320, 450), ("γ", "C", "support vectors", "new points")): T(ax, x, 30, t, MUT, 14, False)
    rows = [(0.01, 1000), (0.5, 1000), (0.5, 0.01), (0.5, 1), (50, 1000)]
    for i, (g, C) in enumerate(rows):
        Kg = lambda A, B, g=g: K_rbf(A, B, g); m = fit(Kg, Xtr, ytr, C); n = len(m.support_); a = acc(m, Kg, Xtr, Xte, yte); y = 85 + i * 52
        col = RED if a < 0.9 else TXT
        for x, t, c in ((90, f"{g}", TXT), (190, f"{C}", TXT), (320, f"{n}", col), (450, f"{a*100:.1f}%", col)): T(ax, x, y, t, c, 19)
    T(ax, 270, 365, "few is not always good, many is not always bad", MUT, 16, False)
    save(fig, "lec05-kp21-dense")

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "training points x = 0 and x = 1, targets +1 and −1", TXT, 18)
    T(ax, 270, 90, "kernel K(x, z) = xz + 1", TXT, 19)
    T(ax, 270, 160, "question 1: C = 1, solve a = (K + I)⁻¹ y; find g(0), g(1)", RED, 16)
    T(ax, 270, 210, "question 2: compare with C = 0, where g(0) = 1, g(1) = −1", RED, 16)
    T(ax, 270, 270, "g(x) = a₁ K(x, 0) + a₂ K(x, 1)", MUT, 16, False)
    save(fig, "lec05-kp21-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("K = [[1, 1], [1, 2]],   K + I = [[2, 1], [1, 3]],   det = 5", TXT), ("(K + I)⁻¹ = (1/5) [[3, −1], [−1, 2]]", TXT), ("a = (1/5) (3 + 1, −1 − 2) = (0.8, −0.6)", GRN), ("g(0) = 0.8·1 − 0.6·1 = 0.2", GRN), ("g(1) = 0.8·1 − 0.6·2 = −0.4", GRN), ("C = 0: g(0) = 1, g(1) = −1; C = 1 shrinks both", RED)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 15)
    save(fig, "lec05-kp21-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
