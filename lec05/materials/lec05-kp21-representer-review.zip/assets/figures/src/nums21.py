import numpy as np, sys
sys.path.insert(0, "../kp19")
from nums19 import rings, K_lin, K_poly, K_rbf, fit, acc
def sin_data(n=9, noise=0.2, seed=0):
    rng = np.random.default_rng(seed); x = np.linspace(0, 2 * np.pi, n) + rng.normal(0, 0.05, n); return x[:, None], np.sin(x) + rng.normal(0, noise, n)
def gauss(A, B, s): return np.exp(-((A[:, None, :] - B[None, :, :]) ** 2).sum(-1) / (2 * s * s))
def kr_fit(K, X, y, C=0.0): return np.linalg.solve(K(X, X) + C * np.eye(len(X)), y)
def kr_pred(K, X, a, Xs): return K(Xs, X) @ a
def phi6(X): return np.c_[np.ones(len(X)), 2 ** .5 * X[:, 0], 2 ** .5 * X[:, 1], X[:, 0] ** 2, 2 ** .5 * X[:, 0] * X[:, 1], X[:, 1] ** 2]
def dictionary(X, K, mu0):
    D = [0]
    for i in range(1, len(X)):
        if max(K(X[i:i + 1], X[D]).ravel()) <= mu0: D.append(i)
    return D
if __name__ == "__main__":
    Xtr, ytr = rings(60, 1, sd=0.25); Xte, yte = rings(500, 2, sd=0.25)
    Kr = lambda A, B: K_rbf(A, B, 0.5)
    m = fit(Kr, Xtr, ytr); print("SV", len(m.support_), "of", len(ytr), "test", acc(m, Kr, Xtr, Xte, yte))
    # representer check
    rng = np.random.default_rng(3); X = rng.normal(size=(30, 2)); y = rng.normal(size=30); C = 0.7
    F = phi6(X); w = np.linalg.solve(F.T @ F + C * np.eye(6), F.T @ y); a = kr_fit(K_poly, X, y, C)
    print("w vs F^T a maxdiff", np.abs(w - F.T @ a).max(), "|w|", np.linalg.norm(w)); Xs = rng.normal(size=(5, 2)); print("pred diff", np.abs(phi6(Xs) @ w - kr_pred(K_poly, X, a, Xs)).max())
    # sin
    X1, y1 = sin_data(); Xg = np.linspace(0, 2 * np.pi, 200)[:, None]; K1 = lambda A, B: gauss(A, B, 0.8)
    G = K1(X1, X1); print("cond", np.linalg.cond(G))
    for C in (0, 1e-6, 1e-3, 1e-2, 1e-1, 1, 10, 100):
        a1 = kr_fit(K1, X1, y1, C); tr = np.mean((kr_pred(K1, X1, a1, X1) - y1) ** 2); te = np.mean((kr_pred(K1, X1, a1, Xg) - np.sin(Xg[:, 0])) ** 2)
        print("C", C, "train mse", round(tr, 5), "test mse vs sin", round(te, 4), "nonzero", int((np.abs(a1) > 1e-9).sum()), "max|a|", round(np.abs(a1).max(), 2))
    # kernel LS classifier on rings
    for C in (0, 1e-3, 1e-1, 1):
        a = kr_fit(Kr, Xtr, ytr, C); print("kLS rings C", C, "train", (np.sign(kr_pred(Kr, Xtr, a, Xtr)) == ytr).mean(), "test", (np.sign(kr_pred(Kr, Xtr, a, Xte)) == yte).mean(), "nonzero", int((np.abs(a) > 1e-9).sum()))
    # SV counts
    for g in (0.01, 0.5, 50):
        for C in (0.01, 1, 10, 1000):
            Kg = lambda A, B, g=g: K_rbf(A, B, g); mm = fit(Kg, Xtr, ytr, C); print("g", g, "C", C, "nSV", len(mm.support_), "test", round(acc(mm, Kg, Xtr, Xte, yte), 3))
    # dictionary
    rng = np.random.default_rng(0); S = Xtr[rng.permutation(120)]
    for mu0 in (0.99, 0.9, 0.7, 0.5):
        D = dictionary(S, Kr, mu0); print("mu0", mu0, "dict", len(D), "of", len(S))
    # hand example
    Kh = lambda A, B: A @ B.T + 1; Xh = np.array([[0.], [1.]]); yh = np.array([1., -1.])
    a = kr_fit(Kh, Xh, yh); print("hand a", a, "g(.5)", kr_pred(Kh, Xh, a, np.array([[.5]])), "ridge a", kr_fit(Kh, Xh, yh, 1.0), "g0", kr_pred(Kh, Xh, kr_fit(Kh, Xh, yh, 1.0), np.array([[0.], [1.]])))
