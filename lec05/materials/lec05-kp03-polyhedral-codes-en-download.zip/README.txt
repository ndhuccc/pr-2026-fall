Pattern Recognition, Chapter 4, KP03: Codes of several lines and the limit of two layers (English version)

Slides: slides/lec05-kp03-polyhedral-codes-en.html (offline web page, open in a browser); slides/lec05-kp03-polyhedral-codes-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp03-polyhedral-codes-en-lecture.pdf (PDF), lec05-kp03-polyhedral-codes-en-reading.html (offline web page), lectures/lec05-kp03-polyhedral-codes-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
