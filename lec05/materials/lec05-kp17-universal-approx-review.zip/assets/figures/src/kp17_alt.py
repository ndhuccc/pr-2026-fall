ALT = {
 "summary": ("三個通用近似器：多項式（誤差約 r^(−2/l)）、一層 sigmoid 網路（約 1/k）、RBF 網路（也是通用近似器）。", "Three universal approximators: polynomials (error about r^(−2/l)), a one-hidden-layer sigmoid network (about 1/k) and an RBF network (also universal)."),
 "polyerr": ("sin 2πx + 0.3x² 的多項式最大誤差對階數 1 到 12 的半對數曲線：r=5 為 0.0152，r=9 為 0.000015。", "Semi-log curve of the polynomial largest error against the degree 1 to 12 for sin 2πx + 0.3x²: 0.0152 at r=5 and 0.000015 at r=9."),
 "runge": ("龍格函數與兩種 12 階多項式：等距內插在端點劇烈擺動（誤差 3.66），最小二乘貼得很好（0.068）。", "The Runge function with two degree-12 polynomials: equal-spaced interpolation oscillates wildly at the ends (error 3.66) and least squares fits well (0.068)."),
 "mlpfit": ("目標波形與 k=1、2、4 個 sigmoid 節點的擬合：k=1 太平，k=2 與 4 幾乎重合。", "The target wave with fits by k=1, 2 and 4 sigmoid nodes: k=1 is too flat, while k=2 and 4 nearly coincide with the target."),
 "equal": ("相同參數量（7、13、19）時多項式與 sigmoid 網路的最大誤差：多項式一樣好或更好。", "Largest error of polynomials and sigmoid networks at equal parameters (7, 13, 19): the polynomial is as good or better."),
 "ridge": ("5 維單一脊函數目標：多項式 r=1、2、3、5 的新點誤差 0.326、0.326、0.222、0.257，網路 k=1、2、4 都低於 0.0001。", "A 5-dimensional single-ridge target: polynomials r=1, 2, 3, 5 have errors 0.326, 0.326, 0.222, 0.257 on new points while networks k=1, 2, 4 are all below 0.0001."),
 "halving": ("誤差減半所需的增長：多項式 r 要乘 2^(l/2)（l=2、5、10、20 為 2、5.7、32、1024），網路 k 只要加倍。", "Growth needed to halve the error: a polynomial's r times 2^(l/2) (2, 5.7, 32, 1024 for l=2, 5, 10, 20) against only doubling k for the network."),
 "restarts": ("同一份資料 8 個隨機起點：k=2 有 5 個低於 0.1、3 個卡在 0.82 附近；k=3 也有卡住的起點。", "Eight random starts on the same data: for k=2, 5 are below 0.1 and 3 are stuck near 0.82; k=3 also has stuck starts."),
 "hat": ("帽函數疊 1、2、3 層得 2、4、8 段；表列 n=3、6、10 時深網路 6、12、20 個節點，單層 7、63、1023 個。", "The hat function stacked 1, 2, 3 times has 2, 4, 8 pieces; the table lists 6, 12, 20 nodes for a deep network and 7, 63, 1023 for one layer at n=3, 6, 10."),
 "practice": ("練習圖：l=8 時誤差減半的 r 倍數，以及 5 層帽函數的片段數與節點數。", "Practice figure: the factor of r to halve the error at l=8 and the pieces and node counts of the five-fold hat function."),
 "practice-sol": ("題 1：16 倍；題 2：32 段，深網路 10 個節點，單層 31 個節點。", "Question 1: 16 times; question 2: 32 pieces, 10 nodes deep and 31 nodes in one layer."),
}
