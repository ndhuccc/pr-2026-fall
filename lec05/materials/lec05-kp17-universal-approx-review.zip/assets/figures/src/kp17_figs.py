import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums17 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax

def f_summary():
    fig, ax = blank(540, 440)
    rows = [("polynomial", "Weierstrass: any continuous g", "error ~ r^(−2/l)", A_C), ("sigmoid net, one hidden layer", "any continuous g", "error ~ 1/k", RED), ("RBF network", "any continuous g", "(also universal)", GRN)]
    for i, (a, b, c, col) in enumerate(rows):
        y0 = 15 + i * 105; ax.add_patch(Rectangle((12, y0), 516, 92, fc="none", ec=col, lw=2.6))
        ax.text(26, y0 + 24, a, color=col, fontsize=fpx(19), va="center", fontweight="bold"); ax.text(26, y0 + 56, "can approximate: " + b, color=TXT, fontsize=fpx(16), va="center"); ax.text(26, y0 + 80, "speed: " + c, color=TXT, fontsize=fpx(17), va="center", fontweight="bold")
    ax.text(270, 360, "universal approximation is the ticket to enter,", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 394, "not an advantage: the speed is what differs", color=RED, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 428, "l = input dimension, r = polynomial order, k = number of nodes", color=MUT, fontsize=fpx(14), ha="center")
    save(fig, "lec05-kp17-summary")

def f_polyerr():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 20, 420, 245); axstyle(ax)
    rs = list(range(1, 13)); es = [N.sup_err(N.poly_ls(r)) for r in rs]
    ax.semilogy(rs, es, "o-", color=A_C, lw=3, ms=8); ax.set_xticks(rs); ax.set_ylim(1e-8, 3)
    for r in (1, 3, 5, 7, 9, 11): ax.text(r, es[r - 1] * 2.2, f"{es[r-1]:.3g}", color=TXT, fontsize=fpx(14), ha="center", fontweight="bold")
    ax.set_xlabel("polynomial degree r", color=TXT, fontsize=fpx(16)); ax.set_ylabel("largest error", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "target g(x) = sin 2πx + 0.3x² on [0, 1]", TXT, 17, True), (382, "r = 5: 0.0152,   r = 9: 0.000015", GRN, 18, True), (415, "least-squares fit on 401 points; the error keeps shrinking", MUT, 15, False)])
    save(fig, "lec05-kp17-polyerr")

def f_runge():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    runge = lambda x: 1 / (1 + 25 * x ** 2); xs = np.linspace(-1, 1, 1000); r = 12
    nodes = np.linspace(-1, 1, r + 1); ci = np.polynomial.chebyshev.chebfit(nodes, runge(nodes), r); xd = np.linspace(-1, 1, 400); cl = np.polynomial.chebyshev.chebfit(xd, runge(xd), r)
    ax.plot(xs, runge(xs), color=TXT, lw=3, label="g(x) = 1/(1 + 25x²)"); ax.plot(xs, np.polynomial.chebyshev.chebval(xs, ci), color=RED, lw=2.4, label="interpolate 13 equal-spaced points"); ax.plot(xs, np.polynomial.chebyshev.chebval(xs, cl), color=GRN, lw=2.4, label="least squares, 400 points")
    ax.set_ylim(-1.2, 3.2); ax.legend(fontsize=fpx(13), frameon=False, labelcolor=TXT, loc="upper center"); ax.set_xlabel("x", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "degree 12:  interpolation error 3.66,  least squares 0.068", TXT, 16, True), (382, "equal-spaced degrees 4, 8, 12, 16, 20 → 0.44, 1.05, 3.66, 14.4, 59.8", RED, 15, True), (415, "a high order alone does not give a good fit", MUT, 15, False)])
    save(fig, "lec05-kp17-runge")

def f_mlpfit():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    x = N.XG; ax.plot(x, N.target(x), color=TXT, lw=4, alpha=0.5, label="target")
    for k, c in ((1, MUT), (2, RED), (4, GRN)):
        (e, p), res = N.best_mlp(k); ax.plot(x, N.mlp_fn(p, k, x), color=c, lw=2.2, label=f"k = {k}  (largest error {e:.3g})")
    ax.legend(fontsize=fpx(13), frameon=False, labelcolor=TXT, loc="lower left"); ax.set_xlabel("x", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "one hidden layer of k sigmoid nodes, best of 8 starts", TXT, 17, True), (382, "k = 1, 2, 3, 4, 6, 8: 0.819, 0.0142, 0.0056, 0.0058, 0.0045, 0.0011", GRN, 15, True), (415, "two sigmoids already follow the wave", MUT, 15, False)])
    save(fig, "lec05-kp17-mlpfit")

def f_equal():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 80, 20, 430, 245); axstyle(ax)
    labs = ["7 parameters", "13 parameters", "19 parameters"]; pol = [N.sup_err(N.poly_ls(6)), N.sup_err(N.poly_ls(12)), N.sup_err(N.poly_ls(18))]
    ml = [0.0142, 0.0058, 0.0045]; x = np.arange(3)
    ax.bar(x - 0.2, pol, width=0.38, color=A_C, label="polynomial"); ax.bar(x + 0.2, ml, width=0.38, color=RED, label="sigmoid net (k = 2, 4, 6)")
    ax.set_yscale("log"); ax.set_ylim(1e-14, 3e4); ax.set_xticks(x); ax.set_xticklabels(labs, fontsize=fpx(15)); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right")
    for i in range(3): ax.text(i - 0.2, pol[i] * 2, f"{pol[i]:.2g}", color=TXT, fontsize=fpx(13), ha="center", fontweight="bold"); ax.text(i + 0.2, ml[i] * 2, f"{ml[i]:.3g}", color=TXT, fontsize=fpx(13), ha="center", fontweight="bold")
    ax.set_ylabel("largest error (log)", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(345, "same sin 2πx + 0.3x² target in one dimension", TXT, 17, True), (382, "with equal parameters the polynomial is as good or better", A_C, 17, True), (415, "the advantage of adaptive nodes is not here", MUT, 15, False)])
    save(fig, "lec05-kp17-equal")

def f_ridge():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 20, 420, 245); axstyle(ax)
    labs = ["poly r=1\n6", "poly r=2\n21", "poly r=3\n56", "poly r=5\n252", "net k=1\n8", "net k=2\n15", "net k=4\n29"]
    v = [0.3256, 0.3260, 0.2222, 0.2569, 1e-4, 1e-4, 1e-4]; cols = [A_C] * 4 + [RED] * 3
    ax.bar(range(7), v, color=cols, width=0.62); ax.set_yscale("log"); ax.set_ylim(5e-5, 1.5); ax.set_xticks(range(7)); ax.set_xticklabels(labs, fontsize=fpx(11))
    for i, t in enumerate(["0.326", "0.326", "0.222", "0.257", "< 0.0001", "< 0.0001", "< 0.0001"]): ax.text(i, v[i] * 1.5, t, color=TXT, fontsize=fpx(12), ha="center", fontweight="bold")
    ax.set_ylabel("error on 2000 new points", color=TXT, fontsize=fpx(14))
    cap(fig, h, [(345, "l = 5 inputs; target tanh(2 w·x), a single ridge", TXT, 17, True), (382, "second line of each label: number of parameters", MUT, 15, False), (415, "built to favour the adaptive nodes; see the text", RED, 16, True)])
    save(fig, "lec05-kp17-ridge")

def f_halving():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 80, 20, 430, 245); axstyle(ax)
    ls = [2, 5, 10, 20]; v = [2 ** (l / 2) for l in ls]
    ax.bar(np.arange(4) - 0.2, v, width=0.38, color=A_C, label="polynomial: r grows by 2^(l/2)"); ax.bar(np.arange(4) + 0.2, [2] * 4, width=0.38, color=RED, label="sigmoid net: k doubles")
    ax.set_yscale("log"); ax.set_ylim(1, 3000); ax.set_xticks(range(4)); ax.set_xticklabels([f"l = {l}" for l in ls], fontsize=fpx(16)); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper left")
    for i, t in enumerate(["2", "5.7", "32", "1024"]): ax.text(i - 0.2, v[i] * 1.25, t, color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.set_ylabel("growth needed to halve the error", color=TXT, fontsize=fpx(13))
    cap(fig, h, [(345, "rates: polynomial O(r^(−2/l)),  sigmoid net O(1/k)", TXT, 17, True), (382, "halving the polynomial error: r × 2^(l/2)", A_C, 17, True), (415, "from the rate formulas, not from an experiment", MUT, 15, False)])
    save(fig, "lec05-kp17-halving")

def f_restarts():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 80, 20, 430, 245); axstyle(ax)
    r2 = [0.061, 0.015, 0.819, 0.823, 0.819, 0.023, 0.042, 0.014]; r3 = [0.006, 0.019, 0.816, 0.017, 0.023, 0.026, 0.823, 0.999]
    x = np.arange(8); ax.bar(x - 0.2, r2, width=0.38, color=A_C, label="k = 2"); ax.bar(x + 0.2, r3, width=0.38, color=VIO2, label="k = 3")
    ax.axhline(0.1, color=RED, ls=(0, (4, 3)), lw=1.8); ax.text(7.4, 0.12, "0.1", color=RED, fontsize=fpx(14), ha="right")
    ax.set_yscale("log"); ax.set_ylim(1e-3, 30); ax.set_xticks(x); ax.set_xticklabels([str(i + 1) for i in x], fontsize=fpx(15)); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper left")
    ax.set_xlabel("random start number", color=TXT, fontsize=fpx(16)); ax.set_ylabel("largest error (log)", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(345, "the same data, 8 random starts of the training", TXT, 17, True), (382, "k = 2: 5 of 8 reach below 0.1, 3 get stuck near 0.82", RED, 17, True), (415, "a non-convex problem: local minima are the price", MUT, 15, False)])
    save(fig, "lec05-kp17-restarts")

def f_hat():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 55, 15, 430, 175); axstyle(ax)
    x = np.linspace(0, 1, 2001); hh = lambda t: 2 * np.minimum(t, 1 - t); y = x.copy()
    for n, c in ((1, A_C), (2, TEAL2), (3, RED)): y = hh(y); ax.plot(x, y, color=c, lw=2.2, label=f"h applied {n}×: {2**n} pieces")
    ax.set_ylim(0, 2.1); ax.legend(fontsize=fpx(12), frameon=False, labelcolor=TXT, loc="upper center"); ax.set_xlabel("x", color=TXT, fontsize=fpx(14))
    for x0, t in zip((60, 175, 330, 450), ("layers n", "pieces 2^n", "deep: 2n nodes", "one layer: 2^n − 1")): fig.text(x0 / w, 1 - 235 / h, t, color=MUT, fontsize=fpx(13), ha="center")
    for i, n in enumerate((3, 6, 10)):
        y0 = 280 + i * 42
        for x0, t, c in zip((60, 175, 330, 450), (str(n), str(2 ** n), str(2 * n), str(2 ** n - 1)), (TXT, TXT, GRN, RED)): fig.text(x0 / w, 1 - y0 / h, t, color=c, fontsize=fpx(19), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 425 / h, "h(x) = 2 min(x, 1−x) costs 2 ReLU nodes per layer", color=MUT, fontsize=fpx(14), ha="center")
    save(fig, "lec05-kp17-hat")

def f_practice():
    fig, ax = blank(540, 330)
    ax.text(270, 40, "polynomial error ~ r^(−2/l)", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 100, "sigmoid net error ~ 1/k", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 175, "question 1: l = 8; how much larger must r be to halve the error?", color=RED, fontsize=fpx(15), ha="center", fontweight="bold")
    ax.text(270, 220, "question 2: how many ReLU nodes does one hidden layer need", color=RED, fontsize=fpx(15), ha="center", fontweight="bold")
    ax.text(270, 255, "for the 5-fold hat function h(h(h(h(h(x))))), against 2n deep?", color=RED, fontsize=fpx(15), ha="center", fontweight="bold")
    save(fig, "lec05-kp17-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("halve the error: r^(−2/8) × 1/2", "r × 2^(8/2)", TXT), ("2^(8/2) = 2^4", "= 16 times larger r", GRN), ("5 layers: pieces 2^5", "= 32", TXT), ("deep: 2 × 5", "= 10 nodes", GRN), ("one hidden layer: 2^5 − 1", "= 31 nodes", RED)]
    for i, (a, b, c) in enumerate(L):
        y = 40 + i * 62; ax.text(15, y, a, color=c, fontsize=fpx(17), va="center", fontweight="bold"); ax.text(330, y, b, color=c, fontsize=fpx(18), va="center", fontweight="bold")
    ax.text(270, 365, "the rate formula is an asymptotic statement, not an exact count", color=MUT, fontsize=fpx(14), ha="center")
    save(fig, "lec05-kp17-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try: fn()
            except Exception as e: print("FAILED", n, e)
