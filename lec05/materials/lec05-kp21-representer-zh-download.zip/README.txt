圖型識別 第四章 KP21：Representer 定理、核函數展開與模型稀疏化（中文版）

簡報：slides/lec05-kp21-representer-zh.html（離線網頁，用瀏覽器開啟）；slides/lec05-kp21-representer-zh.jbd.json 為 JianBauDau 可編輯原檔。
講義：lec05-kp21-representer-zh-lecture.pdf（PDF）、lec05-kp21-representer-zh-reading.html（離線網頁）、lectures/lec05-kp21-representer-zh.md（Markdown 原文）。
英文版為另一個下載包（-en）。草稿，待教師驗收。
