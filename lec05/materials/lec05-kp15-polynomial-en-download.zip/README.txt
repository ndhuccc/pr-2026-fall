Pattern Recognition, Chapter 4, KP15: Polynomial classifiers (English version)

Slides: slides/lec05-kp15-polynomial-en.html (offline web page, open in a browser); slides/lec05-kp15-polynomial-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp15-polynomial-en-lecture.pdf (PDF), lec05-kp15-polynomial-en-reading.html (offline web page), lectures/lec05-kp15-polynomial-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
