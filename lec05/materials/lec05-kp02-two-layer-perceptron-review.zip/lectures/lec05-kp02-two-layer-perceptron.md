# KP02 兩層感知器與 XOR 的重新表示（Two-layer perceptrons and a new representation of XOR）

> 程度：大學三年級（undergrad）／Level: Undergraduate (undergrad)
>
> 圖型識別｜第四章 §4.3｜第 5 週主題：非線性分類器
>
> Pattern Recognition | Chapter 4, Section 4.3 | Week 5: Nonlinear classifiers

[簡報閱讀與下載（Slides）](../slides/lec05-kp02-two-layer-perceptron.html)

## 學習目標（Learning objectives）

- 能算出隱藏層與輸出層的四點預測。（Compute hidden and output responses for all four inputs.）
- 能說明重新表示如何讓 XOR 在隱藏空間變得可分。（Explain how a representation change makes XOR separable in hidden space.）
- 能區分輸入節點與有運算的層。（Distinguish input nodes from computational layers.）

## KP02 先編碼位置，再分類（Encode positions before classifying）

**一句話重點**：兩個隱藏神經元先把輸入相對於兩條線的位置編成二元向量，輸出神經元再對這個向量分類。

**One-sentence summary**: Two hidden neurons encode the input's position relative to two lines as a binary vector. An output neuron then classifies that vector.

### 為什麼單一直線的失敗不是終點（Why the failure of one line is not the end）

**白話說明**：KP01 排除的是原始輸入上的單一線性判別。現在仍用相同的四個 XOR 點，但允許先處理輸入，再讓另一個神經元判斷。這樣改變的是表示方法，不是只換一組舊權重。

**Plain explanation**: KP01 ruled out a single linear discriminator on the original inputs. We keep the same four XOR points but allow a preprocessing layer before the final neuron. This changes the representation, rather than merely choosing different old weights.

先畫兩條平行線。第一條檢查輸入總和是否超過 0.5，第二條檢查是否超過 1.5。每個檢查只留下 0 或 1，像替點貼上兩張位置標籤。這個比喻只描述離散編碼，並不是把原始座標完整保存。

Draw two parallel lines. The first checks whether the input sum exceeds 0.5; the second checks whether it exceeds 1.5. Each check retains only 0 or 1, like attaching two position labels. This analogy describes a discrete code, not preservation of every original coordinate.

![XOR 四點與兩條隱藏邊界（XOR inputs and two hidden boundaries）](../assets/figures/lec05-kp02-input.png)

圖說 `lec05-kp02-input`：先看 A 圓點與 B 方點，再看兩條平行邊界。每個點都要回答兩次「是否位於正側」，不是讓兩條線各自給出最終類別。

Figure `lec05-kp02-input`: First identify A circles and B squares, then inspect the parallel boundaries. Each point receives two positive-side checks, not two independent final class labels.

### 把位置檢查寫成網路（Writing the position checks as a network）

**正式定義**：本單元固定階梯函數在正分時輸出 1，零分與負分輸出 0。

**Formal definition**: The step function outputs 1 for a positive argument and 0 for a zero or negative argument.

$$
f(t)=\begin{cases}1,&t>0,\\0,&t\leq0.\end{cases}
$$

兩個隱藏神經元使用下式。這些權重與偏置是來源的 XOR 標準構造；本單元先檢查它能否表示 XOR，尚未聲稱它們是由訓練自動學得。

The two hidden neurons use the following source construction. We check whether these weights and biases represent XOR; we do not claim that training automatically found them.

$$
g_1(\mathbf{x})=x_1+x_2-0.5,\qquad g_2(\mathbf{x})=x_1+x_2-1.5,
\qquad \mathbf{y}=[f(g_1),f(g_2)]^T.
$$

輸出層的輸入是隱藏編碼，不是原來的兩個座標。

The output layer receives the hidden code, not the two original coordinates.

$$
g_{\mathrm{out}}(\mathbf{y})=y_1-y_2-0.5,\qquad \widehat c=f(g_{\mathrm{out}}).
$$

| 符號 | 中文意義 | English meaning |
|---|---|---|
| $\mathbf{x}=[x_1,x_2]^T$ | 2 維布林輸入 | Two-dimensional Boolean input |
| $g_1,g_2$ | 隱藏神經元的純量分數 | Scalar hidden-neuron scores |
| $f,t$ | 階梯函數及其純量引數 | Step function and its scalar argument |
| $\mathbf{y}=[y_1,y_2]^T$ | 2 維二元隱藏編碼 | Two-dimensional binary hidden code |
| $g_{\mathrm{out}},\widehat c$ | 輸出分數與預測類別，1 為 A、0 為 B | Output score and predicted class: 1 for A, 0 for B |

輸入節點只是提供 $x_1,x_2$，不算一個有運算的層。本書的「兩層」指一個隱藏層加一個輸出層；閱讀其他文獻時仍要先核對它的計層慣例。

Input nodes supply $x_1,x_2$ without a computational layer. In this text, “two-layer” means one hidden layer and one output layer. Check the counting convention when reading other sources.

### 完整算例：四個輸入逐層通過（Worked example: all four inputs pass through both layers）

**例子**：先算隱藏分數、再做階梯判斷，最後算輸出分數。每一步都使用同一個正分規則。

**Example**: Calculate hidden scores, apply the step rule, and then calculate the output score. Use the same positive-score convention throughout.

1. 對 $(0,1)$，第一個分數為 $0+1-0.5=0.5$，所以 $y_1=1$；第二個分數為 $0+1-1.5=-0.5$，所以 $y_2=0$。（For $(0,1)$, the scores are $0.5$ and $-0.5$, producing $y_1=1,y_2=0$.）
2. 將隱藏編碼代入輸出式：$1-0-0.5=0.5>0$，所以預測 A。（Substitute the hidden code: $1-0-0.5=0.5>0$, so the prediction is A.）
3. 對另外三點重複相同流程，得到下表。（Repeat the same process for the other three points to obtain the table.）

| 輸入 Input | $g_1$ 的代入 Substitution | $g_2$ 的代入 Substitution | 編碼 Code | 輸出代入 Output substitution | 預測 Prediction |
|---|---|---|---|---|---|
| $(0,0)$ | $0+0-0.5=-0.5$ | $0+0-1.5=-1.5$ | $(0,0)$ | $0-0-0.5=-0.5$ | B |
| $(0,1)$ | $0+1-0.5=0.5$ | $0+1-1.5=-0.5$ | $(1,0)$ | $1-0-0.5=0.5$ | A |
| $(1,0)$ | $1+0-0.5=0.5$ | $1+0-1.5=-0.5$ | $(1,0)$ | $1-0-0.5=0.5$ | A |
| $(1,1)$ | $1+1-0.5=1.5$ | $1+1-1.5=0.5$ | $(1,1)$ | $1-1-0.5=-0.5$ | B |

驗算：預測為 $(0,1,1,0)$，與 XOR 真值相同，故錯誤數為 $0$，正確率 $4/4=100\%$。這是構造的四點驗證，不是新資料上的準確率估計。

Check: the predictions $(0,1,1,0)$ match XOR, giving zero errors and $4/4=100\%$ accuracy on these points. This verifies the construction; it is not an estimate of accuracy on new data.

### 真正的改變發生在隱藏空間（The essential change occurs in hidden space）

![四個輸入映到三個隱藏位置（Four inputs map to three hidden locations）](../assets/figures/lec05-kp02-hidden.png)

圖說 `lec05-kp02-hidden`：先找 $(1,0)$ 的 A 圓點；它代表兩個不同輸入合併後的編碼。再看 $y_2=y_1-0.5$ 如何把它與兩個 B 位置分開。

Figure `lec05-kp02-hidden`: First locate the A circle at $(1,0)$, which represents two merged inputs. Then inspect how $y_2=y_1-0.5$ separates it from the two B locations.

兩個 A 輸入 $(0,1)$ 與 $(1,0)$ 都映到 $(1,0)$，所以四個輸入只占三個隱藏位置。B 的編碼分別為 $(0,0)$ 與 $(1,1)$。只要合併的點有相同標籤，這種資訊丟失就不妨礙本例分類。

Both A inputs map to $(1,0)$, so four inputs occupy only three hidden locations. B maps to $(0,0)$ and $(1,1)$. Losing input distinctions does not harm this classification because the merged points share a label.

原始空間的兩個階梯判斷組合出非線性分類器；不是把輸出層的直線直接畫回原圖，也不是把座標軸旋轉就完成。階梯是非線性運算，不能隨意省略。

The step decisions together produce a nonlinear classifier on the original inputs. The output line is defined in hidden space, not directly in the original plot. Rotating axes is not the mechanism, and the nonlinear step operations cannot be omitted.

### 條件、限制與實作（Conditions, limitations, and implementation）

**常見迷思**：看到隱藏層有兩個輸出，就把它們當成兩個類別機率。本例的 $y_1,y_2$ 是邊界正側的位元，不是經過機率校準的估計。

**Common misconception**: Two hidden outputs are not two class probabilities. Here, $y_1,y_2$ encode positive sides of boundaries; they are not calibrated probability estimates.

另一個誤解是，兩層網路對任何分類都足夠。這個構造只證明 XOR 可表示；其他問題仍要檢查隱藏編碼是否能被輸出層分開。如果不同類輸入映到同一編碼，後面的決策就無法再把它們分開。

This construction proves representability of XOR, not of every classification problem. Other tasks still require separable hidden codes. If different classes collapse to the same code, later decisions cannot distinguish them.

實作順序是先計算兩個隱藏分數，逐元素套用 `> 0`，再算輸出分數。不能把階梯直接去掉，否則原來的映射已被改變。學習這些參數的問題，留給後續訓練單元。

Implementation computes both hidden scores, applies `> 0` elementwise, and evaluates the output score. Removing the step operations changes the mapping. Learning these parameters is a later training question.

**小練習**：將輸出偏置由 $-0.5$ 改成 $+0.5$，四點會怎麼預測？提示：保留隱藏編碼，只重算輸出分數。另一題：哪些不同輸入被合併？為什麼這次不會造成分類衝突？

**Practice**: Change only the output bias from $-0.5$ to $+0.5$. What are the predictions? Hint: retain the hidden codes and recompute the output scores. Also identify the merged inputs and explain why their merger causes no label conflict.

下一個問題是：推廣到更多隱藏神經元時，哪些區域組合仍能由單一輸出分開？

The next question is which region combinations remain separable by one output neuron when the hidden layer grows.

## 術語與來源（Terminology and source）

| 中文 | English |
|---|---|
| 隱藏層 | Hidden layer |
| 輸出層 | Output layer |
| 階梯函數 | Step function |
| 隱藏編碼 | Hidden code |
| 兩層感知器 | Two-layer perceptron |

來源：[第四章 KP02，§4.3](https://ndhuccc.github.io/CCC-LNS/PR_115/Ch04-nonlinear-classifiers/index.html#kp2)，2026-10-24 讀取。保留原四點、閾值及輸出式；重新撰寫說明與繪圖。額外的符號定義與驗算只展開原構造，沒有新增分類方法。

Source: Chapter 4, KP02, Section 4.3, accessed 2026-10-24. Original points, thresholds, and output scores are retained. Explanations and figures are newly authored; definitions and checks elaborate the same construction.
