"""KP02 deck: encode positions first, then classify. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp02"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:隱藏層": "term:Hidden layer", "term:位元": "term:Bit", "term:階梯規則": "term:Step rule", "term:隱藏編碼": "term:Hidden code", "term:隱藏空間": "term:Hidden space"})
from kp02_text import *

def side_page(u, t, fig, fx=60, cx=610, cw=610, rev=False):
    p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure(fig, fx, y); _, ids = stack(p, cx, y, cw, t["cards"]); step(p, *t["notes"])
    if rev: reveal(p, ids)
    return p

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    P = PAGES
    figs = ["net-wiring", "input-sides", None, "bands", "hidden-plane", "hidden-scores", "strip-net", "merge-bad", "bias-line", "bias-plus", "no-step"]
    for i, t in enumerate(P):
        if i == 2:       # flow page with connectors
            p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
            p.figure("lec05-kp02-bits-example", 60, y)
            _, ids = stack(p, 610, y, 610, t["cards"], gap=24)
            for a, b in zip(ids, ids[1:]): p.conn(a, 8, b, 0)
            step(p, *t["notes"]); continue
        rev = i in (9, 10)
        side_page(u, t, "lec05-kp02-" + figs[i], cx=(610 if i != 8 else 610), rev=rev)
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
