ALT = {
 "net-wiring": ("兩層網路的接線：輸入 x1、x2 接到兩個隱藏單元 g1（青）與 g2（紫），各輸出一個位元 y1、y2，再接到一個輸出單元；每個單元算一個分數，分界線是它在平面上的圖形。", "Wiring of the two-layer network: inputs x1 and x2 feed two hidden units g1 (teal) and g2 (violet) that output bits y1 and y2, which feed one output unit; each unit computes a score and its boundary is a line in the plane."),
 "input-lines": ("XOR 的四個點與兩條平行線 g1=x1+x2-0.5（青）與 g2=x1+x2-1.5（紫）。", "The XOR points with two parallel lines g1=x1+x2-0.5 (teal) and g2=x1+x2-1.5 (violet)."),
 "input-sides": ("同一張圖，兩條線的正側分別著色並以箭頭標出：g1 的正側（青）與 g2 的正側（紫）重疊處是兩條線都在正側。", "The same figure with the positive side of each line tinted and marked by an arrow; where the tints overlap both lines are on their positive side."),
 "bits-example": ("以點 (0,1) 為例：g1=0.5>0 所以 y1=1，g2=-0.5≤0 所以 y2=0，編碼是 (1,0)。", "Example point (0,1): g1=0.5>0 gives y1=1 and g2=-0.5<=0 gives y2=0, so its code is (1,0)."),
 "bands": ("平面被兩條線切成三條帶，各標編碼 (0,0)、(1,0)、(1,1)；兩個 A 點在中間那條 (1,0) 帶。", "The two lines cut the plane into three bands labelled with the codes (0,0), (1,0) and (1,1); both A points lie in the middle band (1,0)."),
 "hidden-plane": ("隱藏空間 (y1,y2)：(0,0) 是 B、(1,0) 是 A（兩個輸入合併）、(1,1) 是 B，(0,1) 空心沒有輸入；輸出線 y2=y1-0.5 把 A 與 B 分開。", "Hidden space (y1,y2): (0,0) is B, (1,0) is A (two merged inputs), (1,1) is B, and (0,1) is empty; the output line y2=y1-0.5 separates A from B."),
 "hidden-scores": ("隱藏空間三個位置的輸出分數：(0,0) 為 -0.5、(1,0) 為 0.5、(1,1) 為 -0.5；只有 (1,0) 為正，判 A。", "Output scores at the three hidden locations: -0.5 at (0,0), 0.5 at (1,0) and -0.5 at (1,1); only (1,0) is positive, so class A."),
 "strip-net": ("回到原平面：y1=1 且 y2=0 的區域就是兩條線之間的帶，兩個 A 在帶內，兩個 B 在帶外。", "Back in the original plane: the region y1=1 and y2=0 is the strip between the two lines, with both A points inside and both B points outside."),
 "merge-bad": ("示意：若不同類的 A 與 B 得到同一個編碼 (1,1)，用紅圈標出，輸出層怎麼畫線都分不開。", "Schematic: if an A and a B receive the same code (1,1), marked by a red ring, no output line can separate them."),
 "bias-line": ("練習圖：隱藏空間三個位置與輸出線 y2=y1+0.5（輸出偏置改為 +0.5）。", "Practice figure: the three hidden locations with the output line y2=y1+0.5 (output bias changed to +0.5)."),
 "bias-plus": ("輸出偏置改為 +0.5 之後，三個位置的分數都為正，全部預測 A；兩個 B 位置 (0,0)、(1,1) 以紅圈標為錯。", "With the output bias +0.5 all three locations have positive scores and are predicted A; the two B locations (0,0) and (1,1) are circled in red as wrong."),
 "no-step": ("拿掉階梯後輸出分數處處等於 0.5，整個平面都預測 A；兩個 B 點 (0,0)、(1,1) 以紅圈標為錯。", "Without the steps the output score equals 0.5 everywhere, so the whole plane is predicted A; the two B points (0,0) and (1,1) are circled in red as wrong."),
}
