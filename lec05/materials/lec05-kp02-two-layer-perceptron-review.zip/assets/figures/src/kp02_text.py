from deckcommon import AUX, EDGE, MAIN, OK, REF, WARN, VIO, ROSE
UNIT_ZH, UNIT_EN = "先編碼位置，再分類", "Encode and classify"
TITLE_ZH = "圖型識別 第四章 KP02：先編碼位置，再分類（大三・自學）"
TITLE_EN = "Pattern Recognition, Chapter 4, KP02: encode positions first, then classify (undergraduate, self-study)"
NOTE_ZH = "教材程度：大學三年級（undergrad）。主線 8 頁，另有 3 頁延伸（不計時）；自主學習用，中文版。依 CLARITY.md C12–C18 重做：術語先用白話說、標題講明白、頁與頁以疑問接力、空間內容每頁有圖。備註會隨檔案公開，不含學號、成績或考題。"
NOTE_EN = "Level: undergraduate (year 3). Main line 8 pages plus 3 extension pages (not timed). Self-study deck, English version. Rewritten under CLARITY.md C12 to C18: plain words before terms, titles that state the point, pages linked by questions, a figure on every spatial page. These notes are public with the file and contain no student IDs, grades or exam questions."
P = []
P.append(dict(
 lab=("先問兩個小問題", "Two small questions"),
 title=("一條線不行，那就先問兩條線，再看答案", "One line fails, so ask two lines first and then decide"),
 bridge=("上一個 KP 用兩條線夾出一條帶，就選出 XOR 的 A。這兩個判斷要怎麼用神經元做出來？", "The previous KP picked out A with a strip between two lines. How can neurons make these two decisions?"),
 cards=[("c1", "**想法**：一條線直接答「A 還是 B」答不了，就改成先問兩個小問題，再用答案分類。", "**Idea**: one line cannot answer 'A or B?' directly, so first ask two small questions and classify from the answers.", REF, 118),
        ("term:隱藏層", "**隱藏層與輸出層**：先問小問題的一排計算單元叫隱藏層，每個單元的分界線是平面上的一條線；最後做分類的單元叫輸出層。輸入只提供座標，不算一層；兩層網路＝隱藏層＋輸出層。",
         "**Hidden layer and output layer**: the row of computing units that asks the small questions is the hidden layer, and the boundary of each unit is a line in the plane; the unit that makes the final classification is the output layer. Inputs only supply coordinates and are not a layer: a two-layer network is a hidden layer plus an output layer.", EDGE, 210),
        ("q", "**要問的問題**：兩條線各問什麼？", "**To answer**: what does each of the two lines ask?", MAIN, 86)],
 notes=("上一個 KP 的結論是：兩條平行線夾出一條帶，帶內是 XOR 的 A。這一頁開始把它做成網路。一條線直接回答「A 還是 B」答不了，所以改成先問兩個小問題，再用兩個答案做最後的分類。先問小問題的那一排線叫隱藏層，最後分類的平面叫輸出層。輸入節點只是提供座標 x1、x2，不算一層，所以這裡的兩層網路是一個隱藏層加一個輸出層；讀別的文獻時要先核對它怎麼數層。圖上是同樣四個 XOR 點與兩條平行線 g1 與 g2。接下來第二頁看每條線具體問什麼。",
        "The previous KP ended with two parallel lines enclosing a strip that contains the A points of XOR; this page starts turning that into a network. One line cannot answer 'A or B?' directly, so we first ask two small questions and classify from the two answers. The row of lines that asks the small questions is the hidden layer and the plane that makes the final classification is the output layer. The input nodes only supply the coordinates x1 and x2 and are not a layer, so a two-layer network here is one hidden layer plus one output layer; check how other texts count layers. The figure shows the same four XOR points with the two parallel lines g1 and g2. Next, page 2 shows what each line asks.")))
P.append(dict(
 lab=("每條線給一個位元", "One bit per line"),
 title=("每條線問一次：點在正側嗎？記成一個位元", "Each line asks: is the point on the positive side? Record one bit"),
 bridge=("要先問兩個小問題，就用兩條平行線，每條線問一次「點在正側嗎」。每個答案怎麼記？", "To ask two small questions, use two parallel lines and ask each: is the point on its positive side? How do we record each answer?"),
 cards=[("term:位元", "**位元**：點在線的正側（分數 $>0$）記 1，否則記 0。", "**Bit**: a point on the positive side of a line (score $>0$) gets 1, otherwise 0.", AUX, 118),
        ("term:階梯規則", "**階梯規則**：分數大於 0 記 1，其餘記 0（剛好等於 0 也記 0）。", "**Step rule**: a positive score gives 1, anything else gives 0 (exactly 0 also gives 0).", EDGE, 118),
        ("c3", "**兩條平行線**：$g_1=x_1+x_2-0.5$，$g_2=x_1+x_2-1.5$。每個點會得到兩個位元 $y_1,y_2$；下一頁走完一個點後，再給這一對位元一個名字。",
         "**Two parallel lines**: $g_1=x_1+x_2-0.5$ and $g_2=x_1+x_2-1.5$. Every point gets two bits $y_1,y_2$; the next page walks one point through and then names this pair of bits.", REF, 180)],
 notes=("上一頁決定先問兩個小問題，這一頁說清楚每條線問什麼：點在這條線的正側嗎？正側就是分數大於 0 的那一側，是的記 1，不是記 0，這個 0 或 1 叫位元；剛好在線上分數是 0，也記 0。兩條線是 g1 等於 x1+x2−0.5 與 g2 等於 x1+x2−1.5，圖上青色與紫色著色的是各自的正側，箭頭指向正側。兩個位元合在一起是 (y1,y2)，下一頁走完例子後再給它名字。這一步把分數變成 0 或 1 的規則叫階梯規則，它是非線性的，後面第十一頁會說明為什麼不能省。接下來第三頁用一個點走一遍。",
        "The previous page decided to ask two small questions; here we say exactly what each line asks: is the point on the positive side of this line? The positive side is where the score is greater than 0; if yes the answer is recorded as 1 and otherwise 0, and this 0 or 1 is a bit; a point exactly on the line has score 0 and also gets 0. The two lines are g1 = x1+x2-0.5 and g2 = x1+x2-1.5, and in the figure teal and violet tint their positive sides with arrows pointing to them. The two bits together, (y1, y2), get their name on the next page after the example. The rule that turns a score into 0 or 1 is the step rule; it is nonlinear, and the last extension page shows why it cannot be removed. Next, page 3 walks one point through.")))
P.append(dict(
 lab=("以 (0,1) 走一遍", "Walk through (0,1)"),
 title=("以 (0,1) 為例：分數 0.5 與 −0.5，編碼 (1,0)", "Take (0,1): scores 0.5 and −0.5, code (1,0)"),
 bridge=("每條線給一個位元。用 $(0,1)$ 當例子，實際走一遍：它會得到什麼隱藏編碼？", "Each line asks whether the point is on its positive side and records one bit. Walk $(0,1)$ through: what hidden code does it get?"),
 cards=[("f1", "**輸入** $(0,1)$", "**Input** $(0,1)$", REF, 86),
        ("f2", "**兩個分數**：$g_1=0+1-0.5=0.5$，$g_2=0+1-1.5=-0.5$", "**Two scores**: $g_1=0+1-0.5=0.5$ and $g_2=0+1-1.5=-0.5$", REF, 86),
        ("f3", "**階梯規則**：$0.5>0$ 所以 $y_1=1$；$-0.5\\le0$ 所以 $y_2=0$", "**Step rule**: $0.5>0$ gives $y_1=1$; $-0.5\\le0$ gives $y_2=0$", EDGE, 86),
        ("term:隱藏編碼", "**隱藏編碼** $\\mathbf y=(1,0)$：兩個位元連起來，像替點貼上兩張位置標籤。", "**Hidden code** $\\mathbf y=(1,0)$: the two bits together, like two position labels on the point.", OK, 118)],
 notes=("上一頁定義了位元，這一頁用 (0,1) 走一遍，走完再把兩個位元合起來取名為隱藏編碼。輸入 (0,1) 代入第一條線得到 g1 等於 0 加 1 減 0.5，是 0.5，大於 0，所以 y1 是 1；代入第二條線得到 g2 等於 0 加 1 減 1.5，是 −0.5，不大於 0，所以 y2 是 0。隱藏編碼是 (1,0)。圖上的星號是這個點，旁邊寫了兩個分數與兩個位元。請學生自己用 (0,0) 再走一次。右邊的流程從上到下是：輸入、兩個分數、階梯規則、隱藏編碼。接下來第四頁把四個點都算完。",
        "The previous page defined bits; here we walk (0,1) through and afterwards name the two bits together the hidden code. Substituting (0,1) into the first line gives g1 = 0 + 1 - 0.5 = 0.5, which is greater than 0, so y1 = 1; the second line gives g2 = 0 + 1 - 1.5 = -0.5, which is not greater than 0, so y2 = 0. The hidden code is (1,0). The star in the figure is this point and the labels show its two scores and two bits. Let the students repeat it with (0,0). The flow on the right reads top to bottom: input, two scores, step rule, hidden code. Next, page 4 computes all four points.")))
P.append(dict(
 lab=("四個點的編碼", "The four codes"),
 title=("四個點只得到三種編碼：(0,0)、(1,0)、(1,1)", "Four points, only three codes: (0,0), (1,0), (1,1)"),
 bridge=("$(0,1)$ 得到編碼 $(1,0)$。把四個點都算一遍，編碼會是什麼？", "Walking $(0,1)$ through gave scores 0.5 and −0.5 and the hidden code $(1,0)$. What are the scores and codes of all four points?"),
 cards=[("tab", "**逐點算 $g_1,\\ g_2$**\n$(0,0)$：$-0.5,\\ -1.5$ → $(0,0)$\n$(0,1)$：$0.5,\\ -0.5$ → $(1,0)$\n$(1,0)$：$0.5,\\ -0.5$ → $(1,0)$\n$(1,1)$：$1.5,\\ 0.5$ → $(1,1)$", "**Compute $g_1,\\ g_2$ point by point**\n$(0,0)$: $-0.5,\\ -1.5$ → $(0,0)$\n$(0,1)$: $0.5,\\ -0.5$ → $(1,0)$\n$(1,0)$: $0.5,\\ -0.5$ → $(1,0)$\n$(1,1)$: $1.5,\\ 0.5$ → $(1,1)$", REF, 186),
        ("note", "兩個 A 點 $(0,1)$ 與 $(1,0)$ 得到**同一個編碼** $(1,0)$：四個輸入只占三個位置。兩個點擠在一起，會不會丟資訊？", "The two A points $(0,1)$ and $(1,0)$ get the **same code** $(1,0)$: four inputs occupy only three locations. Does this lose information?", WARN, 148)],
 notes=("上一頁走了 (0,1)，這一頁把四個點都算完：(0,0) 的兩個分數是 −0.5 與 −1.5，編碼 (0,0)；(0,1) 與 (1,0) 的分數都是 0.5 與 −0.5，編碼都是 (1,0)；(1,1) 的分數是 1.5 與 0.5，編碼 (1,1)。圖上平面被兩條線切成三條帶，下面那條是編碼 (0,0)，中間那條是 (1,0)，上面那條是 (1,1)。注意兩個 A 點在中間那一帶，所以得到同一個編碼；四個輸入只占三個位置。這會不會丟資訊？接下來第五頁到編碼的平面上看。",
        "The previous page walked (0,1); here we compute all four points: (0,0) has scores -0.5 and -1.5 and code (0,0); (0,1) and (1,0) both have scores 0.5 and -0.5 and code (1,0); (1,1) has scores 1.5 and 0.5 and code (1,1). In the figure the plane is cut into three bands: the lower one has code (0,0), the middle one (1,0) and the upper one (1,1). Note that both A points lie in the middle band and therefore share one code; four inputs occupy three locations. Does that lose information? Next, page 5 looks at the plane of codes.")))
P.append(dict(
 lab=("編碼平面上一條線", "A line on the codes"),
 title=("在編碼的平面上，一條線就分開 A 和 B", "In the plane of codes, one line separates A from B"),
 bridge=("四個點只占三個位置，兩個 A 擠在一起。這樣的編碼還分得開 A 和 B 嗎？", "Four points occupy three locations and the two A points share one. Can A and B still be separated by these codes?"),
 cards=[("term:隱藏空間", "**隱藏空間**：把每個點換成它的編碼 $(y_1,y_2)$，畫在新的平面上：$(0,0)$ 是 B，$(1,0)$ 是 A（兩個輸入合併），$(1,1)$ 是 B；$(0,1)$ 空心，沒有輸入落在那裡。", "**Hidden space**: replace every point by its code $(y_1,y_2)$ and draw it in a new plane: $(0,0)$ is B, $(1,0)$ is A (two merged inputs) and $(1,1)$ is B; the hollow $(0,1)$ means no input lands there.", AUX, 180),
        ("c2", "**輸出層的線**：$g_{\\text{out}}=y_1-y_2-0.5$，線是 $y_2=y_1-0.5$；$g_{\\text{out}}>0$（線的下方）判 A。", "**The output line**: $g_{\\text{out}}=y_1-y_2-0.5$, the line is $y_2=y_1-0.5$; $g_{\\text{out}}>0$ (below the line) means A.", EDGE, 148),
        ("c3", "兩個 A 合併不要緊，因為它們同類。", "Merging the two A points does not matter, because they are the same class.", OK, 86)],
 notes=("上一頁看到兩個 A 擠到同一個編碼，這一頁到編碼的平面上看：把每個點換成它的編碼 (y1,y2)，畫在新的平面。(0,0) 是 B，(1,0) 是 A（兩個輸入合併成一個位置），(1,1) 是 B，(0,1) 是空心，沒有輸入會到那裡。新的平面上，一條線 y2 等於 y1 減 0.5 就把 A 與 B 分開：它下方的分數 y1−y2−0.5 為正，判 A。兩個 A 合併沒有關係，因為它們同類；如果是不同類被合併才有問題，第八頁會談。這一條線就是輸出層。接下來第六頁用它逐點驗算。",
        "The previous page showed the two A points sharing a code; here we look at the plane of codes: replace every point by its code (y1, y2) and draw it in a new plane. (0,0) is B, (1,0) is A (two inputs merged into one location), (1,1) is B and (0,1) is hollow because no input reaches it. In this new plane the line y2 = y1 - 0.5 separates A from B: below it the score y1 - y2 - 0.5 is positive, class A. Merging the two A points does not matter because they are the same class; merging different classes would be the problem, as page 8 shows. This line is the output layer. Next, page 6 checks it point by point.")))
P.append(dict(
 lab=("輸出層逐點驗算", "Check the output"),
 title=("輸出層逐點驗算：預測 (0,1,1,0) 剛好是 XOR", "Output layer check: predictions (0,1,1,0) are exactly XOR"),
 bridge=("輸出層在編碼的平面上畫了一條線。真的用它逐點算，預測會是什麼？", "The output layer draws one line in the plane of codes. Computed point by point, what are its predictions?"),
 cards=[("tab", "**輸出分數 $g_{\\text{out}}=y_1-y_2-0.5$**\n$(0,0)$：$0-0-0.5=-0.5$，判 B\n$(1,0)$：$1-0-0.5=0.5$，判 A（兩個 A 輸入）\n$(1,1)$：$1-1-0.5=-0.5$，判 B", "**Output score $g_{\\text{out}}=y_1-y_2-0.5$**\n$(0,0)$: $0-0-0.5=-0.5$, predict B\n$(1,0)$: $1-0-0.5=0.5$, predict A (both A inputs)\n$(1,1)$: $1-1-0.5=-0.5$, predict B", REF, 150),
        ("res", "四個輸入的預測依序是 $(0,1,1,0)$，剛好等於 XOR：4 點全對。這只是這四點的驗算，不是新資料上的準確率。", "The predictions for the four inputs are $(0,1,1,0)$, exactly XOR: 4 of 4 correct. This checks these four points; it is not an accuracy on new data.", OK, 148)],
 notes=("上一頁畫出輸出層的線，這一頁逐點驗算輸出分數 y1 減 y2 減 0.5：(0,0) 是 −0.5，判 B；(1,0) 是 0.5，判 A，這個位置代表兩個 A 輸入；(1,1) 是 −0.5，判 B。所以四個輸入的預測依序是 0、1、1、0，剛好等於 XOR，四點全對。圖上每個位置旁邊標了它的輸出分數。請特別說明這只是構造的四點驗證，不是在新資料上的準確率估計，這些權重也不是訓練自動學到的，是來源給的構造。接下來第七頁把整個網路翻回原來的平面。",
        "The previous page drew the output line; here we compute the output score y1 - y2 - 0.5 point by point: (0,0) gives -0.5, class B; (1,0) gives 0.5, class A, which stands for both A inputs; (1,1) gives -0.5, class B. So the predictions for the four inputs are 0, 1, 1, 0, exactly XOR, four of four correct. The figure shows the output score beside each location. Stress that this checks the construction on four points and is not an accuracy estimate on new data; these weights were not learned automatically but come from the source's construction. Next, page 7 turns the whole network back into the original plane.")))
P.append(dict(
 lab=("整個網路是一條帶", "The net is a strip"),
 title=("回到原來的平面：整個網路就是兩條線夾出的帶", "Back in the original plane: the whole network is the strip between two lines"),
 bridge=("輸出層分對了四個點。把整個網路翻回原來的 $(x_1,x_2)$ 平面，會是什麼樣子？", "The output layer classified the four points. Back in the original $(x_1,x_2)$ plane, what does the whole network look like?"),
 cards=[("c1", "**翻回去看**：$y_1=1$ 且 $y_2=0$，就是 $g_1>0$ 且 $g_2\\le0$，也就是 $x_1+x_2>0.5$ 而且 $x_1+x_2\\le1.5$。", "**Translate back**: $y_1=1$ and $y_2=0$ means $g_1>0$ and $g_2\\le0$, that is $x_1+x_2>0.5$ and $x_1+x_2\\le1.5$.", REF, 118),
        ("c2", "**這就是上一個 KP 的帶**：隱藏層做兩個判斷，輸出層只接受「$g_1>0$ 且 $g_2\\le0$」；整個網路在原平面上選出兩條線之間的帶，兩個 A 在帶內。", "**This is the strip of the previous KP**: the hidden layer makes the two decisions and the output layer accepts only $g_1>0$ and $g_2\\le0$; in the original plane the network selects the strip between the lines, with both A points inside.", AUX, 180),
        ("c3", "**留下的問題**：隱藏的線再多，會切出什麼？（下一個 KP）", "**Next**: if we add more hidden lines, what do they cut? (the next KP)", MAIN, 118)],
 notes=("上一頁驗算了輸出層，這一頁把整個網路翻回原來的 (x1,x2) 平面：y1 等於 1 且 y2 等於 0，就是 x1+x2 大於 0.5 而且不大於 1.5，也就是兩條平行線之間的那條帶。這就是上一個 KP 最後那條「0.5 小於 s 不大於 1.5」：隱藏層做兩個判斷，輸出層做「兩個都成立」。圖上藍色的帶裡有兩個 A 點，帶外有兩個 B 點。這張圖和上一個 KP 的帶狀圖是同一張，請學生對照。要注意：輸出層的線畫在編碼的平面上，不是直接畫在原來的圖上。接下來第八頁談這個構造的限制。",
        "The previous page checked the output layer; here we turn the whole network back into the original (x1, x2) plane: y1 = 1 and y2 = 0 means x1+x2 is greater than 0.5 and at most 1.5, the strip between the two parallel lines. This is the condition 0.5 < s <= 1.5 that ended the previous KP: the hidden layer makes the two decisions and the output layer asks for both. In the figure the blue strip contains the two A points and the two B points lie outside; it is the same picture as the strip of the previous KP, so let students compare. Note that the output line is drawn in the plane of codes, not directly on the original plot. Next, page 8 discusses the limits of this construction.")))
P.append(dict(
 lab=("合併的限制", "Limits of merging"),
 title=("合併同類沒關係，異類合併就糟了", "Merging the same class is fine; merging different classes is not"),
 bridge=("整個網路是一條帶，兩個 A 合併也沒問題。那所有合併都沒關係嗎？什麼情況會出問題？", "The whole network is a strip and merging the two A points is harmless. Is every merge harmless? When does it go wrong?"),
 cards=[("c1", "**合併同類沒關係**：本例兩個 A 合併，輸出層仍分得開。注意 $y_1,y_2$ 只是「在正側嗎」的位元，不是類別的機率。", "**Merging one class is harmless**: here the two A points merge and the output layer still separates them. Note that $y_1,y_2$ are only 'on the positive side?' bits, not class probabilities.", OK, 148),
        ("c2", "**異類合併就糟了**：若不同類的點得到同一個編碼，輸出層怎麼畫線都分不開，後面的決策救不回來。", "**Merging different classes is bad**: if points of different classes receive the same code, no output line can separate them and later decisions cannot recover.", WARN, 148),
        ("c3", "**留下的問題**：兩層網路更多隱藏線能分開任意標籤嗎？（下一個 KP）", "**Next**: with more hidden lines, can a two-layer network separate any labelling? (the next KP)", MAIN, 118)],
 notes=("上一頁看到整個網路是一條帶，兩個 A 合併沒有造成問題。這一頁問：所有合併都沒關係嗎？同類合併沒關係，因為合併後它們仍然有相同的標籤；但如果不同類的點得到同一個編碼，輸出層怎麼畫線都分不開。圖是示意：把一個 A 與一個 B 都放在 (1,1)，紅圈標出衝突。另一個常見誤解是把 y1、y2 當成類別機率，其實它們只是「在正側嗎」的位元。還要記得，這個構造只證明 XOR 可以表示，其他問題要先檢查隱藏編碼能不能被輸出層分開。接下來進入下一個 KP：隱藏的線更多，一個輸出層還分得開任意標籤嗎？",
        "The previous page showed that the whole network is a strip and that merging the two A points caused no trouble. This page asks whether every merge is harmless. Merging one class is harmless because the merged points still have the same label; but if points of different classes receive the same code, no output line can separate them. The figure is a schematic with an A and a B both at (1,1) and a red ring marking the conflict. Another common mistake is to read y1 and y2 as class probabilities; they are only 'on the positive side?' bits. This construction proves that XOR is representable, while other tasks must first check that the hidden codes can be separated by the output layer. Next comes the following KP: with more hidden lines, can one output layer separate any labelling?")))
P.append(dict(
 lab=("延伸:練習", "Extension: practice"),
 title=("延伸：練習，把輸出偏置改成 +0.5", "Extension: practice, change the output bias to +0.5"),
 bridge=("異類合併會讓輸出層失敗，那輸出層本身的係數改了呢？只把偏置從 $-0.5$ 改成 $+0.5$，四點會怎麼預測？", "Merging different classes makes the output layer fail. What if only the output bias changes from $-0.5$ to $+0.5$: what are the four predictions?"),
 cards=[("q1", "**題 1**：把輸出分數改成 $g_{\\text{out}}=y_1-y_2+0.5$，四個輸入的預測是什麼？", "**Question 1**: with $g_{\\text{out}}=y_1-y_2+0.5$, what are the predictions for the four inputs?", REF, 118),
        ("h1", "**提示**：偏置是分數式中的常數項（這裡的 $+0.5$）。保留隱藏編碼 $(0,0),(1,0),(1,0),(1,1)$，只重算輸出分數。", "**Hint**: the bias is the constant term of the score formula (here $+0.5$). Keep the hidden codes $(0,0),(1,0),(1,0),(1,1)$ and recompute only the output scores.", AUX, 118),
        ("q2", "**題 2**：哪些不同的輸入被合併？為什麼這次合併不造成衝突？", "**Question 2**: which different inputs are merged, and why does the merge cause no conflict?", REF, 118)],
 notes=("上一頁說異類合併才有問題，這一頁出練習讓學生自己驗證：保留隱藏編碼，只把輸出偏置從 −0.5 改成 +0.5。提示是保留隱藏編碼 (0,0)、(1,0)、(1,0)、(1,1)，只重算輸出分數 y1−y2+0.5。圖上畫的是新的輸出線 y2 等於 y1 加 0.5，請學生先判斷每個位置落在線的哪一側，再翻下一頁對照解答。題 2 問哪些輸入被合併、為什麼沒有衝突，提示：看它們的標籤。",
        "The previous page said that only merging different classes is a problem; this page asks students to check by themselves. Keep the hidden codes and change only the output bias from -0.5 to +0.5. The hint is to keep the codes (0,0), (1,0), (1,0), (1,1) and recompute the output score y1 - y2 + 0.5. The figure draws the new output line y2 = y1 + 0.5; ask the students to decide first which side each location lies on and then compare with the solution on the next page. Question 2 asks which inputs are merged and why that causes no conflict; hint: look at their labels.")))
P.append(dict(
 lab=("延伸:解題示範", "Extension: solution"),
 title=("延伸：題 1 的解題示範", "Extension: worked solution of question 1"),
 bridge=("練習把輸出偏置改成 $+0.5$，只重算輸出分數。四個輸入的預測是什麼？", "The practice changed the output bias to $+0.5$ and recomputed only the output scores. What are the four predictions?"),
 cards=[("a1", "**① 符號式**：$g_{\\text{out}}=y_1-y_2+0.5$，$g_{\\text{out}}>0$ 判 A。", "**① Formula**: $g_{\\text{out}}=y_1-y_2+0.5$, class A if $g_{\\text{out}}>0$.", REF, 86),
        ("a2", "**② 代入三個位置**：$(0,0)$：$0.5$；$(1,0)$：$1.5$；$(1,1)$：$0.5$。", "**② Substitute the three locations**: $(0,0)$: $0.5$; $(1,0)$: $1.5$; $(1,1)$: $0.5$.", REF, 86),
        ("a3", "**③ 預測**：三個位置的分數都為正，四個輸入全判 A。", "**③ Predictions**: all three scores are positive, so all four inputs are predicted A.", REF, 86),
        ("a4", "**④ 核對**：XOR 的真值是 B、A、A、B，兩個 B 被判成 A，錯 2 點；偏置移動了線，讓線不再分開 B 與 A。題 2：被合併的是 $(0,1)$ 與 $(1,0)$，同為 A，所以沒有衝突。", "**④ Check**: XOR is B, A, A, B, so the two B inputs are predicted A: 2 errors. The bias moved the line so it no longer separates B from A. Question 2: the merged inputs are $(0,1)$ and $(1,0)$, both A, so there is no conflict.", WARN, 148)],
 notes=("上一頁出了題 1，這一頁是它的完整解題示範：符號式 g_out 等於 y1 減 y2 加 0.5；代入 (0,0) 得 0.5，(1,0) 得 1.5，(1,1) 得 0.5；三個都是正的，所以四個輸入全判 A；XOR 的真值是 B、A、A、B，兩個 B 被判成 A，錯 2 點。圖上的紅圈是這兩個錯誤。這說明輸出層的偏置不能隨便改：它把線平移，會讓原本分開的 B 與 A 又跑到同一側。這和第一個 KP 學到的常數項是同一件事。接下來最後一頁問：如果去掉階梯，會怎樣？",
        "The previous page posed question 1 and this page is its full solution: the formula is g_out = y1 - y2 + 0.5; substituting gives 0.5 at (0,0), 1.5 at (1,0) and 0.5 at (1,1); all three are positive, so all four inputs are predicted A; XOR is B, A, A, B, so the two B inputs are wrong, 2 errors, marked by the red rings. The output bias cannot be changed freely: it shifts the line and can put B and A back on the same side. This is the same constant term as in the first KP. Next, the last page asks what happens if we remove the steps.")))
P.append(dict(
 lab=("延伸:階梯不能省", "Extension: steps"),
 title=("延伸：階梯不能省，否則整個網路還是線性的", "Extension: the steps cannot be removed, or the network stays linear"),
 bridge=("輸出層的偏置不能亂改。那隱藏層的階梯呢？如果去掉階梯，輸出分數會變成什麼？", "The output bias cannot be changed freely. What about the steps in the hidden layer? If we remove them, what does the output score become?"),
 cards=[("b1", "**① 去掉階梯**：$y_1=g_1=x_1+x_2-0.5$，$y_2=g_2=x_1+x_2-1.5$。", "**① Remove the steps**: $y_1=g_1=x_1+x_2-0.5$ and $y_2=g_2=x_1+x_2-1.5$.", REF, 118),
        ("b2", "**② 代入輸出分數**：$g_{\\text{out}}=y_1-y_2-0.5=(x_1+x_2-0.5)-(x_1+x_2-1.5)-0.5$", "**② Substitute into the output score**: $g_{\\text{out}}=y_1-y_2-0.5=(x_1+x_2-0.5)-(x_1+x_2-1.5)-0.5$", REF, 118),
        ("b3", "**③ 化簡**：$g_{\\text{out}}=0.5$，和 $x$ 無關。", "**③ Simplify**: $g_{\\text{out}}=0.5$, independent of $x$.", REF, 86),
        ("b4", "**④ 結果**：每個點都判 A，XOR 錯 2 點。線性式的疊加仍是線性式，所以非線性要靠階梯。", "**④ Result**: all points predicted A, 2 XOR errors. Linear combinations stay linear, so nonlinearity needs the steps.", WARN, 118)],
 notes=("上一頁看到偏置不能亂改，這一頁問階梯可不可以省。去掉階梯，隱藏層的輸出就是分數本身，y1 等於 x1+x2−0.5，y2 等於 x1+x2−1.5；代入輸出分數得到 (x1+x2−0.5) 減 (x1+x2−1.5) 再減 0.5，x1 與 x2 全部消掉，剩 0.5，是一個常數，所以每個點都判 A，XOR 錯 2 點。道理是：線性式的組合還是線性式，疊幾層都一樣，非線性只能來自階梯這類運算。這是補充的推導，已用程式驗算。KP02 到此結束，接下來進入下一個 KP：更多隱藏線能切出什麼區域。",
        "The previous page showed that the bias cannot be changed freely; this page asks whether the steps can be dropped. Without the steps the hidden outputs are the scores themselves, y1 = x1+x2-0.5 and y2 = x1+x2-1.5; substituting into the output score gives (x1+x2-0.5) - (x1+x2-1.5) - 0.5, where x1 and x2 cancel completely and leave the constant 0.5, so every point is predicted A and XOR has 2 errors. The reason is that a combination of linear expressions is linear again, however many layers there are, so the nonlinearity can only come from operations such as the step. This is an added derivation, checked by program. KP02 ends here; next comes the following KP: what regions do more hidden lines cut?")))
PAGES = P
