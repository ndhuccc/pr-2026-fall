// lecture md -> single-file reading HTML (marked + KaTeX, images inlined as base64)
import fs from "fs"; import path from "path";
import { createRequire } from "module";
const req = createRequire("/home/user/pr-2026-fall/.agents/skills/slides-to-html/package.json");
const { marked } = await import(req.resolve("marked").replace(/\.cjs$/, ".esm.js").replace("lib/marked.cjs","lib/marked.esm.js")).catch(async () => ({ marked: req("marked").marked }));
const katex = req("katex");
const [,, mdPath, outPath, assetsDir, lang = "zh-Hant", docTitle = "KP03"] = process.argv;
let md = fs.readFileSync(mdPath, "utf8");
const store = [];
const hold = (tex, display) => { store.push([tex, display]); return `@@M${store.length - 1}@@`; };
md = md.replace(/\$\$([\s\S]+?)\$\$/g, (_, t) => hold(t, true));
md = md.replace(/\$([^$\n]+?)\$/g, (_, t) => hold(t, false));
let html = marked.parse(md);
html = html.replace(/@@M(\d+)@@/g, (_, i) => { const [t, d] = store[+i]; try { return katex.renderToString(t, { displayMode: d, throwOnError: true }); } catch (e) { throw new Error("KaTeX: " + t + " " + e.message); } });
html = html.replace(/<img src="\.\.\/assets\/figures\/([^"]+)"/g, (_, f) => {
  const p = path.join(assetsDir, f); const b = fs.readFileSync(p).toString("base64"); return `<img style="max-width:100%" src="data:image/png;base64,${b}"`; });
html = html.replace(/<a href="\.\.\/slides\/([^"]+)">/g, '<a href="$1">');
const kdir = path.dirname(req.resolve("katex/dist/katex.min.css"));
const css = fs.readFileSync(path.join(kdir, "katex.min.css"), "utf8").replace(/src:\s*url\((fonts\/[^)]+?\.woff2)\)[^;}]*/g, (_, f) => `src:url(data:font/woff2;base64,${fs.readFileSync(path.join(kdir, f)).toString("base64")}) format("woff2")`);
const doc = `<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${docTitle}</title><style>${css}
body{font-family:"Inter","Helvetica Neue",Arial,"Noto Sans CJK TC","Noto Sans TC","PingFang TC",sans-serif;max-width:860px;margin:2rem auto;padding:0 1rem;line-height:1.7;color:#1c1712}
h1{font-size:1.6rem}h2{border-bottom:2px solid #e0995f;padding-bottom:.2rem;margin-top:2rem}h3{margin-top:1.6rem}
table{border-collapse:collapse;margin:1rem 0}td,th{border:1px solid #bbb;padding:.3rem .7rem}blockquote{border-left:4px solid #e0995f;margin:1rem 0;padding:.1rem 1rem;color:#555}
img{display:block;margin:1rem auto}</style></head><body>${html}</body></html>`;
fs.writeFileSync(outPath, doc); console.log("ok", Math.round(doc.length / 1024), "KB");
