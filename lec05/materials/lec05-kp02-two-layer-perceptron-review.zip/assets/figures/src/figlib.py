"""KP03 figures (dark skin). All coordinates computed from the lecture's three lines g1=x1, g2=x2, g3=-x1+x2-1."""
import itertools, os, sys
import numpy as np
sys.path.insert(0, "/home/user/pr-2026-fall/.agents/skills/view-from-text")
from jbd_figure import *
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle, Rectangle, ConnectionPatch, FancyArrowPatch

use_jbd_style(18)
LIGHT = os.environ.get("LIGHT") == "1"
BG, CUBE_EDGE, STAR = ("#ffffff", "#4a443b", "#1c1712") if LIGHT else ("#1c1712", "#cfc8bb", "#ffffff")
if LIGHT:
    plt.rcParams.update({"text.color": BG, "axes.labelcolor": BG, "axes.edgecolor": "#6b645a", "xtick.color": "#4a443b", "ytick.color": "#4a443b"})
OUT = os.path.join(os.getcwd(), "assets", "figures")
def set_out(d):
    global OUT
    OUT = d
TXT, MUT = (("#1c1712", "#6b645a") if LIGHT else (PALETTE["text"], PALETTE["muted"]))
A_C, B_C = "#6a9fd6", "#d97757"          # class A (circle) blue, class B (square) orange
LINE = "#e0995f"
TINT = {"000": "#5fb8a8", "001": "#a98bd0", "010": "#b9a35e", "011": "#d08bb0",
        "100": "#7dbb8c", "101": "#888888", "110": "#8fa7b8", "111": "#c9a27a"}
CODES = ["".join(map(str, b)) for b in itertools.product([0, 1], repeat=3)]
A1 = {"000", "001", "011"}                 # first labelling (succeeds)
A2 = {"000", "110", "111"}                 # second labelling (fails)
REAL = [c for c in CODES if c != "101"]
Q = lambda y: -y[0] - y[1] + y[2] + 0.5

def code_of(x1, x2):
    return "".join("1" if g > 0 else "0" for g in (x1, x2, -x1 + x2 - 1))

def fpx(px): return px_to_pt(px)

def save(fig, name):
    CUR[0] = name
    os.makedirs(OUT, exist_ok=True)
    if LIGHT:
        bad = check_not_clipped(fig)
        if bad: raise ValueError("; ".join(bad))
        os.makedirs(os.path.join(os.path.dirname(OUT), "light"), exist_ok=True)
        fig.savefig(os.path.join(os.path.dirname(OUT), "light", name + ".png"), dpi=150, facecolor="white", transparent=False)
        plt.close(fig); print("light", name); return
    svg = svg_text_checked(fig)
    open(os.path.join(OUT, name + ".svg"), "w", encoding="utf-8").write(svg)
    print(name, len(svg) // 1024, "KB")

CUR = [""]
def svg_text_checked(fig):
    os.makedirs(os.path.join(os.path.dirname(OUT), "..", "prevfig"), exist_ok=True)
    bad = check_not_clipped(fig)
    if bad: raise ValueError("; ".join(bad))
    import io
    fig.savefig(os.path.join(os.path.dirname(OUT), "..", "prevfig", CUR[0] + ".png"), dpi=100, facecolor=BG, transparent=False)
    svg = svg_text(fig)
    pr = check_svg(svg)
    if pr: raise ValueError("; ".join(pr))
    return svg

def new_fig(w, h):
    fig = plt.figure(figsize=(w / 100, h / 100))
    return fig

def panel(fig, w, h, x, y, pw, ph):
    """axes at pixel box (x,y from top-left)."""
    return fig.add_axes([x / w, 1 - (y + ph) / h, pw / w, ph / h])

# ------------------------------------------------------------------ plane
LIM = 2.6
def draw_plane(ax, tint=True, classes=None, show_codes=True, show_lines=True, signs=True, lim=LIM, codefs=18, dashed_g3=False):
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_aspect("equal"); ax.axis("off")
    n = 400
    xs = np.linspace(-lim, lim, n); X, Y = np.meshgrid(xs, xs)
    code = (X > 0) * 4 + (Y > 0) * 2 + ((-X + Y - 1) > 0) * 1
    for k, c in enumerate(CODES):
        mask = (code == k).astype(float)
        if mask.sum() == 0: continue
        if classes is None: col, al = TINT[c], 0.40
        else: col, al = (A_C if c in classes else B_C), 0.55
        ax.contourf(X, Y, mask, levels=[0.5, 1.5], colors=[col], alpha=al, antialiased=True)
    ax.add_patch(Rectangle((-lim, -lim), 2 * lim, 2 * lim, fill=False, ec=MUT, lw=1.4))
    if show_lines:
        ax.plot([0, 0], [-lim, lim], color=LINE, lw=3)
        ax.plot([-lim, lim], [0, 0], color=LINE, lw=3)
        ax.plot([-lim, lim - 1], [-lim + 1, lim], color=LINE, lw=3, ls="--" if dashed_g3 else "-")
    if show_codes:
        pos = {"000": (-1.2, -1.1), "001": (-2.0, -0.3), "010": (-0.55, 0.2), "011": (-1.6, 1.5),
               "100": (1.6, -0.7), "110": (1.9, 0.5), "111": (0.4, 1.85)}
        for c, (px, py) in pos.items():
            ax.text(px, py, c, color=TXT, fontsize=fpx(codefs), ha="center", va="center", fontweight="bold")
    return ax

def line_labels(ax, fs=20):
    ax.text(0.12, 2.36, "$g_1=0$", color=LINE, fontsize=fpx(fs), ha="left", fontweight="bold")
    ax.text(2.45, -0.3, "$g_2=0$", color=LINE, fontsize=fpx(fs), ha="right")
    ax.text(-2.5, -2.3, "$g_3=0$", color=LINE, fontsize=fpx(fs), ha="left", rotation=0)

def plus_arrows(ax, fs=18):
    # '+' side of each line (score > 0)
    for (x, y, dx, dy) in [(0.0, -2.0, 0.55, 0), (-1.9, 0.0, 0, 0.55), (1.2, 2.2, -0.35, 0.35)]:
        pass
    ax.annotate("", xy=(0.75, -2.15), xytext=(0.05, -2.15), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(0.85, -2.15, "+", color=TXT, fontsize=fpx(fs), va="center", fontweight="bold")
    ax.annotate("", xy=(-2.15, 0.75), xytext=(-2.15, 0.05), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(-2.15, 0.9, "+", color=TXT, fontsize=fpx(fs), ha="center", fontweight="bold")
    ax.annotate("", xy=(-2.0, -0.12), xytext=(-1.55, -0.57), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(-2.2, -0.0, "+", color=TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold")

def mark(ax, x, y, text, fs=18, dx=0.12, dy=0.18, shape="*", col=None, ms=16):
    col = col or STAR
    ax.plot([x], [y], marker=shape, color=col, ms=ms, mec=BG, mew=1.2, zorder=6)
    ax.text(x + dx, y + dy, text, color=TXT, fontsize=fpx(fs), zorder=7,
            bbox=dict(boxstyle="round,pad=0.15", fc=BG, ec="none", alpha=0.75))

# ------------------------------------------------------------------ cube (oblique projection)
def P(y):
    return (y[0] + 0.5 * y[1], y[2] + 0.4 * y[1])

def draw_cube(ax, pad=0.55, edge=CUBE_EDGE, lw=2.2, fill_faces=None):
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-pad, 1.5 + pad); ax.set_ylim(-pad, 1.4 + pad)
    V = {c: tuple(int(b) for b in c) for c in CODES}
    hidden = {("010", "110"), ("010", "011"), ("000", "010")}
    for a, b in itertools.combinations(CODES, 2):
        if sum(x != y for x, y in zip(a, b)) != 1: continue
        (x0, y0), (x1, y1) = P(V[a]), P(V[b])
        dash = (a, b) in hidden or (b, a) in hidden
        ax.plot([x0, x1], [y0, y1], color=edge, lw=lw, ls=(0, (4, 3)) if dash else "-", alpha=0.55 if dash else 0.95, zorder=1)
    return V

LBL_OFF = {"000": (-0.20, -0.16), "100": (0.18, -0.16), "010": (-0.24, 0.0), "110": (0.28, 0.0),
           "001": (-0.20, 0.16), "101": (-0.22, 0.16), "011": (-0.28, 0.14), "111": (0.26, 0.14)}
def corner(ax, c, kind="tint", lab=True, fs=18, ms=18, extra=None, vfs=None):
    x, y = P(tuple(int(b) for b in c))
    if kind == "tint":
        ax.plot([x], [y], "o", ms=ms, color=TINT[c] if c != "101" else "none", mec=TXT if c != "101" else MUT, mew=2.2 if c != "101" else 2.2,
                ls="none", zorder=5)
        if c == "101": ax.plot([x], [y], "o", ms=ms, mfc="none", mec=MUT, mew=2.2, zorder=5)
    elif kind == "A":
        ax.plot([x], [y], "o", ms=ms, color=A_C, mec=BG, mew=1.5, zorder=5)
    elif kind == "B":
        ax.plot([x], [y], "s", ms=ms - 2, color=B_C, mec=BG, mew=1.5, zorder=5)
    elif kind == "none":
        ax.plot([x], [y], "o", ms=ms, mfc="none", mec=MUT, mew=2.4, zorder=5)
    if lab:
        dx, dy = LBL_OFF[c]
        ax.text(x + dx, y + dy, extra if extra is not None else c, color=TXT, fontsize=fpx(vfs or fs), ha="center", va="center", fontweight="bold",
                zorder=7, bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.6))

def axes_arrows(ax, fs=18):
    for (y, name, off) in [((1.28, 0, 0), "$y_1$", (0.04, -0.17)), ((0, 1.28, 0), "$y_2$", (0.0, 0.1)), ((0, 0, 1.28), "$y_3$", (0, 0.1))]:
        pass

def cut_polygon(coef, b):
    """polygon where  coef.y + b = 0 meets the unit cube (list of 3D points, ordered)."""
    pts = []
    for a, c in itertools.combinations(CODES, 2):
        if sum(x != y for x, y in zip(a, c)) != 1: continue
        ya, yc = np.array([int(t) for t in a], float), np.array([int(t) for t in c], float)
        fa, fc = coef @ ya + b, coef @ yc + b
        if fa * fc < 0:
            t = fa / (fa - fc); pts.append(ya + t * (yc - ya))
        elif fa == 0: pts.append(ya)
    uniq = []
    for p in pts:
        if not any(np.allclose(p, u) for u in uniq): uniq.append(p)
    pts2 = np.array([P(p) for p in uniq]); cen = pts2.mean(0)
    order = np.argsort(np.arctan2(pts2[:, 1] - cen[1], pts2[:, 0] - cen[0]))
    return [tuple(pts2[i]) for i in order]

def draw_cut(ax, coef, b, fc=LINE, alpha=0.30):
    poly = cut_polygon(np.array(coef, float), b)
    ax.add_patch(Polygon(poly, closed=True, fc=fc, ec=fc, alpha=alpha, lw=0, zorder=3))
    ax.add_patch(Polygon(poly, closed=True, fc="none", ec=fc, lw=2.6, zorder=4))

def legend_ab(ax, x, y, fs=18, dx=0.55, tx=0.12):
    ax.plot([x], [y], "o", ms=14, color=A_C, mec=BG); ax.text(x + tx, y, "A", color=TXT, fontsize=fpx(fs), va="center")
    ax.plot([x + dx], [y], "s", ms=12, color=B_C, mec=BG); ax.text(x + dx + tx, y, "B", color=TXT, fontsize=fpx(fs), va="center")


