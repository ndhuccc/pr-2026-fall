import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
PTS = [(0, 0), (0, 1), (1, 0), (1, 1)]
LAB = {"OR": {(0, 0): "B", (0, 1): "A", (1, 0): "A", (1, 1): "A"},
       "AND": {(0, 0): "B", (0, 1): "B", (1, 0): "B", (1, 1): "A"},
       "XOR": {(0, 0): "B", (0, 1): "A", (1, 0): "A", (1, 1): "B"}}
LO, HI = -0.4, 1.4
RED = "#e07a70"

def sq(ax, ticks=True):
    ax.set_xlim(LO, HI); ax.set_ylim(LO, HI); ax.set_aspect("equal")
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.set_xticks([0, 1] if ticks else []); ax.set_yticks([0, 1] if ticks else [])
    ax.tick_params(labelsize=fpx(17))
    ax.text(HI - 0.02, LO + 0.04, "$x_1$", fontsize=fpx(19), ha="right", va="bottom", color=TXT)
    ax.text(LO + 0.04, HI - 0.02, "$x_2$", fontsize=fpx(19), ha="left", va="top", color=TXT)
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=MUT, lw=1.2, ls=(0, (3, 3))))

def pt(ax, xy, cls, ms=20, z=5):
    if cls == "A": ax.plot(*xy, "o", ms=ms, color=A_C, mec=BG, mew=1.5, zorder=z)
    else: ax.plot(*xy, "s", ms=ms - 2, color=B_C, mec=BG, mew=1.5, zorder=z)

def tint(ax, w1, w2, w0, color=A_C, alpha=0.22):
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (w1 * X + w2 * Y + w0 > 0).astype(float), levels=[0.5, 1.5], colors=[color], alpha=alpha, zorder=1)

def line(ax, w1, w2, w0, color=LINE, lw=3, ls="-"):
    n = 400; xs = np.linspace(LO, HI, n)
    if abs(w2) > 1e-9:
        ys = -(w1 * xs + w0) / w2; m = (ys >= LO) & (ys <= HI); ax.plot(xs[m], ys[m], color=color, lw=lw, ls=ls, zorder=3)
    else:
        ax.plot([-w0 / w1] * 2, [LO, HI], color=color, lw=lw, ls=ls, zorder=3)

def ring(ax, xy, ms=34):
    ax.plot(*xy, "o", ms=ms, mfc="none", mec=RED, mew=3, zorder=6)

def cap(fig, w, h, x, ytop, text, color=None, fs=20):
    fig.text(x / w, 1 - ytop / h, text, color=color or TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold")


TEAL2, VIO2 = "#5fb8a8", "#a98bd0"
def pts_xor(ax, ms=20):
    for p_ in PTS: pt(ax, p_, LAB["XOR"][p_], ms=ms)

def sides(ax):
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (X + Y - 0.5 > 0).astype(float), levels=[0.5, 1.5], colors=[TEAL2], alpha=0.22, zorder=1)
    ax.contourf(X, Y, (X + Y - 1.5 > 0).astype(float), levels=[0.5, 1.5], colors=[VIO2], alpha=0.30, zorder=1)

def plus(ax, base, col):
    x0, y0 = base
    ax.annotate("", xy=(x0 + 0.17, y0 + 0.17), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", color=col, lw=2.6), zorder=8)

def f_net_wiring():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    ins = [(70, 150, "$x_1$"), (70, 310, "$x_2$")]; hid = [(250, 100, "$g_1$", TEAL2, "$y_1$"), (250, 360, "$g_2$", VIO2, "$y_2$")]
    for (x0, y0, _) in ins:
        for (x1, y1, *_r) in hid: ax.plot([x0 + 28, x1 - 34], [y0, y1], color=MUT, lw=1.8, zorder=1)
    for (x1, y1, *_r) in hid: ax.plot([x1 + 34, 430 - 34], [y1, 230], color=MUT, lw=1.8, zorder=1)
    for (x0, y0, t) in ins:
        ax.add_patch(Circle((x0, y0), 28, fc="none", ec=TXT, lw=2.4, zorder=3)); ax.text(x0, y0, t, color=TXT, fontsize=fpx(20), ha="center", va="center", zorder=4)
    for (x0, y0, t, col, yb) in hid:
        ax.add_patch(Circle((x0, y0), 34, fc="none", ec=col, lw=3, zorder=3)); ax.text(x0, y0, t, color=TXT, fontsize=fpx(20), ha="center", va="center", zorder=4)
        ax.text(x0, y0 + (58 if y0 < 200 else -58), "bit " + yb, color=col, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
    ax.add_patch(Circle((430, 230), 34, fc="none", ec=A_C, lw=3, zorder=3)); ax.text(430, 230, "out", color=TXT, fontsize=fpx(19), ha="center", va="center", zorder=4)
    for x0, t in [(70, "input"), (250, "hidden layer"), (430, "output layer")]: ax.text(x0, 30, t, color=MUT, fontsize=fpx(18), ha="center")
    ax.text(260, 440, "each unit has a boundary line in the plane", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    save(fig, "lec05-kp02-net-wiring")

def f_input_lines():
    w, h = 520, 490
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    line(ax, 1, 1, -0.5, color=TEAL2); line(ax, 1, 1, -1.5, color=VIO2); pts_xor(ax)
    ax.text(0.42, 0.42, "$g_1=x_1+x_2-0.5$", color=TEAL2, fontsize=fpx(18), fontweight="bold", ha="center", va="center", rotation=-45, rotation_mode="anchor")
    ax.text(0.62, 0.62, "$g_2=x_1+x_2-1.5$", color=VIO2, fontsize=fpx(18), fontweight="bold", ha="center", va="center", rotation=-45, rotation_mode="anchor")
    cap(fig, w, h, 285, 435, "XOR points and two parallel lines", fs=20)
    from matplotlib.lines import Line2D
    for (px, m_, c_, t_) in [(200, "o", A_C, "A"), (260, "s", B_C, "B")]:
        fig.add_artist(Line2D([px / w], [1 - 465 / h], marker=m_, color=c_, ms=14, mec=BG, transform=fig.transFigure, ls="none"))
        fig.text((px + 14) / w, 1 - 465 / h, t_, color=TXT, fontsize=fpx(18), va="center")
    save(fig, "lec05-kp02-input-lines")

def f_input_sides():
    w, h = 520, 478
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax); sides(ax)
    line(ax, 1, 1, -0.5, color=TEAL2); line(ax, 1, 1, -1.5, color=VIO2); pts_xor(ax)
    plus(ax, (0.2, 0.55), TEAL2); ax.text(0.42, 0.78, "$+$", color=TEAL2, fontsize=fpx(22), fontweight="bold")
    plus(ax, (0.9, 1.0), VIO2); ax.text(1.12, 1.2, "$+$", color=VIO2, fontsize=fpx(22), fontweight="bold")
    ax.text(0.02, 1.28, "$g_1$", color=TEAL2, fontsize=fpx(20), fontweight="bold", va="center")
    ax.text(0.45, 1.28, "$g_2$", color=VIO2, fontsize=fpx(20), fontweight="bold", va="center")
    cap(fig, w, h, 285, 430, "tint = positive side of a line", fs=20)
    from matplotlib.lines import Line2D
    for (px, m_, c_, t_) in [(200, "o", A_C, "A"), (260, "s", B_C, "B")]:
        fig.add_artist(Line2D([px / w], [1 - 458 / h], marker=m_, color=c_, ms=14, mec=BG, transform=fig.transFigure, ls="none"))
        fig.text((px + 14) / w, 1 - 458 / h, t_, color=TXT, fontsize=fpx(18), va="center")
    save(fig, "lec05-kp02-input-sides")

def f_bits_example():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    line(ax, 1, 1, -0.5, color=TEAL2); line(ax, 1, 1, -1.5, color=VIO2); pts_xor(ax)
    ax.plot([0], [1], "*", ms=30, color=STAR, mec=BG, zorder=9)
    ax.text(0.1, 1.2, "$(0,1)$", color=TXT, fontsize=fpx(19), fontweight="bold", va="center", zorder=9)
    ax.text(0.12, 0.78, "$g_1=0.5>0$: $y_1=1$", color=TEAL2, fontsize=fpx(17), fontweight="bold", zorder=9, bbox=dict(boxstyle="round,pad=0.15", fc=BG, ec="none", alpha=0.8))
    ax.text(0.12, 0.62, "$g_2=-0.5\\leq0$: $y_2=0$", color=VIO2, fontsize=fpx(17), fontweight="bold", zorder=9, bbox=dict(boxstyle="round,pad=0.15", fc=BG, ec="none", alpha=0.8))
    cap(fig, w, h, 285, 435, "the point (0,1) gets the code (1,0)", fs=20)
    save(fig, "lec05-kp02-bits-example")

def f_bands():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs); S = X + Y
    for lo_, hi_, col in [(-9, 0.5, "#8fa7b8"), (0.5, 1.5, A_C), (1.5, 9, "#8fa7b8")]:
        ax.contourf(X, Y, ((S > lo_) & (S <= hi_)).astype(float), levels=[0.5, 1.5], colors=[col], alpha=0.25, zorder=1)
    line(ax, 1, 1, -0.5, color=TEAL2); line(ax, 1, 1, -1.5, color=VIO2); pts_xor(ax)
    ax.text(0.12, -0.18, "code $(0,0)$", color=TXT, fontsize=fpx(18), fontweight="bold", ha="left")
    ax.text(0.28, 0.5, "code $(1,0)$", color=TXT, fontsize=fpx(18), fontweight="bold", ha="center", rotation=-45)
    ax.text(0.95, 1.2, "code $(1,1)$", color=TXT, fontsize=fpx(18), fontweight="bold", ha="center")
    cap(fig, w, h, 285, 435, "three bands, three codes", fs=20)
    save(fig, "lec05-kp02-bands")

def hid(ax, hollow=True):
    ax.set_xlim(LO, HI); ax.set_ylim(LO, HI); ax.set_aspect("equal")
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1]); ax.tick_params(labelsize=fpx(17))
    ax.text(HI - 0.02, LO + 0.04, "$y_1$", fontsize=fpx(19), ha="right", va="bottom", color=TXT)
    ax.text(LO + 0.04, HI - 0.02, "$y_2$", fontsize=fpx(19), ha="left", va="top", color=TXT)
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=MUT, lw=1.2, ls=(0, (3, 3))))
    if hollow: ax.plot([0], [1], "o", ms=20, mfc="none", mec=MUT, mew=2.2, zorder=4)

def hidden_points(ax, ms=22):
    pt(ax, (1, 0), "A", ms=ms); pt(ax, (0, 0), "B", ms=ms); pt(ax, (1, 1), "B", ms=ms)

def f_hidden_plane():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); hid(ax)
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (X - Y - 0.5 > 0).astype(float), levels=[0.5, 1.5], colors=[A_C], alpha=0.22, zorder=1)
    ax.plot([-0.4, 0.9], [-0.9, 0.4], color=LINE, lw=3, zorder=3)
    ax.plot([-0.4, 0.9], [-0.9, 0.4], color=LINE, lw=0)
    # line y2 = y1 - 0.5 inside window
    xs2 = np.linspace(LO, HI, 50); ys2 = xs2 - 0.5; m = ys2 >= LO
    ax.plot(xs2[m], ys2[m], color=LINE, lw=3, zorder=3)
    hidden_points(ax)
    ax.text(1.02, 0.16, "A  ×2 inputs", color=TXT, fontsize=fpx(17), fontweight="bold", va="center")
    ax.text(0.02, 1.25, "$y_2=y_1-0.5$", color=LINE, fontsize=fpx(19), fontweight="bold", va="center")
    ax.text(0.7, -0.3, "$g_{out}>0$ below", color=A_C, fontsize=fpx(17), fontweight="bold", va="center")
    cap(fig, w, h, 285, 435, "hidden space: one line separates A from B", fs=19)
    save(fig, "lec05-kp02-hidden-plane")

def f_hidden_scores():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); hid(ax)
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (X - Y - 0.5 > 0).astype(float), levels=[0.5, 1.5], colors=[A_C], alpha=0.22, zorder=1)
    xs2 = np.linspace(LO, HI, 50); ys2 = xs2 - 0.5; m = ys2 >= LO
    ax.plot(xs2[m], ys2[m], color=LINE, lw=3, zorder=3)
    hidden_points(ax)
    for (x, y, t, dx, dy) in [(0, 0, "$g_{out}=-0.5$", 0.05, 0.2), (1, 0, "$g_{out}=0.5$", 0.0, -0.22), (1, 1, "$g_{out}=-0.5$", 0.0, 0.2)]:
        ax.text(x + dx, y + dy, t, color=TXT, fontsize=fpx(17), fontweight="bold", ha="center", va="center", zorder=7,
                bbox=dict(boxstyle="round,pad=0.12", fc=BG, ec="none", alpha=0.75))
    cap(fig, w, h, 285, 435, "output score at each hidden location", fs=20)
    save(fig, "lec05-kp02-hidden-scores")

def f_strip_net():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs); S = X + Y
    ax.contourf(X, Y, ((S > 0.5) & (S <= 1.5)).astype(float), levels=[0.5, 1.5], colors=[A_C], alpha=0.25, zorder=1)
    line(ax, 1, 1, -0.5, color=TEAL2); line(ax, 1, 1, -1.5, color=VIO2); pts_xor(ax)
    ax.text(0.02, 1.28, "$y_1=1$ and $y_2=0$", color=A_C, fontsize=fpx(19), fontweight="bold", va="center")
    cap(fig, w, h, 285, 435, "the whole network = the strip", fs=20)
    save(fig, "lec05-kp02-strip-net")

def f_merge_bad():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); hid(ax, hollow=False)
    pt(ax, (0, 0), "B", ms=22); pt(ax, (1, 0), "A", ms=22)
    ax.plot([1], [1], "o", ms=24, color=A_C, mec=BG, mew=1.5, zorder=5, markerfacecoloralt=B_C, fillstyle="left")
    ax.plot([1], [1], "o", ms=24, color=B_C, mec=BG, mew=1.5, zorder=5, fillstyle="right")
    ax.plot([1], [1], "o", ms=40, mfc="none", mec=RED, mew=3, zorder=6)
    ax.text(0.98, 0.78, "A and B share a code", color=RED, fontsize=fpx(18), fontweight="bold", ha="right", va="center")
    cap(fig, w, h, 285, 435, "different classes, same code: no output line helps", fs=18)
    save(fig, "lec05-kp02-merge-bad")

def f_bias_line():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); hid(ax)
    xs2 = np.linspace(LO, HI, 50); ys2 = xs2 + 0.5; m = ys2 <= HI
    ax.plot(xs2[m], ys2[m], color=LINE, lw=3, zorder=3)
    hidden_points(ax)
    ax.annotate("", xy=(0.9, 0.62), xytext=(0.9, 1.0 - 0.0 - 0.4 + 0.0), arrowprops=dict(arrowstyle="-|>", color=LINE, lw=2.6), zorder=8) if False else None
    ax.annotate("", xy=(0.62, 0.3), xytext=(0.3, 0.5 + 0.3 - 0.3) if False else (0.4, 0.62), arrowprops=dict(arrowstyle="-|>", color=LINE, lw=2.6), zorder=8)
    ax.text(0.68, 0.22, "$g_{out}>0$", color=LINE, fontsize=fpx(17), fontweight="bold", va="center")
    ax.text(0.02, 1.25, "$y_2=y_1+0.5$", color=LINE, fontsize=fpx(19), fontweight="bold", va="center")
    cap(fig, w, h, 285, 435, "the output bias is changed to +0.5", fs=20)
    save(fig, "lec05-kp02-bias-line")

def f_bias_plus():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); hid(ax)
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (X - Y + 0.5 > 0).astype(float), levels=[0.5, 1.5], colors=[A_C], alpha=0.22, zorder=1)
    xs2 = np.linspace(LO, HI, 50); ys2 = xs2 + 0.5; m = ys2 <= HI
    ax.plot(xs2[m], ys2[m], color=LINE, lw=3, zorder=3)
    hidden_points(ax)
    ring(ax, (0, 0), 34); ring(ax, (1, 1), 34)
    ax.text(0.02, 1.25, "$y_2=y_1+0.5$", color=LINE, fontsize=fpx(19), fontweight="bold", va="center")
    cap(fig, w, h, 285, 435, "output bias +0.5: all three locations predict A", fs=18)
    save(fig, "lec05-kp02-bias-plus")

def f_no_step():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, np.ones_like(X), levels=[0.5, 1.5], colors=[A_C], alpha=0.22, zorder=1)
    pts_xor(ax); ring(ax, (0, 0), 34); ring(ax, (1, 1), 34)
    ax.text(0.5, 1.28, "$g_{out}=0.5$ everywhere", color=A_C, fontsize=fpx(19), fontweight="bold", ha="center", va="center")
    cap(fig, w, h, 285, 435, "without the steps: predict A everywhere", fs=19)
    save(fig, "lec05-kp02-no-step")

if __name__ == "__main__":
    for f in [f_net_wiring, f_input_lines, f_input_sides, f_bits_example, f_bands, f_hidden_plane, f_hidden_scores, f_strip_net, f_merge_bad, f_bias_line, f_bias_plus, f_no_step]:
        try: f()
        except Exception as e: print("FAILED", f.__name__, e)
