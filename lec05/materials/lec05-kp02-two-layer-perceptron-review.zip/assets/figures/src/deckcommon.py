"""Shared helpers for the KP decks: one script builds the zh, en (or bilingual) deck, switched by KP_LANG."""
import json, os, re, sys
os.environ.setdefault("DECK_WORK", os.getcwd())
sys.path.insert(0, "/home/user/pr-2026-fall/.agents/skills/view-from-text/tools/deckkit")
import kit
from kit import AUX, EDGE, MAIN, OK, REF, WARN
VIO, ROSE = "#a98bd0", "#d08bb0"
kit.RGB[VIO] = (169, 139, 208); kit.RGB[ROSE] = (208, 139, 176)
TEAL = AUX
KP_LANG = os.environ.get("KP_LANG", "zh")          # zh | en | bi
RENAME = {}
TERM_EN = {}

def X(zh, en_):
    if KP_LANG == "zh":
        return zh
    if KP_LANG == "en":
        return en_
    return zh + "\n" + "\n".join("*" + ln + "*" if ln.strip() else ln for ln in en_.split("\n"))

def card(p, key, x, y, w, h, zh, en_, **kw):
    nid = p.card(key, x, y, w, h, X(zh, en_), **kw)
    if key.startswith("term:"): RENAME[nid] = key
    return nid

def bridge(p, zh, en_):
    h = p.need_h("bridge", 70)
    p.card("bridge", 60, 134, 1160, h, X(zh, en_), c=None, size=22)
    return 134 + h + 10

def stack(p, x, y, w, items, gap=10):
    """items: (key, zh, en, color, min_h)"""
    ids = []
    for key, zh, en_, c, mh in items:
        h = p.need_h(key, mh)
        ids.append(card(p, key, x, y, w, h, zh, en_, c=c, size=22))
        y += h + gap
    return y, ids

def newpage(u, lz, le, tz, te):
    if KP_LANG == "en":
        return u.page(le, te, "")
    return u.page(lz, tz, te if KP_LANG == "bi" else "")

def step(p, nz, ne):
    p.step(ne if KP_LANG == "en" else nz)

def reveal(p, ids, start=500, every=1400):
    for nid in ids:
        kit.nodes[nid]["initiallyHidden"] = True
    kit.steps[-1]["reveal"] = {"timing": "after-camera", "exitNodeIds": [],
                               "enter": [{"nodeId": nid, "effect": "fade", "delayMs": start + k * every, "durationMs": 500} for k, nid in enumerate(ids)]}

def finish(U, title_zh, title_en, note_zh, note_en, out):
    doc = kit.assemble(U, title_en if KP_LANG == "en" else title_zh, [], {"x": 200, "y": 100, "zoom": 1.2, "rotation": 0})
    for nid, nm in RENAME.items():
        doc["nodes"][nid]["name"] = TERM_EN.get(nm, nm) if KP_LANG == "en" else nm
    doc["steps"][0]["speakerNotes"] = note_en if KP_LANG == "en" else note_zh
    if KP_LANG != "bi":
        for nid in [k for k, n in doc["nodes"].items() if k.endswith("-sub") and not (n.get("text") or "").strip()]:
            sc = doc["nodes"][nid]["sceneId"]; doc["scenes"][sc]["nodeIds"].remove(nid); del doc["nodes"][nid]
    json.dump(doc, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("pages", sum(1 for s in doc["steps"] if s["target"]["sceneId"] != "scene-root"), "KB", os.path.getsize(out) // 1024)
