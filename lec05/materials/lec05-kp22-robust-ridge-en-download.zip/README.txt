Pattern Recognition, Chapter 4, KP22: Robust statistical regression and ridge regression (English version)

Slides: slides/lec05-kp22-robust-ridge-en.html (offline web page, open in a browser); slides/lec05-kp22-robust-ridge-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp22-robust-ridge-en-lecture.pdf (PDF), lec05-kp22-robust-ridge-en-reading.html (offline web page), lectures/lec05-kp22-robust-ridge-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
