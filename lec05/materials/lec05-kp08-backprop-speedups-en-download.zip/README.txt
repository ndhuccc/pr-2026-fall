Pattern Recognition, Chapter 4, KP08: Speeding up backpropagation (English version)

Slides: slides/lec05-kp08-backprop-speedups-en.html (offline web page, open in a browser); slides/lec05-kp08-backprop-speedups-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp08-backprop-speedups-en-lecture.pdf (PDF), lec05-kp08-backprop-speedups-en-reading.html (offline web page), lectures/lec05-kp08-backprop-speedups-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
