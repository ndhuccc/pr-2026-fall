Pattern Recognition, Chapter 4, KP18: The probabilistic neural network (PNN) (English version)

Slides: slides/lec05-kp18-pnn-en.html (offline web page, open in a browser); slides/lec05-kp18-pnn-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp18-pnn-en-lecture.pdf (PDF), lec05-kp18-pnn-en-reading.html (offline web page), lectures/lec05-kp18-pnn-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
