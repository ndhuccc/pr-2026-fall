Pattern Recognition, Chapter 4, KP19: The nonlinear SVM and the Mercer kernel trick (English version)

Slides: slides/lec05-kp19-kernel-svm-en.html (offline web page, open in a browser); slides/lec05-kp19-kernel-svm-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp19-kernel-svm-en-lecture.pdf (PDF), lec05-kp19-kernel-svm-en-reading.html (offline web page), lectures/lec05-kp19-kernel-svm-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
