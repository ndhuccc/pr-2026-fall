import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"
T3 = ["000", "110", "111"]
def bits(c): return [int(b) for b in c]
def mism(a, b): return sum(x != y for x, y in zip(a, b))
def score(t, c): return 0.5 - mism(t, c)
def fmt(v): return f"{v:+.1f}".replace("-", "−")

def cap(fig, w, h, x, ytop, text, color=None, fs=20):
    fig.text(x / w, 1 - ytop / h, text, color=color or TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold")

def cube_ax(fig, w, h, x=5, y=0, pw=None, ph=None, pad=0.5):
    ax = panel(fig, w, h, x, y, pw or w - 10, ph or h - 5); draw_cube(ax, pad=pad); return ax

def lab(ax, c, text, k=1.35, fs=17, col=None):
    x, y = P(bits(c)); dx, dy = LBL_OFF[c]
    ax.text(x + dx * k, y + dy * k, text, color=col or TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold",
            zorder=7, linespacing=1.05, bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.6))

def f_cube_target():
    w, h = 560, 440
    fig = new_fig(w, h); ax = cube_ax(fig, w, h, pad=0.5)
    for c in CODES:
        if c == "101": corner(ax, c, "none", lab=False, ms=21); lab(ax, c, "101")
        else: corner(ax, c, "A" if c in A2 else "B", lab=False, ms=21); lab(ax, c, c)
    for c1, c2 in (("000", "110"), ("100", "010")):
        p1, p2 = P(bits(c1)), P(bits(c2))
        ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color=RED, lw=3, ls=(0, (5, 3)), zorder=2)
    ax.text(1.05, -0.4, "bottom face: A and B on opposite diagonals", color=RED, fontsize=fpx(17), ha="center", va="center", fontweight="bold")
    legend_ab(ax, -0.45, 1.78, 18)
    ax.plot([0.95], [1.78], "o", ms=14, mfc="none", mec=MUT, mew=2.2); ax.text(1.07, 1.78, "no input", color=TXT, fontsize=fpx(18), va="center")
    ax.set_ylim(-0.6, 1.95)
    save(fig, "lec05-kp04-cube-target")

def box(ax, x, y, w_, h_, text, ec=LINE, fs=18, fc=None):
    ax.add_patch(Rectangle((x, y), w_, h_, fc=fc or "none", ec=ec, lw=2.6, zorder=2))
    ax.text(x + w_ / 2, y + h_ / 2, text, color=TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold", zorder=3, linespacing=1.15)

def f_stages():
    w, h = 520, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    rows = [("input  $(x_1,x_2)$", "2 numbers", MUT), ("code  $y$", "3 lines, 3 bits", "#5fb8a8"),
            ("detectors  $h$", "1 per target code", LINE), ("OR  $\\to$ A / B", "fires if any h = 1", A_C)]
    y0 = 14
    for i, (t, sub, col) in enumerate(rows):
        y = y0 + i * 108
        box(ax, 60, y, 290, 70, t, ec=col, fs=20)
        ax.text(372, y + 35, sub, color=MUT, fontsize=fpx(17), va="center")
        if i < 3: ax.annotate("", xy=(205, y + 106), xytext=(205, y + 72), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.4))
    save(fig, "lec05-kp04-stages")

def f_cube_one():
    w, h = 600, 440
    fig = new_fig(w, h); ax = cube_ax(fig, w, h, x=5, pw=590, ph=435)
    t = "110"
    for c in CODES:
        x, y = P(bits(c))
        if c == t:
            ax.plot([x], [y], "*", ms=30, color=LINE, mec=BG, mew=1.2, zorder=6)
        else:
            ax.plot([x], [y], "o", ms=18, color=TINT[c], mec=TXT, mew=1.6, zorder=5)
        lab(ax, c, f"{c}\n{fmt(score(bits(t), bits(c)))}", col=LINE if c == t else None)
    ax.text(-0.5, 1.86, "detector for 110: score $=0.5-$ (wrong bits)", color=LINE, fontsize=fpx(18), va="center", fontweight="bold")
    ax.set_ylim(-0.6, 2.0); ax.set_xlim(-0.6, 2.1)
    save(fig, "lec05-kp04-cube-one")

def f_three_det():
    w, h = 1160, 285
    fig = new_fig(w, h)
    for i, t in enumerate(T3):
        ax = panel(fig, w, h, 5 + i * 385, 0, 375, 250); draw_cube(ax, pad=0.42)
        for c in CODES:
            x, y = P(bits(c))
            if c == t: ax.plot([x], [y], "*", ms=28, color=LINE, mec=BG, mew=1.2, zorder=6)
            else: ax.plot([x], [y], "o", ms=14, color=TINT[c], mec=TXT, mew=1.4, zorder=5)
            lab(ax, c, c, k=1.1, fs=15, col=LINE if c == t else None)
        ax.set_xlim(-0.55, 2.05)
        cap(fig, w, h, 5 + i * 385 + 190, 268, ["$h_{000}$: detect 000", "$h_{110}$: detect 110", "$h_{111}$: detect 111"][i], fs=19)
    save(fig, "lec05-kp04-three-det")

def f_net_110():
    w, h = 540, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    inx, dx_, ox = 70, 285, 470
    ys = [120, 235, 350]; oy = 235
    vals = [1, 1, 0]
    sc = [score(bits(t), [1, 1, 0]) for t in T3]; hb = [1 if s > 0 else 0 for s in sc]
    for a in ys:
        for b in ys:
            on = (b == ys[1])
            ax.plot([inx + 28, dx_ - 44], [a, b], color=LINE if on else MUT, lw=2.4 if on else 1.2, alpha=1 if on else 0.45, zorder=1)
    for b, hv in zip(ys, hb):
        ax.plot([dx_ + 44, ox - 36], [b, oy], color=LINE if hv else MUT, lw=2.4 if hv else 1.2, alpha=1 if hv else 0.45, zorder=1)
    for i, (y_, v) in enumerate(zip(ys, vals)):
        ax.add_patch(Circle((inx, y_), 28, fc="none", ec=TXT, lw=2.4, zorder=3))
        ax.text(inx, y_, f"$y_{i+1}$={v}", color=TXT, fontsize=fpx(17), ha="center", va="center", fontweight="bold", zorder=4)
    for i, (y_, t, s, hv) in enumerate(zip(ys, T3, sc, hb)):
        ax.add_patch(Circle((dx_, y_), 44, fc=(LINE if hv else "none"), ec=LINE, lw=2.6, alpha=0.35 if hv else 1, zorder=2))
        ax.add_patch(Circle((dx_, y_), 44, fc="none", ec=LINE, lw=2.6, zorder=3))
        ax.text(dx_, y_ - 9, fmt(s), color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold", zorder=4)
        ax.text(dx_, y_ + 14, f"$\\to${hv}", color=TXT, fontsize=fpx(18), ha="center", va="center", fontweight="bold", zorder=4)
        ax.text(dx_, y_ - 58, f"detects {t}", color=MUT, fontsize=fpx(16), ha="center", va="center")
    ax.add_patch(Circle((ox, oy), 36, fc=A_C, ec=A_C, lw=2.6, alpha=0.4, zorder=2)); ax.add_patch(Circle((ox, oy), 36, fc="none", ec=A_C, lw=2.6, zorder=3))
    ax.text(ox, oy - 9, "+0.5", color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold", zorder=4)
    ax.text(ox, oy + 14, "A", color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold", zorder=4)
    ax.text(inx, 30, "code", color=MUT, fontsize=fpx(17), ha="center"); ax.text(dx_, 30, "detectors", color=MUT, fontsize=fpx(17), ha="center"); ax.text(ox, 30, "OR", color=MUT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp04-net-110")

def f_or_line():
    w, h = 520, 330
    fig = new_fig(w, h); ax = panel(fig, w, h, 20, 20, 480, 250); ax.set_xlim(-1.0, 3.4); ax.set_ylim(-1.2, 1.5); ax.axis("off")
    ax.annotate("", xy=(3.3, 0), xytext=(-0.9, 0), arrowprops=dict(arrowstyle="-|>", color=MUT, lw=2.2))
    ax.add_patch(Rectangle((0, -0.35), 3.3, 0.7, fc=A_C, ec="none", alpha=0.18, zorder=0))
    ax.add_patch(Rectangle((-0.9, -0.35), 0.9, 0.7, fc=B_C, ec="none", alpha=0.18, zorder=0))
    ax.plot([0, 0], [-0.6, 0.6], color=LINE, lw=3.2)
    ax.text(0, -0.82, "$q=0$", color=LINE, fontsize=fpx(19), ha="center", fontweight="bold")
    for k in range(4):
        v = k - 0.5
        if v < 0: ax.plot([v], [0], "s", ms=18, color=B_C, mec=BG, mew=1.5, zorder=5)
        else: ax.plot([v], [0], "o", ms=18, color=A_C, mec=BG, mew=1.5, zorder=5)
        ax.text(v, 0.55, fmt(v), color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
        ax.text(v, 1.1 if k < 3 else 1.1, f"k={k}", color=MUT, fontsize=fpx(17), ha="center")
    cap(fig, w, h, 260, 300, "k = number of detectors that fire", fs=19)
    save(fig, "lec05-kp04-or-line")

def f_firing():
    w, h = 520, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    cols = [150, 220, 290, 380]; heads = ["$h_{000}$", "$h_{110}$", "$h_{111}$", "OR"]
    for x, t in zip(cols, heads): ax.text(x, 22, t, color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    ax.text(60, 22, "code", color=MUT, fontsize=fpx(17), ha="center", va="center")
    for r, c in enumerate(CODES):
        y = 62 + r * 48
        real = c != "101"
        ax.text(60, y, c, color=TXT if real else MUT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
        hs = [1 if score(bits(t), bits(c)) > 0 else 0 for t in T3]
        for x, hv in zip(cols[:3], hs):
            if hv: ax.add_patch(Circle((x, y), 17, fc=LINE, ec=LINE, alpha=0.9, zorder=3))
            ax.text(x, y, str(hv), color=BG if hv else MUT, fontsize=fpx(18), ha="center", va="center", fontweight="bold", zorder=4)
        a = sum(hs) > 0
        if a: ax.plot([cols[3]], [y], "o", ms=20, color=A_C, mec=BG, mew=1.5, zorder=4)
        else: ax.plot([cols[3]], [y], "s", ms=18, color=B_C, mec=BG, mew=1.5, zorder=4)
        if not real: ax.text(448, y, "no input", color=MUT, fontsize=fpx(16), ha="left", va="center")
    ax.plot([20, 500], [40, 40], color=MUT, lw=1.2)
    save(fig, "lec05-kp04-firing")

def f_plane_final():
    w, h = 520, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 30, 8, 460, 424); draw_plane(ax, classes=A2, codefs=19)
    line_labels(ax, 17)
    for (x, y, c) in [(1.2, 0.4, "110"), (1.1, 2.2, "111"), (-0.9, -1.7, "000")]:
        ax.plot([x], [y], "o", ms=14, color=A_C, mec=BG, mew=1.5, zorder=6)
    ax.plot([-0.1], [0.65], "s", ms=14, color=B_C, mec=BG, mew=1.5, zorder=6)
    legend_ab(ax, -2.4, 2.35, 18)
    save(fig, "lec05-kp04-plane-final")

def f_refine():
    w, h = 520, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 30, 12, 460, 400)
    ax.set_xlim(-0.7, 3.7); ax.set_ylim(-0.7, 3.7); ax.set_aspect("equal"); ax.axis("off")
    cells = set()
    for i in range(3):
        for j in range(3):
            inR1 = i < 2 and j < 2; inR2 = i >= 1 and j >= 1
            if inR1 or inR2:
                ax.add_patch(Rectangle((i, j), 1, 1, fc=A_C, ec="none", alpha=0.45, zorder=1)); cells.add((i, j))
    for v in range(4):
        ax.plot([v, v], [0, 3], color=MUT, lw=1.4, ls=(0, (3, 3)), zorder=2); ax.plot([0, 3], [v, v], color=MUT, lw=1.4, ls=(0, (3, 3)), zorder=2)
    ax.add_patch(Rectangle((0, 0), 2, 2, fc="none", ec=LINE, lw=3.4, zorder=3)); ax.add_patch(Rectangle((1, 1), 2, 2, fc="none", ec="#a98bd0", lw=3.4, zorder=3))
    for n, (i, j) in enumerate(sorted(cells), 1):
        ax.text(i + 0.5, j + 0.5, str(n), color=TXT, fontsize=fpx(22), ha="center", va="center", fontweight="bold", zorder=4)
    ax.text(0.1, 3.3, "2 rectangles", color=LINE, fontsize=fpx(19), fontweight="bold", va="center")
    ax.text(1.6, -0.45, "7 cells = 7 detectors", color=TXT, fontsize=fpx(19), fontweight="bold", va="center")
    assert len(cells) == 7
    save(fig, "lec05-kp04-refine")

def f_cube_011():
    w, h = 560, 430
    fig = new_fig(w, h); ax = cube_ax(fig, w, h)
    for c in CODES:
        x, y = P(bits(c))
        if c == "011": ax.plot([x], [y], "*", ms=30, color=LINE, mec=BG, mew=1.2, zorder=6)
        else: ax.plot([x], [y], "o", ms=18, color=TINT[c], mec=TXT, mew=1.6, zorder=5)
        lab(ax, c, c, col=LINE if c == "011" else None)
    ax.text(-0.5, 1.8, "target: 011", color=LINE, fontsize=fpx(20), va="center", fontweight="bold")
    ax.set_ylim(-0.6, 1.95)
    save(fig, "lec05-kp04-cube-011")

def f_cube_011_scores():
    w, h = 600, 440
    fig = new_fig(w, h); ax = cube_ax(fig, w, h, x=5, pw=590, ph=435)
    t = "011"
    for c in CODES:
        x, y = P(bits(c))
        if c == t: ax.plot([x], [y], "*", ms=30, color=LINE, mec=BG, mew=1.2, zorder=6)
        else: ax.plot([x], [y], "o", ms=18, color=TINT[c], mec=TXT, mew=1.6, zorder=5)
        lab(ax, c, f"{c}\n{fmt(score(bits(t), bits(c)))}", col=LINE if c == t else None)
    ax.text(-0.5, 1.86, "$h_{011}=-y_1+y_2+y_3-1.5$", color=LINE, fontsize=fpx(19), va="center", fontweight="bold")
    ax.set_ylim(-0.6, 2.0); ax.set_xlim(-0.6, 2.1)
    save(fig, "lec05-kp04-cube-011-scores")

if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("f_") and callable(f): f()
