"""KP04 deck: detect each target code, then merge with OR. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp04"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:目標碼": "term:Target code", "term:三層網路": "term:Three-layer network", "term:偵測器": "term:Detector", "term:或合併": "term:OR merge"})
from kp04_text import *

def side_page(u, t, fig, fx=60, cx=640, cw=580, rev=False):
    p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure(fig, fx, y); _, ids = stack(p, cx, y, cw, t["cards"]); step(p, *t["notes"])
    if rev: reveal(p, ids)
    return p

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    figs = ["cube-target", "stages", "cube-one", "three-det", "net-110", "or-line", "firing", "plane-final", "refine", "cube-011", "cube-011-scores"]
    for i, t in enumerate(PAGES):
        if i == 3:
            p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
            yb = p.figure("lec05-kp04-three-det", 60, y)
            stack(p, 60, yb + 10, 1160, t["cards"]); step(p, *t["notes"]); continue
        side_page(u, t, "lec05-kp04-" + figs[i], rev=(i in (9, 10)))
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
