# KP04 三層感知器與區域聯集（Three-layer perceptrons and unions of regions）

> 程度：大學三年級（undergrad）／Level: Undergraduate (undergrad)
>
> 圖型識別｜第四章 §4.4｜Pattern Recognition, Chapter 4, Section 4.4

[簡報閱讀與下載（Slides）](../slides/lec05-kp04-three-layer-perceptron.html)

## 學習目標（Learning objectives）

- 能說明超平面、區域與類別之間的三階段關係。（Explain the stages from hyperplanes to regions to classes.）
- 能驗算只偵測單一二元頂點的神經元。（Verify a neuron that detects one binary vertex.）
- 能區分存在性構造、訓練方法與網路大小。（Distinguish a representation construction from training and network-size claims.）

## KP04 先偵測個別區域，再取聯集（Detect individual regions before taking their union）

**一句話重點**：第二隱藏層可為每個目標編碼建立偵測器，最後用 OR 合併，因而表示固定有限分割中的任意目標區域聯集。

**One-sentence summary**: A second hidden layer can detect each target code, and an OR output combines the detections to represent any selected union in a fixed finite partition.

### 先把要解決的困難說清楚（State the obstacle before adding a layer）

**白話說明**：KP03 的問題不是區域不存在，而是目標編碼未必能被單一輸出超平面分開。現在改成逐個辨認目標編碼，再問「是否至少命中一個」。這把一次困難的分隔，拆成多次容易的偵測。

**Plain explanation**: In KP03, target cells existed, but their codes could not always be separated by one output hyperplane. We now recognize target codes individually and ask whether any detector fires. One difficult separation becomes several simpler detections.

可以把這個構造想成多個只認一種通行碼的檢查器，再用一個「任一通過」的總開關。這個比喻只描述有限二元碼，不表示網路在現實中已知道所有區域。

Think of several checkers that each accept one code, followed by an “any accepted” switch. The analogy describes finite binary codes; it does not imply that real applications already know all regions.

沿用 A 的編碼集合 $\{000,110,111\}$。三層計數仍不含輸入節點：第一隱藏層產生半空間位元，第二隱藏層偵測區域，輸出層合併為類別。

Retain the A-code set $\{000,110,111\}$. Excluding input nodes, three computational layers produce half-space bits, detect regions, and combine detections into a class.

![目標編碼在原始空間形成區域聯集（Target codes form a union of input cells）](../assets/figures/lec05-kp04-regions.png)

圖說 `lec05-kp04-regions`：使用 KP03 的三條邊界。橘色區域對應 000、110、111；藍色區域屬其他實際編碼。先確認標籤，再思考如何分別辨認三個目標碼。

Figure `lec05-kp04-regions`: Using KP03's boundaries, orange cells have codes 000, 110, and 111; blue cells have other realized codes. Identify the labels before considering separate detectors.

### 為什麼可以孤立目標頂點（Why an individual vertex can be isolated）

**正式定義［補充］**：令目標頂點為 $\mathbf{v}\in\{0,1\}^p$，實際隱藏編碼為 $\mathbf{y}\in\{0,1\}^p$。定義一個偵測分數：

**Formal definition [Added]**: For a target vertex $\mathbf{v}\in\{0,1\}^p$ and a hidden code $\mathbf{y}\in\{0,1\}^p$, define the detector score:

$$
r_{\mathbf{v}}(\mathbf{y})=\sum_{i=1}^p(2v_i-1)y_i+0.5-\sum_{i=1}^p v_i,
\qquad h_{\mathbf{v}}=f(r_{\mathbf{v}}),
$$

其中 $f(t)=1$ 當 $t>0$，其餘為零。這條式子把來源的「可孤立一個頂點」寫成可實際代入的構造。

Here $f(t)=1$ for positive $t$ and zero otherwise. The formula makes the source's vertex-isolation claim directly computable.

| 符號 | 中文意義 | English meaning |
|---|---|---|
| $p,i$ | 二元碼長度與位元索引 | Code length and bit index |
| $\mathbf{v},\mathbf{y}$ | 目標頂點與收到的編碼 | Target vertex and received code |
| $r_{\mathbf{v}},h_{\mathbf{v}}$ | 偵測分數及其 0/1 輸出 | Detector score and binary response |
| $K$ | 要接受的目標編碼數 | Number of accepted target codes |
| $\widehat c$ | 最後類別，1 為 A、0 為 B | Final class, 1 for A and 0 for B |

當 $\mathbf{y}=\mathbf{v}$，每個目標為 1 的位置貢獻 1，其餘貢獻 0；兩個總和相消，留下 $0.5$。任何一個位元與目標不同，分數都恰好減少 1。因此，只要至少有一位不同，分數就不超過 $-0.5$。

At $\mathbf{y}=\mathbf{v}$, target-one positions contribute 1, cancelling the count of target ones and leaving 0.5. Each mismatched bit reduces the score by exactly 1. Any other binary code therefore scores at most -0.5.

所以這個階梯神經元只接受目標頂點。此論證使用二元輸入；對連續的 $[0,1]^p$ 內部點，不能直接宣稱「只剩一個點」。

The step neuron thus accepts only the target vertex among binary codes. This argument relies on binary inputs; it does not isolate one point from every continuous point inside $[0,1]^p$.

### 三個偵測器與 OR 的完整算例（A worked example with three detectors and OR）

**例子［補充］**：對 A 的三個目標碼，式子化簡如下。

**Example [Added]**: For the three A codes, the detector scores simplify to:

$$
r_{000}=0.5-y_1-y_2-y_3,
\qquad r_{110}=y_1+y_2-y_3-1.5,
\qquad r_{111}=y_1+y_2+y_3-2.5.
$$

1. 輸入碼 110：$r_{000}=0.5-1-1-0=-1.5$；$r_{110}=1+1-0-1.5=0.5$；$r_{111}=1+1+0-2.5=-0.5$。（For 110, the scores are -1.5, 0.5, and -0.5.）
2. 套階梯後得到 $(h_{000},h_{110},h_{111})=(0,1,0)$，只有目標偵測器啟動。（Applying the step function produces $(0,1,0)$, with only the matching detector active.）
3. OR 也可用階梯神經元實現：$\widehat c=f(h_{000}+h_{110}+h_{111}-0.5)=f(0+1+0-0.5)=1$。（A step output implements OR and predicts 1.）

再用非目標碼 010 檢查反例：三個分數分別為 $0.5-0-1-0=-0.5$、$0+1-0-1.5=-0.5$、$0+1+0-2.5=-1.5$，所以三個輸出都為 0；最終分數 $0+0+0-0.5=-0.5$，預測 B。

For non-target code 010, the three scores are -0.5, -0.5, and -1.5. All detectors output zero; the final score is -0.5, predicting B.

| 收到的碼 Received code | 三個偵測輸出 Detector responses | OR 輸出 OR output |
|---|---|---|
| 000 | $(1,0,0)$ | 1 |
| 110 | $(0,1,0)$ | 1 |
| 111 | $(0,0,1)$ | 1 |
| 001、010、011、100、101 | $(0,0,0)$ | 0 |

101 即使是虛擬碼，偵測器也會給出一致定義，但不影響原始輸入分類。對每個實際 A 碼，這個逐頂點構造恰好啟動一個偵測器；不是讓每個輸入必須同時命中所有目標。

The detectors define a response even for unrealized code 101, without affecting actual inputs. Each realized A code activates exactly one detector in this vertex-wise construction; acceptance does not require all target detectors to fire.

### 從有限分割推廣到有限多面體聯集（From finite partitions to finite polyhedral unions）

若 A 是有限個多面體的聯集，先收集所有面所需的超平面。這些平面可能把原來的一個多面體再切成多個小區域。每個小區域有固定編碼，再逐一偵測屬於 A 的碼，最後取 OR。

For a finite union of polyhedra, first collect all supporting hyperplanes. Their arrangement may refine one original polyhedron into several cells. Detect every realized code belonging to A, then combine the detections with OR.

因此 $K$ 應按要接受的細分編碼計算，不一定等於原先列出的多面體個數。這是對來源敘述的精確化；有限寬度足以表示這種有限聯集，不代表寬度一定小。

Thus $K$ counts accepted refined codes, not necessarily the original number of polyhedra. This clarifies the source's construction: finite width suffices, but it need not be small.

多類別可以為每類設一個 OR 輸出，合併該類的偵測器。若原任務要唯一類別，原區域標籤與邊界規則也必須一致，不能同時把同一輸入指定給互斥類別。

For multiple classes, one OR output per class combines that class's detectors. A unique-class task also requires consistent region labels and boundary conventions; mutually exclusive labels cannot be assigned to the same input.

### 存在性不等於能直接學到（Existence is not a training procedure）

**常見迷思**：既然三層足夠，就知道實際該用哪些權重。這個構造預先知道超平面與目標區域；真實問題通常只有有限標記點，並沒有這份幾何答案。

**Common misconception**: Knowing that three layers suffice does not reveal the weights for real data. The construction assumes known hyperplanes and target cells, while real tasks usually provide only finitely many labeled examples.

另一個誤解是，三層可以精確表示任意曲線邊界。有限階梯網路的這個證明針對有限多面體聯集；一般曲線若用多面體逼近，還要另行討論逼近誤差，不能把兩個主張混為一談。

The proof also does not establish exact representation of arbitrary curved boundaries. It concerns finite unions of polyhedral cells. Approximating general curves introduces a separate approximation question.

實務因而有兩條路：逐步擴增網路直到訓練點能分開，或先固定架構再調整權重以減少損失。這是接下來構造式方法與反向傳播的動機，不是本單元已完成的學習演算法。

Two practical routes follow: grow a network to separate training examples, or fix an architecture and optimize its weights. These motivate constructive methods and backpropagation; neither is already supplied by the representation proof.

**小練習**：自己建立 011 的頂點偵測器，分別代入 011 與 010。提示：使用一般式，不改階梯的零分規則。再想一想：兩個目標碼若可共同被一個平面分開，是否一定要分配兩個偵測器？只需說明可能節省的原因，不求最小網路。

**Practice**: Construct a detector for 011 and test 011 and 010. Hint: use the general formula and retain the tie rule. If one plane separates two target codes together, explain why two separate detectors might be unnecessary; no minimal network is required.

## 術語與來源（Terminology and source）

| 中文 | English |
|---|---|
| 頂點偵測器 | Vertex detector |
| 區域聯集 | Union of regions |
| 構造式證明 | Constructive proof |
| 細分區域 | Refined cell |
| 存在性 | Existence |

來源：[第四章 KP04，§4.4](https://ndhuccc.github.io/CCC-LNS/PR_115/Ch04-nonlinear-classifiers/index.html#kp4)，2026-10-24 讀取。逐頂點孤立與 OR 為原主線；偵測器通式、數值算例與細分計數澄清為［補充］，不宣稱來源已列出這些參數。

Source: Chapter 4, KP04, Section 4.4, accessed 2026-10-24. Vertex isolation and OR follow the source. The explicit detector formula, numerical checks, and refined-code count are [Added] clarifications.
