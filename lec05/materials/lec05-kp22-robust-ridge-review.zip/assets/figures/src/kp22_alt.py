ALT = {
 "outlier": ("20 個點加 1 個離群點（星號）：最小平方線的斜率從乾淨資料的 2.01 被拉到 2.69。", "20 points plus one outlier (star): the least-squares slope is pulled from 2.01 on clean data to 2.69."),
 "losses": ("三種損失對殘差 e：平方、Huber（c=1）與 ε-不敏感（ε=0.5，陰影為不計罰的帶）。", "Three losses against the residual e: squared, Huber (c=1) and ε-insensitive (ε=0.5, shaded band costs nothing)."),
 "hfit": ("同樣 21 個點：最小平方斜率 2.69，Huber（c=1）斜率 2.10。", "The same 21 points: least squares has slope 2.69 and Huber (c=1) slope 2.10."),
 "svr": ("ε-不敏感迴歸的目標、迴歸器與 KKT 讀出：誤差小於 ε 的點係數為 0，ε 是稀疏度旋鈕。", "The objective, the regressor and the KKT readings of ε-insensitive regression: points with error below ε have coefficient 0, so ε is the sparsity knob."),
 "eps": ("支撐向量數對 ε：ε=0.01、0.1、0.2、0.3、0.5、1.0 依序為 58、29、9、6、5、2 個。", "Support vectors against ε: 58, 29, 9, 6, 5 and 2 for ε=0.01, 0.1, 0.2, 0.3, 0.5 and 1.0."),
 "ridge": ("脊迴歸：最小化 C‖w‖²+Σξᵢ²，閉式解 g(x)=yᵀ(K+C·I)⁻¹p，線性核的兩種寫法最大差 6e-16。", "Ridge regression: minimize C‖w‖²+Σξᵢ² with the closed form g(x)=yᵀ(K+C·I)⁻¹p; the two linear-kernel forms differ by at most 6e-16."),
 "collinear": ("幾乎共線的兩個特徵：C=0 時係數 −169.98 與 170.96，C=0.1 時為 0.49 與 0.49，條件數從 5e8 降到 776。", "Two almost collinear features: coefficients −169.98 and 170.96 at C=0 and 0.49 and 0.49 at C=0.1, with the condition number falling from 5e8 to 776."),
 "compare": ("同一份離群點資料四種方法的斜率：最小平方 2.686、Huber 2.099、ε-不敏感 2.122（4 個支撐向量）、脊迴歸 2.679。", "Slopes of four methods on the same outlier data: least squares 2.686, Huber 2.099, ε-insensitive 2.122 (4 support vectors) and ridge 2.679."),
 "csweep": ("Huber 門檻 c 對斜率：c=0.2 為 2.045，c=20 為 2.686，與最小平方相同。", "Slope against the Huber threshold c: 2.045 at c=0.2 and 2.686 at c=20, the same as least squares."),
 "practice": ("練習圖：Huber（c=1）在 e=0.5 與 3、ε-不敏感（ε=0.5）在 e=0.3 與 2 的損失。", "Practice figure: the Huber (c=1) loss at e=0.5 and 3 and the ε-insensitive (ε=0.5) loss at e=0.3 and 2."),
 "practice-sol": ("Huber：0.125 與 2.5；ε-不敏感：0 與 1.5。", "Huber: 0.125 and 2.5; ε-insensitive: 0 and 1.5."),
}
