import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums22 as N
from nums22 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
xc, yc = trend(out=False); xo, yo = trend()
def line(ax, w, c, lab, ls="-"): xs = np.array([-0.2, 5.3]); ax.plot(xs, w[0] * xs + w[1], color=c, lw=3, ls=ls, label=lab)

def f_outlier():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    ax.plot(xo[:-1], yo[:-1], "o", color=A_C, ms=8); ax.plot([xo[-1]], [yo[-1]], "*", color=RED, ms=22)
    wc, wo = ols(xc, yc), ols(xo, yo); line(ax, wc, GRN, f"clean points: slope {wc[0]:.2f}", "--"); line(ax, wo, RED, f"with one outlier: slope {wo[0]:.2f}")
    ax.legend(fontsize=fpx(13), frameon=False, labelcolor=TXT, loc="upper left"); ax.set_xlabel("x", color=TXT, fontsize=fpx(16)); ax.set_ylim(-1.5, 24)
    cap(fig, h, [(352, "true slope 2; one wrong point at the right edge", TXT, 16, True), (386, f"least squares tilts from {wc[0]:.2f} to {wo[0]:.2f} and the intercept 1.00 to {wo[1]:.2f}", RED, 16, True), (420, "squaring the residual lets one point dominate", MUT, 15, False)])
    save(fig, "lec05-kp22-outlier"); return wc, wo

def f_losses():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    e = np.linspace(-4, 4, 400)
    ax.plot(e, 0.5 * e ** 2, color=RED, lw=3, label="squared ½e²"); ax.plot(e, huber(e, 1.0), color=GRN, lw=3, label="Huber (c = 1)"); ax.plot(e, eins(e, 0.5), color=A_C, lw=3, label="ε-insensitive (ε = 0.5)")
    ax.axvspan(-0.5, 0.5, color=A_C, alpha=0.15); ax.set_ylim(0, 6); ax.set_xlim(-4, 4); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper center"); ax.set_xlabel("residual e = y − g(x)", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(352, "Huber: quadratic up to |e| = c, then linear", GRN, 16, True), (386, "ε-insensitive: flat (shaded) inside |e| ≤ ε", A_C, 16, True), (420, "at e = 3: squared 4.5, Huber 2.5, ε-insensitive 2.5", TXT, 15, True)])
    save(fig, "lec05-kp22-losses")

def f_hfit():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    ax.plot(xo[:-1], yo[:-1], "o", color=A_C, ms=8); ax.plot([xo[-1]], [yo[-1]], "*", color=RED, ms=22)
    wo = ols(xo, yo); wh = huber_irls(xo, yo, 1.0); line(ax, wo, RED, f"least squares: slope {wo[0]:.2f}"); line(ax, wh, GRN, f"Huber (c = 1): slope {wh[0]:.2f}")
    ax.legend(fontsize=fpx(13), frameon=False, labelcolor=TXT, loc="upper left"); ax.set_xlabel("x", color=TXT, fontsize=fpx(16)); ax.set_ylim(-1.5, 24)
    cap(fig, h, [(352, "same 21 points, true slope 2 and intercept 1", TXT, 16, True), (386, f"Huber: slope {wh[0]:.2f}, intercept {wh[1]:.2f}", GRN, 17, True), (420, f"least squares: slope {wo[0]:.2f}, intercept {wo[1]:.2f}", RED, 16, True)])
    save(fig, "lec05-kp22-hfit"); return wh

def f_svr():
    fig, ax = blank(540, 440)
    T(ax, 270, 28, "minimize ½‖w‖² + C Σ (ξᵢ + ξᵢ*)", TXT, 18)
    T(ax, 270, 65, "tube: |yᵢ − ⟨w, φ(xᵢ)⟩ − w₀| ≤ ε + slack", MUT, 15, False)
    T(ax, 270, 125, "g(x) = Σᵢ (λᵢ* − λᵢ) K(x, xᵢ) + w₀", RED, 19)
    T(ax, 270, 190, "KKT readings", GRN, 18)
    T(ax, 30, 235, "|error| < ε   →   λᵢ = λᵢ* = 0   (no contribution)", TXT, 15, True, "left")
    T(ax, 30, 275, "support vectors:   |error| ≥ ε", TXT, 15, True, "left")
    T(ax, 30, 315, "|error| > ε   →   λᵢ = C   (at the upper bound)", TXT, 15, True, "left")
    T(ax, 270, 380, "ε is the sparsity knob", RED, 20)
    T(ax, 270, 415, "(support vectors: the points on or outside the tube)", MUT, 15, False)
    save(fig, "lec05-kp22-svr")

def f_eps():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    from sklearn.svm import SVR
    rng = np.random.default_rng(1); xs = np.sort(rng.uniform(0, 2 * np.pi, 60)); ys = np.sin(xs) + rng.normal(0, 0.15, 60); xg = np.linspace(0, 2 * np.pi, 300)
    eps = [0.01, 0.1, 0.2, 0.3, 0.5, 1.0]; nsv, mse = [], []
    for e in eps:
        m = SVR(kernel="rbf", gamma=0.5, C=10, epsilon=e).fit(xs[:, None], ys); nsv.append(len(m.support_)); mse.append(float(np.mean((m.predict(xg[:, None]) - np.sin(xg)) ** 2)))
    ax.bar(range(6), nsv, color=A_C, width=0.6)
    for i, (n, m_) in enumerate(zip(nsv, mse)): ax.text(i, n + 1.5, f"{n}", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.set_xticks(range(6)); ax.set_xticklabels([str(e) for e in eps], fontsize=fpx(16)); ax.set_xlabel("ε", color=TXT, fontsize=fpx(16)); ax.set_ylabel("support vectors (of 60)", color=TXT, fontsize=fpx(15)); ax.set_ylim(0, 70)
    cap(fig, h, [(352, "error against sin: 0.0008 (ε = 0.01) → 0.0551 (ε = 0.5)", RED, 16, True), (386, "a larger ε keeps fewer support vectors", A_C, 17, True), (420, "but the fit gets worse: sparsity is paid for", MUT, 15, False)])
    save(fig, "lec05-kp22-eps"); return nsv, [round(m, 4) for m in mse]

def f_ridge():
    fig, ax = blank(540, 400)
    T(ax, 270, 30, "ε = 0, w₀ = 0, equality constraints:", MUT, 15, False)
    T(ax, 270, 70, "minimize  C‖w‖² + Σ ξᵢ²,   ξᵢ = yᵢ − ⟨w, φ(xᵢ)⟩", TXT, 16)
    T(ax, 270, 135, "g(x) = yᵀ (K + CI)⁻¹ p", RED, 22)
    T(ax, 270, 195, "linear kernel, two forms of the same w:", GRN, 16)
    T(ax, 270, 240, "w = (XᵀX + CI)⁻¹ Xᵀ y", A_C, 18)
    T(ax, 270, 285, "w = Xᵀ (XXᵀ + CI)⁻¹ y", B_C, 18)
    rng = np.random.default_rng(2); X = rng.normal(size=(15, 4)); y = rng.normal(size=15); C = 0.8
    d = float(np.abs(np.linalg.solve(X.T @ X + C * np.eye(4), X.T @ y) - X.T @ np.linalg.solve(X @ X.T + C * np.eye(15), y)).max())
    T(ax, 270, 345, f"15 random points, 4 features, C = 0.8:  gap {d:.0e}", GRN, 16)
    T(ax, 270, 380, "no ε, so no zero coefficients", MUT, 15, False)
    save(fig, "lec05-kp22-ridge"); return d

def f_collinear():
    fig, ax = blank(540, 420)
    rng = np.random.default_rng(3); t = rng.normal(size=30); X2 = np.c_[t, t + 1e-4 * rng.normal(size=30)]; y2 = t + 0.1 * rng.normal(size=30)
    for x, tx in zip((60, 230, 430), ("C", "w₁, w₂", "cond(XᵀX + CI)")): T(ax, x, 28, tx, MUT, 14, False)
    rows = [("0", np.linalg.lstsq(X2, y2, rcond=None)[0], np.linalg.cond(X2.T @ X2))] + [(f"{C}", np.linalg.solve(X2.T @ X2 + C * np.eye(2), X2.T @ y2), np.linalg.cond(X2.T @ X2 + C * np.eye(2))) for C in (1e-3, 0.1, 1)]
    for i, (C, w, c) in enumerate(rows):
        y = 85 + i * 62; col = RED if i == 0 else TXT
        T(ax, 60, y, C, col, 19); T(ax, 230, y, f"{w[0]:.2f}, {w[1]:.2f}", col, 19); T(ax, 430, y, f"{c:.3g}", col, 18)
    T(ax, 270, 345, "two almost identical columns: both y ≈ x₁ and y ≈ x₂ fit", TXT, 14)
    T(ax, 270, 380, "C = 0 gives −170 and 171; a small C gives about 0.5 and 0.5", GRN, 15)
    save(fig, "lec05-kp22-collinear"); return [(r[0], r[1].round(3).tolist(), float(r[2])) for r in rows]

def f_compare():
    fig, ax = blank(540, 420)
    for x, tx in zip((120, 300, 440), ("method", "slope", "nonzero")): T(ax, x, 28, tx, MUT, 14, False)
    wo = ols(xo, yo); wh = huber_irls(xo, yo, 1.0); ws, m = svr_lin(xo, yo, 0.5, 10); wr = ridge_lin(xo, yo, 0.1)
    rows = [("least squares", wo[0], "21 of 21", RED), ("Huber (c = 1)", wh[0], "21 of 21", GRN), ("ε-insens. (ε = 0.5)", ws[0], f"{len(m.support_)} of 21", A_C), ("ridge (C = 0.1)", wr[0], "21 of 21", VIO2)]
    for i, (n, s_, z, c) in enumerate(rows):
        y = 85 + i * 58; T(ax, 12, y, n, c, 15, True, "left"); T(ax, 300, y, f"{s_:.3f}", c, 19); T(ax, 440, y, z, c, 16)
    T(ax, 270, 330, "true slope 2; the clean-data fit gives 2.009", MUT, 15, False)
    T(ax, 270, 365, "Huber and the ε loss resist the outlier; ridge does not", GRN, 15)
    T(ax, 270, 400, "only the ε loss gives a sparse solution", A_C, 15)
    save(fig, "lec05-kp22-compare"); return [(r[0], round(float(r[1]), 3), r[2]) for r in rows]

def f_csweep():
    fig, ax = blank(540, 400)
    T(ax, 270, 28, "slope of the Huber line on the same 21 points", TXT, 16)
    for x, tx in zip((120, 400), ("c", "slope")): T(ax, x, 65, tx, MUT, 14, False)
    cs = [0.2, 0.5, 1, 2, 5, 20]
    for i, c in enumerate(cs):
        y = 110 + i * 38; s_ = huber_irls(xo, yo, c)[0]; col = RED if c == 20 else TXT
        T(ax, 120, y, f"{c}", col, 18); T(ax, 400, y, f"{s_:.3f}", col, 18)
    T(ax, 270, 360, "c large: same as least squares (2.686)", RED, 15)
    T(ax, 270, 388, "c small: nearly ignores the outlier", GRN, 15)
    save(fig, "lec05-kp22-csweep")

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "residual e = y − g(x)", TXT, 19)
    T(ax, 270, 90, "Huber with c = 1;  ε-insensitive with ε = 0.5", TXT, 17)
    T(ax, 270, 160, "question 1: Huber loss at e = 0.5 and at e = 3", RED, 17)
    T(ax, 270, 210, "question 2: ε-insensitive loss at e = 0.3 and at e = 2", RED, 17)
    T(ax, 270, 270, "Huber: ½e² if |e| ≤ c, else c|e| − c²/2", MUT, 15, False)
    save(fig, "lec05-kp22-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("question 1: e = 0.5 ≤ 1,  Huber = ½ · 0.25 = 0.125", GRN), ("e = 3 > 1,  Huber = 1·3 − 1/2 = 2.5", GRN), ("(squared ½e² would give 0.125 and 4.5)", MUT), ("question 2: e = 0.3,  max(0, 0.3 − 0.5) = 0", GRN), ("e = 2,  max(0, 2 − 0.5) = 1.5", GRN), ("small errors vanish, large ones grow linearly", RED)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 15)
    save(fig, "lec05-kp22-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
