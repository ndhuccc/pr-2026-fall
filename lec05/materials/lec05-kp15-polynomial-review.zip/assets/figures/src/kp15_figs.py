import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums15 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax

def f_terms():
    fig, ax = blank(540, 400)
    ax.text(270, 30, "input x = (x₁, x₂), order r = 2", color=MUT, fontsize=fpx(17), ha="center")
    items = [("1", "bias", MUT), ("x₁", "linear", A_C), ("x₂", "linear", A_C), ("x₁x₂", "interaction", RED), ("x₁²", "square", VIO2), ("x₂²", "square", VIO2)]
    for i, (t, d, c) in enumerate(items):
        r, cc = divmod(i, 3); x0 = 25 + cc * 170; y0 = 65 + r * 120
        ax.add_patch(Rectangle((x0, y0), 150, 95, fc="none", ec=c, lw=2.6)); ax.text(x0 + 75, y0 + 38, t, color=TXT, fontsize=fpx(26), ha="center", va="center", fontweight="bold"); ax.text(x0 + 75, y0 + 74, d, color=c, fontsize=fpx(16), ha="center", va="center")
    ax.text(270, 335, "g(x) = w₀ + w₁x₁ + w₂x₂ + w₁₂x₁x₂ + w₁₁x₁² + w₂₂x₂²", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 372, "6 terms: linear in 6 weights, curved in x", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp15-terms")

def f_xor():
    fig, ax = blank(540, 400)
    heads = ["x₁", "x₂", "y₃ = x₁x₂", "g", "class"]; xs = [45, 120, 235, 365, 465]
    for x, t in zip(xs, heads): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center")
    g = lambda a, b: -0.25 + a + b - 2 * a * b
    for i, (a, b) in enumerate([(0, 0), (0, 1), (1, 0), (1, 1)]):
        v = g(a, b); y = 78 + i * 55
        for x, t, c in zip(xs, [str(a), str(b), str(a * b), f"{v:+.2f}".replace("-", "−"), "A" if v > 0 else "B"], [TXT, TXT, TXT, GRN if v > 0 else RED, GRN if v > 0 else RED]): ax.text(x, y, t, color=c, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
    ax.text(270, 335, "g = −¼ + x₁ + x₂ − 2x₁x₂", color=TXT, fontsize=fpx(22), ha="center", fontweight="bold")
    ax.text(270, 372, "only one new feature, x₁x₂, solves XOR", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp15-xor")

def f_hyper():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 400, 270); axstyle(ax)
    xs = np.linspace(-0.6, 1.6, 400); X1, X2 = np.meshgrid(xs, xs); G = -0.25 + X1 + X2 - 2 * X1 * X2
    ax.contourf(X1, X2, G, levels=[-10, 0, 10], colors=[B_C, A_C], alpha=0.22); ax.contour(X1, X2, G, levels=[0], colors=[GRN], linewidths=3)
    for (a, b) in ((0, 0), (1, 1)): ax.plot([a], [b], "s", color=B_C, ms=13)
    for (a, b) in ((0, 1), (1, 0)): ax.plot([a], [b], "o", color=A_C, ms=13)
    ax.set_xlim(-0.6, 1.6); ax.set_ylim(-0.6, 1.6); ax.set_aspect("equal"); ax.set_xlabel("x₁", color=TXT, fontsize=fpx(16)); ax.set_ylabel("x₂", color=TXT, fontsize=fpx(16), rotation=0, labelpad=10)
    cap(fig, h, [(355, "g = 0 is a pair of hyperbola branches", GRN, 18, True), (390, "a plane in (x₁, x₂, y₃), a curve in (x₁, x₂)", TXT, 17, False), (423, "blue circles: class A     orange squares: class B", MUT, 15, False)])
    save(fig, "lec05-kp15-hyper")

def f_kcount():
    fig, ax = blank(540, 400)
    for x, t in zip((70, 210, 420), ("r", "k = (2 + r)! / (r! 2!)", "terms")): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center")
    for i, r in enumerate(range(1, 6)):
        y = 78 + i * 52
        for x, t, c in zip((70, 210, 420), (str(r), f"({2+r})! / ({r}! · 2!)", str(N.k_terms(2, r))), (TXT, MUT, GRN)): ax.text(x, y, t, color=c, fontsize=fpx(21), ha="center", va="center", fontweight="bold")
    ax.text(270, 355, "l = 2 inputs; also l = 3, r = 2 gives 10 terms", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.text(270, 385, "k counts every product with total power ≤ r", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp15-kcount")

def f_explode():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 25, 420, 245); axstyle(ax)
    rs = np.arange(1, 11)
    for l, c in zip((2, 10, 100), (A_C, VIO2, RED)): ax.plot(rs, [N.k_terms(l, int(r)) for r in rs], "o-", color=c, lw=2.6, label=f"l = {l}")
    ax.plot([10], [184756], "*", color=TXT, ms=20, zorder=5); ax.text(9.7, 8e6, "184,756", color=TXT, fontsize=fpx(17), ha="right", fontweight="bold")
    ax.set_yscale("log"); ax.set_ylim(1, 3e14); ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper left"); ax.set_xticks(rs)
    ax.set_xlabel("order r", color=TXT, fontsize=fpx(16)); ax.set_ylabel("terms k", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "l = 10, r = 10:  k = 184,756", RED, 20, True), (382, "l = 100, r = 2:  5151;   l = 100, r = 3:  176,851", MUT, 16, False)])
    save(fig, "lec05-kp15-explode")

def f_memory():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 190, 30, 320, 215); axstyle(ax)
    labs = ["a laptop's memory", "Φ: 1000 samples × k", "ΦᵀΦ: k × k"]; vals = [16, 1.478, 273.08]
    ax.barh(range(3), vals, color=[MUT, A_C, RED], height=0.55); ax.set_yticks(range(3)); ax.set_yticklabels(labs, fontsize=fpx(16)); ax.invert_yaxis()
    ax.set_xscale("log"); ax.set_xlim(0.5, 2000)
    for i, v in enumerate(vals): ax.text(v * 1.2, i, f"{v:.4g} GB", color=TXT, fontsize=fpx(18), va="center", fontweight="bold")
    ax.set_xlabel("gigabytes (log axis)", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(335, "l = 10, r = 10, 8-byte numbers", TXT, 18, True), (372, "k = 184,756 columns", MUT, 17, False), (408, "the normal equation alone needs 273 GB", RED, 19, True)])
    save(fig, "lec05-kp15-memory")

def f_moons():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 245); axstyle(ax)
    Xtr, ytr = N.moons(30, 0.2, 0); Xte, yte = N.moons(500, 0.2, 1)
    res = [N.fit_acc(r, Xtr, ytr, Xte, yte) for r in range(1, 11)]
    ax.plot(range(1, 11), [a for a, b, c in res], "o-", color=A_C, lw=2.8, label="training (60 points)"); ax.plot(range(1, 11), [b for a, b, c in res], "s-", color=RED, lw=2.8, label="new points (1000)")
    ax.set_ylim(0.5, 1.03); ax.set_xticks(range(1, 11)); ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="lower left")
    ax.set_xlabel("polynomial order r", color=TXT, fontsize=fpx(16)); ax.set_ylabel("accuracy", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "two moons, least-squares polynomial classifier", TXT, 17, True), (382, "r = 3: 93.2% on new points;  r = 10: 100% / 55.5%", RED, 18, True), (415, "terms k = 3, 6, 10, 15, 21, 28, 36, 45, 55, 66", MUT, 15, False)])
    save(fig, "lec05-kp15-moons"); return res

def f_cond():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 25, 420, 245); axstyle(ax)
    Xtr, ytr = N.moons(30, 0.2, 0); cs = [np.linalg.cond(N.poly_features(Xtr, r)) for r in range(1, 9)]
    ax.semilogy(range(1, 9), cs, "o-", color=VIO2, lw=3, ms=9)
    for r, c in zip(range(1, 9), cs): ax.text(r, c * 1.6, f"{c:.3g}", color=TXT, fontsize=fpx(14), ha="center", fontweight="bold")
    ax.set_ylim(1, 3e8); ax.set_xticks(range(1, 9)); ax.set_xlabel("polynomial order r", color=TXT, fontsize=fpx(16)); ax.set_ylabel("condition number of Φ", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(345, "same 60 points, more and more columns", TXT, 17, True), (382, "r = 1: 3.25  →  r = 8: 4.4 million", RED, 19, True), (415, "the columns x₁^a·x₂^b become nearly parallel", MUT, 15, False)])
    save(fig, "lec05-kp15-cond")

def f_kernel():
    fig, ax = blank(540, 440)
    ax.text(270, 30, "x = (1, 2),   z = (3, −1),   order 2", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 90, "(1 + x·z)²  =  (1 + 3 − 2)²  =  4", color=GRN, fontsize=fpx(22), ha="center", fontweight="bold")
    ax.text(270, 150, "φ(x) = (1, √2x₁, √2x₂, x₁², x₂², √2x₁x₂)", color=TXT, fontsize=fpx(17), ha="center")
    ax.text(270, 200, "φ(x)·φ(z) = 1 + 6 − 4 + 9 + 4 − 12 = 4", color=RED, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 270, "same number, but the left side never builds φ", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 325, "l = 10, r = 10:", color=MUT, fontsize=fpx(18), ha="center")
    ax.text(270, 365, "left: about 10 multiplications and a power", color=GRN, fontsize=fpx(17), ha="center")
    ax.text(270, 400, "right: a 184,756-term inner product", color=RED, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp15-kernel")

def f_practice():
    fig, ax = blank(540, 330)
    ax.text(270, 40, "l = 4 inputs, order r = 3", color=TXT, fontsize=fpx(22), ha="center", fontweight="bold")
    ax.text(270, 105, "k = (l + r)! / (r! · l!)", color=MUT, fontsize=fpx(20), ha="center")
    ax.text(270, 180, "g = −¼ + x₁ + x₂ − 2x₁x₂", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 245, "question 1: how many terms k?", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 285, "question 2: which class is the point (1.5, 1.5)?", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    save(fig, "lec05-kp15-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("k = 7! / (3! · 4!)", "= 35", TXT), ("5040 / (6 · 24)", "= 35", MUT), ("g(1.5, 1.5)", "= −0.25 + 3 − 4.5 = −1.75", RED), ("class", "B  (g < 0)", RED)]
    for i, (a, b, c) in enumerate(L):
        y = 55 + i * 75; ax.text(20, y, a, color=c, fontsize=fpx(19), va="center", fontweight="bold"); ax.text(230, y, b, color=c, fontsize=fpx(19), va="center", fontweight="bold")
    ax.text(270, 365, "the point is in the upper-right B region, like (1, 1)", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp15-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r: print(n, r if not isinstance(r, list) else [tuple(round(float(v), 3) for v in t) for t in r])
            except Exception as e: print("FAILED", n, e)
