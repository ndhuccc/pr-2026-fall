ALT = {
 "terms": ("兩個輸入二階展開的六個方塊：1、x₁、x₂、x₁x₂、x₁²、x₂²，以及 g 的六項和。", "Six boxes of the order-2 expansion of two inputs: 1, x₁, x₂, x₁x₂, x₁², x₂², and the six-term sum for g."),
 "xor": ("XOR 四點加上 y₃=x₁x₂ 後的 g=−¼+x₁+x₂−2x₁x₂：−0.25、+0.75、+0.75、−0.25，類別 B、A、A、B。", "The four XOR points with y₃=x₁x₂ and g=−¼+x₁+x₂−2x₁x₂: −0.25, +0.75, +0.75, −0.25, classes B, A, A, B."),
 "hyper": ("g=0 在 (x₁,x₂) 平面上是一對雙曲線分支，把 (0,1)、(1,0) 兩個圓點與 (0,0)、(1,1) 兩個方點分開。", "g=0 on the (x₁,x₂) plane is a pair of hyperbola branches separating the circles (0,1), (1,0) from the squares (0,0), (1,1)."),
 "kcount": ("l=2 時 r=1 到 5 的項數公式與結果：3、6、10、15、21。", "The term formula for l=2 and r=1 to 5 with results 3, 6, 10, 15 and 21."),
 "explode": ("項數 k 對階數 r 的對數圖，l=2、10、100 三條線；星號標出 l=10、r=10 的 184,756。", "Log plot of the term count k against the order r for l=2, 10 and 100; a star marks 184,756 at l=10, r=10."),
 "memory": ("l=10、r=10 時記憶體需求的對數長條圖：Φ 1.478 GB，ΦᵀΦ 273.1 GB，遠大於 16 GB。", "Log bar chart of memory for l=10, r=10: Φ 1.478 GB and ΦᵀΦ 273.1 GB, far above 16 GB."),
 "moons": ("兩個月牙資料階數 1 到 10 的準確率：新點在 r=3 達 93.2%，r=10 掉到 55.5%，訓練點升到 100%。", "Accuracy of order 1 to 10 on the two-moons data: new points reach 93.2% at r=3 and fall to 55.5% at r=10 while training reaches 100%."),
 "cond": ("同樣 60 點，設計矩陣條件數對階數 1 到 8 的半對數曲線：3.25 升到 4.4 百萬。", "Semi-log curve of the condition number of the design matrix for orders 1 to 8 on the same 60 points: 3.25 rising to 4.4 million."),
 "kernel": ("x=(1,2)、z=(3,−1) 的例子：(1+x·z)²=4，與六維映射的內積 1+6−4+9+4−12=4 相同。", "The example x=(1,2), z=(3,−1): (1+x·z)²=4, equal to the inner product 1+6−4+9+4−12=4 of the six-dimensional map."),
 "practice": ("練習圖：l=4、r=3 的項數，以及 g=−¼+x₁+x₂−2x₁x₂ 在 (1.5,1.5) 的類別。", "Practice figure: the term count for l=4, r=3 and the class of (1.5,1.5) under g=−¼+x₁+x₂−2x₁x₂."),
 "practice-sol": ("k=7!/(3!4!)=35；g(1.5,1.5)=−1.75，類 B。", "k=7!/(3!4!)=35; g(1.5,1.5)=−1.75, class B."),
}
