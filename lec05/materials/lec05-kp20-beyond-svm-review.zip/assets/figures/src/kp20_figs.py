import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums20 as N
from nums20 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
Xtr, ytr = rings(60, 1, sd=0.25); Xte, yte = rings(500, 2, sd=0.25)
Kr = lambda A, B: K_rbf(A, B, 0.5)

def f_recipe():
    fig, ax = blank(540, 420)
    T(ax, 270, 30, "any algorithm that uses only inner products", MUT, 16, False)
    for i, (n, t, c) in enumerate(((1, "rewrite it with inner products only", A_C), (2, "replace each inner product by K", B_C), (3, "write the answer as a sum over training points", GRN))):
        y = 95 + i * 80; ax.add_patch(plt.Circle((40, y), 22, fc="none", ec=c, lw=2.8)); T(ax, 40, y, str(n), c, 20); T(ax, 80, y, t, TXT, 17, True, "left")
    T(ax, 270, 330, "the weight vector w is never computed", RED, 19)
    T(ax, 270, 370, "examples here: nearest-mean rule, perceptron", MUT, 16, False)
    T(ax, 270, 400, "(the SVM of KP19 was the first example)", MUT, 15, False)
    save(fig, "lec05-kp20-recipe")

def f_kmean():
    fig, ax = blank(540, 420)
    T(ax, 270, 30, "feature space: compare ‖φ(x) − μ₁‖² with ‖φ(x) − μ₂‖²", TXT, 16)
    T(ax, 270, 85, "⟨φ(x), μ₂ − μ₁⟩ > θ", TXT, 22)
    T(ax, 270, 135, "μ₁ = mean of φ(xᵢ) over class 1,  μ₂ over class 2", MUT, 15, False)
    T(ax, 270, 205, "replace every inner product by K:", GRN, 17)
    T(ax, 270, 255, "(1/N₂) Σ K(x, xᵢ) − (1/N₁) Σ K(x, xᵢ) > θ", RED, 18)
    T(ax, 270, 295, "class 2 sum minus class 1 sum", MUT, 15, False)
    T(ax, 270, 345, "2θ = mean K within class 2 − mean K within class 1", TXT, 16)
    T(ax, 270, 395, "each sum looks like a Parzen density estimate", GRN, 17)
    save(fig, "lec05-kp20-kmean")

def f_kmeanres():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    vals = [("linear\nkernel", (kmean_pred(K_lin, Xtr, ytr, Xte) == yte).mean(), MUT), ("quadratic\nkernel", (kmean_pred(K_poly, Xtr, ytr, Xte) == yte).mean(), A_C), ("Gaussian\nkernel", (kmean_pred(Kr, Xtr, ytr, Xte) == yte).mean(), GRN), ("Gaussian,\nθ dropped", (parzen_pred(Kr, Xtr, ytr, Xte) == yte).mean(), RED)]
    for i, (n, v, c) in enumerate(vals): ax.bar(i, v, color=c, width=0.6); ax.text(i, v + 0.015, f"{v*100:.1f}", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.set_xticks(range(4)); ax.set_xticklabels([v[0] for v in vals], fontsize=fpx(14)); ax.set_ylim(0, 1.1); ax.set_ylabel("accuracy on new points", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(335, "nearest-mean rule in the kernel space, rings with sd 0.25", TXT, 16, True), (372, "the threshold θ matters: without it the sums give 79.8%", RED, 17, True), (409, "(sums only = Parzen comparison with equal priors)", MUT, 15, False)])
    save(fig, "lec05-kp20-kmeanres"); return [round(float(v[1]), 3) for v in vals]

def f_kperc():
    fig, ax = blank(540, 420)
    T(ax, 270, 28, "on a mistake: w ← w + yₜ φ(xₜ)", TXT, 18)
    T(ax, 270, 75, "count the mistakes of each point in αᵢ", MUT, 16, False)
    T(ax, 270, 125, "w = Σ αᵢ yᵢ φ(xᵢ),   w₀ = Σ αᵢ yᵢ", TXT, 18)
    T(ax, 270, 180, "g(x) = Σ αᵢ yᵢ K(x, xᵢ) + Σ αᵢ yᵢ", RED, 19)
    for i, t in enumerate(("start with all αᵢ = 0", "repeat: for i = 1 … N", "   if yᵢ g(xᵢ) ≤ 0 then αᵢ ← αᵢ + 1", "until no mistakes in a whole pass")):
        T(ax, 70, 240 + i * 36, t, GRN if i == 2 else TXT, 16, True, "left")
    T(ax, 270, 400, "w itself is never computed", MUT, 16, False)
    save(fig, "lec05-kp20-kperc")

def f_trace():
    fig, ax = blank(540, 440)
    T(ax, 270, 24, "points (1,0)+, (−1,0)+, (0,1)−, (0,−1)−;  K = (xᵀz + 1)²", TXT, 14)
    heads = ["pass", "mistakes", "α after the pass"]
    for x, t in zip((60, 150, 380), heads): T(ax, x, 65, t, MUT, 14, False)
    rows = [("1", "3", "(1, 0, 1, 1)"), ("2", "1", "(1, 1, 1, 1)"), ("3", "0", "(1, 1, 1, 1)")]
    for i, (a, b, c) in enumerate(rows):
        y = 115 + i * 50; T(ax, 60, y, a, TXT, 19); T(ax, 150, y, b, RED if b != "0" else GRN, 19); T(ax, 380, y, c, TXT, 19)
    T(ax, 270, 290, "g(x) = Σ αᵢ yᵢ K(x, xᵢ) + Σ αᵢ yᵢ = 2 (x₁² − x₂²)", RED, 17)
    T(ax, 270, 335, "no straight line separates these four points", MUT, 15, False)
    T(ax, 270, 375, "but g has the right sign on all four: g = +8 at (2, 0)", GRN, 16)
    T(ax, 270, 410, "g = −8 at (0, 2)", GRN, 16)
    save(fig, "lec05-kp20-trace")

def f_epochs():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    Xa, ya = rings(60, 1, sd=0.15)
    _, hl = perceptron(Xtr, ytr, 500); _, h1 = kperceptron(Kr, Xa, ya); _, h2 = kperceptron(Kr, Xtr, ytr)
    ax.plot(range(1, len(hl) + 1), hl, color=MUT, lw=1.6, label="linear perceptron: never reaches 0"); ax.plot(range(1, len(h2) + 1), h2, color=RED, lw=1.8, label=f"kernel, sd 0.25: 0 after {len(h2)} passes"); ax.plot(range(1, len(h1) + 1), h1, "o-", color=GRN, lw=2.6, ms=6, label=f"kernel, sd 0.15: 0 after {len(h1)} passes")
    ax.set_xscale("log"); ax.set_xlabel("pass over the data (log scale)", color=TXT, fontsize=fpx(15)); ax.set_ylabel("mistakes in the pass", color=TXT, fontsize=fpx(15)); ax.set_ylim(-0.5, 24); ax.legend(fontsize=fpx(13), frameon=False, labelcolor=TXT, loc="upper right")
    cap(fig, h, [(352, "linear: 50.0% on new points after 500 passes", MUT, 17, True), (386, "kernel (γ = 0.5): 98.2% (sd 0.15), 95.6% (sd 0.25)", GRN, 17, True), (420, "touching classes need many more passes to separate", RED, 16, True)])
    save(fig, "lec05-kp20-epochs"); return len(hl), len(h1), len(h2)

def f_losses():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    z = np.linspace(-2, 2.5, 400)
    ax.plot(z, hinge(z), color=A_C, lw=3, label="hinge"); ax.plot(z, np.minimum(expl(z), 8), color=RED, lw=3, label="exponential"); ax.plot(z, logi(z), color=GRN, lw=3, label="logistic"); ax.step(z, zo(z), color=TXT, lw=2.4, where="post", label="0/1")
    ax.set_ylim(0, 4); ax.set_xlim(-2, 2.5); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlabel("z = y·g(x)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("loss", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(352, "z > 0: classified correctly;  z ≤ 0: a mistake", TXT, 16, True), (386, "hinge max(0,1−z), exponential e^(−z), logistic ln(1+e^(−z))", MUT, 15, False), (420, "the exponential is the steepest on the left", RED, 17, True)])
    save(fig, "lec05-kp20-losses")

def f_lossvals():
    fig, ax = blank(540, 400)
    zs = [-2, -1, 0, 1, 2]
    T(ax, 50, 30, "z", MUT, 15, False)
    for i, z in enumerate(zs): T(ax, 160 + i * 85, 30, f"{z}", MUT, 17)
    z = np.array(zs, float)
    for j, (nm, v, c) in enumerate((("hinge", hinge(z), A_C), ("exponential", expl(z), RED), ("logistic", logi(z), GRN), ("0/1", zo(z), TXT))):
        y = 90 + j * 52; T(ax, 12, y, nm, c, 15, True, "left")
        for i, x in enumerate(v): T(ax, 160 + i * 85, y, f"{x:.3f}".rstrip("0").rstrip(".") if abs(x - round(x)) > 1e-9 else f"{x:.0f}", c, 17)
    T(ax, 270, 320, "at z = −2: exponential 7.389 against hinge 3", RED, 16)
    T(ax, 270, 358, "one badly wrong point weighs 2.5 times more", RED, 16)
    T(ax, 270, 388, "(7.389 / 3 = 2.46)", MUT, 14, False)
    save(fig, "lec05-kp20-lossvals")

def f_logup():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    z = np.linspace(-2, 3, 400)
    ax.step(z, zo(z), color=TXT, lw=2.6, where="post", label="0/1"); ax.plot(z, logi(z), color=GRN, lw=3, label="ln(1+e^(−z))"); ax.plot(z, logi(z) / np.log(2), color=RED, lw=3, label="ln(1+e^(−z)) / ln 2")
    ax.plot([0], [logi(np.array([0.0]))[0]], "o", color=GRN, ms=10); ax.set_ylim(0, 3.2); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlabel("z = y·g(x)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("loss", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(352, "at z = 0 the logistic loss is ln 2 = 0.693 < 1", GRN, 17, True), (386, "dividing by ln 2 lifts it to 1: now it lies above 0/1", RED, 17, True), (420, "so the raw logistic loss is not an upper bound", MUT, 15, False)])
    save(fig, "lec05-kp20-logup")

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "points (1,0)+, (−1,0)+, (0,1)−, (0,−1)−", TXT, 19)
    T(ax, 270, 90, "K = (xᵀz + 1)²,   all αᵢ = 1", TXT, 19)
    T(ax, 270, 160, "question 1: g(x) at x = (1, 2) from the four kernels", RED, 17)
    T(ax, 270, 210, "question 2: simplify g to a formula in x₁, x₂", RED, 17)
    T(ax, 270, 270, "g(x) = Σ αᵢ yᵢ K(x, xᵢ) + Σ αᵢ yᵢ", MUT, 16, False)
    save(fig, "lec05-kp20-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("K(x,(1,0)) = (1+1)² = 4,   K(x,(−1,0)) = 0", TXT), ("K(x,(0,1)) = (2+1)² = 9,   K(x,(0,−1)) = 1", TXT), ("Σ αᵢyᵢ = 1 + 1 − 1 − 1 = 0", TXT), ("g = 4 + 0 − 9 − 1 + 0 = −6  →  class −", GRN), ("sum of the four squares = 2(x₁²+1) − 2(x₂²+1)", TXT), ("g(x) = 2 (x₁² − x₂²) = 2 (1 − 4) = −6", GRN)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 16)
    T(ax, 270, 385, "both ways give −6", RED, 17)
    save(fig, "lec05-kp20-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
