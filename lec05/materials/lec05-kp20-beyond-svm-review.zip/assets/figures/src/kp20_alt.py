ALT = {
 "recipe": ("核技巧三步配方：改寫成只含內積、內積換成 K、把解寫成訓練點的線性組合；權重向量從不計算。", "The three-step recipe of the kernel trick: rewrite with inner products only, replace them by K, write the solution as a combination of training points; the weight vector is never computed."),
 "kmean": ("核化的歐氏分類器：核空間中比到兩類均值的距離，化簡成兩類核值平均之差大於 θ。", "The kernelized Euclidean classifier: comparing distances to the two class means in the kernel space reduces to a difference of mean kernel values above θ."),
 "kmeanres": ("同心環上核化歐氏分類器的新點準確率：線性核 48.8%、二次核 93.8%、高斯核 97.4%、高斯核拿掉 θ 79.8%。", "New-point accuracy of the kernelized Euclidean classifier on rings: linear 48.8%, quadratic 93.8%, Gaussian 97.4% and Gaussian with θ dropped 79.8%."),
 "kperc": ("核感知器：誤分類時 αᵢ 加 1；w=Σαᵢyᵢφ(xᵢ)、g(x)=Σαᵢyᵢ K(x,xᵢ)+Σαᵢyᵢ，與演算法四行。", "The kernel perceptron: αᵢ gains 1 at a mistake; w=Σαᵢyᵢφ(xᵢ) and g(x)=Σαᵢyᵢ K(x,xᵢ)+Σαᵢyᵢ, with the four lines of the algorithm."),
 "trace": ("4 個點與二次核的手算：第 1 輪 3 個錯、第 2 輪 1 個錯、第 3 輪停，α=(1,1,1,1)，g(x)=2(x₁²−x₂²)。", "The hand run on 4 points with the quadratic kernel: 3 mistakes in pass 1, 1 in pass 2, stop in pass 3 with α=(1,1,1,1) and g(x)=2(x₁²−x₂²)."),
 "epochs": ("每輪錯誤數：線性感知器 500 輪仍有錯；核感知器標準差 0.15 時 8 輪歸零、0.25 時 428 輪歸零。", "Mistakes per pass: the linear perceptron still errs after 500 passes; the kernel perceptron reaches 0 after 8 passes at sd 0.15 and 428 at sd 0.25."),
 "losses": ("四種損失對 z=y·g(x) 的曲線：hinge、指數、logistic 與 0/1，指數在左側最陡。", "The four losses against z=y·g(x): hinge, exponential, logistic and 0/1, with the exponential steepest on the left."),
 "lossvals": ("四種損失在 z=−2、−1、0、1、2 的數值；z=−2 時指數 7.389 對 hinge 3。", "The four losses at z=−2, −1, 0, 1 and 2; at z=−2 the exponential is 7.389 against 3 for the hinge."),
 "logup": ("0/1 損失、logistic 損失與除以 ln 2 的 logistic 損失；z=0 時 logistic 只有 0.693，除以 ln 2 後才到 1。", "The 0/1 loss, the logistic loss and the logistic loss divided by ln 2; at z=0 the logistic is only 0.693 and reaches 1 after dividing by ln 2."),
 "practice": ("練習圖：四個點、二次核、α 全為 1；題 1 算 x=(1,2) 的 g，題 2 化簡 g。", "Practice figure: four points, the quadratic kernel and all α equal to 1; question 1 computes g at x=(1,2) and question 2 simplifies g."),
 "practice-sol": ("題 1：g=4+0−9−1+0=−6；題 2：g=2(x₁²−x₂²)=−6，兩種算法相同。", "Question 1: g=4+0−9−1+0=−6; question 2: g=2(x₁²−x₂²)=−6, the same by both ways."),
}
