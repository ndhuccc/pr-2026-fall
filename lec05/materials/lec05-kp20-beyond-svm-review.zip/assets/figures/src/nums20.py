import numpy as np
import sys; sys.path.insert(0, "../kp19")
from nums19 import rings, K_lin, K_poly, K_rbf
def kmean_scores(K, Xtr, ytr, Xte):
    """kernelized Euclidean (nearest-mean) classifier. y=+1 -> class1, y=-1 -> class2. returns g>0 -> class 1 (mu1 closer)."""
    p, m = ytr > 0, ytr < 0
    Kt = K(Xte, Xtr); n1, n2 = p.sum(), m.sum()
    f = Kt[:, m].mean(1) - Kt[:, p].mean(1)   # (1/N2)sum K - (1/N1) sum K ; >theta => class 2
    Kp = K(Xtr[p], Xtr[p]); Km = K(Xtr[m], Xtr[m])
    theta = 0.5 * (Km.mean() - Kp.mean())
    return f - theta     # >0 => class 2 (y=-1)
def kmean_pred(K, Xtr, ytr, Xte): return np.where(kmean_scores(K, Xtr, ytr, Xte) > 0, -1, 1)
def parzen_pred(K, Xtr, ytr, Xte):
    p, m = ytr > 0, ytr < 0; Kt = K(Xte, Xtr)
    return np.where(Kt[:, m].mean(1) > Kt[:, p].mean(1), -1, 1)
def kperceptron(K, X, y, maxep=2000):
    G = K(X, X); a = np.zeros(len(y)); hist = []
    for ep in range(maxep):
        mis = 0
        for i in range(len(y)):
            if y[i] * ((a * y) @ G[:, i] + (a * y).sum()) <= 0: a[i] += 1; mis += 1
        hist.append(mis)
        if mis == 0: break
    return a, hist
def kp_pred(K, X, y, a, Xte): return np.sign((a * y) @ K(X, Xte) + (a * y).sum() + 1e-12)
def perceptron(X, y, maxep=2000):
    A = np.c_[X, np.ones(len(X))]; w = np.zeros(3); hist = []
    for ep in range(maxep):
        mis = 0
        for i in range(len(y)):
            if y[i] * (A[i] @ w) <= 0: w += y[i] * A[i]; mis += 1
        hist.append(mis)
        if mis == 0: break
    return w, hist
def hinge(z): return np.maximum(0, 1 - z)
def expl(z): return np.exp(-z)
def logi(z): return np.log1p(np.exp(-z))
def zo(z): return (z <= 0).astype(float)
if __name__ == "__main__":
    for sd in (0.15, 0.25):
        Xtr, ytr = rings(60, 1, sd=sd); Xte, yte = rings(500, 2, sd=sd)
        # note rings(): -1 = inner, +1 = outer
        Kr = lambda A, B: K_rbf(A, B, 0.5)
        for nm, K in (("rbf.5", Kr), ("lin", K_lin), ("poly2", K_poly)):
            km = (kmean_pred(K, Xtr, ytr, Xte) == yte).mean(); pz = (parzen_pred(K, Xtr, ytr, Xte) == yte).mean()
            agree = (kmean_pred(K, Xtr, ytr, Xte) == parzen_pred(K, Xtr, ytr, Xte)).mean()
            print(sd, nm, "kmean", km, "parzen", pz, "agree", agree)
        a, h = kperceptron(Kr, Xtr, ytr); print(sd, "kperc rbf.5 epochs", len(h), "mis hist", h[:8], "nonzero a", (a > 0).sum(), "sum a", a.sum(), "test", (kp_pred(Kr, Xtr, ytr, a, Xte) == yte).mean(), "train", (kp_pred(Kr, Xtr, ytr, a, Xtr) == ytr).mean())
        a2, h2 = kperceptron(lambda A, B: K_poly(A, B), Xtr, ytr, 3000); print(sd, "kperc poly2 epochs", len(h2), h2[-3:], "test", (kp_pred(lambda A, B: K_poly(A, B), Xtr, ytr, a2, Xte) == yte).mean())
        w, hw = perceptron(Xtr, ytr, 500); print(sd, "linear perceptron epochs", len(hw), "last mis", hw[-3:], "min mis", min(hw), "test", ((np.c_[Xte, np.ones(len(Xte))] @ w > 0) * 2 - 1 == yte).mean())
    # hand example
    X = np.array([[1, 0], [-1, 0], [0, 1], [0, -1.]]); y = np.array([1, 1, -1, -1.])
    for nm, K in (("poly2", K_poly),):
        a, h = kperceptron(K, X, y); print(nm, "alpha", a, "hist", h)
        G = K(X, X); print(G)
    print("linear perc xor:", len(perceptron(X, y, 200)[1]))
    z = np.array([-2, -1, 0, 1, 2.]); print("hinge", hinge(z), "exp", expl(z).round(3), "log", logi(z).round(3), "log/ln2", (logi(z) / np.log(2)).round(3), "01", zo(z))
