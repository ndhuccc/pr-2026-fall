import numpy as np
from nums20 import *
Xtr, ytr = rings(60, 1, sd=0.25); Xte, yte = rings(500, 2, sd=0.25)
res = {}
for nm, K in (("lin", K_lin), ("poly2", K_poly), ("rbf", lambda A, B: K_rbf(A, B, 0.5))):
    res[nm] = (kmean_pred(K, Xtr, ytr, Xte) == yte).mean()
res["parzen"] = (parzen_pred(lambda A, B: K_rbf(A, B, 0.5), Xtr, ytr, Xte) == yte).mean()
print(res)
Kr = lambda A, B: K_rbf(A, B, 0.5)
# gamma sensitivity for perceptron epochs
for g in (0.1, 0.5, 2, 8):
    Kg = lambda A, B, g=g: K_rbf(A, B, g); a, h = kperceptron(Kg, Xtr, ytr, 5000)
    print("gamma", g, "epochs", len(h), "converged", h[-1] == 0, "nonzero a", (a > 0).sum(), "test", (kp_pred(Kg, Xtr, ytr, a, Xte) == yte).mean())
