"""KP07 deck: from the step to the backpropagation gradient. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp07"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:epoch":"term:Epoch","term:批次訓練":"term:Batch training","term:停止條件":"term:Stop rule","term:初始化":"term:Initialization","term:區域極小值":"term:Local minimum","term:逐筆訓練":"term:Pattern training","term:凍結權重":"term:Frozen weights"})
from kp07_text import *

def side_page(u, t, fig, fx=60, cx=640, cw=580, rev=False):
    p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure(fig, fx, y); _, ids = stack(p, cx, y, cw, t["cards"]); step(p, *t["notes"])
    if rev: reveal(p, ids)
    return p

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    figs = ["loop","epoch1-forward","epoch1-update","curve","eta-bars","zero-init","stuck","batch-pattern","frozen","practice-forward","practice-sol"]
    for i, t in enumerate(PAGES):
        side_page(u, t, "lec05-kp07-" + figs[i], rev=(i in (9, 10)))
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
