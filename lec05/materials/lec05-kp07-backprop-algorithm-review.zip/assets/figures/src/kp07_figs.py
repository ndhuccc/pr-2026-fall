import os, sys, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums7 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
C = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "curves.json")))
def fm(v, d=3):
    if abs(v) < 0.5 * 10 ** (-d): v = 0.0
    return f"{v:.{d}f}".replace("-", "−")
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def box(ax, x, y, w_, h_, text, ec, fs=18):
    ax.add_patch(Rectangle((x, y), w_, h_, fc="none", ec=ec, lw=2.6, zorder=2))
    ax.text(x + w_ / 2, y + h_ / 2, text, color=TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold", zorder=3, linespacing=1.15)

def f_loop():
    w, h = 540, 470
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    box(ax, 20, 15, 500, 52, "1  initialize: small random weights (once)", MUT, 18)
    ys = [100, 175, 250, 325]; labs = ["2  forward, all N samples, store values", "3  backward: δ of every sample", "4  update once: Δw = η·sum(δ·input)/N", "stop if J small or gradient small"]
    cols = [TEAL2, RED, LINE, A_C]
    for y, t, c in zip(ys, labs, cols): box(ax, 60, y, 420, 52, t, c, 18)
    ax.annotate("", xy=(270, 98), xytext=(270, 68), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.4))
    for a, b in zip(ys, ys[1:]): ax.annotate("", xy=(270, b - 2), xytext=(270, a + 54), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.4))
    ax.annotate("", xy=(40, 126), xytext=(40, 351), arrowprops=dict(arrowstyle="-|>", color=MUT, lw=2.2, connectionstyle="arc3,rad=0.0"))
    ax.plot([40, 60], [351, 351], color=MUT, lw=2.2); ax.plot([40, 60], [126, 126], color=MUT, lw=2.2)
    ax.text(270, 405, "one pass over all N = 4 samples is one epoch", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 440, "repeat steps 2 to 4 until the stop rule", color=MUT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp07-loop")

def f_epoch1_forward():
    w, h = 540, 420
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    heads = ["input", "target", "h₁", "h₂", "output o"]; xs = [60, 150, 240, 330, 435]
    for x, t in zip(xs, heads): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center", va="center")
    ax.plot([15, 525], [48, 48], color=MUT, lw=1.2)
    for r, (x, y) in enumerate(zip(N.X, N.Y)):
        hh, o = N.fwd(N.W0, x); yy = 82 + r * 56
        vals = [f"({int(x[0])},{int(x[1])})", str(int(y)), fm(hh[0], 4), fm(hh[1], 4), fm(o, 4)]
        for xx, v in zip(xs, vals): ax.text(xx, yy, v, color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
        ok = (o >= 0.5) == bool(y)
        ax.plot([505], [yy], "o" if y else "s", ms=18, color=A_C if y else B_C, mec=BG, mew=1.5)
    J, c, _ = N.evalJ(N.W0)
    ax.text(270, 330, f"J = mean of ½(target − o)² = {J:.4f}", color=LINE, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 372, "all four already on the right side of 0.5", color=MUT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp07-epoch1-forward")

def f_epoch1_update():
    w, h = 540, 430
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    eta = 1.5; Wn, G = N.batch_epoch(N.W0, eta); dW = eta * G / 4
    rows = [("hidden 1", 0), ("hidden 2", 1), ("output", 2)]; heads = ["bias", "x₁ / h₁", "x₂ / h₂"]
    for j, t in enumerate(heads): ax.text(200 + j * 115, 40, t, color=MUT, fontsize=fpx(17), ha="center")
    for i, (nm, r) in enumerate(rows):
        ax.text(20, 105 + i * 80, nm, color=TXT, fontsize=fpx(18), va="center", fontweight="bold")
        for j in range(3):
            v = dW[r][j]; mag = min(1, abs(v) / 0.02)
            ax.add_patch(Rectangle((140 + j * 115, 75 + i * 80), 105, 60, fc=(B_C if v < 0 else A_C), alpha=0.15 + 0.5 * mag, ec=MUT, lw=1.2))
            ax.text(192 + j * 115, 105 + i * 80, f"{v:+.4f}".replace("-", "−"), color=TXT, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
    ax.text(270, 335, "Δw = η · (sum of δ × input over 4 samples) / 4,  η = 1.5", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    J1 = N.evalJ(Wn)[0]
    ax.text(270, 378, f"J: {N.evalJ(N.W0)[0]:.5f}  →  {J1:.5f}", color=LINE, fontsize=fpx(21), ha="center", fontweight="bold")
    save(fig, "lec05-kp07-epoch1-update")

def f_curve():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 30, 430, 330); axstyle(ax)
    c = np.array(C["curve15"]); ax.plot(np.arange(len(c)), c, color=A_C, lw=3)
    ax.set_xscale("symlog", linthresh=10); ax.set_yscale("log"); ax.set_xlim(0, 3000); ax.set_ylim(1e-4, 2e-2)
    for e in (1, 10, 100, 1000):
        ax.plot([e], [c[e]], "o", color=LINE, ms=9, zorder=5); ax.annotate(f"{c[e]:.5f}", (e, c[e]), textcoords="offset points", xytext=(4, 9), color=TXT, fontsize=fpx(15), fontweight="bold")
    ax.plot([len(c) - 1], [c[-1]], "o", color=GRN, ms=9, zorder=5)
    ax.axhline(2e-4, color=GRN, ls=(0, (4, 3)), lw=1.8); ax.text(1.2, 2.25e-4, "stop: J < 0.0002", color=GRN, fontsize=fpx(16))
    ax.set_xlabel("epoch", color=TXT, fontsize=fpx(17)); ax.set_ylabel("J", color=TXT, fontsize=fpx(17), rotation=0, labelpad=14)
    ax.text(2900, 1.15e-4, "epoch 3707", color=TXT, fontsize=fpx(16), ha="right")
    save(fig, "lec05-kp07-curve")

def f_eta_bars():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 90, 30, 430, 330); axstyle(ax)
    etas = [0.1, 0.5, 1.5, 3, 6, 30, 100]; eps = [55607, 11121, 3707, 1853, 926, 185, 53]
    ax.bar(range(7), eps, color=[A_C] * 7, width=0.6); ax.set_yscale("log"); ax.set_ylim(10, 2e5)
    ax.bar([7], [1e5], color=RED, width=0.6)
    ax.set_xticks(range(8)); ax.set_xticklabels([str(e) for e in etas] + ["200"], fontsize=fpx(16))
    for i, v in enumerate(eps): ax.text(i, v * 1.3, f"{v}", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(7, 1.4e5, "fails", color=RED, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.set_xlabel("learning rate η", color=TXT, fontsize=fpx(17)); ax.set_ylabel("epochs", color=TXT, fontsize=fpx(17), rotation=90)
    ax.text(0, 9e4 * 1.7, "epochs until J < 0.0002 and 4 of 4 correct", color=MUT, fontsize=fpx(15))
    save(fig, "lec05-kp07-eta-bars")

def f_zero_init():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 30, 430, 330); axstyle(ax)
    c = np.array(C["curve15"]); n = len(c)
    ax.plot(np.arange(n), c, color=A_C, lw=3, label="source weights")
    ax.plot([0, n - 1], [0.125, 0.125], color=RED, lw=3, label="all weights 0")
    ax.set_yscale("log"); ax.set_ylim(1e-4, 0.3); ax.set_xlim(0, n)
    ax.legend(fontsize=fpx(16), frameon=False, labelcolor=TXT, loc="center right")
    ax.text(n * 0.55, 0.15, "J = 0.125 forever", color=RED, fontsize=fpx(18), fontweight="bold", ha="center")
    ax.set_xlabel("epoch", color=TXT, fontsize=fpx(17))
    save(fig, "lec05-kp07-zero-init")

def f_stuck():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 30, 430, 330); axstyle(ax)
    s = np.array(C["stuck"]); g = np.array(C["good"])
    ax.plot(np.arange(len(s)), s, color=RED, lw=3, label="initial values A")
    ax.plot(np.arange(len(g)), g, color=GRN, lw=3, label="initial values B")
    ax.set_yscale("log"); ax.set_ylim(1e-4, 0.3); ax.set_xlim(0, 20000)
    ax.legend(fontsize=fpx(16), frameon=False, labelcolor=TXT, loc="center right")
    ax.text(9000, 0.085, "J = 0.0626, outputs 0.01, 0.99, 0.5, 0.5", color=RED, fontsize=fpx(16), fontweight="bold", ha="center")
    ax.set_xlabel("epoch", color=TXT, fontsize=fpx(17))
    save(fig, "lec05-kp07-stuck")

def f_batch_pattern():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 175, 30, 340, 300); axstyle(ax)
    labs = ["batch, η=1.5", "pattern, η=1.5", "batch, η=6"]; vals = [3707, 924, 926]
    ax.barh(range(3), vals, color=[A_C, VIO2, A_C], height=0.55); ax.set_yticks(range(3)); ax.set_yticklabels(labs, fontsize=fpx(17)); ax.invert_yaxis()
    for i, v in enumerate(vals): ax.text(v + 60, i, str(v), color=TXT, fontsize=fpx(18), va="center", fontweight="bold")
    ax.set_xlim(0, 4500); ax.set_title("epochs to converge (source weights)", color=TXT, fontsize=fpx(16), loc="left")
    ax.text(0, 3.0, "same start A: batch, pattern, shuffled pattern", color=RED, fontsize=fpx(16), fontweight="bold")
    ax.text(0, 3.45, "all stay at J ≈ 0.0626 after 20000 epochs", color=RED, fontsize=fpx(16), fontweight="bold")
    ax.set_ylim(3.7, -0.5)
    save(fig, "lec05-kp07-batch-pattern")

def f_frozen():
    w, h = 540, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    Wt = np.array(C["trained"])
    rows = [("hidden 1", Wt[0]), ("hidden 2", Wt[1]), ("output", Wt[2])]
    ax.text(270, 28, "frozen weights after 3707 epochs", color=MUT, fontsize=fpx(18), ha="center")
    for i, (nm, r) in enumerate(rows):
        y = 75 + i * 52; ax.text(20, y, nm, color=TXT, fontsize=fpx(18), va="center", fontweight="bold")
        ax.text(250, y, "(" + ",  ".join(fm(v, 3) for v in r) + ")", color=TXT, fontsize=fpx(18), va="center")
    ax.plot([15, 525], [250, 250], color=MUT, lw=1.2)
    for r, (x, y) in enumerate(zip(N.X, N.Y)):
        o = N.fwd(Wt, x)[1]; yy = 285 + r * 38
        ax.text(70, yy, f"({int(x[0])},{int(x[1])})", color=TXT, fontsize=fpx(19), va="center", fontweight="bold")
        ax.text(220, yy, f"o = {o:.4f}", color=TXT, fontsize=fpx(19), va="center")
        ax.plot([440], [yy], "o" if y else "s", ms=17, color=A_C if y else B_C, mec=BG, mew=1.5)
    ax.text(270, 440, "9 weights; each input costs 6 multiply-adds and 3 sigmoids", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp07-frozen")

def f_practice_forward():
    w, h = 540, 330
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    hh, o = N.fwd(N.W0, N.X[0]); G0, do, d, hh, o = N.grads(N.W0, N.X[0], N.Y[0])
    lines = ["sample (0,0), target 0", f"h₁ = {hh[0]:.4f}   h₂ = {hh[1]:.4f}", f"output o = {o:.4f}", "weights: hidden 1 (−2, 5, 5), hidden 2 (−7, 5, 5),", "output (−2, 8, −12)"]
    for i, t in enumerate(lines): ax.text(270, 40 + i * 52, t, color=TXT if i < 3 else MUT, fontsize=fpx(20 if i < 3 else 17), ha="center", va="center", fontweight="bold" if i < 3 else "normal")
    save(fig, "lec05-kp07-practice-forward")

def f_practice_sol():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 150, 50, 360, 270)
    G0, do, d, hh, o = N.grads(N.W0, N.X[0], N.Y[0]); dw = 1.5 * do * np.array([1, *hh])
    ax.barh(range(3), dw, color=[MUT, TEAL2, VIO2], height=0.55); ax.set_yticks(range(3)); ax.set_yticklabels(["bias (input 1)", f"from h₁ ({hh[0]:.4f})", f"from h₂ ({hh[1]:.4f})"], fontsize=fpx(16)); ax.invert_yaxis(); ax.axvline(0, color=MUT, lw=1.2)
    for i, v in enumerate(dw): ax.text(v - 0.003, i, fm(v, 4), color=TXT, fontsize=fpx(17), va="center", ha="right", fontweight="bold")
    ax.set_xlim(-0.12, 0.0); axstyle(ax); ax.set_title(f"output weights, one sample, δ at output = {fm(do, 4)}", color=TXT, fontsize=fpx(16), loc="left")
    fig.text(0.5, 1 - 365 / h, "one pattern-mode step on sample (0,0)", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    save(fig, "lec05-kp07-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try: fn()
            except Exception as e: print("FAILED", n, e)
