import numpy as np, math
X=np.array([[0,0],[0,1],[1,0],[1,1]],float); Y=np.array([0,1,1,0],float)
W0=np.array([[-2,5,5],[-7,5,5],[-2,8,-12]],float)
sig=lambda v:1/(1+np.exp(-np.clip(v,-40,40)))
def fwd(W,x):
    h=sig(W[:2,0]+W[:2,1:]@x); o=sig(W[2,0]+W[2,1:]@h); return h,o
def evalJ(W):
    J=0;c=0;outs=[]
    for x,y in zip(X,Y):
        h,o=fwd(W,x); J+=0.5*(y-o)**2; c+=(o>=0.5)==y; outs.append(o)
    return J/4,int(c),outs
def grads(W,x,y):
    h,o=fwd(W,x); do=(y-o)*o*(1-o); d=h*(1-h)*do*W[2,1:]
    G=np.zeros((3,3)); G[2]=do*np.array([1,h[0],h[1]]); G[0]=d[0]*np.array([1,*x]); G[1]=d[1]*np.array([1,*x]); return G,do,d,h,o
def batch_epoch(W,eta):
    G=sum(grads(W,x,y)[0] for x,y in zip(X,Y)); return W+eta*G/4,G
def train_batch(W,eta,maxE=60000,tol=2e-4):
    W=W.copy(); hist=[evalJ(W)[0]]
    for e in range(1,maxE+1):
        W,_=batch_epoch(W,eta); J,c,_=evalJ(W); hist.append(J)
        if c==4 and J<tol: return W,hist,e
    return W,hist,None
def train_pattern(W,eta,order=None,maxE=60000,tol=2e-4):
    W=W.copy(); hist=[evalJ(W)[0]]; idx=[0,1,2,3] if order is None else order
    for e in range(1,maxE+1):
        for i in idx:
            G=grads(W,X[i],Y[i])[0]; W=W+eta*G
        J,c,_=evalJ(W); hist.append(J)
        if c==4 and J<tol: return W,hist,e
    return W,hist,None
if __name__=="__main__":
    J0,c0,o0=evalJ(W0); print('init J',J0,c0,[round(o,4) for o in o0])
    for x,y in zip(X,Y):
        G,do,d,h,o=grads(W0,x,y); print(x,y,'h',h.round(4),'o',round(o,4),'do',round(do,4),'d',d.round(5))
    Wn,G=batch_epoch(W0,1.5); print('G sum',G.round(5)); print('dW',(1.5*G/4).round(5)); print('after1',evalJ(Wn)[:2])
    for eta in (0.1,0.5,1.5,3.0):
        W,h,e=train_batch(W0,eta); print('eta',eta,'epochs',e,'final J',h[-1],'J at 1,10,100,1000:',[round(h[k],5) if k<len(h) else None for k in (1,10,100,1000)])
    W,h,e=train_batch(W0,1.5); print('trained W',W.round(3)); print('outs',[round(o,4) for o in evalJ(W)[2]])
    Wp,hp,ep=train_pattern(W0,1.5); print('pattern eta1.5 epochs',ep)
    Wp,hp,ep=train_pattern(W0,0.5); print('pattern eta0.5 epochs',ep)
    # zero init
    Z=np.zeros((3,3)); W,h,e=train_batch(Z,1.5,maxE=20000); print('zero init:',e,h[0],h[100],h[-1]); print(W.round(4))
    # random seeds small init, batch eta 1.5
    res=[]
    for s in range(20):
        r=np.random.RandomState(s); Wr=r.uniform(-0.5,0.5,(3,3)); W,h,e=train_batch(Wr,1.5,maxE=30000); res.append((s,e,round(h[-1],5)))
    print(res)
