ALT = {
 "loop": ("訓練迴圈：前向傳遞、算誤差、反向傳播、更新權重四步，重複到停止條件；跑完 N=4 筆資料算一個 epoch。", "The training loop: forward pass, compute error, backpropagate, update weights, repeated until the stop rule; one pass over the N=4 samples is one epoch."),
 "epoch1-forward": ("第一個 epoch 的前向傳遞：XOR 四個點的輸出為 0.2578、0.9851、0.9851、0.0043，代價 J=0.0084，四點都在 0.5 的正確一側。", "Forward pass of the first epoch: the four XOR outputs are 0.2578, 0.9851, 0.9851 and 0.0043, cost J=0.0084, all on the correct side of 0.5."),
 "epoch1-update": ("第一個 epoch 的九個權重更新量（η=1.5，四筆平均）；J 由 0.00837 降到 0.00799。", "The nine weight updates of the first epoch (η=1.5, averaged over four samples); J goes from 0.00837 to 0.00799."),
 "curve": ("代價 J 隨 epoch 下降的對數曲線：第 1、10、100、1000 個 epoch 為 0.00799、0.00567、0.00175、0.00046，第 3707 個 epoch 低於門檻 0.0002。", "Log curve of the cost J against epochs: 0.00799, 0.00567, 0.00175 and 0.00046 at epochs 1, 10, 100, 1000, crossing the 0.0002 threshold at epoch 3707."),
 "eta-bars": ("學習率與所需 epoch 數：η=0.1 要 55607，0.5 要 11121，1.5 要 3707，3 要 1853，6 要 926，30 要 185，100 要 53，η=200 失敗。", "Learning rate against epochs needed: 55607 for η=0.1, 11121 for 0.5, 3707 for 1.5, 1853 for 3, 926 for 6, 185 for 30, 53 for 100, and η=200 fails."),
 "zero-init": ("所有權重為 0 時代價永遠停在 J=0.125，與一般初始值的下降曲線對照。", "With all weights 0 the cost stays at J=0.125 forever, compared with the falling curve from ordinary initial values."),
 "stuck": ("兩組起始值的代價曲線：起始值 A 停在 J=0.0626（輸出 0.01、0.99、0.5、0.5），起始值 B 在 8204 個 epoch 收斂。", "Cost curves of two starts: start A stalls at J=0.0626 (outputs 0.01, 0.99, 0.5, 0.5) and start B converges in 8204 epochs."),
 "batch-pattern": ("三種做法的 epoch 數：批次 η=1.5 要 3707、逐筆 η=1.5 要 924、批次 η=6 要 926；同一個卡住的起始值，三種做法 20000 個 epoch 後都停在 J≈0.0626。", "Epochs of three setups: batch η=1.5 needs 3707, pattern η=1.5 needs 924, batch η=6 needs 926; from the stuck start all three remain at J≈0.0626 after 20000 epochs."),
 "frozen": ("訓練完成後凍結的九個權重，以及四個輸入的輸出 0.029、0.982、0.982、0.010。", "The nine frozen weights after training and the outputs 0.029, 0.982, 0.982 and 0.010 for the four inputs."),
 "practice-forward": ("練習圖：樣本 (0,0) 的前向傳遞，隱藏輸出 0.1192、0.0009，輸出 0.2578，目標 0。", "Practice figure: forward pass of sample (0,0), hidden outputs 0.1192 and 0.0009, output 0.2578, target 0."),
 "practice-sol": ("樣本 (0,0) 的輸出層三個權重更新量：偏置 −0.0740、來自單元 1 的 −0.0088、來自單元 2 的 −0.0001。", "Output-layer updates for sample (0,0): bias −0.0740, from hidden 1 −0.0088, from hidden 2 −0.0001."),
}
