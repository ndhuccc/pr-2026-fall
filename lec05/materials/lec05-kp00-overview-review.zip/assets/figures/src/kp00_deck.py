"""Chapter 4 overview deck. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp00"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
from kp00_text import *

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    figs = ["lec05-kp01-xor-check", "lec05-kp00-map", "lec05-kp01-strip", "lec05-kp02-strip-net", "lec05-kp03-cube-cut", "lec05-kp04-plane-final", "lec05-kp05-code-plane", "lec05-kp04-stages"]
    for t, f in zip(PAGES, figs):
        p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
        p.figure(f, 60, y); stack(p, 640, y, 580, t["cards"]); step(p, *t["notes"])
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
