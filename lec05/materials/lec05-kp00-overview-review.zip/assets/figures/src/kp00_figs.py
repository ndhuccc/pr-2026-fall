import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
def f_map():
    w, h = 540, 470
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    rows = [("KP01", "one line fails on XOR", "#d97757"), ("KP02", "encode, then classify", "#5fb8a8"), ("KP03", "codes on a cube, limit of one cut", "#a98bd0"),
            ("KP04", "detect each code, then OR", LINE), ("KP05", "grow the network from points", "#6a9fd6")]
    for i, (k, t, col) in enumerate(rows):
        y = 12 + i * 92
        ax.add_patch(Rectangle((20, y), 500, 64, fc="none", ec=col, lw=2.8))
        ax.text(48, y + 32, k, color=col, fontsize=fpx(22), va="center", fontweight="bold")
        ax.text(130, y + 32, t, color=TXT, fontsize=fpx(19), va="center", fontweight="bold")
        if i < 4: ax.annotate("", xy=(270, y + 90), xytext=(270, y + 66), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.4))
    save(fig, "lec05-kp00-map")
if __name__ == "__main__": f_map()
