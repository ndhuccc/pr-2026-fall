import base64, json, os, re
S="/tmp/claude-0/-home-user/45feda6c-d91f-5d4d-a7e1-176e77f608e6/scratchpad"
ALT={"lec05-kp00-map":("全章五個知識點由上而下排成一條路線：KP01 一條線在 XOR 失敗、KP02 先編碼再分類、KP03 立方體上的編碼與一個切面的極限、KP04 逐碼偵測再用或合併、KP05 從訓練點長出網路。","The five knowledge points of the chapter as one route from top to bottom: KP01 one line fails on XOR, KP02 encode then classify, KP03 codes on a cube and the limit of one cut, KP04 detect each code then OR, KP05 grow the network from points.")}
for li,L in enumerate(["zh","en"]):
    figs={}
    for k in range(1,6):
        figs.update(json.load(open(f"{S}/kp0{k}/W_{L}/figs.json")))
    for n,a in ALT.items():
        raw=open(f"assets/figures/{n}.svg","rb").read(); m=re.search(rb'viewBox="0 0 ([\d.]+) ([\d.]+)"',raw)
        figs[n]={"uri":"data:image/svg+xml;base64,"+base64.b64encode(raw).decode(),"w":round(float(m.group(1))*100/72),"h":round(float(m.group(2))*100/72),"alt":a[li]}
    json.dump(figs,open(f"W_{L}/figs.json","w",encoding="utf-8"),ensure_ascii=False)
print("ok")
