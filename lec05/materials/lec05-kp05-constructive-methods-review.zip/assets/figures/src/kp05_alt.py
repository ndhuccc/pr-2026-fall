ALT = {
 "master": ("XOR 的四個點與主要節點的線 z1=f(x1+x2-0.5)：線上方為 1 群（含 (0,1)、(1,0)、(1,1)），左下角只有 (0,0) 在 0 群。", "The four XOR points with the master line z1=f(x1+x2-0.5): the 1 group above the line holds (0,1), (1,0) and (1,1), and only (0,0) in the lower left is in the 0 group."),
 "mixed": ("同一張圖，紅圈標出 1 群的三個點 (0,1)、(1,0)、(1,1)，兩個 A 與一個 B，是混雜群；(0,0) 是 B，分對。", "The same picture with red rings on the three points (0,1), (1,0), (1,1) of the 1 group, two A and one B, the mixed group; (0,0) is B and correct."),
 "anc": ("實線是主要節點，紫色虛線是輔助節點 z2=f(1.5-x1-x2)：(0,1) 與 (1,0) 得 0.5，(1,1) 得 -0.5。", "The solid line is the master unit and the violet dashed line is the ancillary unit z2=f(1.5-x1-x2): (0,1) and (1,0) score 0.5 and (1,1) scores -0.5."),
 "codes": ("四個點的兩位編碼 z1z2：(0,0) 為 01，(0,1) 與 (1,0) 為 11，(1,1) 為 10。", "The two-bit codes z1z2 of the four points: (0,0) is 01, (0,1) and (1,0) are 11, and (1,1) is 10."),
 "code-plane": ("新的 (z1,z2) 平面：兩個 A 合併在 11，B 在 01 與 10，00 空心沒有點；線 z1+z2=1.5 把 11 與另外兩個編碼分開。", "The new (z1,z2) plane: the two A points merge at 11, B is at 01 and 10, 00 is hollow with no point; the line z1+z2=1.5 separates 11 from the other two codes."),
 "progress": ("長條圖：只有主要節點時混雜群 3 點、答對 3 點；加上輔助節點與新主要節點後混雜群 0 點、答對 4 點，虛線是總點數 N=4。", "Bar chart: with the master only, 3 points in the mixed group and 3 correct; after the ancillary and the new master, 0 mixed points and 4 correct; the dashed line marks N=4."),
 "conflict": ("同一個輸入同時標為 A 與 B：圓點與方塊疊在同一位置，紅圈標示，網路對同一輸入只有一個輸出。", "One input labelled both A and B: a circle and a square on the same location with a red ring; the network has only one output for one input."),
 "nearest": ("兩個訓練點 a=(0,0)（A）與 b=(1,0)（B），中間的垂直平分線 x1=0.5 到兩點等距。", "Two training points a=(0,0) (A) and b=(1,0) (B) with the perpendicular bisector x1=0.5 at equal distance from both."),
 "layers": ("示意：後面各層的輸入是二元編碼，用偵測器加或合併就夠（三層）；逐層增長的程序沒有給出層數上限。", "Schematic: inputs of later layers are binary codes, and detectors plus OR are enough (three layers); a layer-by-layer growth procedure has no stated bound on the number of layers."),
 "groups": ("左：只依主要節點位元分群，0 群是一個 B，1 群是兩個 A 與一個 B（混雜，3 點）；右：依完整編碼分群，01 是 B，11 是兩個 A，10 是 B，全部純，混雜 0 點。", "Left: grouped by the master bit only, the 0 group is one B and the 1 group is two A and one B (mixed, 3 points); right: grouped by the full code, 01 is B, 11 is two A and 10 is B, all pure, 0 mixed points."),
}
