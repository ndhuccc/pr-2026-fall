import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
PTS = [(0, 0), (0, 1), (1, 0), (1, 1)]
LAB = {"OR": {(0, 0): "B", (0, 1): "A", (1, 0): "A", (1, 1): "A"},
       "AND": {(0, 0): "B", (0, 1): "B", (1, 0): "B", (1, 1): "A"},
       "XOR": {(0, 0): "B", (0, 1): "A", (1, 0): "A", (1, 1): "B"}}
LO, HI = -0.4, 1.4
RED = "#e07a70"

def sq(ax, ticks=True, lx="$x_1$", ly="$x_2$"):
    ax.set_xlim(LO, HI); ax.set_ylim(LO, HI); ax.set_aspect("equal")
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.set_xticks([0, 1] if ticks else []); ax.set_yticks([0, 1] if ticks else [])
    ax.tick_params(labelsize=fpx(17))
    ax.text(HI - 0.02, LO + 0.04, lx, fontsize=fpx(19), ha="right", va="bottom", color=TXT)
    ax.text(LO + 0.04, HI - 0.02, ly, fontsize=fpx(19), ha="left", va="top", color=TXT)
    ax.add_patch(Rectangle((0, 0), 1, 1, fill=False, ec=MUT, lw=1.2, ls=(0, (3, 3))))

def pt(ax, xy, cls, ms=20, z=5):
    if cls == "A": ax.plot(*xy, "o", ms=ms, color=A_C, mec=BG, mew=1.5, zorder=z)
    else: ax.plot(*xy, "s", ms=ms - 2, color=B_C, mec=BG, mew=1.5, zorder=z)

def tint(ax, w1, w2, w0, color=A_C, alpha=0.22):
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (w1 * X + w2 * Y + w0 > 0).astype(float), levels=[0.5, 1.5], colors=[color], alpha=alpha, zorder=1)

def line(ax, w1, w2, w0, color=LINE, lw=3, ls="-"):
    n = 400; xs = np.linspace(LO, HI, n)
    if abs(w2) > 1e-9:
        ys = -(w1 * xs + w0) / w2; m = (ys >= LO) & (ys <= HI); ax.plot(xs[m], ys[m], color=color, lw=lw, ls=ls, zorder=3)
    else:
        ax.plot([-w0 / w1] * 2, [LO, HI], color=color, lw=lw, ls=ls, zorder=3)

def ring(ax, xy, ms=34):
    ax.plot(*xy, "o", ms=ms, mfc="none", mec=RED, mew=3, zorder=6)

def cap(fig, w, h, x, ytop, text, color=None, fs=20):
    fig.text(x / w, 1 - ytop / h, text, color=color or TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold")


TEAL2, VIO2 = "#5fb8a8", "#a98bd0"
def pts_xor(ax, ms=20):
    for p_ in PTS: pt(ax, p_, LAB["XOR"][p_], ms=ms)

def sides(ax):
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, (X + Y - 0.5 > 0).astype(float), levels=[0.5, 1.5], colors=[TEAL2], alpha=0.22, zorder=1)
    ax.contourf(X, Y, (X + Y - 1.5 > 0).astype(float), levels=[0.5, 1.5], colors=[VIO2], alpha=0.30, zorder=1)

def plus(ax, base, col):
    x0, y0 = base
    ax.annotate("", xy=(x0 + 0.17, y0 + 0.17), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", color=col, lw=2.6), zorder=8)


def tint2(ax, expr, color, alpha=0.22):
    n = 300; xs = np.linspace(LO, HI, n); X, Y = np.meshgrid(xs, xs)
    ax.contourf(X, Y, expr(X, Y).astype(float), levels=[0.5, 1.5], colors=[color], alpha=alpha, zorder=1)

def ttl(ax, x, y, s, color, fs=18, **kw):
    ax.text(x, y, s, color=color, fontsize=fpx(fs), fontweight="bold", va="center", **kw)

def base(w=520, h=460, caption=None, cx=285):
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax)
    if caption: cap(fig, w, h, cx, 435, caption, fs=20)
    return fig, ax

def pts4(ax):
    for p_ in PTS: pt(ax, p_, LAB["XOR"][p_])

def f_master():
    fig, ax = base(caption="master $z_1$ splits the points in two groups")
    tint2(ax, lambda X, Y: X + Y - 0.5 > 0, LINE, 0.20)
    line(ax, 1, 1, -0.5); pts4(ax)
    ttl(ax, 0.55, 1.2, "1 group", LINE); ttl(ax, -0.3, -0.25, "0 group", MUT)
    save(fig, "lec05-kp05-master")

def f_mixed():
    fig, ax = base(caption="the 1 group holds A, A and B")
    tint2(ax, lambda X, Y: X + Y - 0.5 > 0, LINE, 0.14)
    line(ax, 1, 1, -0.5)
    pts4(ax)
    for p_ in [(0, 1), (1, 0), (1, 1)]: ring(ax, p_, ms=36)
    ttl(ax, 0.3, 1.3, "mixed group: 3 points", RED)
    ax.text(0.0, -0.27, "(0,0): B, correct", color=MUT, fontsize=fpx(16), va="center")
    save(fig, "lec05-kp05-mixed")

def f_anc():
    fig, ax = base(caption="solid: master, dashed: ancillary")
    tint2(ax, lambda X, Y: 1.5 - X - Y > 0, VIO2 if False else "#a98bd0", 0.20)
    line(ax, 1, 1, -0.5); line(ax, 1, 1, -1.5, color="#a98bd0", ls=(0, (6, 4)))
    pts4(ax)
    ax.text(1.05, 0.18, "score 0.5", color="#a98bd0", fontsize=fpx(16), va="center")
    ax.text(0.06, 0.82, "score 0.5", color="#a98bd0", fontsize=fpx(16), va="center"); ax.text(0.9, 1.15, "score $-0.5$", color="#a98bd0", fontsize=fpx(16), va="center")
    save(fig, "lec05-kp05-anc")

def f_codes():
    fig, ax = base(caption="two bits $z_1z_2$ for every point")
    tint2(ax, lambda X, Y: X + Y - 0.5 > 0, LINE, 0.10); tint2(ax, lambda X, Y: 1.5 - X - Y > 0, "#a98bd0", 0.12)
    line(ax, 1, 1, -0.5); line(ax, 1, 1, -1.5, color="#a98bd0", ls=(0, (6, 4)))
    pts4(ax)
    for (x, y, t, dx, dy) in [(0, 0, "01", 0.1, -0.2), (0, 1, "11", 0.1, 0.2), (1, 0, "11", 0.1, -0.2), (1, 1, "10", 0.1, 0.2)]:
        ax.text(x + dx, y + dy, t, color=TXT, fontsize=fpx(22), fontweight="bold", va="center", zorder=8,
                bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.7))
    save(fig, "lec05-kp05-codes")

def f_code_plane():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 15, 430, 380); sq(ax, lx="$z_1$", ly="$z_2$")
    cap(fig, w, h, 285, 435, "the new plane of codes $(z_1,z_2)$", fs=20)
    tint2(ax, lambda X, Y: X + Y - 1.5 > 0, A_C, 0.22)
    line(ax, 1, 1, -1.5)
    ax.plot(0, 0, "o", ms=20, mfc="none", mec=MUT, mew=2.2, zorder=5)
    pt(ax, (0, 1), "B"); pt(ax, (1, 0), "B"); pt(ax, (1, 1), "A")
    ax.text(0.1, 1.18, "01", color=TXT, fontsize=fpx(20), fontweight="bold", va="center"); ax.text(1.1, 0.18, "10", color=TXT, fontsize=fpx(20), fontweight="bold", va="center")
    ax.text(0.62, 1.3, "11 (two A)", color=TXT, fontsize=fpx(18), fontweight="bold", va="center")
    ax.text(0.1, 0.18, "00: none", color=MUT, fontsize=fpx(17), va="center")
    ax.text(0.05, -0.28, "$z_1+z_2=1.5$", color=LINE, fontsize=fpx(18), fontweight="bold", va="center")
    save(fig, "lec05-kp05-code-plane")

def f_progress():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 60, 20, 440, 370)
    ax.set_xlim(-0.5, 6.0); ax.set_ylim(0, 5.2)
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.set_xticks([0.2, 1.4, 4.2, 5.3]); ax.set_xticklabels(["master\nonly", "after\nancillary", "master\nonly", "new\nmaster"], fontsize=fpx(15))
    ax.set_yticks([0, 1, 2, 3, 4]); ax.tick_params(labelsize=fpx(17))
    for x, v, col in [(0.2, 3, RED), (1.4, 0, RED), (4.2, 3, A_C), (5.3, 4, A_C)]:
        if v: ax.bar(x, v, width=0.6, color=col, alpha=0.85)
        ax.text(x, v + 0.12, str(v), color=TXT, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.plot([2.8, 2.8], [0, 5], color=MUT, lw=1.2, ls=(0, (3, 3)))
    ax.text(0.8, 4.85, "same layer", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold"); ax.text(0.8, 4.45, "points in mixed group", color=RED, fontsize=fpx(16), ha="center")
    ax.text(4.75, 4.85, "across layers", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold"); ax.text(4.75, 4.45, "correct points", color=A_C, fontsize=fpx(16), ha="center")
    ax.plot([3.0, 6.0], [4, 4], color=MUT, ls=(0, (4, 3)), lw=1.6); ax.text(3.05, 3.62, "$N=4$ points", color=MUT, fontsize=fpx(16))
    save(fig, "lec05-kp05-progress")

def f_conflict():
    fig, ax = base(caption="identical input, opposite labels")
    ax.plot(0.5, 0.5, "o", ms=26, color=A_C, mec=BG, mew=1.5, zorder=5); ax.plot(0.5, 0.5, "s", ms=14, color=B_C, mec=BG, mew=1.5, zorder=6)
    ring(ax, (0.5, 0.5), ms=52)
    ax.text(0.5, 0.15, "one input $x$,\nlabels A and B", color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    ax.text(0.5, 0.95, "one output only", color=RED, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    save(fig, "lec05-kp05-conflict")

def f_nearest():
    fig, ax = base(caption="perpendicular bisector of two points")
    tint2(ax, lambda X, Y: X < 0.5, B_C, 0.16); tint2(ax, lambda X, Y: X >= 0.5, A_C, 0.16)
    ax.plot([0.5, 0.5], [LO, HI], color=LINE, lw=3, zorder=3)
    pt(ax, (0, 0), "B"); pt(ax, (1, 0), "A")
    ax.annotate("", xy=(0.5, 0.0), xytext=(0.0, 0.0), arrowprops=dict(arrowstyle="<|-|>", color=TXT, lw=2, shrinkA=14, shrinkB=0), zorder=7)
    ax.annotate("", xy=(0.5, 0.0), xytext=(1.0, 0.0), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2, shrinkA=14, shrinkB=0), zorder=7)
    ax.text(0.0, 0.2, "u", color=TXT, fontsize=fpx(22), ha="center", fontweight="bold"); ax.text(1.0, 0.2, "v", color=TXT, fontsize=fpx(22), ha="center", fontweight="bold")
    ax.text(0.52, 0.62, "$x_1=0.5$", color=LINE, fontsize=fpx(19), fontweight="bold", va="center")
    ax.text(0.5, -0.22, "equal distance", color=TXT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp05-nearest")

def f_layers():
    w, h = 520, 460
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    rows = [("layer 1: code $z$", "binary bits from lines", "#5fb8a8"), ("layer 2: detectors", "one per code (KP04)", LINE), ("layer 3: OR $\\to$ A / B", "enough: 3 layers", A_C)]
    for i, (t, sub, col) in enumerate(rows):
        y = 20 + i * 92
        ax.add_patch(Rectangle((40, y), 270, 62, fc="none", ec=col, lw=2.6)); ax.text(175, y + 31, t, color=TXT, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
        ax.text(325, y + 31, sub, color=MUT, fontsize=fpx(16), va="center")
        if i < 2: ax.annotate("", xy=(175, y + 90), xytext=(175, y + 64), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.4))
    ax.add_patch(Rectangle((40, 310), 270, 62, fc="none", ec=RED, lw=2.6, ls=(0, (6, 4))))
    ax.text(175, 341, "growing procedure: ? layers", color=TXT, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
    ax.text(325, 341, "no bound given", color=MUT, fontsize=fpx(16), va="center")
    ax.text(175, 410, "exists $\\neq$ guarantee", color=TXT, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
    save(fig, "lec05-kp05-layers")

def f_groups():
    w, h = 1000, 200
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    def grp(x, y, ww, hh, items, ec, title):
        ax.add_patch(Rectangle((x, y), ww, hh, fc="none", ec=ec, lw=2.8, ls=(0, (6, 4)) if ec == RED else "-"))
        ax.text(x + ww / 2, y - 16, title, color=TXT, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
        for i, k in enumerate(items):
            cx = x + ww / 2 + (i - (len(items) - 1) / 2) * 52; cy = y + hh / 2
            if k == "A": ax.plot(cx, cy, "o", ms=22, color=A_C, mec=BG, mew=1.5)
            else: ax.plot(cx, cy, "s", ms=20, color=B_C, mec=BG, mew=1.5)
    ax.text(250, 20, "grouped by the master bit only", color=MUT, fontsize=fpx(18), ha="center", va="center")
    grp(40, 70, 130, 70, ["B"], OK_C if False else "#7dbb8c", "$z_1=0$")
    grp(210, 70, 220, 70, ["A", "A", "B"], RED, "$z_1=1$ (mixed)")
    ax.text(750, 20, "grouped by the full code", color=MUT, fontsize=fpx(18), ha="center", va="center")
    grp(560, 70, 110, 70, ["B"], "#7dbb8c", "01")
    grp(700, 70, 150, 70, ["A", "A"], "#7dbb8c", "11")
    grp(880, 70, 110, 70, ["B"], "#7dbb8c", "10")
    ax.text(250, 172, "mixed points: 3", color=RED, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    ax.text(750, 172, "mixed points: 0", color="#7dbb8c", fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    save(fig, "lec05-kp05-groups")

if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("f_") and callable(f): f()
