"""KP05 deck: grow a network from points. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp05"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:主要節點": "term:Master unit", "term:混雜群": "term:Mixed group", "term:輔助節點": "term:Ancillary unit", "term:純化": "term:Purification"})
from kp05_text import *

def side_page(u, t, fig, fx=60, cx=640, cw=580, rev=False):
    p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure(fig, fx, y); _, ids = stack(p, cx, y, cw, t["cards"]); step(p, *t["notes"])
    if rev: reveal(p, ids)
    return p

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    figs = ["master", "mixed", "anc", "codes", "code-plane", "progress", "conflict", "nearest", "layers", "master", "groups"]
    for i, t in enumerate(PAGES):
        if i == 10:
            p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
            yb = p.figure("lec05-kp05-groups", 60, y)
            _, ids = stack(p, 60, yb + 10, 1160, t["cards"]); step(p, *t["notes"]); reveal(p, ids); continue
        side_page(u, t, "lec05-kp05-" + figs[i], rev=(i == 9))
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
