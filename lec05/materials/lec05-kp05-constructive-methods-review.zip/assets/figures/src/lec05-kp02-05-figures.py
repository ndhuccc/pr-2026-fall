from pathlib import Path
import sys,json,itertools
import numpy as np
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'.agents/skills/view-from-text'))
from jbd_figure import *
OUT=ROOT/'assets/figures';OUT.mkdir(exist_ok=True)
X=np.array([[0,0],[0,1],[1,0],[1,1]]);T=np.array([0,1,1,0]);Y=(X.sum(1)[:,None]>np.array([.5,1.5])).astype(int)
V=np.array(list(itertools.product([0,1],repeat=3)))
f=lambda z:(np.asarray(z)>0).astype(int)
H=np.stack([f(.5-V.sum(1)),f(V[:,0]+V[:,1]-V[:,2]-1.5),f(V.sum(1)-2.5)],axis=1)
pred=f(H.sum(1)-.5);target=np.array([tuple(v) in [(0,0,0),(1,1,0),(1,1,1)] for v in V]).astype(int);assert np.array_equal(pred,target)
Z=np.column_stack([f(X.sum(1)-.5),f(1.5-X.sum(1))]);assert np.array_equal(f(Z.sum(1)-1.5),T)
DATA={}
def start(dark=True):
 use_jbd_style(20)
 if not dark:plt.rcParams.update({'text.color':'#292c29','axes.labelcolor':'#292c29','axes.edgecolor':'#60625a','xtick.color':'#60625a','ytick.color':'#60625a','figure.facecolor':'white','savefig.transparent':False})
 return new_figure(530,440,(75,65,20,95))
def pts(ax,P,labels):
 for v,c,m,lab in [(1,PALETTE['positive'],'o','A: class 1'),(0,PALETTE['negative'],'s','B: class 0')]:
  q=P[labels==v];ax.scatter(q[:,0],q[:,1],color=c,marker=m,s=130,zorder=4,label=lab)
def axes(ax,xlabel='$x_1$',ylabel='$x_2$',lo=-.3,hi=1.3):
 ax.set(xlim=(lo,hi),ylim=(lo,hi),xlabel=xlabel,ylabel=ylabel);ax.set_aspect('equal');ax.grid(alpha=.15)
def legend(ax):ax.legend(loc='lower center',bbox_to_anchor=(.5,1.03),frameon=False,ncol=2,fontsize=px_to_pt(18),labelspacing=.2)
def make(key,dark):
 fig,ax=start(dark);xx=np.linspace(-.3,1.3,400)
 if key=='kp02-input':
  pts(ax,X,T);axes(ax)
  for b in [.5,1.5]:ax.plot(xx,b-xx,color=PALETTE['boundary'],lw=2.5)
  ax.plot([],[],color=PALETTE['boundary'],label='Hidden boundaries');legend(ax)
 elif key=='kp02-hidden':
  pts(ax,np.array([[0,0],[1,0],[1,1]]),np.array([0,1,0]));axes(ax,'$y_1$','$y_2$')
  ax.plot(xx,xx-.5,color=PALETTE['boundary'],label='Output boundary')
  ax.annotate('2 inputs merge',xy=(1,0),xytext=(.12,.4),arrowprops={'arrowstyle':'->','color':PALETTE['muted']},fontsize=px_to_pt(18));legend(ax)
 elif key=='kp03-regions':
  xx=np.linspace(-2.6,2.6,401);ax.axvline(0,c=PALETTE['boundary']);ax.axhline(0,c=PALETTE['boundary']);ax.plot(xx,xx+1,c=PALETTE['boundary']);axes(ax,lo=-2.6,hi=2.6)
  pp=[(-.7,-1.7,'000'),(-1.8,-.2,'001'),(-.25,.35,'010'),(-1.5,1.6,'011'),(1.2,-1.2,'100'),(1.7,.65,'110'),(.3,2,'111')]
  for a,b,s in pp:ax.text(a,b,s,ha='center',va='center',fontsize=px_to_pt(20),bbox={'facecolor':'#151513' if dark else 'white','alpha':.9,'edgecolor':'none','pad':1})
  ax.plot([],[],color=PALETTE['boundary'],label='g1=0, g2=0, g3=0');legend(ax)
 elif key=='kp03-obstruction':
  P=np.array([[0,0],[0,1],[1,0],[1,1]]);labels=np.array([1,0,0,1]);pts(ax,P,labels);axes(ax,'$y_1$','$y_2$')
  for (a,b),s,off in zip(P,['000','010','100','110'],[(.1,-.15),(.1,.12),(-.3,-.15),(-.3,.12)]):ax.text(a+off[0],b+off[1],s,fontsize=px_to_pt(19))
  ax.plot([0,1],[0,1],ls='--',color=PALETTE['positive'],alpha=.5);ax.plot([0,1],[1,0],ls=':',color=PALETTE['negative'],alpha=.5);legend(ax)
 elif key=='kp04-regions':
  a,b=np.meshgrid(np.linspace(-2.6,2.6,450),np.linspace(-2.6,2.6,450));v=np.stack([a>0,b>0,-a+b-1>0],axis=-1).astype(int);mask=((v==[0,0,0]).all(-1)|(v==[1,1,0]).all(-1)|(v==[1,1,1]).all(-1))
  ax.contourf(a,b,mask,levels=[-.5,.5,1.5],colors=[PALETTE['negative'],PALETTE['positive']],alpha=.23)
  xx=np.linspace(-2.6,2.6,400);ax.axvline(0,c=PALETTE['boundary']);ax.axhline(0,c=PALETTE['boundary']);ax.plot(xx,xx+1,c=PALETTE['boundary']);axes(ax,lo=-2.6,hi=2.6)
  for a,b,s in [(-1,-1,'A: 000'),(1.5,.6,'A: 110'),(.3,2,'A: 111'),(-1,1.2,'B'),(1,-1,'B')]:ax.text(a,b,s,ha='center',fontsize=px_to_pt(18))
  from matplotlib.patches import Patch
  ax.legend(handles=[Patch(facecolor=PALETTE['positive'],label='A: selected cells'),Patch(facecolor=PALETTE['negative'],label='B: other cells')],loc='lower center',bbox_to_anchor=(.5,1.03),frameon=False,fontsize=px_to_pt(18))
 elif key=='kp05-input':
  pts(ax,X,T);axes(ax);ax.plot(xx,.5-xx,c=PALETTE['boundary'],lw=3,label='Master boundary');ax.plot(xx,1.5-xx,c=PALETTE['vector'],ls='--',lw=3,label='Ancillary boundary');legend(ax)
 elif key=='kp05-code':
  pts(ax,np.array([[0,1],[1,1],[1,0]]),np.array([0,1,0]));axes(ax,'$z_1$','$z_2$');ax.plot(xx,1.5-xx,c=PALETTE['boundary'],label='Next master boundary');ax.annotate('2 A inputs',xy=(1,1),xytext=(.1,.65),arrowprops={'arrowstyle':'->','color':PALETTE['muted']},fontsize=px_to_pt(18));legend(ax)
 elif key=='kp05-progress':
  ax.bar([0,1],[3,0],color=[PALETTE['warning'],PALETTE['ok']],width=.52)
  ax.set(xticks=[0,1],xticklabels=['Master only','With ancillary'],ylim=(0,3.7),ylabel='Samples in mixed codes');ax.set_yticks([0,1,2,3]);ax.text(0,3.1,'3',ha='center',fontsize=px_to_pt(22));ax.scatter([1],[0],c=PALETTE['ok'],s=110,zorder=4);ax.text(1,.15,'0',ha='center',fontsize=px_to_pt(22));ax.tick_params(axis='x',labelsize=px_to_pt(18));ax.grid(axis='y',alpha=.15)
 elif key=='kp05-nearest':
  pts(ax,np.array([[0,0],[1,0]]),np.array([0,1]));axes(ax,lo=-.5,hi=1.5);ax.axvline(.5,c=PALETTE['boundary'],label='Equal-distance boundary');ax.plot([0,1],[0,0],ls=':',c=PALETTE['muted']);legend(ax)
 return fig
for key in ['kp02-input','kp02-hidden','kp03-regions','kp03-obstruction','kp04-regions','kp05-input','kp05-code','kp05-progress','kp05-nearest']:
 fig=make(key,False);fig.savefig(OUT/f'lec05-{key}.png',dpi=160);plt.close(fig)
 fig=make(key,True);DATA[key]=svg_data_uri(fig)
Path('/tmp/batch-figures.json').write_text(json.dumps(DATA))
report={'xorInput':X.tolist(),'xorHidden':Y.tolist(),'xorScores':(Y[:,0]-Y[:,1]-.5).tolist(),'cubeVertices':V.tolist(),'isolators':H.tolist(),'threeLayerPredictions':pred.tolist(),'constructiveCodes':Z.tolist(),'constructivePredictions':f(Z.sum(1)-1.5).tolist(),'mixedCounts':[3,0]}
assert np.array_equal(f(Y[:,0]-Y[:,1]-.5),T)
Path('/tmp/batch-numerical.json').write_text(json.dumps(report,indent=2))
print('9 figures and exact numerical checks complete')
