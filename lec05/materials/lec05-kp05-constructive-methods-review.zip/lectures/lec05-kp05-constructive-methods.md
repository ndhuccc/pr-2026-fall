# KP05 構造式網路與訓練集精確分類（Constructive networks and exact training-set classification）

> 程度：大學三年級（undergrad）／Level: Undergraduate (undergrad)
>
> 圖型識別｜第四章 §4.5｜Pattern Recognition, Chapter 4, Section 4.5

[簡報閱讀與下載（Slides）](../slides/lec05-kp05-constructive-methods.html)

## 學習目標（Learning objectives）

- 能區分 master unit、ancillary unit 與純化編碼的作用。（Distinguish master units, ancillary units, and code purification.）
- 能用有限樣本及嚴格進展解釋停止論證。（Explain finite termination through strict progress on a finite sample set.）
- 能說明訓練全對不保證泛化，也不保證小網路。（Explain why zero training error guarantees neither generalization nor a small network.）

## KP05 依錯誤需求逐步增長網路（Grow a network in response to remaining classification needs）

**一句話重點**：構造式方法從小架構開始，依規則增加節點或層，讓有限訓練集逐步可分；這是訓練集上的目標，不等於對未見資料的保證。

**One-sentence summary**: Constructive methods start small and add nodes or layers under rules that improve separability of a finite training set. Their training-set objective does not guarantee performance on unseen data.

### 從已知幾何答案轉向只有訓練點（From known geometry to labeled training points）

**白話說明**：KP04 的存在性構造知道目標區域，實務卻通常只有點與標籤。構造式方法先用很小的網路嘗試，再依尚未解決的部分加節點。有些方法增加深度，有些固定深度增加寬度。

**Plain explanation**: KP04 assumed known target regions, while applications usually supply points and labels. A constructive method starts with a small network and adds capacity where classification remains unresolved. Some variants grow depth; others keep depth fixed and grow width.

可把過程想成先畫少量隔板，再處理仍混雜的區域。不過新增節點的方式必須有規則；隨便增加神經元，並不自動得到有限步停止的保證。

Think of drawing a few dividers, then addressing the remaining mixed cells. Node additions must follow specified rules; arbitrary growth does not automatically guarantee finite termination.

### Tiling 的兩種節點各負責什麼（The two roles in tiling）

**正式定義**：設有限標記訓練集為 $X=\{(\mathbf{x}_n,c_n)\}_{n=1}^N$，類別 $c_n\in\{0,1\}$。第一個主要分類節點稱 master unit，以 pocket 等線性學習方法在該層輸入上訓練。

**Formal definition**: Let $X=\{(\mathbf{x}_n,c_n)\}_{n=1}^N$ be a finite labeled set with binary labels. A master unit is the main classifier trained on that layer's inputs, for example with a pocket-based linear learner.

master 的輸出把資料分成 $X^+$ 與 $X^-$。若同一輸出群仍含兩類，增加 ancillary unit，只用需要分辨的混雜子集訓練它。新增位元的目的，是讓不同類樣本不再共享完全相同的層輸出。

The master partitions inputs into $X^+$ and $X^-$. If one output group contains both classes, add an ancillary unit trained on the relevant mixed subset. Its new bit helps prevent opposite-label samples from sharing the complete layer code.

| 符號／名稱 | 中文意義 | English meaning |
|---|---|---|
| $N,n,X$ | 樣本總數、索引與訓練集 | Sample count, index, and training set |
| $c_n$ | 第 $n$ 點的真實類別 | True class of sample $n$ |
| $X^+,X^-$ | master 輸出 1 與 0 的群 | Groups with master output 1 and 0 |
| master unit | 該層主要分類節點 | Main classification unit of a layer |
| ancillary unit | 分辨混雜子群的輔助節點 | Auxiliary unit that separates a mixed subgroup |
| $\mathbf{z},\mathbf{z}^{(k)}$ | 層編碼與第 $k$ 層編碼 | Layer code and code at layer $k$ |

來源提到 pocket、LMS 或解析計算可作節點學習手段，這是構造式方法的不同選擇，不能把每個選擇都當成同一個 tiling 定理的充分條件。

The source mentions pocket, LMS, or analytic calculations as possible local learners across constructive methods. They are alternatives, not automatically interchangeable sufficient conditions for every tiling theorem.

### 用 XOR 手算一次純化過程（A hand-computable XOR purification example）

**例子［補充］**：為看懂 master 與 ancillary 的分工，沿用 XOR 四點，選擇下列解析參數。這是機制示範，不是聲稱實際跑過 pocket，亦不重現原文演算法的全部選擇規則。

**Example [Added]**: Use XOR to illustrate the two roles with explicit parameters. This demonstrates the mechanism; it is not a recorded pocket run or a full implementation of every original tiling choice.

$$
z_1=f(x_1+x_2-0.5),\qquad z_2=f(1.5-x_1-x_2),\qquad f(t)=\begin{cases}1,&t>0,\\0,&t\leq0.\end{cases}
$$

先只看 master $z_1$：$(0,0)$ 獨自落在 0 群，其餘三點落在 1 群。1 群含兩個 A 與一個 B，還不純。ancillary 的 $z_2$ 針對這個三點子問題，把兩個 A 與右上角 B 分開。

Using only master $z_1$, $(0,0)$ forms the zero group and the other three form the one group. The latter contains two A points and one B point. Ancillary bit $z_2$ separates the two A points from the upper-right B within this mixed subgroup.

![master 與 ancillary 的兩條邊界（Master and ancillary boundaries）](../assets/figures/lec05-kp05-input.png)

圖說 `lec05-kp05-input`：實線為 master，虛線為 ancillary；圓點 A、方點 B。先找 master 的三點混合群，再看 ancillary 如何把這三點分成兩類。

Figure `lec05-kp05-input`: The solid boundary is the master and the dashed boundary is ancillary. Circles are A; squares are B. Locate the master's three-point mixed group before examining its refinement.

1. 對 $(0,1)$：$z_1=f(0+1-0.5)=f(0.5)=1$，$z_2=f(1.5-0-1)=f(0.5)=1$，編碼為 11。（For $(0,1)$, both scores are 0.5, producing code 11.）
2. 對 $(1,1)$：$z_1=f(1+1-0.5)=f(1.5)=1$，$z_2=f(1.5-1-1)=f(-0.5)=0$，編碼為 10。（For $(1,1)$, the scores are 1.5 and -0.5, producing code 10.）
3. 對 $(0,0)$：$z_1=f(-0.5)=0$，$z_2=f(1.5)=1$，編碼為 01。$(1,0)$ 與 $(0,1)$ 同為 A，編碼同為 11。（For $(0,0)$ the code is 01. Input $(1,0)$ shares A's code 11.）

| 輸入 Input | 真值 Label | 編碼 Code |
|---|---|---|
| $(0,0)$ | B | 01 |
| $(0,1)$ | A | 11 |
| $(1,0)$ | A | 11 |
| $(1,1)$ | B | 10 |

現在不同類不共用同一編碼，但 B 仍分布在兩個碼；純化不是要求一個類只能有一個碼。

Opposite classes no longer share codes, though B occupies two codes. Purification does not require one code per class.

下一層可用 $f(z_1+z_2-1.5)$ 當新 master。對 A 的 11，$1+1-1.5=0.5$；對 B 的 01 或 10，分別為 $0+1-1.5=-0.5$、$1+0-1.5=-0.5$。因此四點全對。

A next-layer master can use $f(z_1+z_2-1.5)$. A's code 11 scores 0.5; B's codes 01 and 10 both score -0.5. All four points are therefore classified correctly.

![純化編碼與下一層分類邊界（Purified codes and the next master boundary）](../assets/figures/lec05-kp05-code.png)

圖說 `lec05-kp05-code`：橫縱軸是新增後的 $z_1,z_2$。兩個 A 輸入合併於 11，另外兩個 B 位置可由 $z_1+z_2=1.5$ 隔開。

Figure `lec05-kp05-code`: Axes are $z_1,z_2$. Two A inputs merge at 11, and the output boundary separates this location from both B codes.

### 有限步停止究竟依賴什麼（What finite termination actually requires）

第一種進展是，同層處理混雜子集時，需繼續分辨的子問題嚴格變小。第二種進展是，來源所述的適當層間構造，讓新 master 保留原來分對的點，並至少多分對一點。兩個論證不能混成「每加一個節點，總錯誤一定立刻下降」。

One progress argument shrinks the mixed subgroup that still needs refinement within a layer. A second, under the source's appropriate inter-layer construction, preserves the earlier master's correct classifications and adds at least one. Neither says that every arbitrary new node immediately lowers total error.

若第 $k$ 層 master 正確點數為 $C_k$，上述保留與進步條件可寫成 $C_{k+1}\geq C_k+1$，且 $C_k\leq N$。有限整數序列不可能永遠嚴格增加。這是條件成立時的停止理由，不是宣稱 pocket 在任何不可分子集上都會找到完美直線。

Let $C_k$ count the correctly classified points at master layer $k$. The preservation-and-progress condition is $C_{k+1}\geq C_k+1$, with $C_k\leq N$. A bounded integer sequence cannot increase forever. This is conditional termination reasoning, not a claim that pocket perfectly separates every nonseparable subgroup.

［補充］必要資料條件也要說明：如果完全相同的輸入被標成兩個互斥類別，任何確定性網路都不可能全對。有限步精確分類的敘述必須排除這種標籤衝突，並滿足構造所要求的嚴格進展。

[Added] Identical inputs with contradictory labels cannot both be correctly classified by a deterministic network. Exact finite classification requires excluding such conflicts and satisfying the construction's strict-progress conditions.

![本例混雜碼中的樣本數由三降為零（Mixed-code sample count falls from three to zero in this example）](../assets/figures/lec05-kp05-progress.png)

圖說 `lec05-kp05-progress`：計數是「仍屬混雜碼的樣本」，不是錯誤數或節點數。master 之後有 3 點在混雜群，加入 ancillary 後為 0；這是本例實算，不是原文實驗曲線。

Figure `lec05-kp05-progress`: The quantity is samples in mixed codes, not errors or neuron count. It is 3 after the master and 0 after refinement. These values are computed for this example, not copied from an empirical source curve.

### 三層足夠，與演算法最多長三層不同（Three layers suffice does not cap every growth procedure）

第一層之後的輸入是二元碼，因此可以使用 KP04 的頂點偵測與 OR 構造。這說明適當的三層表示足以完成有限純化碼的分類，但不表示任何逐層增長的 tiling 執行都自動在三層內停止。

Later-layer inputs are binary codes, so KP04's detector-and-OR construction can classify them. This establishes sufficiency of a suitable three-layer representation, not an automatic three-layer stopping bound for every layer-growing tiling execution.

來源把這兩種說法接得過緊；這裡明確區分存在性架構與特定訓練程序的深度保證，不把它們當成同一個定理。

The source connects these statements too closely. We distinguish a sufficient architecture from a depth guarantee for a particular training procedure.

### 最近鄰啟發的另一條構造路線（A second construction inspired by nearest neighbors）

另一種方法以兩個訓練點的垂直平分超平面作位置比較，再以 AND 形成鄰近區域，最後以 OR 合併同類區域。［補充］令 $\mathbf{a},\mathbf{b}$ 為兩個訓練位置，等距條件可展開為：

Another construction compares point locations using perpendicular-bisector hyperplanes, combines comparisons with AND to form local regions, and merges same-class regions with OR. [Added] For training locations $\mathbf{a},\mathbf{b}$, equal distances give:

先將兩個平方範數展開；共同的二次項會消去。

First expand the two squared norms; the common quadratic term cancels.

$$
\mathbf{x}^T\mathbf{x}-2\mathbf{a}^T\mathbf{x}+\|\mathbf{a}\|^2
=\mathbf{x}^T\mathbf{x}-2\mathbf{b}^T\mathbf{x}+\|\mathbf{b}\|^2.
$$

$$
\|\mathbf{x}-\mathbf{a}\|^2=\|\mathbf{x}-\mathbf{b}\|^2
\quad\Longleftrightarrow\quad
2(\mathbf{b}-\mathbf{a})^T\mathbf{x}=\|\mathbf{b}\|^2-\|\mathbf{a}\|^2.
$$

取 $\mathbf{a}=(0,0)$、$\mathbf{b}=(1,0)$，代入得到 $2(1,0)^T\mathbf{x}=1-0$，所以 $2x_1=1$，即 $x_1=0.5$。這只是原方法的雙點可視化，不是完整最近鄰網路實驗。

For $\mathbf{a}=(0,0)$ and $\mathbf{b}=(1,0)$, substitution gives $2x_1=1$, hence $x_1=0.5$. This visualizes one pairwise comparison, not a complete nearest-neighbor network experiment.

![兩個訓練點的等距邊界（Equal-distance boundary of two training points）](../assets/figures/lec05-kp05-nearest.png)

圖說 `lec05-kp05-nearest`：先找兩個相距 1 的訓練點，再看中間 $x_1=0.5$ 的垂直線。它是線段的垂直平分線，對應到一個線性距離比較。

Figure `lec05-kp05-nearest`: Find the two training points one unit apart, then inspect the perpendicular bisector at $x_1=0.5$, which implements a linear distance comparison.

這種直接構造可能需要大量成對比較；$N$ 個點最多有 $N(N-1)/2$ 個不同無向點對。［補充］這個計數說明可能的二次成長，不表示所有比較都必須保留，也不是最小網路大小。

There can be many pairwise comparisons: $N$ points have at most $N(N-1)/2$ distinct unordered pairs. [Added] This illustrates potential quadratic growth, not a required or minimal network size.

### 訓練全對不代表學得好（Perfect training classification is not the whole goal）

**常見迷思**：既然最後能把訓練點全分對，就保證新資料也正確。保證只涉及已提供的有限樣本；網路可能為這些點建立過多局部區域，對未見位置卻沒有好預測。

**Common misconception**: Perfect training classification does not guarantee correct predictions on new inputs. The guarantee concerns supplied finite samples; a network can create many local cells without predicting unseen locations well.

同樣地，有限步停止不代表網路最小、計算最省，或所有學習選擇都同樣可靠。這些落差引出另一條主流路線：先固定架構，再以代價函數學習權重，亦即下一批的反向傳播。

Finite termination also guarantees neither minimal size nor low computation, and not every learning choice is equally reliable. These gaps motivate the next route: fix the architecture and learn weights by minimizing a cost function through backpropagation.

**小練習**：用本例四點重算混雜群大小，說明為何 3 降到 0 不是錯誤率。提示：依完整編碼分組，再檢查每組的真值。再想一想：若同一個輸入出現矛盾標籤，新增再多節點能否讓兩筆都分對？只需用確定性輸出說明理由。

**Practice**: Recompute the mixed-group sample counts and explain why 3 to 0 is not an error-rate curve. Hint: group by full codes and inspect labels. Could more nodes correctly classify two identical inputs with conflicting labels? Explain using deterministic outputs.

## 術語與來源（Terminology and source）

| 中文 | English |
|---|---|
| 構造式方法 | Constructive method |
| 主要節點 | Master unit |
| 輔助節點 | Ancillary unit |
| 純化編碼 | Code purification |
| 垂直平分超平面 | Perpendicular-bisector hyperplane |
| 泛化 | Generalization |

來源：[第四章 KP05，§4.5](https://ndhuccc.github.io/CCC-LNS/PR_115/Ch04-nonlinear-classifiers/index.html#kp5)，2026-10-24 讀取。保留 tiling、pocket、LMS、二元中介表示及最近鄰構造的比較；未查得原始論文完整演算法，故不宣稱重現其全部更新或證明。XOR 純化數值、等距式與資料一致性條件均標示為補充。

Source: Chapter 4, KP05, Section 4.5, accessed 2026-10-24. The tiling discussion, local-learning alternatives, binary intermediate representations, and nearest-neighbor comparison follow the source. The complete original algorithm was not available, so no full replication is claimed. The numerical purification example, distance formula, and consistency conditions are marked additions.
