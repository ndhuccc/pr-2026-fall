圖型識別 第四章 KP00：第四章路線圖（中文版）

簡報：slides/lec05-kp00-overview-zh.html（離線網頁，用瀏覽器開啟）；slides/lec05-kp00-overview-zh.jbd.json 為 JianBauDau 可編輯原檔。
講義：lec05-kp00-overview-zh-lecture.pdf（PDF）、lec05-kp00-overview-zh-reading.html（離線網頁）、lectures/lec05-kp00-overview-zh.md（Markdown 原文）。
英文版為另一個下載包（-en）。草稿，待教師驗收。
