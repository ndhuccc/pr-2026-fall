from pathlib import Path
import os,io,json,base64,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from math import comb
OUT=Path(os.environ.get('KP_BUILD',str(Path(__file__).resolve().parent/'build')));(OUT/'assets/figures').mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'path','mathtext.fontset':'cm','axes.spines.top':False,'axes.spines.right':False})
REG={};blue='#6a9fd6';orange='#d97757';green='#5fb8a8';red='#e07a70'

def generate(name,kind,alt,w=540,h=390):
 for light in [False,True]:
  fg='#26221e' if light else '#f2ede4';bg='white' if light else '#151513'
  plt.rcParams.update({'text.color':fg,'axes.labelcolor':fg,'xtick.color':fg,'ytick.color':fg,'axes.edgecolor':fg,'font.size':14.4})
  fig=plt.figure(figsize=(w/100,h/100),dpi=100);fig.patch.set_facecolor(bg)
  ax=fig.add_axes([.17,.18,.78,.74]);ax.set_facecolor(bg);ax.tick_params(labelsize=13)
  def leg():ax.legend(fontsize=13,facecolor=bg,edgecolor=fg,labelcolor=fg)
  if kind=='size':
   x=np.linspace(0,1,400);xp=np.array([.08,.22,.38,.52,.70,.88]);yp=np.array([.5,.95,.45,-.35,-.8,-.9])
   ax.plot(x,np.sin(2*np.pi*x),color=green,label='smooth trend');ax.scatter(xp,yp,color=orange,s=50,label='training samples')
   ax.plot(x,np.interp(x,xp,yp),color=blue,ls='--',label='sample detail');ax.set(xlabel=r'$x$',ylabel=r'$y$');leg()
  elif kind=='early':
   ep=np.arange(1,6);tr=[.5,.3,.2,.15,.10];va=[.55,.35,.25,.28,.40]
   ax.plot(ep,tr,'o-',color=blue,label='training');ax.plot(ep,va,'s-',color=orange,label='validation');ax.axvline(3,color=green,ls='--');ax.annotate('save epoch 3',xy=(3,.25),xytext=(3.05,.53),arrowprops={'arrowstyle':'->','color':fg},fontsize=13)
   ax.set(xlabel='epoch',ylabel='mean loss',xticks=ep,ylim=(0,.65));leg()
  elif kind=='regions':
   x=np.arange(0,9)
   for d,c in [(1,blue),(2,orange),(3,green)]:ax.plot(x,[sum(comb(int(k),m) for m in range(min(d,int(k))+1)) for k in x],'-o',color=c,label=f'd={d}')
   ax.set(xlabel='hidden units K',ylabel='maximum cells',xticks=[0,2,4,6,8]);leg()
  elif kind=='lines':
   ax.set_aspect('equal');x=np.linspace(-1,2,400);ax.plot(x,.5-x,color=green,label=r'$x_1+x_2=0.5$');ax.plot(x,1.5-x,color=orange,label=r'$x_1+x_2=1.5$');ax.fill_between(x,.5-x,1.5-x,color=blue,alpha=.2)
   for p,c,m in [((0,0),orange,'s'),((0,1),blue,'o'),((1,0),blue,'o'),((1,1),orange,'s')]:ax.scatter(*p,color=c,marker=m,s=80)
   ax.set(xlim=(-.3,1.3),ylim=(-.3,1.3),xlabel=r'$x_1$',ylabel=r'$x_2$');leg()
  elif kind=='curvature':
   t=np.linspace(0,1.3,400);ax.plot(t,.5*100*(t-.2)**2,color=orange,label=r'$w_A^*=0.2,\ H_{AA}=100$');ax.plot(t,.5*.02*(t-1)**2,color=blue,label=r'$w_B^*=1,\ H_{BB}=0.02$');ax.set_yscale('symlog',linthresh=.01);ax.scatter([0,0],[2,.01],color=[orange,blue],s=65);ax.set(xlabel='weight after change',ylabel='local loss increase');leg()
  elif kind in ('saliency','saliency-practice'):
   vals=[2,.01] if kind=='saliency' else [1,.2];names=['A: |w|=0.2','B: |w|=1.0'] if kind=='saliency' else ['C: |w|=0.5','D: |w|=2.0']
   ax.bar(names,vals,color=[orange,blue]);ax.set_yscale('log');ax.set(ylabel='predicted deletion cost',ylim=(.004,5));ax.text(0,vals[0]*1.2,f'{vals[0]:.2f}',ha='center');ax.text(1,vals[1]*1.2,f'{vals[1]:.2f}',ha='center')
  elif kind in ('rho','rho-practice'):
   t=np.linspace(-4,4,500);tau=1 if kind=='rho' else 2;ax.plot(t,t*t/(tau*tau+t*t),color=blue,label=rf'$\rho(w)=w^2/({tau*tau}+w^2)$');ax.axhline(1,color=orange,ls='--')
   if kind=='rho':ax.scatter([.2,1,3],[.04/1.04,.5,.9],color=orange,s=50)
   ax.set(xlabel='weight w',ylabel='penalty',ylim=(-.05,1.1));leg()
  elif kind=='gradient':
   t=np.linspace(-4,4,500);ax.plot(t,2*t/(1+t*t)**2,color=blue,label=r'$\rho\prime(w)$');ax.axhline(0,color=fg,lw=1);ax.axvline(0,color=fg,lw=1);ax.set(xlabel='weight w',ylabel='penalty derivative');leg()
  elif kind in ('data','boundary'):
   rng=np.random.default_rng(20261025);A=np.array([[.4,.9],[2,1.8],[2.3,2.3],[2.6,1.8]]);B=np.array([[1.5,1],[1.9,1],[1.5,3],[3.3,2.6]])
   for mus,c,m,label in [(A,blue,'o','class A: 200'),(B,orange,'+','class B: 200')]:
    pts=np.concatenate([rng.normal(mu,math.sqrt(.08),(50,2)) for mu in mus]);ax.scatter(*pts.T,color=c,marker=m,s=12,alpha=.6,label=label)
   ax.set(xlabel=r'$x_1$',ylabel=r'$x_2$',xlim=(-.7,4.2),ylim=(-.2,4));ax.set_aspect('equal');leg()
  elif kind=='counts':
   ax.bar(['before','after'],[480,25],color=[orange,blue]);ax.set(ylabel='reported weights',ylim=(0,550));ax.text(0,490,'480',ha='center');ax.text(1,45,'25',ha='center');ax.text(.5,400,'case report\nnot a new experiment',ha='center',fontsize=13)
  elif kind=='patch':
   a=np.zeros((6,6));a[1:4,1]=1;ax.imshow(a,cmap='Blues',vmin=0,vmax=1);ax.add_patch(Rectangle((-.5,.5),3,3,fill=False,edgecolor=orange,lw=3));ax.set(xticks=range(6),yticks=range(6),xlabel='column',ylabel='row');ax.set_title('6 x 6 image; orange = 3 x 3 field',fontsize=14)
  elif kind=='kernel':
   a=np.array([[0,1,0],[0,1,0],[0,1,0]]);ax.imshow(a,cmap='Blues',vmin=0,vmax=1)
   for i in range(3):
    for j in range(3):ax.text(j,i,str(a[i,j]),ha='center',va='center',fontsize=20,color='#111' if a[i,j]==0 else 'white')
   ax.set(xticks=range(3),yticks=range(3),xlabel='kernel column',ylabel='kernel row');ax.set_title('one reusable set of 9 weights',fontsize=14)
  elif kind in ('shift','maps','maps-practice'):
   fig.delaxes(ax)
   size=8 if kind=='maps-practice' else 6
   a=np.zeros((size,size));a[1:4,1]=1;b=np.zeros((size,size));b[1:4,3]=1;k=np.zeros((3,3));k[:,1]=1
   def corr(x):return np.array([[np.sum(x[i:i+3,j:j+3]*k) for j in range(size-2)] for i in range(size-2)])
   arrays=[a,b] if kind=='shift' else [corr(a),corr(b)]
   for j,z in enumerate(arrays):
    aa=fig.add_axes([.08+j*.48,.20,.40,.65]);aa.imshow(z,cmap='Blues',vmin=0,vmax=1 if kind=='shift' else 3);aa.set_xticks([]);aa.set_yticks([]);aa.set_title('before shift' if j==0 else 'shift right by 2',fontsize=14)
    if kind in ('maps','maps-practice'):
     for row,col in [(1,0 if j==0 else 2)]:aa.text(col,row,'3',ha='center',va='center',fontsize=20,color='white')
   fig.text(.5,.06,'same object, new position' if kind=='shift' else 'max(before) = max(after) = 3',ha='center',fontsize=14,color=fg)
  elif kind=='pair':
   ax.set_aspect('equal');ax.set(xlim=(-.5,4.5),ylim=(-.7,3.5),xlabel='column',ylabel='row',xticks=range(5),yticks=range(4));ax.grid(alpha=.2)
   for p,q,c,label in [((0,0),(1,1),blue,'displacement (1,1)'),((2,0),(3,1),blue,'same displacement'),((0,1),(2,3),orange,'same slope, twice as long')]:
    ax.plot([p[0],q[0]],[p[1],q[1]],'o-',color=c,lw=3,label=label)
   leg()
  elif kind=='radius':
   ax.set_aspect('equal');t=np.linspace(0,2*np.pi,400);ax.plot(np.cos(t),np.sin(t),color=green);ax.scatter([1,0],[0,1],s=80,color=[blue,orange]);ax.annotate('same squared norm = 1',xy=(0,1),xytext=(-1.3,1.3),fontsize=14);ax.set(xlim=(-1.5,1.5),ylim=(-1.4,1.6),xlabel=r'$x_1$',ylabel=r'$x_2$')
  else: raise ValueError(kind)
  svg=io.BytesIO();fig.savefig(svg,format='svg',facecolor=bg);png=OUT/'assets/figures'/f'{name}.png'
  if light:fig.savefig(png,dpi=150,facecolor='white')
  else:
   raw=svg.getvalue();(OUT/'assets/figures'/f'{name}.svg').write_bytes(raw);REG[name]={'w':w,'h':h,'uri':'data:image/svg+xml;base64,'+base64.b64encode(raw).decode(),'alt':alt,'kind':kind}
  plt.close(fig)

specs=[('10-trend','size','同一批帶雜訊的樣本與平滑規律；折線僅作教學示意，不是網路訓練結果。'),('10-early','early','五個檢查點的訓練與驗證平均損失；驗證最低在第3輪，訓練最低在第5輪。'),('10-regions','regions','不同輸入維度 d 下，K 個一般位置超平面形成區域數的最大值。'),('10-xor','lines','XOR 四點與兩條平行線；實際只有三個區域，不等於一般位置最大值四。'),('11-curvature','curvature','局部二次損失：小權重A刪除代價2，大權重B刪除代價0.01。'),('11-saliency','saliency','對數刻度比較兩個可手算的刪除代價2與0.01。'),('11-rho','rho','飽和懲罰 w平方除以1加w平方；w為0.2、1、3時約0.0385、0.5、0.9。'),('11-gradient','gradient','飽和懲罰的導數，在零點為零；因此平滑懲罰本身不會保證精確零權重。'),('11-data','data','按來源八組均值與每組50點重抽的400個樣本，變異數0.08，固定種子20261025；不是原始資料。'),('11-counts','counts','來源案例報告權重數從480減至25；未宣稱重跑原實驗。'),('12-shift','shift','相同三格直筆畫在6乘6影像內向右移動兩格，沒有裁掉筆畫。'),('12-patch','patch','6乘6影像中的3乘3視窗，視窗是單一位置的感受野。'),('12-kernel','kernel','重用的3乘3權重矩陣，中欄為1，其餘為0，偏置為0。'),('12-maps','maps','共享同一權重計算兩張4乘4特徵圖，反應跟著平移，最大值都等於3。'),('12-pair','pair','兩條位移為1,1的線段與同斜率但位移為2,2的線段；同斜率不足以判定純平移。'),('12-radius','radius','點1,0與0,1的平方範數都是1；平方範數項對旋轉不變，但不代表整個模型不變。')]
specs += [('11-saliency-practice','saliency-practice','練習C與D的顯著度為1與0.2，與同頁解答一致。'),('11-rho-practice','rho-practice','練習的懲罰尺度tau=2，曲線為w平方除以4加w平方。'),('11-boundary','boundary','補充計分r=x2-0.6x1-1的logistic輸出，其0.5等高線由401乘401網格計算；不是訓練實驗。'),('12-maps-practice','maps-practice','8乘8輸入的練習產生6乘6特徵圖，平移前後最大值都為3。')]
for suffix,kind,alt in specs:generate('lec05-kp'+suffix,kind,alt)
(OUT/'figs.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2))
# Numeric evidence, independent of slide text.
x=np.zeros((6,6));x[1:4,1]=1;y=np.zeros((6,6));y[1:4,3]=1;k=np.zeros((3,3));k[:,1]=1
conv=lambda z:np.array([[float(np.sum(z[i:i+3,j:j+3]*k)) for j in range(4)] for i in range(4)])
checks={'parameter_2_3_1':(2+1)*3+(3+1),'parameter_2_3_2_1':9+8+3,'early_best_epoch':int(np.argmin([.55,.35,.25,.28,.4])+1),'saliency':[.5*100*.2**2,.5*.02*1**2],'rho':[v*v/(1+v*v) for v in [.2,1,3]],'retained_percent':100*25/480,'removed_percent':100*455/480,'unshared_parameters':16*10,'shared_parameters':10,'maps':[conv(x).tolist(),conv(y).tolist()],'pool_max':[float(conv(x).max()),float(conv(y).max())],'shared_gradient':.2*3-.1*1,'weight_update':1-.1*.5,'full_hessian_cost':.5*np.array([-.5,.25])@np.array([[4,1],[1,2]])@np.array([-.5,.25])}
assert checks['parameter_2_3_1']==13 and checks['early_best_epoch']==3
assert np.allclose(checks['saliency'],[2,.01]) and checks['pool_max']==[3,3]
(OUT/'numerical-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print('figures',len(REG),'numeric checks verified')
