from pathlib import Path
import json,re
from build import PAGES,SLUG,TITLES,OUT
from labels import ENALT
GROUPS={
10:[(1,3,('大小先問能學到什麼','What capacity can learn'),('先把「記住訓練答案」與「預測新資料」分開，才知道為何要控制大小。下面的參數計數建立在明確架構上；不同架構不能只拿隱藏單元數比較。','Separate memorizing training answers from predicting new data before discussing size. Parameter counts below belong to explicit architectures, not hidden-unit counts alone.')),(4,7,('用保留資料選訓練檢查點','Choose checkpoints using held-out data'),('大小固定仍可能過度配合訓練資料，因此要另外控制訓練時間。先看兩條損失曲線，再用五組數字選模型，最後區分驗證與測試的用途。','Even a fixed architecture may adapt too closely to training data. Examine two loss curves, choose among five checkpoints, and distinguish validation from testing.')),(8,9,('幾何容量上界與 XOR 的實際構造','Geometric capacity versus an actual XOR construction'),('資料選擇回答預測好不好，幾何計數只回答架構最多能切出幾塊。兩者是不同問題；我們用 XOR 看出最大值和實際值為何不必相同。','Held-out selection asks about prediction, while geometry counts possible cells. XOR makes the distinction between a maximum and an actual arrangement concrete.')),(10,10,('三種選大小的策略','Three size-selection strategies'),('上界沒有告訴我們如何找到合適的權重，於是回到實際模型搜尋。下面比較從大往小與從小往大的兩種方向。','A cell bound does not find good weights. Return to practical model search and compare shrinking a network with growing one.')),(11,11,('讀懂來源互動示範的範圍','Interpret the source demonstration within scope'),('理論與資料選擇有了區分，再讀來源的正弦示範，就不會把一次實驗當成通用最佳設定。','With capacity and selection separated, the source sine demonstration becomes a case rather than a universal setting.')),(12,13,('小練習與逐步核對','Practice and worked checks'),('先遮住解題段落，自己判斷兩題，再用數值核對理由。','Cover the worked answers first, make both decisions, then check the numerical reasoning.'))],
11:[(1,3,('刪除量不等於刪除代價','A deletion amount is not its cost'),('已經訓練好的網路可能有冗餘，但不能只看權重大小就判斷重要性。先固定我們要做的操作，再看代價曲線如何回應。','A fitted network may be redundant, but weight magnitude alone is not importance. Specify the deletion operation before examining how loss responds.')),(4,6,('從 Taylor 展開得到顯著度','Derive saliency from a Taylor expansion'),('附近的斜率與曲率提供局部預測。推導的每次簡化都有條件；接著的小例子刻意讓權重大小和重要性給出相反排序。','Local slopes and curvature predict nearby changes. Every simplification has conditions; the example deliberately reverses the magnitude-based ranking.')),(7,7,('把估計放進可檢查的剪枝程序','Turn estimates into a checked pruning procedure'),('顯著度不是刪除後的實測值，所以流程必須包含重新評估與再訓練，而不能把一個排序永久當成真理。','Saliency is not a measurement after deletion. The procedure therefore needs reassessment and retraining rather than treating one ranking as permanent.')),(8,11,('在代價函數中加入模型偏好','Put a model preference into the objective'),('剪枝改結構，正則化先改目標。先比較兩個固定候選模型，再看來源的飽和懲罰曲線，最後分清縮小數值與真正刪除。','Pruning changes structure; regularization first changes the objective. Compare two candidates, examine the saturating penalty, then distinguish shrinkage from deletion.')),(12,13,('單元輸出與權重範數也需要考慮','Consider unit outputs and weight norms'),('一條連線不是整個單元，一個單元也不是整條訊號路徑。把這些尺度分開，才能理解為何參數數量並非唯一複雜度指標。','A connection is not a unit, and a unit is not a whole signal path. These distinctions help explain why parameter count is not the only complexity measure.')),(14,15,('級聯相關法用新單元補殘差','Cascade correlation adds units for residual structure'),('另一條路從小架構出發。輸入側先找與殘差有關的反應，凍結後再讓輸出側降低誤差；兩個階段不能混成同一個訓練目標。','Growth starts from a small architecture. Incoming weights first find residual-related responses; outgoing weights then reduce error after freezing. These are different objectives.')),(16,19,('把來源模擬報告與本次計算分開','Separate source simulation reports from new calculations'),('下面完整保留來源的重要設定與報告數字。重新抽樣的散點圖只檢查分布，權重長條只比較報告數量；沒有用教學示意冒充重跑原實驗。','The following retains the source settings and reported numbers. Resampled scatter checks the distribution; count bars show reported counts. Neither claims reproduction of the experiments.')),(20,22,('完整二階補償、練習與解答','Full-curvature compensation and practice'),('想再深入時，可以比較其他權重固定與允許補償的差異。最後兩題回到可手算的顯著度及懲罰，檢查是否真的理解操作。','For more depth compare fixed remaining weights with compensating changes. The final problems return to hand-computable saliency and penalties.'))],
12:[(1,3,('從移動的筆畫建立局部共享規則','Build a local shared rule from a moving stroke'),('希望同一物件移動後仍屬同類，不等於要求網路每個數字都不變。先限制每個位置看到的範圍，再給所有位置相同的九個權重。','Keeping an object in the same class after movement does not require every network value to remain unchanged. Define each local field, then reuse nine weights.')),(4,6,('先有等變的特徵圖，再談不變的讀出','Equivariant maps before invariant readout'),('完整保留位置，會得到跟著輸入移動的反應。只有再選擇合適的彙整方式與條件，才可能把位置差異消去；這是最重要的觀念轉折。','Preserving position yields responses that move with the input. Suitable aggregation and assumptions may then discard position; this is the central conceptual turn.')),(7,8,('參數如何計數，又如何共同更新','Count and update shared parameters'),('共享省下的是可獨立調整的數字，不是取消所有位置的計算。訓練時每個使用位置都要對同一參數的梯度負責。','Sharing reduces independent numbers, not all computations over positions. Each use contributes to the gradient of the same parameter.')),(9,9,('把不變性的三條路線放在一起比較','Compare three routes to invariance'),('局部共享只是其中一種架構先驗。實際系統可以結合不變特徵與資料擴增，但要先判斷變換是否保留類別。','Local sharing is one architectural prior. Systems may combine invariant features and augmentation after checking whether transformations preserve labels.')),(10,12,('高階輸入乘積中的幾何共享','Geometric tying of higher-order input products'),('將兩個像素相乘，會讓一對位置的幾何關係進入模型。分清平移保留位移、旋轉保留長度，才不會用錯共享條件。','Pixel products let pair geometry enter the model. Translation preserves displacement, while rotation preserves length; these imply different tying rules.')),(13,14,('平方項特例與歷史架構的限制','A squared-norm special case and the historical architecture'),('特殊的平方和可以只多用一個係數，但一個項具備對稱性不代表整體模型也具備。再回到歷史例子，區分原理與架構細節。','A squared-norm term uses one extra coefficient, but an invariant term does not make the whole model invariant. Distinguish a shared principle from historical architecture details.')),(15,16,('小練習與參數計數核對','Practice and parameter-count checks'),('改變影像大小重新算一次，再用等變與不變的式子描述輸出，檢查是否把位置數與參數數分開。','Change image size and recount, then describe the output using equivariance and invariance equations. Keep position count separate from parameter count.'))]}
EXTRA={10:(r'''#### 為什麼區域數有這個形式？

在一般位置加入第 K 個超平面時，它把原有某些區域切成兩半。這些新切出的部分，對應其他 K−1 個超平面在新平面內形成的低一維區域。因此有遞迴

$$
R(K,d)=R(K-1,d)+R(K-1,d-1).
$$

初始情形為 $R(0,d)=1$、$R(K,0)=1$。利用組合數的 Pascal 關係可得到 $R(K,d)=\sum_{m=0}^d\binom Km$。這個推導計的是空間分割，不包含最後輸出層能否把任意區域標籤分對的條件。

#### 自己可執行的檢查點選擇

```python
validation = [0.55, 0.35, 0.25, 0.28, 0.40]
best_epoch = min(range(len(validation)), key=validation.__getitem__) + 1
assert best_epoch == 3
```

這段只選已提供的檢查點，沒有執行神經網路訓練。真實訓練還要保存及還原該輪的權重、固定資料切分，並記錄使用的評估指標。
''',r'''#### Why does the cell count have this form?

In general position the K-th hyperplane splits some existing cells. The additional pieces correspond to the cells formed by the previous K−1 hyperplanes inside this new, lower-dimensional plane. Hence

$$
R(K,d)=R(K-1,d)+R(K-1,d-1).
$$

Start from $R(0,d)=1$ and $R(K,0)=1$. Pascal's identity gives $R(K,d)=\sum_{m=0}^d\binom Km$. This counts partitions; it does not ensure that the output layer separates arbitrary cell labels.

#### An executable checkpoint check

```python
validation = [0.55, 0.35, 0.25, 0.28, 0.40]
best_epoch = min(range(len(validation)), key=validation.__getitem__) + 1
assert best_epoch == 3
```

This selects from supplied checkpoints, not trained networks. Real fitting also needs saved and restored weights, a fixed data split and a specified assessment metric.
'''),11:(r'''#### 把 Taylor 近似的條件寫完整

將目前權重向量記為 $\mathbf w$，擾動記為 $\delta\mathbf w$。若代價二次可微，在附近可寫成

$$
J(\mathbf w+\delta\mathbf w)-J(\mathbf w)\approx\nabla J(\mathbf w)^T\delta\mathbf w+\frac12\delta\mathbf w^TH\delta\mathbf w.
$$

接近駐點才可忽略第一項。對角近似是計算上的簡化，並不代表所有神經網路的權重真的互相獨立。若只刪一個權重且其餘固定，二階交叉項因其他擾動為零而消失；若讓其他權重補償，則必須重新考慮非對角元素。本講義末尾的 $2\times2$ 例子，正好展示這個差別。

#### 飽和懲罰的導數

令 $u=w^2$、$v=\tau^2+w^2$。由商數微分法則，

$$
\rho'(w)=\frac{2w(\tau^2+w^2)-w^2(2w)}{(\tau^2+w^2)^2}=\frac{2\tau^2w}{(\tau^2+w^2)^2}.
$$

正權重的導數為正，梯度下降的懲罰部分往零拉；負權重則往相反方向拉回零。很大的權重處導數也很小，因為曲線已飽和。這不是凸的 L1 懲罰，也不能保證有限次更新得到精確零。

#### 來源報告的計數疑義

來源報告剪枝模型有兩個各20單元的隱藏層及480權重，但沒有完整交代輸入、輸出及偏置的計數口徑。不能反推一個唯一架構，再把推得的數字當成原文事實。400樣本的2–3–2–1模擬與480→25的剪枝展示，分開記錄，不假定是同一批資料。
''',r'''#### State the Taylor assumptions explicitly

Let the current parameter vector be $\mathbf w$ and its perturbation $\delta\mathbf w$. For a twice differentiable objective, locally

$$
J(\mathbf w+\delta\mathbf w)-J(\mathbf w)\approx\nabla J(\mathbf w)^T\delta\mathbf w+\frac12\delta\mathbf w^TH\delta\mathbf w.
$$

Only near stationarity may the first term be neglected. The diagonal assumption simplifies computation; it does not make real network weights independent. Changing only one weight with all others fixed removes cross terms because other perturbations are zero. Allowing compensation requires the off-diagonal information again. The final $2\times2$ example illustrates this distinction.

#### Differentiate the saturating penalty

With $u=w^2$ and $v=\tau^2+w^2$, the quotient rule yields

$$
\rho'(w)=\frac{2w(\tau^2+w^2)-w^2(2w)}{(\tau^2+w^2)^2}=\frac{2\tau^2w}{(\tau^2+w^2)^2}.
$$

The penalty gradient pulls positive and negative weights toward zero. It is also small for very large magnitudes because the curve saturates. This is not a convex L1 penalty and does not guarantee exact zeros in finite updates.

#### A counting ambiguity in the source

The source reports two 20-unit hidden layers and 480 weights without fully specifying the input/output/bias convention. Do not reverse-engineer a unique architecture and present it as a source fact. Keep the 400-case 2–3–2–1 simulation separate from the 480-to-25 pruning illustration.
'''),12:(r'''#### 共享視窗的精確計算

令影像為 $x$，卷積核為 $K$，偏置為 b。這裡採用不翻轉卷積核的互相關：

$$
r_{ij}=b+\sum_{a=0}^{2}\sum_{b'=0}^{2}K_{ab'}x_{i+a,j+b'}.
$$

i、j 是視窗左上角的位置；a、b′ 是核內列、欄偏移，b′ 與偏置 b 不同。若有逐點活化 $\phi$，特徵圖可取 $F(x)_{ij}=\phi(r_{ij})$；主例子直接使用分數 r，沒有額外活化。兩張影像的特徵圖可完整算得：

$$
F(x)=\begin{bmatrix}2&0&0&0\\3&0&0&0\\2&0&0&0\\1&0&0&0\end{bmatrix},\qquad
F(Tx)=\begin{bmatrix}0&0&2&0\\0&0&3&0\\0&0&2&0\\0&0&1&0\end{bmatrix}.
$$

反應位置改了，兩者最大值卻都是3。全域最大值彙整讓此例的特徵不變；這不等於所有後續任務都應該丟棄位置資訊。

#### 有限網格的邊界

平移等變性的公式需要對應位置都合法。當物件移出畫面、邊界補值不同，或平移量與步長不相容時，等式可能只在內部區域成立或不再精確成立。影像旋轉也可能需要插值；單純相同長度的權重分組不能解除取樣誤差。

#### 共享梯度的來源

一個參數 k 同時進入許多分數 $r_p$。鏈鎖法則把所有路徑相加：$\partial J/\partial k=\sum_p(\partial J/\partial r_p)(\partial r_p/\partial k)$。在局部線性計分下，第二個因子就是該位置輸入 $x_p$。若某些路徑還有活化，其導數包含在 $\delta_p=\partial J/\partial r_p$，不應漏掉或重算。
''',r'''#### The exact shared-window calculation

For image x, kernel K and bias b, use unflipped-kernel cross-correlation:

$$
r_{ij}=b+\sum_{a=0}^{2}\sum_{b'=0}^{2}K_{ab'}x_{i+a,j+b'}.
$$

i,j locate the patch; a,b′ locate offsets inside the kernel. The offset b′ differs from bias b. With a pointwise activation $\phi$, take $F(x)_{ij}=\phi(r_{ij})$; the running example uses r directly without an additional activation. Its complete maps are

$$
F(x)=\begin{bmatrix}2&0&0&0\\3&0&0&0\\2&0&0&0\\1&0&0&0\end{bmatrix},\qquad
F(Tx)=\begin{bmatrix}0&0&2&0\\0&0&3&0\\0&0&2&0\\0&0&1&0\end{bmatrix}.
$$

Response locations change while both maxima remain three. Global max pooling makes this example's feature invariant, not a case for discarding position in every task.

#### Finite-grid boundaries

The equivariance equation needs valid corresponding positions. Cropping, inconsistent padding or a shift incompatible with stride can restrict or break it. Image rotation can also require interpolation; equal-length coefficient groups do not eliminate sampling error.

#### Where the shared gradient comes from

One parameter k enters many scores $r_p$. The chain rule sums all paths: $\partial J/\partial k=\sum_p(\partial J/\partial r_p)(\partial r_p/\partial k)$. For a local linear score, the second factor is input $x_p$. Activation derivatives belong in $\delta_p=\partial J/\partial r_p$ and must neither be omitted nor counted twice.
''')}
OBJECTIVES={10:[('算出給定架構的參數數，區分單元與參數。','Count parameters and distinguish them from units.'),('用驗證數字選檢查點，區分三種資料角色。','Select a checkpoint and distinguish three data roles.'),('解釋區域上界為何不是模型品質保證。','Explain why a cell bound is not a quality guarantee.')],11:[('由 Taylor 近似推導顯著度並說出假設。','Derive saliency and state its assumptions.'),('手算懲罰值、刪除代價與補償例子。','Compute penalties, deletion costs and compensation.'),('區分原文模擬報告與本次教學計算。','Distinguish reported simulations from teaching calculations.')],12:[('手算共享核、特徵圖與參數數量。','Compute a shared response, feature maps and parameter counts.'),('用同一例子分清等變性與不變性。','Distinguish equivariance from invariance on one example.'),('指出平移與旋轉共享的條件與限制。','State conditions and limitations of translation and rotation sharing.')]}
NOTES={10:('來源將驗證與測試並列、把曲線分岔當停止點，並由區域上界直接推足夠；本教材分別澄清資料角色、驗證最低點與明確構造。一般訓練損失也不保證逐輪單調下降。','The source groups validation with testing, describes stopping at divergence and infers sufficiency from a cell bound. This material separates data roles, validation minima and constructive sufficiency. Real training losses also need not decrease monotonically.'),11:('480→25、每100輪檢查與兩組動量參數均為來源報告；本次沒有重跑這些實驗，也沒有原始精確曲線。Bartlett結果只有來源量級摘要，未讀得原始完整定理，不作無條件誤差證書。','The 480-to-25 counts, 100-epoch interval and momentum settings are source reports, not reproduced experiments or new exact traces. The Bartlett result is available only as a scaling summary, not a complete theorem or unconditional certificate.'),12:('來源將共享直接稱為平移不變，本教材區分局部等變與彙整後不變；來源同斜率約束不足以刻畫純平移，改用位移向量。circular模型的平方項不變，不代表整個模型不變。','The source calls sharing translation invariant; this material distinguishes equivariance from aggregated invariance. Displacement replaces slope-only translation grouping. An invariant squared-norm term does not make the whole circular model invariant.')}


EXTRA[10]=(EXTRA[10][0]+r'''
#### 平均平方誤差的意義

來源正弦示範是連續數值預測，採平均平方誤差 $L=\frac1N\sum_{n=1}^N(\hat y_n-t_n)^2$；t 是觀測目標，hat y 是預測，N 是這份資料的筆數。例如兩筆誤差為1和−1，$L=(1^2+(-1)^2)/2=1$。分類還要另外指定門檻與分類錯誤率，不可把這兩種指標當成同一量。前面的五組檢查點數字是教學補充，不是這個互動示範的執行結果。
''',EXTRA[10][1]+r'''
#### What mean squared error measures

The source sine example predicts continuous values with $L=\frac1N\sum_{n=1}^N(\hat y_n-t_n)^2$, where t is target, hat y prediction and N the number of examples in that split. Errors one and minus one give $L=(1^2+(-1)^2)/2=1$. Classification needs a threshold and an additional classification-error measure. The earlier five-checkpoint table is a teaching example, not an execution of the sine demo.
''')
EXTRA[11]=(EXTRA[11][0]+r'''
#### 不直接求二階導數時的數值檢查

只沿第i個權重改動小步長h，其他權重固定，可用中心差分估計

$$
H_{ii}\approx\frac{J(\mathbf w+h\mathbf e_i)-2J(\mathbf w)+J(\mathbf w-h\mathbf e_i)}{h^2}.
$$

$\mathbf e_i$ 是第i個座標為1、其餘為0的方向；h 是差分步長，不是刪除門檻。取 $J(w)=(w-0.5)^2$、目前w=0.5、h=0.1，三個代價為0.01、0、0.01，估得 $(0.01-2\times0+0.01)/0.01=2$，與解析二階導數一致。步長太大會有近似誤差，太小可能有浮點相消；不能把差分公式當成完全精確的黑盒。
''',EXTRA[11][1]+r'''
#### A finite-difference curvature check

Changing only weight i by step h while holding others fixed gives the central-difference estimate

$$
H_{ii}\approx\frac{J(\mathbf w+h\mathbf e_i)-2J(\mathbf w)+J(\mathbf w-h\mathbf e_i)}{h^2}.
$$

$\mathbf e_i$ has one in coordinate i and zeros elsewhere. Step h is not a deletion threshold. With $J(w)=(w-0.5)^2$, w=0.5 and h=0.1, the costs are 0.01, zero, 0.01. Thus $(0.01-2\times0+0.01)/0.01=2$, matching the analytic curvature. Large steps have approximation error; tiny steps can suffer cancellation. The difference formula is not an exact black box in general.
''')

for k,pages in PAGES.items():
 for li,lang in enumerate(['zh','en']):
  stem=f'lec05-kp{k:02}-{SLUG[k]}-{lang}';z=li==0
  fields=['一句話重點','白話說明','正式定義','例子','常見迷思','小練習'] if z else ['One-sentence summary','Plain explanation','Formal definition','Example','Common misconception','Practice']
  lines=[f'# KP{k:02} {TITLES[k][li]}','',('> 程度：大學三年級（undergrad）｜自主學習教材｜繁體中文版' if z else '> Level: third-year undergraduate | Self-study | English edition'),'',('本份可獨立閱讀；先備為加權計分、基本微分及矩陣。新術語會在使用時說明。' if z else 'Read this independently with weighted scores, basic differentiation and matrices as prerequisites. New terms are introduced when needed.'),'',f'[{"開啟同語言簡報" if z else "Open the matching slides"}](../slides/{stem}.html)','',f'## {"學習目標" if z else "Learning objectives"}','']
  lines += ['- '+v[li] for v in OBJECTIVES[k]]
  lines += ['',f'## KP{k:02} {TITLES[k][li]}','',f'**{fields[0]}**：'+({10:('大小、訓練時間與保留資料一起決定選模，不能只追訓練分數。','Select size and training duration using held-out evidence, not training fit alone.'),11:('先估刪除的代價，再以懲罰與驗證控制模型，數量不是唯一判準。','Estimate deletion cost and control the model through penalties and validation; count is not the only criterion.'),12:('共享重用同一規則，通常先得到等變的反應，再以適當讀出取得不變性。','Sharing reuses a rule, usually producing equivariant responses before a suitable readout yields invariance.')}[k][li]),'',f'**{fields[1]}**：'+GROUPS[k][0][3][li],'',f'**{fields[2]}**：'+('以下各段會逐一定義名詞、符號與成立條件；公式中的同一個量維持同一符號。' if z else 'The sections define terms, symbols and assumptions while keeping symbols consistent for the same quantity.'),'',f'**{fields[3]}**：'+('所有新增小算例均為［補充］，已用 Python 核對；來源實驗報告另行標示。' if z else 'All new worked examples are [Added] and checked in Python. Source experiment reports are identified separately.'),'',f'**{fields[4]}**：'+({10:('參數更少或訓練更久，並不各自保證新資料更準。','Fewer parameters and longer fitting do not independently guarantee better new-data performance.'),11:('小權重不必然不重要，平滑懲罰也不等於權重已經刪除。','A small weight need not be unimportant, and a smooth penalty is not deletion.'),12:('權重共享不會自動保證所有平移、旋轉或縮放下分類不變。','Sharing does not automatically guarantee invariance to every translation, rotation or scaling.')}[k][li]),'',f'**{fields[5]}**：'+('末段提供先做後核對的題目、提示及解題示範。' if z else 'The final section provides questions, hints and worked checks for use after your own attempt.'),'']
  used=set()
  for a,b,t,intro in GROUPS[k]:
   lines += [f'### {t[li]}','',intro[li],'']
   for p in pages[a-1:b]:
    for c in p['cards']:lines += [c['texts'][li],'']
    f=p['layout']
    if f not in ['flow','compare']:
     fid='lec05-kp'+f
     if fid not in used:
      used.add(fid);alt=__import__('build').FIGS[fid]['alt'] if z else ENALT[f]
      lines += [f'![{alt}](../assets/figures/{fid}.png)','',f'{"圖說" if z else "Figure"} `{fid}`：'+(('［補充］先看圖中的對照與標籤，再用本段數字核對；圖內的模型示意不代表實驗精確曲線。〔功能：精準度、具象化〕') if z else '[Added] Compare the labelled alternatives, then check them against the numerical discussion. Schematic model drawings are not exact experimental traces.'),'']
  lines += [EXTRA[k][li],'',f'## {"術語表與符號提醒" if z else "Glossary and symbol reminders"}','',('| 中文 | English |' if z else '| English | 中文 |'),'|---|---|']
  for p in pages:
   for c in p['cards']:
    if 'terms' in c:lines.append('| '+' | '.join(c['terms'] if z else list(reversed(c['terms'])))+' |')
  lines += ['',('依本段定義讀取符號，特別區分權重、分數、模型預測與損失；不同實驗的同名超參數不一定有相同用途。' if z else 'Read symbols by their local definitions. Distinguish weights, scores, predictions and loss; identically named hyperparameters in different experiments may have different roles.'),'',f'## {"來源與補充範圍" if z else "Sources and supplementary scope"}','',f'- [Chapter 4, KP{k}](https://ndhuccc.github.io/CCC-LNS/PR_115/Ch04-nonlinear-classifiers/index.html#kp{k})'+('，讀取日期：2026-10-25。' if z else ', accessed 2026-10-25.'),'- '+NOTES[k][li],'- '+({10:'Source reference code: [Mirc 89].',11:'Source reference codes: [Lecu 90], [Hass 93], [Wein 90], [Bart 98], [Fahl 90].',12:'Source reference codes: [Fuku 82], [Rume 86], [Fuku 92], [Lecu 89], [Ride 97].'}[k]),'- '+('來源原圖已檢視：KP10 Figure 4.14；KP11 Figure 4.15、4.16。本教材用自己的圖解講解，沒有把來源圖片或精確實驗曲線冒充新結果。' if z else 'Original Figures 4.14–4.16 were inspected. New teaching diagrams do not claim to be the original figures or exact experimental curves.'),'- '+('本文使用來源的歷史引用代碼，不宣稱已取得其所有原始論文；無法核對的完整定理與實驗細節均保留限制。' if z else 'Historical reference codes follow the source. Full papers, theorem conditions and experimental records were not all available; those limits are retained.'),'']
  dest=OUT/'lectures'/f'{stem}.md';dest.parent.mkdir(exist_ok=True);dest.write_text('\n'.join(lines))
print('six handouts written')
