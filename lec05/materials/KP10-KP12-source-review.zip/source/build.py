from pathlib import Path
import sys,json,datetime,math,copy,re,os
from content import DATA
from bridges import BRIDGES
from labels import LABELS,ENALT
ROOT=Path(os.environ.get('COURSE_ROOT',Path.cwd())).resolve();OUT=Path(os.environ.get('KP_BUILD',Path(__file__).resolve().parent/'build'));OUT.mkdir(exist_ok=True)
os.environ['DECK_WORK']=str(OUT)
sys.path.insert(0,str(ROOT/'.agents/skills/view-from-text/tools'));sys.path.insert(0,str(ROOT/'.agents/skills/view-from-text'))
from deckkit import kit as D
FIGS=json.loads((OUT/'figs.json').read_text());D.FIGS=FIGS
SLUG={10:'network-size',11:'pruning-regularization',12:'weight-sharing'}
SHORT={10:('大小與泛化','Size and fit'),11:('剪枝與正則化','Pruning'),12:('共享與不變性','Weight sharing')}
TITLES={10:('網路大小、泛化與早停','Network size, generalization and early stopping'),11:('剪枝、正則化與模擬實證','Pruning, regularization and reported simulations'),12:('權重共享與轉換不變性','Weight sharing and transformation invariance')}

def parse(text):
 pages=[];p=None
 for ln in text.strip().splitlines():
  if not ln.strip():continue
  tag=ln[0];data=ln[2:]
  if tag=='@':p={'titles':data.split(' || '),'cards':[]};pages.append(p)
  elif tag=='>':p['bridges']=data.split(' || ')
  elif tag in ('-','='):
   pair=data.split(' || ');assert len(pair)==2,ln
   c={'texts':pair}
   if tag=='=':
    terms=[];texts=[]
    for v in pair:
     term,desc=v.split(' :: ',1);terms.append(term);texts.append(f'**{term}**：{desc}' if len(terms)==1 else f'**{term}**: {desc}')
    c={'texts':texts,'terms':terms}
   p['cards'].append(c)
  elif tag=='!':p['coaches']=data.split(' || ')
  elif tag=='#':p['layout']=data
  else:raise ValueError(ln)
 return pages
PAGES={k:parse(v) for k,v in DATA.items()}

# Tailor native diagrams to the semantics rather than drawing arrows between arbitrary paragraphs.
PAGES[10][5]['cards']=[{'texts':['**訓練集**：用它更新權重，學到資料中的規律。','**Training data** fit weights to patterns.']},{'texts':['**驗證集**：用它選大小、懲罰強度及停止點，不直接更新權重。','**Validation data** select size, penalty strength and checkpoints without directly fitting weights.']},{'texts':['**測試集**：模型選完後才做最後評估。反覆看它挑模型，就不再是獨立檢查；也要避免重複個體或時間資訊洩漏。','**Test set**: reserve it for evaluation after model selection. Reusing it to choose models breaks independence; avoid duplicate-subject and temporal leakage.'],'terms':['測試集','Test set']}]
PAGES[10][9]['cards']=[{'texts':['**解析法**：用代數或統計分析估能力，但通常忽略具體的最佳化過程。','**Analytical methods** estimate capacity using algebra or statistics, often without optimization details.']},{'texts':['**剪枝**：先訓練較大網路，再依規則刪掉較不重要的連線。','**Pruning** fits a larger network, then removes less useful connections by a rule.']},{'texts':['**構造式方法**：從小架構逐步增加單元。三條路都需驗證；下一個KP先研究怎麼剪。','**Constructive methods** grow units from a small architecture. All routes need validation; the next KP studies pruning.']}]

for k, changes in BRIDGES.items():
 for idx, pair in changes.items():PAGES[k][idx-1]["bridges"]=list(pair)

def make(k,lang):
 li=0 if lang=='zh' else 1;D.PFX=f'lec05kp{k:02}{lang}';D.scenes.clear();D.nodes.clear();D.steps.clear()
 u=D.Unit('u01',SHORT[k][li],0,0);registry={};seq=PAGES[k]
 for i,p in enumerate(seq):
  title=p['titles'][li];ext=title.startswith(('延伸','Extension'));label=LABELS[k][lang][i]
  pg=D.Page(u,i,label,title,'')
  # Monolingual: replace the bilingual header with one measured two-line title and one bridge.
  sub=f'{D.PFX}-u01-p{i+1}-sub';D.nodes.pop(sub);D.scenes[u.sid]['nodeIds'].remove(sub)
  tn=D.nodes[f'{D.PFX}-u01-p{i+1}-title'];tn['height']=104;tn['style']['fontSize']=40;tn['style']['lineHeight']=1.2
  pg.card('bridge',60,140,1160,84,p['bridges'][li],size=22)
  layout='network' if k==10 and i==1 else 'compare' if k==11 and i==11 else 'loop' if k==11 and i==6 else 'branch' if (k==10 and i==9) or (k==12 and i==8) else p['layout'];ids=[];cols=[D.REF,D.MAIN,D.AUX]
  next_bridge=seq[i+1]['bridges'][li] if i+1<len(seq) else ('你能不用提示，重算一個例子並說出限制嗎？' if li==0 else 'Can you recompute an example and state its limits?')
  if li==0:
   chunks=[x for x in re.split('[。！]',next_bridge) if x.strip()]; question=chunks[-1]
  else:
   chunks=[x for x in re.split(r'(?<=[.!])\s+',next_bridge) if x.strip()];question=chunks[-1]

  # A visible question hands the story to the next page. Keep it away from the right-hand cards.
  qwidth=540 if layout not in ('flow','compare','loop','branch') else 1160
  pg.text(60,650,qwidth,62,question,size=22,color=D.MUTED,lh=1.25,nid=f'{D.PFX}-u01-p{i+1}-next-question')
  if layout=='branch':
   rootnode=pg.card('routes-root',350,242,580,76,('三種路線都要用保留資料檢查' if k==10 else '三種可選擇、也可互補的路線') if li==0 else ('All routes need held-out assessment' if k==10 else 'Three alternative or complementary routes'),size=25)
   for j,c in enumerate(p['cards']):
    nid=pg.card(f'card{j+1}',60+j*400,374,360,250,c['texts'][li],c=cols[j%3],size=23);ids.append(nid)
    pg.conn(rootnode,8,nid,0)
    if 'terms' in c:D.nodes[nid]['name']='term:'+c['terms'][li];registry[c['terms'][li]]={}
  elif layout=='loop':
   texts=(['訓練到合適位置','估計顯著度','選擇性刪除','再訓練與驗證'] if li==0 else ['Fit the model','Estimate saliency','Selective deletion','Retraining and validation'])
   for j,t in enumerate(texts):ids.append(pg.card(f'loop{j}',60+j*303,260,250,120,t,c=cols[j%3],size=24))
   for a,b in zip(ids,ids[1:]):pg.conn(a,4,b,12)
   back=pg.conn(ids[-1],8,ids[0],8);D.nodes[back]['connector']['curve']=True
   for j,c in enumerate(p['cards'][1:]):pg.card(f'card{j+2}',60,440+j*108,1160,90,c['texts'][li],c=cols[j%3],size=24)
  elif layout not in ('flow','compare'):
   if layout=='network':
    ins=[pg.text(85,y,80,70,f'$x_{j+1}$',size=27,shape=True,fill=D.role(D.REF)[0],stroke=D.REF,bw=2,radius=25,nid=f'{D.PFX}-u01-p{i+1}-input{j}') for j,y in enumerate([330,500])]
    hs=[pg.text(315,y,80,70,f'$h_{j+1}$',size=27,shape=True,fill=D.role(D.AUX)[0],stroke=D.AUX,bw=2,radius=25,nid=f'{D.PFX}-u01-p{i+1}-hidden{j}') for j,y in enumerate([260,410,560])]
    out=pg.text(515,410,80,70,r'$\hat y$',size=27,shape=True,fill=D.role(D.MAIN)[0],stroke=D.MAIN,bw=2,radius=25,nid=f'{D.PFX}-u01-p{i+1}-output')
    for a in ins:
     for b in hs:pg.conn(a,4,b,12)
    for a in hs:pg.conn(a,4,out,12)
   else:
    fid='lec05-kp'+layout; pg.figure(fid,60,250)
    if li==1:
     for nid in D.scenes[u.sid]['nodeIds']:
      n=D.nodes[nid]
      if n['type']=='image' and n['name']=='fig:'+fid:n['image']['alt']=ENALT[layout]
   # Give longer cards a proportional share. Browser verification can request an explicit split.
   weights=[]
   for c in p['cards']:
    t=c['texts'][li];plain=re.sub(r'\\[a-zA-Z]+|[${}*]','',t)
    weights.append(max(2,math.ceil(sum(1 if '\u3400'<=ch<='\u9fff' else .52 for ch in plain)/23)))
   avail=448-12*(len(weights)-1);heights=[int(avail*x/sum(weights)) for x in weights]
   if k==11 and i==17:heights=[128,140,156]
   yy=242
   for j,(c,h) in enumerate(zip(p['cards'],heights)):
    nid=pg.card(f'card{j+1}',640,yy,580,h,c['texts'][li],c=cols[j%3],size=22);ids.append(nid);yy+=h+12
    if 'terms' in c:D.nodes[nid]['name']='term:'+c['terms'][li];registry[c['terms'][li]]={}
  elif layout=='flow':
   n=len(p['cards']);gap=38;width=(1160-gap*(n-1))/n
   for j,c in enumerate(p['cards']):
    nid=pg.card(f'card{j+1}',60+j*(width+gap),268,width,365,c['texts'][li],c=cols[j%3],size=24);ids.append(nid)
    if 'terms' in c:D.nodes[nid]['name']='term:'+c['terms'][li];registry[c['terms'][li]]={}
   for a,b in zip(ids,ids[1:]):pg.conn(a,4,b,12)
  else:
   yy=247;n=len(p['cards']);h=(380-16*(n-1))/n
   for j,c in enumerate(p['cards']):
    if k==11 and i==16:h=[100,105,143][j]
    nid=pg.card(f'card{j+1}',60,yy,1160,h,c['texts'][li],c=cols[j%3],size=25);ids.append(nid);yy+=h+16
    if 'terms' in c:D.nodes[nid]['name']='term:'+c['terms'][li];registry[c['terms'][li]]={}
  previous=seq[i-1]['titles'][li] if i else ('自主學習的起點' if li==0 else 'Self-study entry')
  nxt=seq[i+1]['bridges'][li] if i+1<len(seq) else ('請回到本單元的練習，用自己的話說出條件與限制。' if li==0 else 'Return to the practice and state the assumptions in your own words.')
  notes=(f'上一頁的結果：{previous}。\n{p["coaches"][li]}\n接下來：{nxt}' if li==0 else f'Previous page: {previous}.\n{p["coaches"][li]}\nNext page: {nxt}')
  notes+=f'\nSource: Ch04 KP{k}, '+('4.9' if k==10 else '4.9–4.10' if k==11 else '4.11')+f'; focus {i+1}: {title}.'
  mirror=(k==10 and i+1 in [4,9]) or (k==11 and i+1 in [3,5,10,16,19]) or (k==12 and i+1 in [3,5,10,12,15])
  if mirror and layout not in ('flow','compare','branch','loop','network'):
   for nid in D.scenes[u.sid]['nodeIds']:
    n=D.nodes[nid]
    if n['transform']['x']//1440!=i:continue
    if n['type']=='image':n['transform']['x']=pg.ox+680
    elif n['name'].endswith('next-question'):n['transform']['x']=pg.ox+680
    elif n['transform']['x']==pg.ox+640:n['transform']['x']=pg.ox+60
  pg.step(notes)
 doc=D.assemble([u],f'PR Chapter 4 KP{k:02} — {TITLES[k][li]}',[],{'x':200,'y':100,'zoom':1,'rotation':0})
 now=datetime.datetime.now(datetime.timezone.utc).isoformat();doc['metadata'].update(createdAt=now,updatedAt=now)
 doc['steps'][0]['speakerNotes']=('教材程度：大學三年級（undergrad）。用途：自主學習，未排入270分鐘課堂。' if li==0 else 'Level: third-year undergraduate. Intended for self-study outside the 270-minute class.')
 stem=f'lec05-kp{k:02}-{SLUG[k]}-{lang}'
 (OUT/'slides').mkdir(exist_ok=True);(OUT/'slides'/f'{stem}.jbd.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2))
 (OUT/'plans').mkdir(exist_ok=True);(OUT/'plans'/f'{stem}-terms.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2))
 return stem
if __name__=='__main__':
 for k in PAGES:
  for lang in ['zh','en']:print(make(k,lang),'pages',len(PAGES[k]))
 (OUT/'plans/storyboards.json').write_text(json.dumps(PAGES,ensure_ascii=False,indent=2))
