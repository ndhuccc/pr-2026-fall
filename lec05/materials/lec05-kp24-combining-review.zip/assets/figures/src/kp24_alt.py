ALT = {
 "comp": ("三個分類器在月牙形資料上：logistic 85.2%、樹 82.6%、3-NN 87.8%；3-NN 的錯誤有 60% 被另一個分類器答對，三者多數決 86.2%。", "Three classifiers on half-moon data: logistic 85.2%, tree 82.6% and 3-NN 87.8%; 60% of the 3-NN errors are right for another classifier and the vote of the three gets 86.2%."),
 "prod": ("乘積規則：後驗是各分類器後驗的幾何平均；三個分類器的例子乘積為 0.336 對 0.024。", "The product rule: the posterior is the geometric mean of the classifier posteriors; in the three-classifier example the products are 0.336 against 0.024."),
 "sum": ("加總規則：把 KL 兩個引數對調，後驗是算術平均；同一例子平均 0.70 對 0.30。", "The sum rule: swapping the KL arguments gives the arithmetic mean; the same example gives 0.70 against 0.30."),
 "veto": ("五個分類器的後驗：四個給正確類 0.7，一個給 0.001；乘積選錯（0.00024 對 0.00809），加總選對（0.5602 對 0.4398）。", "Posteriors of five classifiers: four give the correct class 0.7 and one gives 0.001; the product chooses wrongly (0.00024 against 0.00809) and the sum rightly (0.5602 against 0.4398)."),
 "vote": ("獨立分類器多數投票的正確率對 L：p=0.6 升向 1，p=0.45 降向 0，p=0.5 維持 0.5。", "Majority-vote accuracy of independent classifiers against L: rising towards 1 for p=0.6, falling towards 0 for p=0.45 and staying at 0.5 for p=0.5."),
 "indep": ("25 棵 bagging 樹：單棵 83.8%，獨立公式 99.99%，實際多數投票 87.7%，V=0.095。", "25 bagged trees: a single tree 83.8%, the independence formula 99.99%, the real majority vote 87.7% and V=0.095."),
 "div": ("10 維資料上三種組合法的投票準確率與 V：bootstrap 77.9%、0.197；隨機特徵子集 75.9%、0.241；5 種分類器 82.1%、0.114。", "Vote accuracy and V of three ensemble types on 10-D data: bootstrap 77.9% with 0.197, random feature subsets 75.9% with 0.241 and 5 classifiers 82.1% with 0.114."),
 "bayes": ("貝氏觀點又導出乘積規則；乘積對估計誤差很敏感，加總較耐誤差，多數投票簡單穩健；沒有一種規則永遠最好。", "The Bayesian view gives the product rule again; the product is very sensitive to estimation errors, the sum tolerates them better and the majority vote is simple and robust; no rule is always best."),
 "median": ("五個輸出 0.80、0.85、0.75、0.01、0.01：加總與乘積選錯，中位數選對。", "Five outputs 0.80, 0.85, 0.75, 0.01 and 0.01: the sum and the product choose wrongly and the median rightly."),
 "practice": ("練習圖：每個分類器答對的機率 0.7，求 L=3 與 L=5 的多數投票正確率。", "Practice figure: every classifier is right with probability 0.7; find the majority-vote accuracy for L=3 and L=5."),
 "practice-sol": ("L=3：0.784；L=5：0.837。", "L=3: 0.784; L=5: 0.837."),
}
