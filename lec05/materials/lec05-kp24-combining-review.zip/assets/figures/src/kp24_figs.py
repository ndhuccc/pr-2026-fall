import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums24 as N
from nums24 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
Xtr, ytr = moons2(100, 1, 0.35); Xte, yte = moons2(1000, 2, 0.35)

def f_comp():
    fig, ax = blank(540, 440)
    cl = {"logistic": LogisticRegression(), "tree (depth 4)": DecisionTreeClassifier(max_depth=4, random_state=0), "3-NN": KNeighborsClassifier(3)}
    pr = {k: m.fit(Xtr, ytr).predict(Xte) for k, m in cl.items()}; acc = {k: float((v == yte).mean()) for k, v in pr.items()}
    T(ax, 270, 25, "three classifiers on 2000 new points (noisy half-moons)", TXT, 16)
    for i, (k, a) in enumerate(acc.items()):
        y = 80 + i * 48; T(ax, 12, y, k, A_C if k == "3-NN" else TXT, 16, True, "left"); T(ax, 330, y, f"{a*100:.1f}%", GRN if k == "3-NN" else TXT, 20)
    best = "3-NN"; wrong = pr[best] != yte; other = np.zeros(len(yte), bool)
    for k, v in pr.items():
        if k != best: other |= (v == yte)
    share = float((wrong & other).sum() / wrong.sum())
    allp = np.array(list(pr.values())); vote = ((allp.mean(0) > 0.5).astype(int) == yte).mean()
    T(ax, 270, 245, f"3-NN is wrong on {wrong.mean()*100:.1f}% of the points", TXT, 18)
    T(ax, 270, 290, f"on {share*100:.0f}% of those another classifier is right", RED, 19)
    T(ax, 270, 345, f"majority vote of the three: {vote*100:.1f}%", TXT, 18)
    T(ax, 270, 385, "still below the best single classifier", RED, 17)
    T(ax, 270, 420, "complementary information must be mined, not just present", MUT, 15, False)
    save(fig, "lec05-kp24-comp"); return acc, share, float(vote)

def f_prod():
    fig, ax = blank(540, 420)
    T(ax, 270, 28, "minimize the average KL distance Σⱼ D(P ‖ Pⱼ)", TXT, 17)
    T(ax, 270, 80, "P(ωᵢ|x) = (1/C) Πⱼ Pⱼ(ωᵢ|x)^(1/L)", RED, 20)
    T(ax, 270, 125, "rule: pick the class with the largest Πⱼ Pⱼ(ωᵢ|x)", GRN, 17)
    P = np.array([[0.8, 0.2], [0.6, 0.4], [0.7, 0.3]]); pr, sm = prod_sum(P)
    T(ax, 270, 190, "example: three classifiers, two classes", MUT, 15, False)
    for i, r in enumerate(P): T(ax, 270, 230 + i * 34, f"P{i+1} = ({r[0]}, {r[1]})", TXT, 17)
    T(ax, 270, 350, f"products: {pr[0]:.3f} for ω₁ against {pr[1]:.3f} for ω₂", GRN, 18)
    T(ax, 270, 392, "all products share the same 1/L power", MUT, 15, False)
    save(fig, "lec05-kp24-prod"); return pr.tolist()

def f_sum():
    fig, ax = blank(540, 420)
    T(ax, 270, 28, "swap the two arguments of the KL distance", TXT, 17)
    T(ax, 270, 75, "Dⱼ = Σᵢ Pⱼ(ωᵢ|x) ln [ Pⱼ(ωᵢ|x) / P(ωᵢ|x) ]", MUT, 16, False)
    T(ax, 270, 135, "P(ωᵢ|x) = (1/L) Σⱼ Pⱼ(ωᵢ|x)", RED, 21)
    T(ax, 270, 180, "the arithmetic mean: the sum rule", GRN, 17)
    P = np.array([[0.8, 0.2], [0.6, 0.4], [0.7, 0.3]]); pr, sm = prod_sum(P)
    T(ax, 270, 245, "same three classifiers as the product example", MUT, 15, False)
    T(ax, 270, 290, f"sums / 3: {sm[0]:.2f} for ω₁ against {sm[1]:.2f} for ω₂", GRN, 19)
    T(ax, 270, 345, "both rules choose ω₁ here", TXT, 17)
    T(ax, 270, 385, "two natural rules, two different derivations", MUT, 15, False)
    save(fig, "lec05-kp24-sum")

def f_veto():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 230); axstyle(ax)
    P = np.array([[0.7, 0.3]] * 4 + [[0.001, 0.999]]); x = np.arange(5)
    ax.bar(x - 0.2, P[:, 0], 0.4, color=GRN, label="correct class ω₁"); ax.bar(x + 0.2, P[:, 1], 0.4, color=RED, label="wrong class ω₂")
    ax.set_xticks(x); ax.set_xticklabels([f"C{i+1}" for i in range(5)], fontsize=fpx(16)); ax.set_ylim(0, 1.25); ax.legend(fontsize=fpx(13), frameon=False, labelcolor=TXT, loc="upper left", ncol=2)
    pr, sm = prod_sum(P)
    cap(fig, h, [(305, f"product: ω₁ {pr[0]:.5f} against ω₂ {pr[1]:.5f}  →  wrong", RED, 16, True), (340, f"sum: ω₁ {sm[0]:.4f} against ω₂ {sm[1]:.4f}  →  right", GRN, 16, True), (374, "majority vote: 4 of 5 right", GRN, 16, True), (412, "one near-zero output vetoes the product", MUT, 16, False)])
    save(fig, "lec05-kp24-veto"); return pr.tolist(), sm.tolist()

def f_vote():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    Ls = np.arange(1, 52, 2)
    for p, c in ((0.6, GRN), (0.55, A_C), (0.45, RED)): ax.plot(Ls, [Pc(L, p) for L in Ls], color=c, lw=3, label=f"p = {p}")
    ax.axhline(0.5, color=MUT, lw=1.2, ls="--"); ax.set_ylim(0, 1.02); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper left"); ax.set_xlabel("number of classifiers L (odd)", color=TXT, fontsize=fpx(15)); ax.set_ylabel("majority-vote accuracy", color=TXT, fontsize=fpx(14))
    cap(fig, h, [(352, "independent classifiers, each right with probability p", TXT, 16, True), (386, "p = 0.6: 0.648 (L=3), 0.754 (L=11), 0.927 (L=51)", GRN, 16, True), (420, "p = 0.45: falls towards 0; p = 0.5: stays 0.5", RED, 16, True)])
    save(fig, "lec05-kp24-vote")

def f_indep():
    fig, ax = blank(540, 440)
    S = []
    for s in range(20):
        X, y = moons2(100, 100 + s, 0.35); bg = BaggingClassifier(DecisionTreeClassifier(criterion="entropy"), n_estimators=25, random_state=0).fit(X, y)
        ind = np.array([e.predict(Xte) for e in bg.estimators_]); pind = (ind == yte).mean(1); vt = (ind.mean(0) > 0.5).astype(int); S.append((pind.mean(), (vt == yte).mean(), Pc(25, pind.mean()), vdiv(ind)))
    S = np.array(S).mean(0)
    T(ax, 270, 28, "25 bagged trees, 20 training sets, 2000 new points", TXT, 16)
    rows = [("a single tree", S[0], TXT), ("independence formula P_c(25, p)", S[2], RED), ("the real majority vote", S[1], GRN)]
    for i, (n, v, c) in enumerate(rows):
        y = 100 + i * 70; T(ax, 12, y, n, c, 16, True, "left"); T(ax, 450, y, f"{v*100:.2f}%" if v > 0.99 else f"{v*100:.1f}%", c, 22)
    T(ax, 270, 330, "the trees are trained on resamples of the same data,", TXT, 16)
    T(ax, 270, 362, "so their mistakes are strongly shared", RED, 17)
    T(ax, 270, 405, f"disagreement with the majority V = {S[3]:.3f}", MUT, 16, False)
    save(fig, "lec05-kp24-indep"); return S.round(4).tolist()

def f_div():
    fig, ax = blank(540, 440)
    def data(n, seed):
        r = np.random.default_rng(seed); y = r.integers(0, 2, n); X = r.normal(0, 1, (n, 10)) + y[:, None] * 0.9 * np.ones(10)[None, :] * (np.arange(10)[None, :] % 2 == 0); return X, y
    res = {"bootstrap": [], "subspace": [], "types": []}; V = {k: [] for k in res}; single = []
    for s in range(15):
        X, y = data(150, 200 + s); Xt, yt = data(2000, 999)
        P1 = np.array([DecisionTreeClassifier(max_depth=3, random_state=i).fit(X[np.random.default_rng(s * 100 + i).integers(0, 150, 150)], y[np.random.default_rng(s * 100 + i).integers(0, 150, 150)]).predict(Xt) for i in range(11)])
        res["bootstrap"].append(((P1.mean(0) > .5) == yt).mean()); V["bootstrap"].append(vdiv(P1)); single.append((P1 == yt).mean())
        P2 = []
        for i in range(11):
            f = np.random.default_rng(s * 100 + i).choice(10, 4, replace=False); P2.append(DecisionTreeClassifier(max_depth=3, random_state=i).fit(X[:, f], y).predict(Xt[:, f]))
        P2 = np.array(P2); res["subspace"].append(((P2.mean(0) > .5) == yt).mean()); V["subspace"].append(vdiv(P2))
        ms = [LogisticRegression(max_iter=500), DecisionTreeClassifier(max_depth=3, random_state=0), KNeighborsClassifier(5), KNeighborsClassifier(15), DecisionTreeClassifier(max_depth=5, random_state=1)]
        P3 = np.array([m.fit(X, y).predict(Xt) for m in ms]); res["types"].append(((P3.mean(0) > .5) == yt).mean()); V["types"].append(vdiv(P3))
    T(ax, 270, 25, "10-D data, 150 training points, vote of 11 / 11 / 5 members", TXT, 15)
    for x, tx in zip((130, 340, 450), ("ensemble", "vote accuracy", "V")): T(ax, x, 62, tx, MUT, 14, False)
    names = {"bootstrap": "bootstrap trees", "subspace": "random feature subsets", "types": "5 different classifiers"}
    for i, k in enumerate(res):
        y = 115 + i * 55; T(ax, 12, y, names[k], TXT, 15, True, "left"); T(ax, 340, y, f"{np.mean(res[k])*100:.1f} ± {np.std(res[k])*100:.1f}", GRN if k == "types" else TXT, 19); T(ax, 450, y, f"{np.mean(V[k]):.3f}", MUT, 18)
    T(ax, 270, 305, f"one tree alone: {np.mean(single)*100:.1f}%", TXT, 17)
    T(ax, 270, 345, "V = share of member decisions that differ from the majority", MUT, 15, False)
    T(ax, 270, 385, "the most diverse ensemble is not the most accurate", RED, 17)
    save(fig, "lec05-kp24-div"); return {k: (round(float(np.mean(res[k])), 4), round(float(np.std(res[k])), 4), round(float(np.mean(V[k])), 3)) for k in res}, round(float(np.mean(single)), 4)

def f_bayes():
    fig, ax = blank(540, 440)
    T(ax, 270, 28, "independent x₁ … x_L, Bayes rule:", TXT, 16)
    T(ax, 270, 75, "max_k  P(ωₖ)^(1−L) Πⱼ P(ωₖ|xⱼ)", RED, 21)
    T(ax, 270, 120, "the product rule again, with a Bayesian blessing", GRN, 16)
    for i, (n, d, c) in enumerate((("product", "very sensitive to estimation errors", RED), ("sum", "tolerates errors better, often wins", GRN), ("majority vote", "simple, robust, widely used", A_C))):
        y = 190 + i * 55; T(ax, 12, y, n, c, 16, True, "left"); T(ax, 175, y, d, TXT, 15, True, "left")
    T(ax, 270, 375, "no rule is best in every case (handwritten digits)", MUT, 15, False)
    T(ax, 270, 410, "no panacea: a bad combination always exists", MUT, 15, False)
    save(fig, "lec05-kp24-bayes")

def f_median():
    fig, ax = blank(540, 420)
    P1 = np.array([0.8, 0.85, 0.75, 0.01, 0.01]); T(ax, 270, 28, "P(ω₁|x) from 5 classifiers; the other class gets 1 − P", TXT, 15)
    T(ax, 270, 72, "0.80   0.85   0.75   0.01   0.01", TXT, 21)
    T(ax, 270, 112, "two classifiers are far off", MUT, 15, False)
    rows = [("sum (mean)", f"ω₁ {P1.mean():.3f} against ω₂ {1-P1.mean():.3f}", "→ ω₂, wrong", RED), ("median", f"ω₁ {np.median(P1):.2f} against ω₂ {1-np.median(P1):.2f}", "→ ω₁, right", GRN), ("product", f"ω₁ {np.prod(P1):.1e} against ω₂ {np.prod(1-P1):.1e}", "→ ω₂, wrong", RED)]
    for i, (n, v, d, c) in enumerate(rows):
        y = 175 + i * 62; T(ax, 12, y - 14, n, c, 16, True, "left"); T(ax, 270, y + 12, v + "   " + d, c, 15)
    T(ax, 270, 385, "the median ignores the extreme values", GRN, 17)
    save(fig, "lec05-kp24-median")

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "L classifiers, each right with probability p = 0.7", TXT, 19)
    T(ax, 270, 90, "independent decisions, majority vote (L odd)", TXT, 17)
    T(ax, 270, 160, "question 1: accuracy of the vote for L = 3", RED, 18)
    T(ax, 270, 210, "question 2: accuracy of the vote for L = 5", RED, 18)
    T(ax, 270, 270, "P_c(L) = Σ_{m=l_c}^{L} C(L,m) pᵐ (1−p)^(L−m)", MUT, 16, False)
    save(fig, "lec05-kp24-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("L = 3: l_c = 2", TXT), ("3·0.7²·0.3 + 0.7³ = 0.441 + 0.343 = 0.784", GRN), ("L = 5: l_c = 3", TXT), ("10·0.7³·0.3² + 5·0.7⁴·0.3 + 0.7⁵", GRN), ("= 0.3087 + 0.36015 + 0.16807 = 0.837", GRN), ("0.7 → 0.784 → 0.837 under independence", RED)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 16)
    save(fig, "lec05-kp24-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
