Pattern Recognition, Chapter 4, KP25: Boosting and AdaBoost: turning weak into strong (English version)

Slides: slides/lec05-kp25-adaboost-en.html (offline web page, open in a browser); slides/lec05-kp25-adaboost-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp25-adaboost-en-lecture.pdf (PDF), lec05-kp25-adaboost-en-reading.html (offline web page), lectures/lec05-kp25-adaboost-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
