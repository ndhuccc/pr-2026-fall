Pattern Recognition, Chapter 4, KP02: Two-layer perceptron (English version)

Slides: slides/lec05-kp02-two-layer-perceptron-en.html (offline web page, open in a browser); slides/lec05-kp02-two-layer-perceptron-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp02-two-layer-perceptron-en-lecture.pdf (PDF), lec05-kp02-two-layer-perceptron-en-reading.html (offline web page), lectures/lec05-kp02-two-layer-perceptron-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
