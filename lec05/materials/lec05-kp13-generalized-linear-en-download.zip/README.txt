Pattern Recognition, Chapter 4, KP13: Generalized linear classifiers (English version)

Slides: slides/lec05-kp13-generalized-linear-en.html (offline web page, open in a browser); slides/lec05-kp13-generalized-linear-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp13-generalized-linear-en-lecture.pdf (PDF), lec05-kp13-generalized-linear-en-reading.html (offline web page), lectures/lec05-kp13-generalized-linear-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
