import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums26 as N
from nums26 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
Xt2, yt2 = make(5000, 100, 2.0, 998)
def fitrun(kind, s, clf="svm", ratio=5.0):
    X, y = make(1000, 20, 2.0, s)
    if kind == "over": X, y = oversample(X, y, s)
    if kind == "under": X, y = undersample(X, y, s)
    if kind == "focus": X, y = focused_under2(X, y, s, ratio)
    kw = {"class_weight": "balanced"} if kind == "cost" else {}
    m = SVC(kernel="rbf", gamma=0.5, C=1.0, **kw) if clf == "svm" else DecisionTreeClassifier(min_samples_leaf=5, random_state=0, **kw)
    return metrics(yt2, m.fit(X, y).predict(Xt2))
_C = {}
def res(kind, clf="svm", ratio=5.0):
    k = (kind, clf, ratio)
    if k not in _C: _C[k] = avg(lambda s: fitrun(kind, s, clf, ratio))
    return _C[k]
def bal(r): return (r["rec"] + 1 - r["fp"] / 5000) / 2

def f_trap():
    fig, ax = blank(540, 440)
    p = res("plain"); allneg = 5000 / 5100
    T(ax, 270, 25, "train 1000 vs 20, test 5000 vs 100 (20 runs)", TXT, 16)
    for x, tx in zip((200, 330, 450), ("accuracy", "recall", "precision")): T(ax, x, 70, tx, MUT, 14, False)
    rows = [("always say majority", allneg, 0.0, None, RED), ("standard SVM", p["acc"], p["rec"], p["prec"], A_C)]
    for i, (n, a, r, pr, c) in enumerate(rows):
        y = 125 + i * 70; T(ax, 12, y, n, c, 16, True, "left"); T(ax, 200, y + 28, f"{a*100:.1f}%", TXT, 20); T(ax, 330, y + 28, f"{r*100:.1f}%", RED if r < 0.1 else TXT, 20); T(ax, 450, y + 28, "—" if pr is None else f"{pr*100:.1f}%", TXT, 20)
    T(ax, 270, 305, f"the SVM catches {p['tp']:.2f} of the 100 rare points on average", RED, 16)
    T(ax, 270, 345, f"with {p['fp']:.0f} false alarms", MUT, 15, False)
    T(ax, 270, 395, "accuracy is almost no better than doing nothing", RED, 17)
    save(fig, "lec05-kp26-trap"); return p

def f_simple():
    w, h = 540, 440; fig = new_fig(w, h); a1 = panel(fig, w, h, 65, 35, 190, 215); a2 = panel(fig, w, h, 315, 35, 190, 215)
    for a in (a1, a2): axstyle(a)
    Cs = [0.01, 0.1, 1, 10, 100]; rc = []
    for C in Cs: rc.append(avg(lambda s: metrics(yt2, SVC(kernel="rbf", gamma=0.5, C=C).fit(*make(1000, 20, 2.0, s)).predict(Xt2)), 10)["rec"])
    a1.plot(range(5), rc, "o-", color=RED, lw=2.8, ms=8); a1.set_xticks(range(5)); a1.set_xticklabels(["0.01", "0.1", "1", "10", "100"], fontsize=fpx(13)); a1.set_ylim(0, 0.4); a1.set_xlabel("SVM C", color=TXT, fontsize=fpx(14)); a1.set_ylabel("minority recall", color=TXT, fontsize=fpx(14))
    Ls = [1, 5, 20, 50]; rl = []
    for L in Ls: rl.append(avg(lambda s: metrics(yt2, DecisionTreeClassifier(min_samples_leaf=L, random_state=0).fit(*make(1000, 20, 2.0, s)).predict(Xt2)), 10)["rec"])
    a2.plot(range(4), rl, "o-", color=A_C, lw=2.8, ms=8); a2.set_xticks(range(4)); a2.set_xticklabels([str(l) for l in Ls], fontsize=fpx(13)); a2.set_ylim(0, 0.4); a2.set_xlabel("tree: minimum points per leaf", color=TXT, fontsize=fpx(13))
    cap(fig, h, [(315, "the simpler the classifier, the less it cares about 20 points", TXT, 16, True), (352, "SVM recall: " + ", ".join(f"{v*100:.0f}" for v in rc) + " (%)", RED, 15, True), (386, "tree recall: " + ", ".join(f"{v*100:.0f}" for v in rl) + " (%)", A_C, 15, True), (420, "accuracy stays about 98% throughout", MUT, 15, False)])
    save(fig, "lec05-kp26-simple"); return [round(float(v), 3) for v in rc], [round(float(v), 3) for v in rl]

def f_grid():
    fig, ax = blank(540, 440)
    T(ax, 270, 22, "minority recall of an RBF SVM (balanced test set)", TXT, 15)
    for x, tx in zip((120, 300, 440), ("majority : minority", "easy task", "hard task")): T(ax, x, 62, tx, MUT, 14, False)
    out = []
    for i, (nmaj, nmin) in enumerate(((100, 100), (1000, 100), (1000, 10), (10000, 100), (10000, 10))):
        y = 112 + i * 52; T(ax, 120, y, f"{nmaj} : {nmin}", TXT, 17); row = []
        for x, d in ((300, 4.0), (440, 1.5)):
            Xe, ye = make(2000, 2000, d, 997); v = avg(lambda s: metrics(ye, SVC(kernel="rbf", gamma=0.5, C=1.0).fit(*make(nmaj, nmin, d, s)).predict(Xe)), 8)["rec"]; row.append(round(float(v), 3)); T(ax, x, y, f"{v*100:.1f}%", GRN if v > 0.85 else (RED if v < 0.3 else TXT), 19)
        out.append(row)
    T(ax, 270, 395, "easy: class means 4 apart;  hard: 1.5 apart (unit variance)", MUT, 15, False)
    T(ax, 270, 425, "the count of rare points matters as much as the ratio", RED, 15)
    save(fig, "lec05-kp26-grid"); return out

def f_data():
    fig, ax = blank(540, 440)
    T(ax, 270, 22, "SVM, train 1000 vs 20, test 5000 vs 100", TXT, 15)
    for x, tx in zip((130, 255, 340, 420, 505), ("", "recall", "precision", "false alarms", "")): 
        if tx: T(ax, x, 60, tx, MUT, 13, False)
    for i, (k, n) in enumerate((("plain", "plain"), ("over", "oversample"), ("under", "undersample"))):
        r = res(k); y = 115 + i * 62; T(ax, 12, y, n, [TXT, A_C, GRN][i], 16, True, "left"); T(ax, 255, y, f"{r['rec']*100:.1f}%", GRN if r['rec'] > 0.5 else RED, 19); T(ax, 340, y, f"{r['prec']*100:.1f}%", TXT, 18); T(ax, 440, y, f"{r['fp']:.0f}", TXT, 18)
    T(ax, 270, 330, "oversample: copy the 20 rare points up to 1000", MUT, 15, False); T(ax, 270, 362, "undersample: keep 20 random majority points", MUT, 15, False)
    T(ax, 270, 405, "rare points found, but the false alarms explode", RED, 17)
    save(fig, "lec05-kp26-data")

def f_focus():
    fig, ax = blank(540, 440)
    T(ax, 270, 22, "keep only the majority points nearest the boundary", TXT, 15)
    for x, tx in zip((100, 220, 330, 450), ("kept", "recall", "accuracy", "false alarms")): T(ax, x, 62, tx, MUT, 13, False)
    out = []
    for i, ratio in enumerate((1, 3, 5, 10)):
        r = res("focus", "svm", float(ratio)); y = 112 + i * 52; out.append((ratio * 20, round(r["rec"], 3), round(r["acc"], 3)))
        T(ax, 100, y, f"{ratio*20}", TXT, 18); T(ax, 220, y, f"{r['rec']*100:.1f}%", GRN if r["rec"] > 0.5 else RED, 19); T(ax, 330, y, f"{r['acc']*100:.1f}%", TXT, 18); T(ax, 450, y, f"{r['fp']:.0f}", TXT, 18)
    T(ax, 270, 340, "kept 20: finds 83% but accuracy falls to 58%", RED, 16)
    T(ax, 270, 372, "kept 60: back to 11% recall", RED, 16)
    T(ax, 270, 412, "how many to keep is a hard, open question", MUT, 15, False)
    save(fig, "lec05-kp26-focus"); return out

def f_cost():
    fig, ax = blank(540, 440)
    r = res("cost")
    T(ax, 270, 22, "cost-sensitive: change the classifier, not the data", TXT, 15)
    T(ax, 270, 70, "SVM: rare class gets C 50 times larger (balanced)", A_C, 16)
    T(ax, 270, 115, f"recall {r['rec']*100:.1f}%, precision {r['prec']*100:.1f}%, false alarms {r['fp']:.0f}", GRN, 17)
    T(ax, 270, 175, "AdaBoost (100 stumps): rare class initial weight ×w", B_C, 16)
    for x, tx in zip((130, 270, 410), ("×w", "recall", "precision")): T(ax, x, 215, tx, MUT, 13, False)
    out = []
    for i, wgt in enumerate((1, 10, 50)):
        def ada(s, wgt=wgt):
            X, y = make(1000, 20, 2.0, s); sw = np.where(y == 1, wgt, 1.0); m = AdaBoostClassifier(DecisionTreeClassifier(max_depth=1), n_estimators=100, random_state=0).fit(X, y, sample_weight=sw / sw.sum()); return metrics(yt2, m.predict(Xt2))
        a = avg(ada, 10); out.append((wgt, round(a["rec"], 3), round(a["prec"], 3))); y = 255 + i * 45
        T(ax, 130, y, f"{wgt}", TXT, 19); T(ax, 270, y, f"{a['rec']*100:.1f}%", GRN if a["rec"] > 0.4 else RED, 19); T(ax, 410, y, f"{a['prec']*100:.1f}%", TXT, 19)
    T(ax, 270, 410, "a heavier rare class raises recall and lowers precision", RED, 15)
    save(fig, "lec05-kp26-cost"); return out

def f_table():
    fig, ax = blank(540, 440)
    for x, tx in zip((150, 255, 345, 440), ("", "recall", "precision", "accuracy")): 
        if tx: T(ax, x, 30, tx, MUT, 13, False)
    T(ax, 12, 62, "SVM", A_C, 15, True, "left")
    rows = [("plain", "plain"), ("over", "oversample"), ("under", "undersample"), ("cost", "cost-sensitive")]
    for i, (k, n) in enumerate(rows):
        r = res(k); y = 95 + i * 36; T(ax, 12, y, n, TXT, 14, False, "left"); T(ax, 255, y, f"{r['rec']*100:.1f}%", TXT, 16); T(ax, 345, y, f"{r['prec']*100:.1f}%", TXT, 16); T(ax, 440, y, f"{r['acc']*100:.1f}%", TXT, 16)
    T(ax, 12, 255, "decision tree (min 5 per leaf)", B_C, 15, True, "left")
    for i, (k, n) in enumerate(rows):
        r = res(k, "tree"); y = 288 + i * 36; T(ax, 12, y, n, TXT, 14, False, "left"); T(ax, 255, y, f"{r['rec']*100:.1f}%", TXT, 16); T(ax, 345, y, f"{r['prec']*100:.1f}%", TXT, 16); T(ax, 440, y, f"{r['acc']*100:.1f}%", TXT, 16)
    T(ax, 270, 440 - 12, "recall up, precision and accuracy down: no free lunch", RED, 15)
    save(fig, "lec05-kp26-table")

def f_recap():
    fig, ax = blank(540, 440)
    T(ax, 270, 40, "harm = simplicity preference × a rare class", RED, 20)
    T(ax, 270, 85, "not the difference in counts alone", MUT, 15, False)
    T(ax, 270, 150, "two families of cures", TXT, 18)
    T(ax, 270, 200, "change the data: over / under sampling", A_C, 17); T(ax, 270, 235, "(random or focused near the boundary)", MUT, 14, False)
    T(ax, 270, 285, "change the cost: heavier rare class", B_C, 17); T(ax, 270, 320, "(SVM C, AdaBoost weights)", MUT, 14, False)
    T(ax, 270, 380, "judge by recall and precision, not accuracy alone", GRN, 16)
    T(ax, 270, 415, "the right class ratio is an open problem", MUT, 15, False)
    save(fig, "lec05-kp26-recap")

def f_bal():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    names = [("always majority", 0.5, TXT), ("SVM plain", bal(res("plain")), MUT), ("oversample", bal(res("over")), A_C), ("undersample", bal(res("under")), GRN), ("cost-sensitive", bal(res("cost")), B_C)]
    for i, (n, v, c) in enumerate(names): ax.bar(i, v, color=c, width=0.6); ax.text(i, v + 0.015, f"{v:.2f}", color=TXT, fontsize=fpx(15), ha="center", fontweight="bold")
    ax.set_xticks(range(5)); ax.set_xticklabels(["always\nmajority", "SVM\nplain", "over-\nsample", "under-\nsample", "cost-\nsensitive"], fontsize=fpx(13)); ax.set_ylim(0, 1); ax.axhline(0.5, color=MUT, lw=1, ls="--")
    cap(fig, h, [(345, "balanced accuracy = (recall + specificity) / 2", TXT, 16, True), (380, "always saying majority scores exactly 0.50", MUT, 16, False), (414, "plain SVM 0.53; the three remedies about 0.78 to 0.81", GRN, 16, True)])
    save(fig, "lec05-kp26-bal"); return [round(float(v[1]), 3) for v in names]

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "1000 negatives and 10 positives", TXT, 19)
    T(ax, 270, 90, "A: says negative for everyone", TXT, 17); T(ax, 270, 130, "B: catches 6 of the 10 positives, 40 false alarms", TXT, 17)
    T(ax, 270, 195, "question 1: accuracy and recall of A and B", RED, 17); T(ax, 270, 240, "question 2: balanced accuracy of A and B", RED, 17)
    T(ax, 270, 290, "balanced accuracy = (recall + TN/(TN+FP)) / 2", MUT, 15, False)
    save(fig, "lec05-kp26-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("A: TP 0, FN 10, FP 0, TN 1000", TXT), ("accuracy 1000/1010 = 0.990, recall 0, balanced 0.5", GRN), ("B: TP 6, FN 4, FP 40, TN 960", TXT), ("accuracy 966/1010 = 0.956, recall 0.6", GRN), ("specificity 960/1000 = 0.96, balanced 0.78", GRN), ("A has the higher accuracy and is useless", RED)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 16)
    save(fig, "lec05-kp26-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
