import numpy as np
from nums26 import *
Xt2, yt2 = make(5000, 100, 2.0, 998)
def r(kind, s, ratio=1.0):
    X, y = make(1000, 20, 2.0, s)
    if kind == "focus": X, y = focused_under2(X, y, s, ratio)
    if kind == "under": X, y = undersample(X, y, s)
    if kind == "plain": pass
    return metrics(yt2, SVC(kernel="rbf", gamma=0.5, C=1.0).fit(X, y).predict(Xt2))
for ratio in (1, 3, 5, 10, 25):
    a = avg(lambda s: r("focus", s, ratio)); print("focus keep", ratio, "x minority", {k: round(v, 3) for k, v in a.items()}, "spec", round(1 - a["fp"] / 5000, 3))
a = avg(lambda s: r("under", s)); print("random under", {k: round(v, 3) for k, v in a.items()}, "spec", round(1 - a["fp"] / 5000, 3))
a = avg(lambda s: r("plain", s)); print("plain", {k: round(v, 3) for k, v in a.items()}, "spec", round(1 - a["fp"] / 5000, 3))
