ALT = {
 "trap": ("1000 對 20 的資料：全判多數準確率 98.0%、召回 0；一般 SVM 準確率 98.1%、召回 5.9%、精確率 56.5%。", "Data of 1000 against 20: always the majority has accuracy 98.0% and recall 0; a standard SVM has accuracy 98.1%, recall 5.9% and precision 56.5%."),
 "simple": ("越簡單的分類器越不在乎稀有類：SVM 的 C 由 0.01 增到 100 召回由 0 升到 16.6%；決策樹每片葉最少點數由 1 增到 50 召回由 25.0% 降到 0%。", "The simpler the classifier the less it cares about the rare class: SVM recall rises from 0 to 16.6% as C goes from 0.01 to 100, and tree recall falls from 25.0% to 0% as the minimum points per leaf go from 1 to 50."),
 "grid": ("少數類召回：簡單任務 100:100 為 97.4%、1000:10 為 65.3%；困難任務 1000:100 為 14.9%，其餘不平衡組為 0%。", "Rare-class recall: on the easy task 97.4% at 100:100 and 65.3% at 1000:10; on the hard task 14.9% at 1000:100 and 0% for the other imbalanced settings."),
 "data": ("資料層對策：一般 SVM 召回 5.9%、誤報 2；過採樣 68.2%、606；欠採樣 77.0%、757。", "Data-level cures: a plain SVM has recall 5.9% and 2 false alarms; oversampling 68.2% and 606; undersampling 77.0% and 757."),
 "focus": ("聚焦欠採樣留下的多數點數：20、60、100、200 個時召回為 82.7%、11.4%、8.3%、6.0%。", "Focused undersampling with 20, 60, 100 and 200 majority points kept: recall 82.7%, 11.4%, 8.3% and 6.0%."),
 "cost": ("代價敏感：SVM 少數類 C 設 50 倍，召回 70.2%、精確率 10.6%；AdaBoost 少數類初始權重 ×1、×10、×50，召回 19.0%、48.1%、60.1%。", "Cost-sensitive: the SVM with a 50 times larger rare-class C has recall 70.2% and precision 10.6%; AdaBoost with rare-class initial weights ×1, ×10 and ×50 has recall 19.0%, 48.1% and 60.1%."),
 "table": ("SVM 與決策樹四種處理的召回、精確率與準確率表：召回升、精確率與準確率降。", "Table of recall, precision and accuracy for four treatments of an SVM and a decision tree: recall rises while precision and accuracy fall."),
 "recap": ("類別不平衡的重點：傷害來自簡單性偏好乘稀有類；兩類對策是改資料或改代價；要看召回與精確率。", "The key points of class imbalance: the harm comes from the simplicity preference times the rare class; the two cures are changing the data or the cost; look at recall and precision."),
 "bal": ("平衡準確率：全判多數 0.50、一般 SVM 0.53、過採樣 0.78、欠採樣 0.81、代價敏感 0.79。", "Balanced accuracy: always the majority 0.50, plain SVM 0.53, oversampling 0.78, undersampling 0.81 and cost-sensitive 0.79."),
 "practice": ("練習圖：1000 個負例與 10 個正例；A 全判負，B 抓到 6 個並誤報 40 個。", "Practice figure: 1000 negatives and 10 positives; A says negative for everyone and B catches 6 with 40 false alarms."),
 "practice-sol": ("A：準確率 0.990、召回 0、平衡準確率 0.5；B：準確率 0.956、召回 0.6、平衡準確率 0.78。", "A: accuracy 0.990, recall 0 and balanced accuracy 0.5; B: accuracy 0.956, recall 0.6 and balanced accuracy 0.78."),
}
