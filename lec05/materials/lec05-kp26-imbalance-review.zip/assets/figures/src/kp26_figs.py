import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums26 as N
from nums26 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
import json
R = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "calc26.json")))
def rec(r): return r["tp"] / 100
def prec(r): return r["tp"] / (r["tp"] + r["fp"]) if r["tp"] + r["fp"] > 0 else None
def acc(r): return (r["tp"] + r["tn"]) / 5100
def balv(r): return (rec(r) + r["tn"] / 5000) / 2
def pc(v, d=1):
    from decimal import Decimal, ROUND_HALF_UP
    if v is None: return "—"
    return f"{Decimal(str(round(v * 100, 6))).quantize(Decimal(1).scaleb(-d), rounding=ROUND_HALF_UP)}%"
def n2(v): return f"{v:.2f}".rstrip("0").rstrip(".") if abs(v - round(v)) > 1e-9 else f"{int(round(v))}"
def hdr(ax, xs, ts, y=62, fs=13):
    for x, t in zip(xs, ts):
        if t: T(ax, x, y, t, MUT, fs, False)

def f_setup():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 55, 15, 430, 225); axstyle(ax)
    X, y = make(1000, 20, 2.0, 0)
    ax.scatter(X[y == 0, 0], X[y == 0, 1], s=9, color=A_C, alpha=0.45, label="majority (1000)")
    ax.scatter(X[y == 1, 0], X[y == 1, 1], s=46, color=B_C, edgecolor="white", linewidth=0.8, label="minority (20)")
    ax.plot([0], [0], "k+", ms=14, mew=2.4, color=TXT); ax.plot([2], [0], "k+", ms=14, mew=2.4, color=TXT)
    ax.text(0, -3.7, "mean (0, 0)", color=TXT, fontsize=fpx(13), ha="center"); ax.text(2.4, -3.3, "mean (2, 0)", color=B_C, fontsize=fpx(13), ha="left")
    ax.set_xlim(-4, 6); ax.set_ylim(-4.2, 4.2); ax.set_xlabel("x1", color=TXT, fontsize=fpx(14)); ax.set_ylabel("x2", color=TXT, fontsize=fpx(14))
    ax.legend(loc="upper right", fontsize=fpx(13), frameon=False, labelcolor=TXT)
    cap(fig, h, [(320, "train: 1000 ~ N((0,0), I)  and  20 ~ N((2,0), I)", TXT, 15, True), (350, "test (one fixed set): 5000 + 100 from the same two", TXT, 15, False), (380, "repeat with training seeds 0 to 19, average the counts", MUT, 15, False), (410, "RBF SVM: exp(-0.5 |x-z|^2), C = 1", A_C, 15, True)])
    save(fig, "lec05-kp26-setup")

def f_metrics():
    fig, ax = blank(540, 440); p = R["plain_svm"]
    T(ax, 270, 22, "test: 5000 majority + 100 rare;  TP = rare caught,  FP = false alarms", TXT, 14)
    T(ax, 270, 55, "recall = TP/100    precision = TP/(TP+FP)", A_C, 15); T(ax, 270, 83, "accuracy = (TP + 5000 - FP)/5100", A_C, 15)
    T(ax, 12, 130, "always say majority:  TP 0,  FP 0", RED, 16, True, "left")
    T(ax, 28, 163, "recall 0/100 = 0%", TXT, 15, False, "left"); T(ax, 28, 191, "accuracy (0 + 5000)/5100 = 98.0%", TXT, 15, False, "left")
    T(ax, 12, 238, f"standard SVM (mean of 20 runs):  TP {n2(p['tp'])},  FP {n2(p['fp'])}", GRN, 16, True, "left")
    T(ax, 28, 271, f"recall {n2(p['tp'])}/100 = {pc(rec(p))}", TXT, 15, False, "left")
    T(ax, 28, 299, f"precision {n2(p['tp'])}/({n2(p['tp'])}+{n2(p['fp'])}) = {pc(prec(p))}", TXT, 15, False, "left")
    T(ax, 28, 327, f"accuracy ({n2(p['tp'])} + {n2(5000-p['fp'])})/5100 = {pc(acc(p))}", TXT, 15, False, "left")
    T(ax, 270, 378, "98.0% vs 98.1%: the 100 rare points are only 2% of the test,", RED, 15); T(ax, 270, 408, "so accuracy can hardly see them", RED, 15)
    save(fig, "lec05-kp26-metrics")

def trow(ax, y, cells, xs, colors=None, fs=16, bold=False):
    for i, (x, t) in enumerate(zip(xs, cells)): T(ax, x, y, t, (colors or [TXT] * len(xs))[i], fs, bold)

def f_simple():
    fig, ax = blank(540, 440)
    xs = (95, 195, 275, 365, 465)
    T(ax, 12, 22, "SVM, larger C = less regularization", A_C, 15, True, "left"); hdr(ax, xs, ("C", "TP", "FP", "recall", "accuracy"), 52)
    for i, C in enumerate(("0.01", "0.1", "1", "10", "100")):
        r = R["C"][C]; trow(ax, 82 + i * 30, (C, n2(r["tp"]), n2(r["fp"]), pc(rec(r)), pc(acc(r))), xs, [TXT, TXT, TXT, GRN if rec(r) > 0.1 else RED, TXT], 16)
    T(ax, 12, 245, "decision tree, larger leaf = simpler", B_C, 15, True, "left"); hdr(ax, xs, ("min leaf", "TP", "FP", "recall", "accuracy"), 273)
    for i, L in enumerate(("1", "5", "20", "50")):
        r = R["leaf"][L]; trow(ax, 305 + i * 30, (L, n2(r["tp"]), n2(r["fp"]), pc(rec(r)), pc(acc(r))), xs, [TXT, TXT, TXT, GRN if rec(r) > 0.1 else RED, TXT], 16)
    T(ax, 270, 422, "means of 20 runs; recall = TP/100; accuracy stays near 98%", MUT, 13, False)
    save(fig, "lec05-kp26-simple")

def f_grid():
    fig, ax = blank(540, 440)
    T(ax, 270, 20, "rare-class recall = TP/2000 on a fixed test set of 2000 + 2000", TXT, 14)
    hdr(ax, (95, 285, 435), ("majority : rare", "easy (means 4 apart)", "hard (1.5 apart)"), 55, 13)
    for i, (maj, mn) in enumerate(((100, 100), (1000, 100), (1000, 10), (10000, 100), (10000, 10))):
        y = 105 + i * 58; T(ax, 95, y, f"{maj} : {mn}", TXT, 17)
        for x, nm in ((285, "easy"), (435, "hard")):
            r = R["grid"][f"{nm}-{maj}:{mn}"]; v = rec(r) / 20
            T(ax, x, y - 9, pc(r["tp"] / 2000), GRN if r["tp"] / 2000 > 0.85 else (RED if r["tp"] / 2000 < 0.3 else TXT), 19); T(ax, x, y + 15, f"TP {n2(r['tp'])} / 2000", MUT, 12, False)
    T(ax, 270, 400, "RBF SVM, C = 1, gamma = 0.5; means of 20 runs", MUT, 14, False)
    T(ax, 270, 425, "the count of rare points matters as much as the ratio", RED, 14)
    save(fig, "lec05-kp26-grid")

def f_data():
    fig, ax = blank(540, 440)
    xs = (88, 188, 252, 318, 392, 462, 515)
    T(ax, 270, 22, "SVM (RBF, C = 1); test 5000 + 100; means of 20 runs", TXT, 14)
    hdr(ax, (90, 215, 285, 365, 445, 510), ("", "TP", "FP", "recall", "precision", "acc."), 56, 13)
    rows = (("plain", "plain", "train 1000 + 20"), ("over", "oversample", "train 1000 + 1000"), ("under", "undersample", "train 20 + 20"))
    for i, (k, n, tr) in enumerate(rows):
        r = R["plain_svm" if k == "plain" else k + "_svm"]; y = 112 + i * 70
        T(ax, 10, y - 10, n, [TXT, A_C, GRN][i], 16, True, "left"); T(ax, 10, y + 14, tr, MUT, 12, False, "left")
        for x, t in zip((215, 285, 365, 445, 510), (n2(r["tp"]), n2(r["fp"]), pc(rec(r)), pc(prec(r)), pc(acc(r)))): T(ax, x, y, t, TXT, 15)
    T(ax, 270, 330, "oversample: copy the 20 rare points, with replacement, up to 1000", MUT, 13, False); T(ax, 270, 358, "undersample: keep 20 of the 1000 majority points at random", MUT, 13, False)
    T(ax, 270, 400, "FP 2 -> over 600: caught more, but far more false alarms", RED, 15)
    save(fig, "lec05-kp26-data")

def f_focus():
    fig, ax = blank(540, 440)
    T(ax, 270, 22, "first SVM scores the majority; keep the highest scores", TXT, 14)
    hdr(ax, (60, 140, 220, 300, 380, 470), ("kept", "train", "TP", "FP", "recall", "accuracy"), 56, 13)
    for i, (key, kept) in enumerate((("1", 20), ("3", 60), ("5", 100), ("10", 200))):
        r = R["focus"][key]; y = 105 + i * 50
        for x, t, c in zip((60, 140, 220, 300, 380, 470), (str(kept), f"{kept}+20", n2(r["tp"]), n2(r["fp"]), pc(rec(r)), pc(acc(r))), (TXT, MUT, TXT, TXT, GRN if rec(r) > 0.5 else RED, TXT)): T(ax, x, y, t, c, 16)
    r = R["plain_svm"]
    for x, t in zip((60, 140, 220, 300, 380, 470), ("1000", "1000+20", n2(r["tp"]), n2(r["fp"]), pc(rec(r)), pc(acc(r)))): T(ax, x, 305, t, MUT, 15, False)
    T(ax, 270, 340, "last row: keep all 1000 = the plain SVM", MUT, 13, False)
    T(ax, 270, 375, "kept 20: TP 83 but FP 2126 and accuracy 58%", RED, 15); T(ax, 270, 405, "kept 60: back down to TP 11. How many to keep?", RED, 15)
    save(fig, "lec05-kp26-focus")

def f_cost():
    fig, ax = blank(540, 440)
    hdr(ax, (140, 235, 320, 405, 490), ("", "TP", "FP", "recall", "precision"), 50, 13)
    T(ax, 12, 24, "SVM: class weights (C of each class)", A_C, 14, True, "left")
    for i, (n, r) in enumerate((("plain  1 : 1", R["plain_svm"]), ("rare 50x  1 : 50", R["cost_svm"]))):
        y = 90 + i * 40; T(ax, 12, y, n, TXT, 14, False, "left")
        for x, t in zip((235, 320, 405, 490), (n2(r["tp"]), n2(r["fp"]), pc(rec(r)), pc(prec(r)))): T(ax, x, y, t, TXT, 16)
    T(ax, 12, 190, "AdaBoost, 100 stumps: rare initial weight x w", B_C, 14, True, "left")
    for i, wv in enumerate(("1", "10", "50")):
        r = R["ada"][wv]; y = 232 + i * 40; T(ax, 12, y, f"w = {wv}", TXT, 14, False, "left")
        for x, t in zip((235, 320, 405, 490), (n2(r["tp"]), n2(r["fp"]), pc(rec(r)), pc(prec(r)))): T(ax, x, y, t, TXT, 16)
    T(ax, 270, 385, "heavier rare class: TP up, FP up, precision down", RED, 15); T(ax, 270, 413, "means of 20 runs; test 5000 + 100", MUT, 13, False)
    save(fig, "lec05-kp26-cost")

def f_table():
    fig, ax = blank(540, 440)
    xs = (205, 258, 320, 385, 450, 510)
    hdr(ax, xs, ("TP", "FP", "recall", "prec.", "acc.", "bal."), 22, 13)
    T(ax, 8, 50, "SVM", A_C, 14, True, "left")
    rows = (("plain", "plain"), ("over", "oversample"), ("under", "undersample"), ("cost", "cost-sensitive"))
    def put(y0, suffix, label):
        for i, (k, n) in enumerate(rows):
            r = R[("plain" if k == "plain" else k) + "_" + suffix]; y = y0 + i * 34
            T(ax, 8, y, n, TXT, 13, False, "left")
            for x, t in zip(xs, (n2(r["tp"]), n2(r["fp"]), pc(rec(r), 0), pc(prec(r), 0), pc(acc(r), 0), f"{balv(r):.2f}")): T(ax, x, y, t, TXT, 14)
    put(80, "svm", "SVM")
    T(ax, 8, 240, "decision tree (min leaf 5)", B_C, 14, True, "left"); put(270, "tree", "tree")
    T(ax, 8, 420, "bal. = (recall + TN/5000)/2;  always majority: bal. 0.50", MUT, 13, False, "left")
    save(fig, "lec05-kp26-table")

def f_recap():
    fig, ax = blank(540, 440)
    T(ax, 270, 40, "harm = simplicity preference × a rare class", RED, 20)
    T(ax, 270, 85, "not the difference in counts alone", MUT, 15, False)
    T(ax, 270, 150, "two families of cures", TXT, 18)
    T(ax, 270, 200, "change the data: over / under sampling", A_C, 17); T(ax, 270, 235, "(random or focused near the boundary)", MUT, 14, False)
    T(ax, 270, 285, "change the cost: heavier rare class", B_C, 17); T(ax, 270, 320, "(SVM C, AdaBoost weights)", MUT, 14, False)
    T(ax, 270, 380, "judge by recall and precision, not accuracy alone", GRN, 16)
    T(ax, 270, 415, "the right class ratio is an open problem", MUT, 15, False)
    save(fig, "lec05-kp26-recap")

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "1000 negatives and 10 positives", TXT, 19)
    T(ax, 270, 90, "A: says negative for everyone", TXT, 17); T(ax, 270, 130, "B: catches 6 of the 10 positives, 40 false alarms", TXT, 17)
    T(ax, 270, 195, "question 1: accuracy and recall of A and B", RED, 17); T(ax, 270, 240, "question 2: balanced accuracy of A and B", RED, 17)
    T(ax, 270, 290, "balanced accuracy = (recall + TN/(TN+FP)) / 2", MUT, 15, False)
    save(fig, "lec05-kp26-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("A: TP 0, FN 10, FP 0, TN 1000", TXT), ("accuracy 1000/1010 = 0.990, recall 0, balanced 0.5", GRN), ("B: TP 6, FN 4, FP 40, TN 960", TXT), ("accuracy 966/1010 = 0.956, recall 0.6", GRN), ("specificity 960/1000 = 0.96, balanced 0.78", GRN), ("A has the higher accuracy and is useless", RED)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 16)
    save(fig, "lec05-kp26-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
