import sys,re; sys.path.insert(0,'.')
import kp26_text as T, kp26_alt as A
figs=["setup","metrics","simple","grid","data","focus","cost","recap","table","practice","practice-sol"]
def build(L):
    zh=(L=="zh"); k=0 if zh else 1
    o=[]
    if zh:
        o+=["# KP26 類別不平衡問題","","> 程度：大學三年級","> ","> 圖型識別｜第四章 §4.23","","[簡報閱讀與下載](../slides/lec05-kp26-imbalance-zh.html)","","## 學習目標","","- 能說明類別不平衡為什麼會損害分類器，以及為什麼準確率會騙人。","- 能說出資料層與代價敏感兩類對策，並比較它們的取捨。","- 能由抓到的稀有點數（TP）與誤報數（FP）算出召回、精確率、準確率與平衡準確率，並能驗算表上的數字。","","## KP26 類別不平衡問題","","**一句話重點**：一類有一萬筆、另一類只有十筆時，「追求簡單」的分類器會理所當然地忽略稀有類，而稀有類往往正是我們真正在乎的那一類。",""]
    else:
        o+=["# KP26 The Class Imbalance Problem","","> Level: undergraduate, year 3","> ","> Pattern Recognition | Chapter 4, §4.23","","[Slides: read and download](../slides/lec05-kp26-imbalance-en.html)","","## Learning objectives","","- Explain why class imbalance harms classifiers and why accuracy can deceive.","- Name the data-level and the cost-sensitive cures and compare their trade-offs.","- Compute recall, precision, accuracy and balanced accuracy from the rare points caught (TP) and the false alarms (FP), and check the numbers in a table.","","## KP26 The Class Imbalance Problem","","**One-sentence summary**: When one class has ten thousand samples and another only ten, a classifier that \"seeks simplicity\" naturally ignores the rare class, which is often the very class we care about.",""]
    n=0; extdone=False
    for i,p in enumerate(T.PAGES):
        lab=p["lab"][k]; ext=lab.startswith("延伸") or lab.startswith("Extension")
        if ext:
            if not extdone:
                o+=["### 延伸：對策比較、平衡準確率與練習" if zh else "### Extension: comparing the cures, balanced accuracy and practice",""]; extdone=True
            o+=[f"**{lab.split(':',1)[-1].strip() if ':' in lab else lab}**",""]
        else:
            n+=1; o+=[f"### {n}. {lab}",""]
        o+=[("**白話說明**：" if zh else "**Plain explanation**: ")+p["bridge"][k],""]
        for c in p["cards"]:
            t=c[1+k]
            o+=[("- "+t) if c[0].startswith("term:") else t,""]
        alt=A.ALT[figs[i]][k] if figs[i] in A.ALT else ""
        nm="lec05-kp26-"+figs[i]
        o+=[("圖說 `%s`：%s"%(nm,alt)) if zh else ("Figure `%s`: %s"%(nm,alt)),"",f"![{lab}](../assets/figures/{nm}.png)",""]
    if zh:
        o+=["## 術語與來源","","| 中文 | English |","|---|---|","| 類別不平衡 | Class imbalance |","| 召回率 | Recall |","","來源：第四章 KP26，§4.23（2026-10-25 讀取）。類別不平衡損害分類器、傷害來自簡單性偏好與稀有類的交互作用、要與任務難度和資料量一起看、資料層與代價敏感兩類對策、聚焦重抽樣、目標分布是未解問題、「怎麼記」依來源；實驗設定、指標的計數算式、$C$ 與葉大小掃描、難度與資料量表、各種對策的比較、平衡準確率與練習由本講義設計並用程式重算（［補充］，（程式計算）），資料生成式、參數、種子與重複次數見第 1 頁，計數算式見第 2 頁。",""]
    else:
        o+=["## Terms and source","","| 中文 | English |","|---|---|","| 類別不平衡 | Class imbalance |","| 召回率 | Recall |","","Source: Chapter 4, KP26, §4.23 (read 2026-10-25). That class imbalance harms classifiers, that the harm comes from the interaction of the simplicity preference with the rare class, that it must be read with task difficulty and data size, the data-level and cost-sensitive cures, focused resampling, the open problem of the target distribution and the 'to remember' line follow the source; the experiment setup, the count formulas of the measures, the sweeps of $C$ and leaf size, the difficulty and data-size table, the comparison of the cures, balanced accuracy and the practice were designed and recomputed for this lecture ([added], (program-computed)); the data generator, parameters, seeds and repeats are on page 1 and the count formulas on page 2.",""]
    t="\n".join(o)
    D={"zh":"**實驗細節**（可重現）：以 Python 的 scikit-learn 實作（SVC、DecisionTreeClassifier、AdaBoostClassifier，版本 1.9.1 預設值，除下列者）。第 1 至 3、5 至 7 頁的測試集是固定的 5000＋100（亂數種子 998），訓練集用種子 0 至 19；過採樣、欠採樣的抽樣沿用該訓練種子。第 4 頁的測試集固定 2000＋2000（種子 997），訓練集同樣用種子 0 至 19、共 20 次，兩類中心只在 $x_1$ 軸相差 4 或 1.5。決策樹為 CART（基尼不純度，亂數種子 0）；AdaBoost 以深度 1 的決策樁為弱分類器、100 輪、學習率 1。SVM 的類別權重取 $n/(2n_c)$：稀有類 $1020/(2\\times 20)=25.5$、多數類 $1020/(2\\times 1000)=0.51$，比值 50。平均計數是 20 次整數計數的平均，所以會有小數（例如 5.85＝117／20）。第 4 頁各格的 TP（共 2000 個稀有測試點）：簡單任務 1950.9、1831.8、1335.1、1561.1、863.8；困難任務 1571.65、298、0.35、0.65、0。",
       "en":"**Experiment details** (reproducible): implemented with scikit-learn in Python (SVC, DecisionTreeClassifier, AdaBoostClassifier, version 1.9.1 defaults except as listed). On pages 1 to 3 and 5 to 7 the test set is fixed at 5000 + 100 (random seed 998) and the training sets use seeds 0 to 19; the sampling of oversampling and undersampling reuses the training seed. On page 4 the test set is fixed at 2000 + 2000 (seed 997) and the training sets again use seeds 0 to 19, 20 runs, with the class centres differing only along the $x_1$ axis by 4 or 1.5. The tree is CART (Gini impurity, random seed 0); AdaBoost uses depth-1 decision stumps, 100 rounds and learning rate 1. The SVM class weights are $n/(2n_c)$: rare $1020/(2\\times 20)=25.5$, majority $1020/(2\\times 1000)=0.51$, a ratio of 50. A mean count is the mean of 20 integer counts, so it can have decimals (for example 5.85 = 117 / 20). TP in each cell of page 4 (of 2000 rare test points): easy task 1950.9, 1831.8, 1335.1, 1561.1, 863.8; hard task 1571.65, 298, 0.35, 0.65, 0."}[L]
    t=t.replace("\n### 2.", "\n"+D+"\n\n### 2.",1) if zh else t.replace("\n### 2.", "\n"+D+"\n\n### 2.",1)
    M={"zh":[("**SVM**（20 次平均計數）：","**例子**（SVM，20 次平均計數）："),("**平衡準確率** $=","**正式定義**：平衡準確率 $="),("**評估**：看抓到","**常見迷思**：以為準確率高就夠了。評估要看抓到"),("**設定**：1000 個負例","**小練習**（設定）：1000 個負例")],
       "en":[("**SVM** (mean of 20 runs):","**Example** (SVM, mean of 20 runs):"),("**Balanced accuracy** $=","**Formal definition**: balanced accuracy $="),("**Evaluation**: look at","**Common misconception**: a high accuracy is enough. Evaluate by looking at"),("**Setup**: 1000 negatives","**Practice** (setup): 1000 negatives")]}[L]
    for a,b in M:
        assert a in t,(L,a); t=t.replace(a,b,1)
    return t
for L in ("zh","en"):
    open(f"lectures/lec05-kp26-imbalance-{L}.md","w",encoding="utf8").write(build(L))
