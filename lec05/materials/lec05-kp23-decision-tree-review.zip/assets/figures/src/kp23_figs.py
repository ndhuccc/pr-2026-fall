import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums23 as N
from nums23 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
Xtr, ytr = moons2(100, 1); Xte, yte = moons2(1000, 2)

def f_partition():
    fig, ax = blank(540, 440)
    ax.add_patch(plt.Rectangle((40, 40), 210, 230, fc="none", ec=TXT, lw=2.2))
    ax.plot([40, 250], [155, 155], color=TXT, lw=2.4); ax.plot([124, 124], [155, 270], color=TXT, lw=2.4)
    for (x, y, t, c) in ((145, 98, "A", A_C), (82, 212, "B", B_C), (187, 212, "C", GRN)): T(ax, x, y, t, c, 26)
    T(ax, 28, 155, "0.5", MUT, 13); T(ax, 124, 285, "0.4", MUT, 13); T(ax, 145, 300, "x₁", MUT, 15); T(ax, 14, 40, "x₂", MUT, 15)
    def box(x, y, t, c=TXT): ax.add_patch(plt.Rectangle((x - 55, y - 20), 110, 40, fc="none", ec=c, lw=2.2)); T(ax, x, y, t, c, 15)
    box(400, 70, "x₂ > 0.5 ?"); box(340, 170, "x₁ ≤ 0.4 ?"); box(465, 170, "leaf A", A_C); box(300, 270, "leaf B", B_C); box(420, 270, "leaf C", GRN)
    for (a_, b_) in (((400, 90), (340, 150)), ((400, 90), (465, 150)), ((340, 190), (300, 250)), ((340, 190), (420, 250))): ax.plot([a_[0], b_[0]], [a_[1], b_[1]], color=MUT, lw=2)
    T(ax, 355, 115, "no", MUT, 13, False); T(ax, 450, 115, "yes", MUT, 13, False); T(ax, 305, 215, "yes", MUT, 13, False); T(ax, 395, 215, "no", MUT, 13, False)
    T(ax, 270, 345, "each question tests one feature against a threshold", TXT, 17)
    T(ax, 270, 385, "so every cut is parallel to a coordinate axis", GRN, 17)
    T(ax, 270, 420, "(OBCT: ordinary binary classification tree)", MUT, 15, False)
    save(fig, "lec05-kp23-partition")

def f_cands():
    fig, ax = blank(540, 380)
    xs = np.array([1.0, 1.4, 2.2, 2.8, 3.5, 4.1, 5.0, 5.5, 6.2, 7.0]); sx = lambda v: 30 + (v - 1) / 6 * 480
    ax.plot([30, 510], [150, 150], color=MUT, lw=2)
    for v in xs: ax.plot([sx(v)], [150], "o", color=A_C, ms=11)
    mids = (xs[1:] + xs[:-1]) / 2
    for m in mids: ax.plot([sx(m), sx(m)], [118, 182], color=GRN, lw=2.4)
    T(ax, 270, 40, "one feature, 10 distinct training values", TXT, 18); T(ax, 270, 85, "thresholds = midpoints of neighbouring values", GRN, 16)
    T(ax, 270, 230, f"{len(mids)} candidate questions for this feature", RED, 21)
    T(ax, 270, 285, "in general at most N_tk − 1 per feature", TXT, 16)
    T(ax, 270, 325, "a finite list instead of infinitely many thresholds", MUT, 16, False)
    save(fig, "lec05-kp23-cands"); return len(mids)

def f_entropy():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 250, 235); axstyle(ax)
    p = np.linspace(0.001, 0.999, 300); ax.plot(p, -(p * np.log2(p) + (1 - p) * np.log2(1 - p)), color=RED, lw=3); ax.plot([0.5], [1], "o", color=RED, ms=10); ax.set_xlabel("P of class 1 (two-class curve)", color=TXT, fontsize=fpx(13)); ax.set_ylabel("entropy", color=TXT, fontsize=fpx(14)); ax.set_ylim(0, 1.15)
    ax.text(0.5, 1.07, "most impure", color=TXT, fontsize=fpx(13), ha="center")
    a2 = panel(fig, w, h, 345, 20, 175, 235); a2.axis("off"); a2.set_xlim(0, 175); a2.set_ylim(235, 0)
    for i, (c, col) in enumerate((([4, 4, 2], TXT), ([1, 1, 1], TXT), ([5, 0, 0], GRN))):
        y = 45 + i * 70; a2.text(5, y - 18, str(tuple(c)), color=MUT, fontsize=fpx(15), fontweight="bold"); a2.text(5, y + 12, f"I = {abs(H(c)):.3f}", color=col, fontsize=fpx(19), fontweight="bold")
    cap(fig, h, [(322, "I(t) = −Σ P(ωᵢ|t) log₂ P(ωᵢ|t)", TXT, 17, True), (358, "maximal when all classes are equal, zero when pure", MUT, 16, False), (394, "(4, 4, 2): 1.522;  (1, 1, 1): log₂3 = 1.585", RED, 17, True), (424, "the book prints 1.521 for (4, 4, 2)", MUT, 14, False)])
    save(fig, "lec05-kp23-entropy")

def f_ex42():
    fig, ax = blank(540, 440)
    T(ax, 270, 25, "Example 4.2: parent (ω₁, ω₂, ω₃) = (4, 4, 2)", TXT, 16)
    rows = [("node", "counts", "I", "recomputed", "book"), ("t", "(4, 4, 2)", f"{H([4,4,2]):.3f}", "", "1.521"), ("t_Y", "(3, 1, 0)", f"{H([3,1,0]):.3f}", "", "0.815"), ("t_N", "(1, 3, 2)", f"{H([1,3,2]):.3f}", "", "1.472")]
    xs = [45, 150, 270, 0, 450]
    for j, hd in enumerate(("node", "counts", "I (recomputed)", "", "book")):
        if hd: T(ax, [45, 150, 290, 0, 470][j], 65, hd, MUT, 13, False)
    for i, (n, c, v, _, b) in enumerate(rows[1:]):
        y = 110 + i * 45; T(ax, 45, y, n, TXT, 17); T(ax, 150, y, c, TXT, 17); T(ax, 290, y, v, GRN, 20); T(ax, 470, y, b, RED if b != "1.521" else MUT, 17)
    d = dI([4, 4, 2], [3, 1, 0], [1, 3, 2])
    T(ax, 270, 275, f"ΔI = {H([4,4,2]):.3f} − (4/10)·{H([3,1,0]):.3f} − (6/10)·{H([1,3,2]):.3f}", TXT, 16)
    T(ax, 270, 320, f"= {d:.3f}", GRN, 26)
    T(ax, 270, 372, "the book prints 0.315 (and 1.472 for t_N)", RED, 16)
    T(ax, 270, 405, "recomputed from its own counts: 0.322", RED, 16)
    save(fig, "lec05-kp23-ex42"); return d

def f_weight():
    fig, ax = blank(540, 440)
    T(ax, 270, 25, "parent: 5 of class 1 and 5 of class 2, I = 1", TXT, 16)
    for x, tx in zip((130, 285, 420), ("split", "weighted ΔI", "unweighted")): T(ax, x, 65, tx, MUT, 14, False)
    A = (dI([5, 5], [1, 0], [4, 5]), H([5, 5]) - (H([1, 0]) + H([4, 5])) / 2); B = (dI([5, 5], [4, 1], [1, 4]), H([5, 5]) - (H([4, 1]) + H([1, 4])) / 2)
    T(ax, 130, 120, "A: one pure point", A_C, 15); T(ax, 130, 145, "(1, 0) | (4, 5)", MUT, 14, False); T(ax, 285, 132, f"{A[0]:.3f}", GRN, 22); T(ax, 420, 132, f"{A[1]:.3f}", RED, 22)
    T(ax, 130, 215, "B: balanced", B_C, 15); T(ax, 130, 240, "(4, 1) | (1, 4)", MUT, 14, False); T(ax, 285, 227, f"{B[0]:.3f}", GRN, 22); T(ax, 420, 227, f"{B[1]:.3f}", RED, 22)
    T(ax, 270, 300, "weighted by N_tY/N_t: B wins (0.278 > 0.108)", GRN, 16)
    T(ax, 270, 338, "unweighted average: A wins (0.504 > 0.278), a bad choice", RED, 16)
    T(ax, 270, 385, "making one tiny child pure is worth little", TXT, 16)
    save(fig, "lec05-kp23-weight"); return A, B

def f_depth():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    ds = [1, 2, 3, 4, 6, 8, 12]; tr, te, lv = [], [], []
    for d in ds:
        t = DecisionTreeClassifier(criterion="entropy", max_depth=d, random_state=0).fit(Xtr, ytr); tr.append(t.score(Xtr, ytr)); te.append(t.score(Xte, yte)); lv.append(int(t.get_n_leaves()))
    ax.plot(range(7), tr, "o-", color=A_C, lw=2.8, ms=9, label="training"); ax.plot(range(7), te, "s-", color=RED, lw=2.8, ms=9, label="new points")
    ax.set_xticks(range(7)); ax.set_xticklabels([f"{d}\n({l})" for d, l in zip(ds, lv)], fontsize=fpx(13)); ax.set_ylim(0.7, 1.03); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="lower right"); ax.set_xlabel("maximum depth (leaves)", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(368, "noisy two-moon data, 100 points per class", TXT, 16, True), (396, f"full tree: {lv[-1]} leaves, training 100%, new points {te[-1]*100:.1f}%", RED, 17, True), (424, f"best depth in the list: {max(te)*100:.1f}% on new points", GRN, 16, True)])
    save(fig, "lec05-kp23-depth"); return tr, te, lv

def f_prune():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    als = [0.0, 0.01, 0.02, 0.05]; lv, te, tr = [], [], []
    for a in als:
        t = DecisionTreeClassifier(criterion="entropy", ccp_alpha=a, random_state=0).fit(Xtr, ytr); lv.append(int(t.get_n_leaves())); te.append(t.score(Xte, yte)); tr.append(t.score(Xtr, ytr))
    ax.plot(range(4), tr, "o-", color=A_C, lw=2.8, ms=9, label="training"); ax.plot(range(4), te, "s-", color=RED, lw=2.8, ms=9, label="new points")
    ax.set_xticks(range(4)); ax.set_xticklabels([f"{a}\n({l} leaves)" for a, l in zip(als, lv)], fontsize=fpx(14)); ax.set_ylim(0.8, 1.03); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="lower left"); ax.set_xlabel("pruning strength α (leaves left)", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(368, "grow a full tree, then prune by error + complexity", TXT, 16, True), (396, f"24 leaves: {te[0]*100:.1f}%;  10 leaves: {te[2]*100:.1f}% on new points", GRN, 17, True), (424, "one dataset, one run: the gain is 2 points", MUT, 15, False)])
    save(fig, "lec05-kp23-prune"); return lv, te

def f_bag():
    fig, ax = blank(540, 440)
    single, bag, rf = [], [], []
    for s in range(20):
        X, y = moons2(100, 100 + s)
        single.append(DecisionTreeClassifier(criterion="entropy", random_state=0).fit(X, y).score(Xte, yte)); bag.append(BaggingClassifier(DecisionTreeClassifier(criterion="entropy"), n_estimators=25, random_state=0).fit(X, y).score(Xte, yte)); rf.append(RandomForestClassifier(n_estimators=25, criterion="entropy", max_features=1, random_state=0).fit(X, y).score(Xte, yte))
    T(ax, 270, 25, "20 different training sets of the same size", TXT, 16)
    for x, tx in zip((120, 300, 440), ("method", "mean ± sd", "")): T(ax, x, 62, tx, MUT, 14, False)
    for i, (n, v, c) in enumerate((("single tree", single, RED), ("bagging, 25 trees", bag, GRN), ("random forest, 25", rf, A_C))):
        y = 110 + i * 55; T(ax, 12, y, n, c, 16, True, "left"); T(ax, 330, y, f"{np.mean(v)*100:.1f} ± {np.std(v)*100:.1f}", c, 20)
    T(ax, 270, 300, "root threshold of 8 trees from 8 training sets:", MUT, 15, False)
    roots = []
    for s in range(8):
        X, y = moons2(100, 40 + s); roots.append(DecisionTreeClassifier(criterion="entropy", random_state=0).fit(X, y).tree_.threshold[0])
    T(ax, 270, 335, "  ".join(f"{r:.2f}" for r in roots[:4]), TXT, 17); T(ax, 270, 365, "  ".join(f"{r:.2f}" for r in roots[4:]), TXT, 17)
    T(ax, 270, 408, "small changes of the data move the first cut", RED, 16)
    save(fig, "lec05-kp23-bag"); return [round(float(np.mean(v)), 4) for v in (single, bag, rf)], [round(float(np.std(v)), 4) for v in (single, bag, rf)], [round(float(r), 2) for r in roots]

def f_oblique():
    w, h = 540, 440; fig = new_fig(w, h); a = panel(fig, w, h, 20, 20, 250, 250)
    rng = np.random.default_rng(5); X = rng.uniform(-1, 1, (300, 2)); y = (X[:, 0] + X[:, 1] > 0).astype(int)
    a.plot(X[y == 0, 0], X[y == 0, 1], "o", color=A_C, ms=4); a.plot(X[y == 1, 0], X[y == 1, 1], "s", color=B_C, ms=4); a.plot([-1, 1], [1, -1], color=GRN, lw=3); a.set_xticks([]); a.set_yticks([]); a.set_aspect("equal")
    ax = panel(fig, w, h, 290, 20, 240, 250); ax.axis("off"); ax.set_xlim(0, 240); ax.set_ylim(250, 0)
    ax.text(120, 18, "axis-parallel tree", color=MUT, fontsize=fpx(14), ha="center")
    Xt = rng.uniform(-1, 1, (3000, 2)); yt = (Xt[:, 0] + Xt[:, 1] > 0).astype(int)
    for i, d in enumerate((1, 3, 6)):
        t = DecisionTreeClassifier(criterion="entropy", max_depth=d, random_state=0).fit(X, y); ax.text(10, 70 + i * 55, f"depth {d}: {t.get_n_leaves()} leaves", color=TXT, fontsize=fpx(15), fontweight="bold"); ax.text(10, 95 + i * 55, f"new points {t.score(Xt, yt)*100:.1f}%", color=RED if d == 1 else GRN, fontsize=fpx(16), fontweight="bold")
    cap(fig, h, [(300, "classes separated by the line x₁ + x₂ = 0 (green)", TXT, 16, True), (338, "one oblique question: Σ cₖxₖ ≤ α, exact here", GRN, 17, True), (376, "axis-parallel cuts need a staircase of many leaves", RED, 17, True), (412, "full tree: 14 leaves, 95.1% on new points", MUT, 15, False)])
    save(fig, "lec05-kp23-oblique")

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "node t: 4 points of ω₁ and 4 points of ω₂", TXT, 19)
    T(ax, 270, 90, "split A: Yes (3, 1), No (1, 3)", TXT, 17); T(ax, 270, 130, "split B: Yes (2, 2), No (2, 2)", TXT, 17)
    T(ax, 270, 195, "question 1: ΔI of split A", RED, 18); T(ax, 270, 240, "question 2: ΔI of split B; which is better?", RED, 18)
    T(ax, 270, 290, "I(3,1) = 0.811;  I(2,2) = 1", MUT, 15, False)
    save(fig, "lec05-kp23-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("I(t) = 1 for (4, 4)", TXT), ("A: both children (3,1) and (1,3): I = 0.811", TXT), ("ΔI = 1 − (4/8)(0.811) − (4/8)(0.811) = 0.189", GRN), ("B: both children (2,2): I = 1", TXT), ("ΔI = 1 − 0.5 − 0.5 = 0", GRN), ("A is better; B gains nothing at all", RED)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 16)
    save(fig, "lec05-kp23-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
