ALT = {
 "partition": ("左：用兩個軸平行的問題把平面切成 A、B、C 三塊；右：對應的樹，每個問題檢查一個特徵與門檻。", "Left: two axis-parallel questions cut the plane into regions A, B and C; right: the matching tree, each question testing one feature against a threshold."),
 "cands": ("一個特徵的 10 個相異訓練值與相鄰值的 9 個中點門檻。", "The 10 distinct training values of one feature and the 9 midpoint thresholds between neighbours."),
 "entropy": ("兩類時的熵曲線在機率 0.5 最大；(4,4,2) 的不純度 1.522，(1,1,1) 為 1.585，(5,0,0) 為 0。", "The two-class entropy curve peaks at probability 0.5; the impurity is 1.522 for (4,4,2), 1.585 for (1,1,1) and 0 for (5,0,0)."),
 "ex42": ("Example 4.2：父節點 (4,4,2)，子節點 (3,1,0) 與 (1,3,2)；重算 ΔI=0.322，教材印 0.315。", "Example 4.2: parent (4,4,2) with children (3,1,0) and (1,3,2); the recomputed ΔI is 0.322 where the book prints 0.315."),
 "weight": ("分裂 A 切出一個純點、分裂 B 較平均：加權時 B 贏（0.278 對 0.108），不加權時 A 贏（0.504 對 0.278）。", "Split A isolates one pure point and split B is balanced: weighted, B wins (0.278 against 0.108); unweighted, A wins (0.504 against 0.278)."),
 "depth": ("月牙形資料上樹深 1 到 12 的訓練與新點準確率：訓練升到 100%，新點約 85%。", "Training and new-point accuracy of trees of depth 1 to 12 on two-moon data: training reaches 100% while new points stay near 85%."),
 "prune": ("剪枝強度 0、0.01、0.02、0.05：24、22、10、7 片葉；新點 85.1%、85.1%、87.3%、86.3%。", "Pruning strengths 0, 0.01, 0.02 and 0.05 leave 24, 22, 10 and 7 leaves with 85.1%, 85.1%, 87.3% and 86.3% on new points."),
 "bag": ("20 份訓練集的新點準確率：單棵樹 84.4±1.4、bagging 87.7±1.1、隨機森林 87.8±1.1；8 棵樹的根門檻在 0.09 到 0.42 之間。", "New-point accuracy over 20 training sets: single tree 84.4±1.4, bagging 87.7±1.1, random forest 87.8±1.1; the root thresholds of 8 trees range from 0.09 to 0.42."),
 "oblique": ("類別由斜線 x₁+x₂=0 決定：軸平行的樹深度 1、3、6 為 2、7、13 片葉，新點 75.0%、89.6%、95.4%。", "The class is set by the line x₁+x₂=0: axis-parallel trees of depth 1, 3 and 6 have 2, 7 and 13 leaves with 75.0%, 89.6% and 95.4% on new points."),
 "practice": ("練習圖：4 對 4 的節點；分裂 A 為 (3,1) 與 (1,3)，分裂 B 為 (2,2) 與 (2,2)。", "Practice figure: a node of 4 against 4; split A gives (3,1) and (1,3), split B gives (2,2) and (2,2)."),
 "practice-sol": ("分裂 A：ΔI=0.189；分裂 B：ΔI=0，A 比較好。", "Split A: ΔI=0.189; split B: ΔI=0, so A is better."),
}
