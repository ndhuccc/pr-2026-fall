# KP01 XOR 與線性分類的限制（XOR and the limits of linear classification）

> 程度：大學三年級（undergrad）／Level: Undergraduate (undergrad)
>
> 圖型識別｜第四章 §§4.1–4.2｜第 5 週主題：非線性分類器
>
> Pattern Recognition | Chapter 4, Sections 4.1–4.2 | Week 5: Nonlinear classifiers

[投影片閱讀與下載（Read or download the slides）](../slides/lec05-kp01-xor.html)

## 學習目標（Learning objectives）

- 能把 OR、AND 與 XOR 的真值表轉成平面上的分類問題。（You can turn the truth tables of OR, AND, and XOR into planar classification problems.）
- 能依判別分數與固定門檻逐點計算預測。（You can compute each prediction from a discriminant score and a fixed threshold.）
- 能用不等式證明 XOR 線性不可分，區分表達能力與訓練問題。（You can prove that XOR is not linearly separable and distinguish representation limits from training problems.）

## KP01 XOR 需要超出單一直線的邊界（XOR requires more than one linear boundary）

**一句話重點**：四個 XOR 點無法由單一直線分開；若模型只允許這種邊界，調整訓練方式仍無法全對。

**One-sentence summary**: A single straight line cannot separate the four XOR points. A model restricted to this boundary cannot classify every point correctly, regardless of its training method.

### 從真值表看見幾何問題（Seeing geometry in a truth table）

**白話說明**：第三章讓我們用一個分數決定類別。現在先不換演算法，只換四個點的標籤，看看原來的模型還能不能回答。

**Plain explanation**: In Chapter 3, a score determined the class. We now keep the four point locations and change their labels to see whether the same model can still represent the answer.

XOR 是「互斥或」：兩個輸入不同時輸出 1，相同時輸出 0。下表的 A 表示輸出 1，B 表示輸出 0；類別名稱本身沒有大小順序。

XOR means exclusive OR: the output is 1 when the two inputs differ and 0 when they match. Class A represents output 1, and class B represents output 0. The class names do not imply an ordering.

| $x_1$ | $x_2$ | OR | AND | XOR | XOR 類別 | XOR class |
|---:|---:|---:|---:|---:|---|---|
| 0 | 0 | 0 | 0 | 0 | B | B |
| 0 | 1 | 1 | 0 | 1 | A | A |
| 1 | 0 | 1 | 0 | 1 | A | A |
| 1 | 1 | 1 | 1 | 0 | B | B |

OR 的 A 類占三個角，AND 的 A 類只占右上角，兩者都有直線可以分開。XOR 則把同類點放在對角：A 與 B 交錯，嘗試幾條線都會留下錯誤。不過，「試過幾條都失敗」還不是所有直線都不行的證明。

For OR, class A occupies three corners. For AND, it occupies only the upper-right corner. Both admit a separating line. XOR places each class on opposite corners, so attempted lines leave errors. However, several failed attempts do not prove that every possible line fails.

![OR 的四個輸入點與分隔線（OR inputs and a separating line）](../assets/figures/lec05-kp01-or.png)

圖說 `lec05-kp01-or`：先看圓點 A 與方點 B，再看邊界 $x_1+x_2=0.5$；三個 A 點都在分數為正的一側。圖內座標是輸入，顏色與形狀表示真實類別。

Figure `lec05-kp01-or`: First locate circles A and squares B, then inspect the boundary $x_1+x_2=0.5$. All three A points have positive scores. Coordinates are inputs; colors and shapes indicate true classes.

![XOR 對角同類的四個點（The four XOR points with matching diagonal classes）](../assets/figures/lec05-kp01-xor.png)

圖說 `lec05-kp01-xor`：與 OR 使用相同四個座標，但右上角改成 B。先沿對角找同類，再想一條線如何同時把兩個 A 留在同側。

Figure `lec05-kp01-xor`: The coordinates match OR, but the upper-right point is now B. First follow each diagonal to find matching classes, then consider how one line could keep both A points on the same side.

![AND 的四個輸入點與分隔線（AND inputs and a separating line）](../assets/figures/lec05-kp01-and.png)

圖說 `lec05-kp01-and`：先找唯一的 A 點，再看 $x_1+x_2=1.5$ 如何把它與三個 B 點分開。AND 與 OR 都線性可分，但正類點數不同。

Figure `lec05-kp01-and`: Locate the only A point, then inspect how $x_1+x_2=1.5$ separates it from the three B points. AND and OR are both linearly separable, with different numbers of positive points.

可以把直線想成只能放一片的筆直隔板，兩類必須分居兩側。這個比喻只說明邊界形狀，不表示實際程式會放隔板，也不處理學習速度。

Think of the line as a single straight divider that must place the two classes on opposite sides. This analogy describes boundary shape, not a physical operation or training speed.

### 固定判別規則，才知道何謂分對（A fixed decision rule makes correctness precise）

**正式定義**：本單元考慮二元輸入與二類分類。允許偏置的線性判別分數如下；嚴格說這是仿射函數，分類慣例仍稱為線性分類器。

**Formal definition**: We consider two binary inputs and two classes. The score below includes a bias, making it affine. By convention, the classifier is still called linear.

$$
g(\mathbf{x})=w_1x_1+w_2x_2+w_0,\qquad
\widehat y(\mathbf{x})=\begin{cases}1\;(A),&g(\mathbf{x})>0,\\0\;(B),&g(\mathbf{x})\leq0.\end{cases}
$$

分數為正就預測 A，否則預測 B。因此邊界上的點也一律判為 B；不能看完真實標籤再改變平手規則。當 $(w_1,w_2)\ne(0,0)$，$g(\mathbf{x})=0$ 是直線；兩個權重都為零時只能做常數預測，也無法解決 XOR。

A positive score predicts A; otherwise the prediction is B. Every boundary point is therefore assigned to B. The tie rule cannot depend on the true label. When $(w_1,w_2)\ne(0,0)$, the zero-score boundary is a line. Zero weights produce only a constant prediction and cannot solve XOR either.

| 符號 | 中文意義 | English meaning |
|---|---|---|
| $\mathbf{x}=[x_1,x_2]^T$ | 2 維輸入向量，各分量為 0 或 1 | Two-dimensional input vector with binary components |
| $w_1,w_2$ | 兩個輸入的純量權重 | Scalar weights of the two inputs |
| $w_0$ | 純量偏置，移動決策邊界 | Scalar bias that shifts the boundary |
| $g(\mathbf{x})$ | 純量判別分數，這裡沒有物理單位 | Scalar discriminant score with no physical unit here |
| $y,\widehat y$ | 真實標籤與預測標籤，皆為 0 或 1 | True and predicted labels, both binary |

線性可分表示：存在同一組權重與偏置，能依固定規則把所有樣本分對。重點是「存在一組參數」，不只是目前找到的參數表現如何。

Linear separability means that one set of weights and bias correctly classifies every sample under the fixed decision rule. It concerns the existence of such parameters, not merely the quality of the current parameters.

### 同一條線，在 OR 全對，在 XOR 錯 1 點（The same line solves OR but misses one XOR point）

**例子**：沿用來源互動示範的 $w_1=w_2=1$、$w_0=-0.5$。先算分數，再套用門檻；不能直接從真實類別填預測。

**Example**: Use the source demonstration parameters $w_1=w_2=1$ and $w_0=-0.5$. Compute each score before applying the threshold. Do not copy the true labels into the prediction column.

① 固定規則：把權重代入一般式。

① Fix the rule by substituting the weights into the general score.

$$
g(\mathbf{x})=1x_1+1x_2-0.5=x_1+x_2-0.5.
$$

② 逐點代入：每列都使用同一組參數。

② Evaluate each point using the same parameters in every row.

| 輸入 Input | 完整代入 Substitution | 分數 Score | 預測 Prediction | XOR 真值 True XOR |
|---|---|---:|---:|---:|
| $(0,0)$ | $1(0)+1(0)-0.5$ | $-0.5$ | 0 | 0 |
| $(0,1)$ | $1(0)+1(1)-0.5$ | $0.5$ | 1 | 1 |
| $(1,0)$ | $1(1)+1(0)-0.5$ | $0.5$ | 1 | 1 |
| $(1,1)$ | $1(1)+1(1)-0.5$ | $1.5$ | 1 | 0 |

③ 核對標籤：預測恰好等於 OR；與 XOR 比較，右上角分錯。

③ Check the labels: these predictions match OR exactly. For XOR, the upper-right point is wrong.

$$
\text{XOR accuracy}=\frac{\text{correct predictions}}{\text{all samples}}=\frac{3}{4}=0.75=75\%.
$$

④ 驗算：四點中 1 點錯，所以錯誤率為 $1/4=25\%$，且 $75\%+25\%=100\%$。這是這組參數的結果，還不能單憑它宣稱所有參數都不可能全對。

④ Verify: one error among four points gives an error rate of $1/4=25\%$, and $75\%+25\%=100\%$. This evaluates one parameter set; by itself, it does not rule out all other parameters.

### 用相加後的矛盾排除所有直線（Adding inequalities rules out every line）

數值例留下的問題是：會不會只是還沒找到好參數？為了排除這個可能，假設有任意一組 $w_1,w_2,w_0$ 能把 XOR 全部分對，列出它必須滿足的條件。

The numerical example leaves a question: perhaps better parameters exist. To rule this out, assume arbitrary parameters $w_1,w_2,w_0$ classify every XOR point correctly and write their necessary conditions.

① A 類要分對：將 $(0,1)$ 與 $(1,0)$ 代入，兩個分數都必須為正。

① Correct A predictions require positive scores at $(0,1)$ and $(1,0)$.

$$
g(0,1)=w_2+w_0>0,\qquad g(1,0)=w_1+w_0>0.
$$

② 把這兩個條件相加：正數加正數仍為正。

② Add the conditions: the sum of two positive numbers is positive.

$$
(w_2+w_0)+(w_1+w_0)=w_1+w_2+2w_0>0.
$$

③ B 類要分對：將 $(0,0)$ 與 $(1,1)$ 代入；依固定規則，分數必須非正。

③ Correct B predictions require nonpositive scores at $(0,0)$ and $(1,1)$ under the fixed tie rule.

$$
g(0,0)=w_0\leq0,\qquad g(1,1)=w_1+w_2+w_0\leq0.
$$

④ 把 B 類條件相加：非正數的和不可能為正。

④ Add the B conditions: a sum of nonpositive numbers cannot be positive.

$$
w_0+(w_1+w_2+w_0)=w_1+w_2+2w_0\leq0.
$$

兩邊得到完全相同的量，卻要求它同時大於零與小於等於零，矛盾。因此不存在能全對的參數。這是對所有線性判別器的證明，不是只排除圖上幾條候選線。

Both sums are identical, but one must be positive and the other nonpositive. This contradiction proves that no parameters classify every point correctly. It rules out every linear discriminator, not just the plotted candidates.

### 表達能力的限制不能靠多訓練消除（Training cannot remove a representation limit）

**常見迷思**：如果多跑幾輪、調小學習率，或者重新初始化，應該就能全對。這些操作只是在同一類直線邊界裡找參數；前面的矛盾已證明，這個集合中沒有全對的答案。

**Common misconception**: More iterations, a smaller learning rate, or a new initialization should eventually solve XOR. These operations search the same family of linear boundaries. The contradiction proves that this family contains no perfect solution.

這不表示訓練毫無作用。換參數仍可能把錯 3 點改善成錯 1 點，只是最低錯誤無法降到 0。訓練是否找到最好的直線，與最好的直線是否足夠，是兩個不同問題。

Training can still help: different parameters may reduce three errors to one. It simply cannot reach zero errors. Finding the best line and deciding whether the best line is sufficient are different questions.

![XOR 的三條候選線仍留下錯誤（Three candidate lines still leave XOR errors）](../assets/figures/lec05-kp01-attempts.png)

圖說 `lec05-kp01-attempts`：先看固定的 XOR 標籤，再分別檢查三種線型。三條線只作示範，線性不可分的結論來自不等式證明。

Figure `lec05-kp01-attempts`: First inspect the fixed XOR labels, then check each line style separately. The lines illustrate failures; the inequality argument establishes nonseparability.

| 分數 Score | 預測，依輸入表順序 Predictions in input-table order | 錯誤數 Errors |
|---|---|---:|
| $x_1+x_2-0.5$ | $(0,1,1,1)$ | 1 |
| $x_1+x_2-1.5$ | $(0,0,0,1)$ | 3 |
| $x_1-x_2$ | $(0,0,1,0)$ | 1 |

第二列會錯 3 點，不能因為「也只切下一個角」就說它一定只錯 1 點；預測哪一側是 A 必須一起考慮。第三列的兩個零分點都依規則判為 B。

The second rule makes three errors. Cutting off one corner does not imply one error: the predicted class of each side also matters. In the third row, both zero-score points are assigned to B.

**實作連結**：逐點算出分數後，以 `score > 0` 產生預測，再與真值比較。測試必須包含邊界上的點，以免程式用 `>=` 而文字用 `>`。這裡的半整數可精確表示；一般實數資料仍需注意浮點誤差。

**Implementation connection**: Compute each score, use `score > 0` for predictions, and compare with true labels. Include boundary points in checks so that code and text use the same inequality. The half-integer values here are exactly representable; general real-valued data still require care with floating-point errors.

### 想深入：兩條邊界打開下一個問題（Going deeper: two boundaries open the next question）

前面排除的是「單一線性分數加固定門檻」，沒有排除多條邊界的組合。來源以兩條線引出下一個單元；以下把這個方向寫成可檢查的條件，標為［補充］。

The proof excludes a single linear score with a fixed threshold, not combinations of boundaries. The source uses two lines to motivate the next unit. The explicit conditions below develop that idea and are marked [Added].

［補充］令 $s=x_1+x_2$。XOR 的四點只會出現 $s=0,1,2$；正類恰好是中間的 $s=1$，因此可用兩個條件的交集選出。

[Added] Let $s=x_1+x_2$. The four XOR points have sums $s=0,1,2$. Only $s=1$ belongs to the positive class, so the intersection of two conditions selects it.

$$
\widehat y=1\quad\Longleftrightarrow\quad 0.5<s\leq1.5.
$$

![兩條邊界圍出包含兩個 A 點的帶狀區域（Two boundaries enclose a strip containing both A points）](../assets/figures/lec05-kp01-strip.png)

圖說 `lec05-kp01-strip`：先看兩條邊界，再看中間陰影；$(0,1)$ 與 $(1,0)$ 在帶內，另兩點在帶外。這只驗證四個布林點，沒有指定連續平面上 XOR 的唯一正確延伸。

Figure `lec05-kp01-strip`: First locate the two boundaries, then the shaded strip. It contains $(0,1)$ and $(1,0)$ and excludes the other two points. This verifies the four Boolean inputs; it does not define a unique correct extension of XOR to the continuous plane.

這裡真正改變的是模型允許的邊界組合，並非只把舊權重換一組。下一個知識點會問：如何用隱藏層神經元實現這種組合？

The change is the allowed combination of boundaries, not merely another choice of old weights. The next concept asks how hidden-layer neurons implement such combinations.

### 小練習與自我檢查（Practice and self-check）

**小練習**：以下只附提示；前面的 OR／XOR 算例提供完整計算示範。

**Practice**: These questions provide hints only. The earlier OR/XOR example supplies a complete worked calculation.

1. 用 $g=x_1+x_2-1.5$ 算四個輸入，分別核對 AND 與 XOR。提示：先算分數，再用同一個 $g>0$ 規則，最後才對照兩組真值。（Evaluate all four inputs with $g=x_1+x_2-1.5$ and check AND and XOR separately. Hint: calculate scores, apply the same positive-score rule, and only then compare both sets of labels.）
2. XOR 失敗的根本原因是樣本太少、雜訊、學習率，還是邊界形狀受限？提示：指出哪一項由不等式矛盾直接排除。（Is XOR failure caused by too few samples, noise, learning rate, or the restricted boundary shape? Hint: identify what the inequality contradiction directly rules out.）
3. OR、XOR、XNOR 中，哪個能由單一直線分開？XNOR 指輸入相同時輸出 1。提示：先畫四點標籤；它們的位置相同，標籤配置不同。（Which of OR, XOR, and XNOR admits a single separating line? XNOR outputs 1 for matching inputs. Hint: draw all four labels; positions stay fixed while label patterns change.）
4. 如何把兩條線的條件交給下一層組合？提示：先列帶狀區域的兩個判斷，再考慮「兩者都成立」需要什麼邏輯。（How could the conditions from two lines be combined in a next layer? Hint: write the two strip conditions before considering the logic of requiring both.）

## 術語對照（Terminology）

| 中文 | English | 本單元意義 Meaning in this unit |
|---|---|---|
| 互斥或 | Exclusive OR, XOR | 輸入不同才輸出 1 / Output 1 only for different inputs |
| 判別分數 | Discriminant score | 用正負號決定類別 / A score whose sign determines the class |
| 偏置 | Bias | 不乘輸入的常數項 / Constant term independent of the input |
| 決策邊界 | Decision boundary | 預測類別轉換的邊界 / Boundary between prediction regions |
| 線性可分 | Linear separability | 一個線性規則可把全部點分對 / One linear rule classifies every point correctly |
| 表達能力 | Representational capacity | 模型能表示哪些分類規則 / The classification rules a model can represent |
| 假設族 | Hypothesis class | 模型允許的候選規則集合 / The family of candidate rules allowed by a model |
| 隱藏層 | Hidden layer | 輸入與輸出之間的處理層 / A processing layer between input and output |

## 來源與補充範圍（Source and added material）

來源：[第四章「非線性分類器」KP01，§§4.1–4.2](https://ndhuccc.github.io/CCC-LNS/PR_115/Ch04-nonlinear-classifiers/index.html#kp1)，讀取日期：2026-10-24。透過同站 GitHub 原始 HTML 讀取。以原有四點、參數與示範為依據重新撰寫；所有幾何圖均依座標重畫，未複製原圖。

Source: Chapter 4, “Nonlinear Classifiers,” KP01, Sections 4.1–4.2, accessed 2026-10-24 through its GitHub source HTML. The explanations are newly written using the original points, parameters, and demonstrations. Every geometry figure was redrawn from coordinates.

補充範圍：兩條邊界的帶狀條件；其餘是原內容的符號定義、算例展開與限制澄清。新增補充未涉及多層網路權重的完整構造，留給下一個知識點。

Added scope: the explicit strip condition for two boundaries. Other expansions define symbols, work through calculations, and clarify limitations already implicit in the source. The full multilayer weight construction is reserved for the next concept.
