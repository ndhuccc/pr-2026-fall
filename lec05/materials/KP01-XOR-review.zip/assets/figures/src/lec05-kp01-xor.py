from pathlib import Path
import sys, json, base64
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'.agents/skills/view-from-text'))
from jbd_figure import *
ROOT=Path(__file__).resolve().parents[3]; OUT=ROOT/'assets/figures'; OUT.mkdir(exist_ok=True)
X=np.array([[0,0],[0,1],[1,0],[1,1]])
LABELS={'OR':np.array([0,1,1,1]),'AND':np.array([0,0,0,1]),'XOR':np.array([0,1,1,0])}

def draw(name='XOR',dark=True,mode='plain',w=530,h=440):
 use_jbd_style(20)
 if not dark:
  plt.rcParams.update({'text.color':'#282923','axes.labelcolor':'#282923','axes.edgecolor':'#60625a','xtick.color':'#60625a','ytick.color':'#60625a','figure.facecolor':'white','savefig.transparent':False})
 fig,ax=new_figure(w,h,(76,64,20,110)); y=LABELS[name]
 for v,mark,c,lab in [(1,'o',PALETTE['positive'],'A: output 1'),(0,'s',PALETTE['negative'],'B: output 0')]:
  pts=X[y==v]; ax.scatter(*pts.T,s=130,marker=mark,c=c,label=lab,zorder=5)
 ax.set(xlim=(-.3,1.3),ylim=(-.3,1.3),xticks=[0,1],yticks=[0,1],xlabel='$x_1$',ylabel='$x_2$');ax.set_aspect('equal');ax.grid(alpha=.14)
 xx=np.linspace(-.3,1.3,400)
 if mode in ['or','and']:
  b=.5 if mode=='or' else 1.5
  ax.plot(xx,b-xx,c=PALETTE['boundary'],lw=2.5,label='Decision boundary')
 if mode=='attempts':
  for yy,ls in [(.5-xx,'--'),(1.5-xx,':'),(xx,'-.')]:ax.plot(xx,yy,ls=ls,c=PALETTE['boundary'],lw=2)
  ax.plot([],[],ls='--',c=PALETTE['boundary'],label='Candidate lines')
 if mode=='strip':
  ax.fill_between(xx,.5-xx,1.5-xx,color=PALETTE['positive'],alpha=.12)
  for b in [.5,1.5]:ax.plot(xx,b-xx,c=PALETTE['boundary'],lw=2.5)
  ax.plot([],[],c=PALETTE['boundary'],label='Two boundaries')
 leg=ax.legend(loc='lower center',bbox_to_anchor=(.5,1.02),ncol=1,frameon=False,fontsize=px_to_pt(18),labelspacing=.3,handlelength=1.4)
 return fig

figs={}
for key,name,mode in [('or','OR','or'),('xor','XOR','plain'),('and','AND','and'),('attempts','XOR','attempts'),('strip','XOR','strip')]:
 fig=draw(name,False,mode);fig.savefig(OUT/f'lec05-kp01-{key}.png',dpi=160);plt.close(fig)
 fig=draw(name,True,mode); figs[key]=svg_data_uri(fig)
Path('/tmp/xor-figures.json').write_text(json.dumps(figs))
# Exact evaluations: boundary ties go to B.
candidates=[(1,1,-.5),(1,1,-1.5),(1,-1,0)]
r=[]
for w1,w2,b in candidates:
 g=X@np.array([w1,w2])+b; pred=(g>0).astype(int);err=int(np.sum(pred!=LABELS['XOR']))
 r.append({'weights':[w1,w2,b],'scores':g.tolist(),'predictions':pred.tolist(),'errors':err,'accuracy':1-err/4})
assert [z['errors'] for z in r]==[1,3,1]
s=X.sum(axis=1);assert np.array_equal(((s>.5)&(s<=1.5)).astype(int),LABELS['XOR'])
assert np.array_equal((s>.5).astype(int),LABELS['OR'])
assert np.array_equal((s>1.5).astype(int),LABELS['AND'])
Path('/tmp/xor-numerical-checks.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,ensure_ascii=False))
