KP10 網路大小、泛化與早停

解壓縮後開啟 index.html。講義PDF在pdf/，離線講義在reading/，離線簡報及可編輯原檔在slides/，Markdown在lectures/。本份為自主學習審閱草稿。
簡報方向鍵換頁；N顯示公開講者備註；沒有音檔。講義與簡報共用此解壓縮目錄，不需要伺服器或網路。
