Pattern Recognition, Chapter 4, KP06: From the step to the gradient of backpropagation (English version)

Slides: slides/lec05-kp06-backprop-gradient-en.html (offline web page, open in a browser); slides/lec05-kp06-backprop-gradient-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp06-backprop-gradient-en-lecture.pdf (PDF), lec05-kp06-backprop-gradient-en-reading.html (offline web page), lectures/lec05-kp06-backprop-gradient-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
