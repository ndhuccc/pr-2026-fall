ALT = {
 "weak": ("20 個「x_j>0？」決策樁的測試錯誤約 27% 到 36%，平均 31.6%；第 1 輪最佳決策樁訓練 25.5%、測試 28.75%。", "Test errors of the 20 stumps 'x_j>0?' range from about 27% to 36%, mean 31.6%; the best stump of round 1 has 25.5% on training and 28.75% on test."),
 "wts": ("最小化指數損失、逐級最佳化：樣本權重 wᵢ=exp(−yᵢF_{m−1}(xᵢ)) 自然出現，φ 要最小化加權錯誤率 P_m。", "Minimizing the exponential loss stage by stage: the sample weight wᵢ=exp(−yᵢF_{m−1}(xᵢ)) emerges and φ must minimize the weighted error P_m."),
 "alpha": ("α=½ln((1−P)/P) 對加權錯誤率 P：P=0.1 為 1.099，0.3 為 0.424，0.5 為 0，0.7 為 −0.424。", "α=½ln((1−P)/P) against the weighted error P: 1.099 at P=0.1, 0.424 at 0.3, 0 at 0.5 and −0.424 at 0.7."),
 "update": ("10 個點各 0.1、錯 3 個、P=0.3、α=0.4236：更新後錯的各 0.1667、對的各 0.0714，錯的三個合起來 0.5。", "Ten points of weight 0.1 with 3 wrong, P=0.3 and α=0.4236: after the update the wrong ones have 0.1667 each and the right ones 0.0714 each, so the 3 wrong points hold 0.5."),
 "algo": ("AdaBoost 演算法：初始權重 1/N；重複找 φ、算 α、更新權重；最後取 Σα_kφ_k 的正負號。", "The AdaBoost algorithm: initial weights 1/N; repeatedly find φ, compute α and update the weights; finally take the sign of Σα_kφ_k."),
 "curve": ("訓練與測試錯誤對輪數（對數軸）：訓練錯誤第 17 輪歸零，測試錯誤 28.75% 降到 200 輪的 3.25% 後持平在約 4%。", "Training and test error against rounds (log axis): training error is 0 from round 17 and the test error falls from 28.75% to 3.25% at round 200, then stays near 4%."),
 "margin": ("邊距表：最小邊距從第 1 輪的 −1.000 升到 2000 輪的 +0.220；邊距小於 0.1 的比例 25.5%、8.5%、0%。", "Margin table: the smallest margin rises from −1.000 at round 1 to +0.220 at round 2000; the share with margin below 0.1 is 25.5%, 8.5% and 0%."),
 "noise": ("測試錯誤對輪數：標籤乾淨降到 5.5%；翻 15% 的標籤在 30 輪最低 17.8% 後升到 23.3%。", "Test error against rounds: it falls to 5.5% with clean labels but with 15% flipped labels it is lowest at 17.8% around round 30 and then rises to 23.3%."),
 "neg": ("P=0.7 的分類器 α=−0.4236，等於用反過來的分類器（P=0.3）；做錯的點權重變小，做對的變大。", "A classifier with P=0.7 has α=−0.4236, the same as using the inverted classifier (P=0.3); points it gets wrong shrink and points it gets right grow."),
 "practice": ("練習圖：5 個權重各 0.2 的樣本、錯 1 個、P=0.2，求 α 與更新後的權重。", "Practice figure: 5 samples of weight 0.2 with 1 wrong and P=0.2; find α and the updated weights."),
 "practice-sol": ("α=½ln4=0.6931；更新並正規化後錯的 0.5、對的各 0.125。", "α=½ln4=0.6931; after the update and normalization the wrong one has 0.5 and each right one 0.125."),
}
