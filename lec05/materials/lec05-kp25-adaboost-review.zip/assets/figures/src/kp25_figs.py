import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums25 as N
from nums25 import *
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
def T(ax, x, y, t, c=None, fs=17, bold=True, ha="center"): ax.text(x, y, t, color=c or TXT, fontsize=fpx(fs), ha=ha, va="center", fontweight="bold" if bold else "normal")
X, y, _ = gauss20(200, 1); Xt, yt, _ = gauss20(400, 2)
CK = [1, 2, 3, 5, 10, 20, 30, 50, 100, 200, 300, 500, 1000, 2000]
RUN = None
def run():
    global RUN
    if RUN is None: RUN = adaboost(X, y, 2000, 0, CK, Xt, yt, stumps="best")
    return RUN

def f_weak():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 240); axstyle(ax)
    errs = np.array([(np.where(Xt[:, j] > 0, 1, -1) != yt).mean() for j in range(20)]); errs = np.minimum(errs, 1 - errs)
    ax.bar(range(20), errs, color=A_C, width=0.7); ax.axhline(0.5, color=MUT, lw=1.2, ls="--"); ax.set_ylim(0, 0.6); ax.set_xticks([0, 5, 10, 15, 19]); ax.set_xticklabels(["1", "6", "11", "16", "20"], fontsize=fpx(15)); ax.set_xlabel("feature of a one-question stump (x_j > 0 ?)", color=TXT, fontsize=fpx(14)); ax.set_ylabel("test error", color=TXT, fontsize=fpx(15))
    ax.text(10, 0.52, "guessing: 0.5", color=MUT, fontsize=fpx(13), ha="center")
    out, als, Ps = run()
    cap(fig, h, [(335, f"each of the 20 stumps: test error {errs.min()*100:.0f}% to {errs.max()*100:.0f}%, mean {errs.mean()*100:.1f}%", TXT, 16, True), (372, f"best stump of round 1: training {out[0][1]*100:.1f}%, test {out[0][2]*100:.2f}%", RED, 17, True), (409, "better than guessing, but not by much", MUT, 16, False)])
    save(fig, "lec05-kp25-weak"); return float(errs.mean()), out[0][1], out[0][2]

def f_wts():
    fig, ax = blank(540, 420)
    T(ax, 270, 28, "minimize Σᵢ exp(−yᵢ F_m(xᵢ)),  F_m = F_{m−1} + α φ", TXT, 16)
    T(ax, 270, 85, "= Σᵢ wᵢ exp(−yᵢ α φ(xᵢ))", RED, 22)
    T(ax, 270, 140, "wᵢ = exp(−yᵢ F_{m−1}(xᵢ))", GRN, 21)
    T(ax, 270, 185, "contains neither α nor φ: it is the sample weight", MUT, 15, False)
    T(ax, 270, 250, "so φ must minimize the weighted error", TXT, 17)
    T(ax, 270, 295, "P_m = Σᵢ wᵢ · [yᵢ φ(xᵢ) < 0]", RED, 20)
    T(ax, 270, 355, "weights are not a heuristic:", TXT, 17); T(ax, 270, 390, "they fall out of the exponential loss", GRN, 17)
    save(fig, "lec05-kp25-wts")

def f_alpha():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    P = np.linspace(0.03, 0.97, 300); ax.plot(P, alpha(P), color=RED, lw=3); ax.axhline(0, color=MUT, lw=1.2); ax.axvline(0.5, color=MUT, lw=1.2, ls="--")
    for p, c in ((0.1, GRN), (0.3, A_C), (0.5, TXT), (0.7, VIO2)): ax.plot([p], [alpha(p)], "o", color=c, ms=10); ax.text(p, alpha(p) + (0.35 if alpha(p) >= 0 else -0.55), f"{alpha(p):.3f}", color=c, fontsize=fpx(14), ha="center", fontweight="bold")
    ax.set_ylim(-2, 2); ax.set_xlabel("weighted error P_m", color=TXT, fontsize=fpx(15)); ax.set_ylabel("α_m", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(352, "α = ½ ln((1 − P)/P)", TXT, 18, True), (386, "P → 0: a large voice;  P = 0.5: no voice (α = 0)", GRN, 16, True), (420, "P > 0.5: negative α, use the answer inverted", VIO2, 16, True)])
    save(fig, "lec05-kp25-alpha")

def f_update():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 235); axstyle(ax)
    a = alpha(0.3); w0 = np.full(10, 0.1); wrong = np.arange(10) < 3; w1 = np.where(wrong, w0 * np.exp(a), w0 * np.exp(-a)); w1 /= w1.sum()
    x = np.arange(10); ax.bar(x - 0.2, w0, 0.4, color=MUT, label="before"); ax.bar(x + 0.2, w1, 0.4, color=np.where(wrong, RED, GRN), label="after")
    ax.set_xticks(x); ax.set_xticklabels([str(i + 1) for i in x], fontsize=fpx(15)); ax.set_xlabel("sample (1–3 misclassified)", color=TXT, fontsize=fpx(15)); ax.set_ylim(0, 0.2)
    ax.text(1, 0.176, f"{w1[0]:.4f}", color=RED, fontsize=fpx(14), ha="center", fontweight="bold"); ax.text(6, 0.108, f"{w1[5]:.4f}", color=GRN, fontsize=fpx(14), ha="center", fontweight="bold")
    cap(fig, h, [(330, f"P = 0.3, α = {a:.4f}", TXT, 17, True), (366, f"wrong: ×e^α = ×{np.exp(a):.4f};  right: ×e^−α = ×{np.exp(-a):.4f}", TXT, 16, True), (402, f"normalized: the 3 wrong points hold {w1[:3].sum():.1f} of the weight", RED, 16, True)])
    save(fig, "lec05-kp25-update"); return float(a), w1[:2].tolist()

def f_algo():
    fig, ax = blank(540, 440)
    L = ["start: wᵢ = 1/N", "repeat:", "   find φ_m minimizing P_m (weighted error)", "   α_m = ½ ln((1 − P_m) / P_m)", "   wᵢ ← wᵢ exp(−yᵢ α_m φ_m(xᵢ)), then divide by Z_m", "until a stopping rule is met", "f(x) = sign( Σ_k α_k φ_k(x) )"]
    for i, t in enumerate(L): T(ax, 40, 45 + i * 46, t, RED if i == 6 else (GRN if i in (3, 4) else TXT), 16, True, "left")
    T(ax, 270, 385, "Example 4.3: 20-D Gaussians, 200 training, 400 test points,", MUT, 15, False); T(ax, 270, 415, "base classifier = a one-question stump", MUT, 15, False)
    save(fig, "lec05-kp25-algo")

def f_curve():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    out, als, Ps = run(); m = [o[0] for o in out]; tr = [o[1] for o in out]; te = [o[2] for o in out]
    ax.plot(m, tr, "o-", color=A_C, lw=2.6, ms=6, label="training"); ax.plot(m, te, "s-", color=RED, lw=2.6, ms=6, label="test"); ax.set_xscale("log"); ax.set_ylim(-0.01, 0.32); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlabel("rounds (log scale)", color=TXT, fontsize=fpx(15)); ax.set_ylabel("error", color=TXT, fontsize=fpx(15))
    ax.axvline(17, color=GRN, lw=1.8, ls="--"); ax.text(19, 0.2, "training error 0\nfrom round 17", color=GRN, fontsize=fpx(13))
    j = int(np.argmin(te))
    cap(fig, h, [(352, f"test error: {te[0]*100:.1f}% (1), {te[4]*100:.1f}% (10), {te[9]*100:.2f}% (200), {te[-1]*100:.2f}% (2000)", TXT, 15, True), (386, "after training error reaches 0 the test error keeps falling", GRN, 16, True), (420, "to about round 200, then stays flat near 4%", MUT, 16, False)])
    save(fig, "lec05-kp25-curve"); return te

def f_margin():
    fig, ax = blank(540, 440)
    out, als, Ps = run()
    for x, tx in zip((60, 200, 370, 480), ("rounds", "min margin", "margin < 0.1", "test")): T(ax, x, 28, tx, MUT, 14, False)
    rows = [o for o in out if o[0] in (1, 10, 50, 100, 200, 2000)]
    for i, (mm, e1, e2, F, wt) in enumerate(rows):
        mg = y * F / als[:mm].sum(); yy = 80 + i * 45; col = RED if mg.min() < 0 else GRN
        T(ax, 60, yy, f"{mm}", TXT, 18); T(ax, 200, yy, f"{mg.min():+.3f}", col, 18); T(ax, 370, yy, f"{(mg < 0.1).mean()*100:.1f}%", TXT, 18); T(ax, 480, yy, f"{e2*100:.2f}%", TXT, 16)
    T(ax, 270, 365, "margin = yF(x) / Σα, in [−1, 1], positive when correct", TXT, 15)
    T(ax, 270, 400, "boosting keeps raising the smallest margins", GRN, 16)
    save(fig, "lec05-kp25-margin")

def f_noise():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    ck = [1, 3, 10, 30, 100, 300, 1000, 2000]; res = {}
    for flip, c in ((0.0, GRN), (0.15, RED)):
        r = []
        for s in range(5):
            Xn, yl, y0 = gauss20(200, 10 + s, flip=flip); Xte, ytl, yt0 = gauss20(400, 50 + s)
            o, al, Pp = adaboost(Xn, yl, 2000, s, ck, Xte, yt0, stumps="best"); r.append([t[2] for t in o])
        res[flip] = np.mean(r, 0); ax.plot(ck, res[flip], "o-", color=c, lw=2.6, ms=6, label=f"{int(flip*100)}% flipped labels")
    ax.set_xscale("log"); ax.set_ylim(0, 0.4); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlabel("rounds (log scale)", color=TXT, fontsize=fpx(15)); ax.set_ylabel("test error (mean of 5 runs)", color=TXT, fontsize=fpx(14))
    cap(fig, h, [(352, f"clean labels: {res[0.0][-1]*100:.1f}% at the end", GRN, 16, True), (386, f"15% flipped: best {res[0.15].min()*100:.1f}% at round {ck[int(np.argmin(res[0.15]))]}, {res[0.15][-1]*100:.1f}% at 2000", RED, 16, True), (420, "after 2000 rounds 36% of the weight sits on the 15.5% flipped points", RED, 15, True)])
    save(fig, "lec05-kp25-noise"); return res[0.0].round(3).tolist(), res[0.15].round(3).tolist()

def f_neg():
    fig, ax = blank(540, 420)
    a = alpha(0.7)
    T(ax, 270, 30, "a weak classifier with weighted error P = 0.7", TXT, 17)
    T(ax, 270, 80, f"α = ½ ln(0.3/0.7) = {a:.4f}", RED, 22)
    T(ax, 270, 135, "negative: its vote enters the sum with the sign flipped", VIO2, 16)
    T(ax, 270, 200, "−0.4236 · φ(x)  =  +0.4236 · (−φ(x))", TXT, 20)
    T(ax, 270, 250, "the inverted classifier has P = 0.3", GRN, 17)
    T(ax, 270, 305, "update: points φ gets wrong shrink (×0.6547)", TXT, 16)
    T(ax, 270, 340, "points φ gets right grow (×1.5275)", TXT, 16)
    T(ax, 270, 385, "the same numbers as the inverted classifier", MUT, 15, False)
    save(fig, "lec05-kp25-neg")

def f_practice():
    fig, ax = blank(540, 330)
    T(ax, 270, 40, "5 samples with equal weights 0.2; one is misclassified", TXT, 18)
    T(ax, 270, 90, "weighted error P = 0.2", TXT, 19)
    T(ax, 270, 160, "question 1: α for P = 0.2", RED, 18)
    T(ax, 270, 210, "question 2: new weights after the update and normalization", RED, 17)
    T(ax, 270, 270, "wᵢ ← wᵢ exp(−yᵢ α φ(xᵢ)) / Z", MUT, 16, False)
    save(fig, "lec05-kp25-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    a = alpha(0.2)
    L = [(f"α = ½ ln(0.8/0.2) = ½ ln 4 = {a:.4f}", GRN), ("e^α = 2,   e^−α = 0.5", TXT), ("wrong: 0.2 × 2 = 0.4;  right (×4): 0.2 × 0.5 = 0.1 each", TXT), ("Z = 0.4 + 4 × 0.1 = 0.8", TXT), ("normalized: wrong 0.5,  right 0.125 each", GRN), ("the misclassified sample now holds half the weight", RED)]
    for i, (t, c) in enumerate(L): T(ax, 270, 40 + i * 58, t, c, 15)
    save(fig, "lec05-kp25-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
