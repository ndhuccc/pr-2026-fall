import numpy as np
def unit(X): return X / np.linalg.norm(X, axis=1, keepdims=True)
def pnn_scores(Xtr, ytr, Xte, h, priors=None):
    """normalised PNN: score_m = P_m/N_m * sum_i exp((x_i.x - 1)/h^2)."""
    A = unit(Xtr); B = unit(Xte); K = np.exp((B @ A.T - 1) / h ** 2); cl = np.unique(ytr); S = []
    for c in cl:
        m = ytr == c; P = (m.mean() if priors is None else priors[c]); S.append(P / m.sum() * K[:, m].sum(1))
    return cl, np.array(S).T
def pnn_pred(Xtr, ytr, Xte, h, priors=None): cl, S = pnn_scores(Xtr, ytr, Xte, h, priors); return cl[S.argmax(1)]
def angdata(n, seed, mu=(40, 110), sd=25):
    rng = np.random.default_rng(seed); th = np.r_[rng.normal(mu[0], sd, n), rng.normal(mu[1], sd, n)] * np.pi / 180
    r = rng.uniform(0.5, 3.0, 2 * n); return np.c_[r * np.cos(th), r * np.sin(th)], np.r_[np.zeros(n), np.ones(n)]
if __name__ == "__main__":
    x = np.array([0.6, 0.8]); xi = np.array([1.0, 0.0]); h = 0.8
    d2 = ((x - xi) ** 2).sum(); print("d2", d2, "2-2dot", 2 - 2 * x @ xi, "fA", np.exp(-d2 / (2 * h * h)), "fB", np.exp((x @ xi - 1) / h ** 2))
    x2 = np.array([1.2, 1.6]); d2 = ((x2 - xi) ** 2).sum(); print("non-unit d2", d2, "fA", np.exp(-d2 / (2 * h * h)), "fB", np.exp((x2 @ xi - 1) / h ** 2))
    ang = lambda deg: np.array([np.cos(np.radians(deg)), np.sin(np.radians(deg))])
    A = [20, 40, 60]; B = [100, 120]; xt = ang(70); h = 0.5
    yA = [float(np.exp((ang(a) @ xt - 1) / h ** 2)) for a in A]; yB = [float(np.exp((ang(b) @ xt - 1) / h ** 2)) for b in B]
    print("yA", np.round(yA, 4), "yB", np.round(yB, 4), "outA", 0.5 / 3 * sum(yA), "outB", 0.5 / 2 * sum(yB))
    Xtr, ytr = angdata(50, 0); Xte, yte = angdata(500, 1)
    for hh in (0.02, 0.05, 0.1, 0.2, 0.3, 0.5, 1.0, 2.0, 5.0):
        print("h", hh, "train", round(float((pnn_pred(Xtr, ytr, Xtr, hh) == ytr).mean()), 3), "test", round(float((pnn_pred(Xtr, ytr, Xte, hh) == yte).mean()), 3))
    # Bayes-ish reference: nearest-by-angle threshold
    th = np.degrees(np.arctan2(Xte[:, 1], Xte[:, 0])); print("angle threshold 75 deg acc", float(((th > 75) == (yte == 1)).mean()))
    for n in (2, 5, 10, 25, 50, 200):
        accs = []
        for s in range(20):
            Xa, ya = angdata(n, 100 + s); accs.append((pnn_pred(Xa, ya, Xte, 0.3) == yte).mean())
        print("N per class", n, "mean test", round(float(np.mean(accs)), 3), "sd", round(float(np.std(accs)), 3))
    rng = np.random.default_rng(0); th = rng.uniform(0, 2 * np.pi, 400); r = np.r_[rng.normal(1, 0.15, 200), rng.normal(2.2, 0.2, 200)]
    Xr = np.c_[r * np.cos(th), r * np.sin(th)]; yr = np.r_[np.zeros(200), np.ones(200)]; idx = rng.permutation(400); tr, te = idx[:200], idx[200:]
    print("rings normalised PNN acc", float((pnn_pred(Xr[tr], yr[tr], Xr[te], 0.3) == yr[te]).mean()))
    print("ops per test point N*l:", {(N, l): N * l for N, l in ((100, 2), (10000, 10), (1000000, 100))})
    # practice
    xa = np.array([1., 0]); xb = np.array([0., 1]); xt = np.array([0.8, 0.6])
    for hh in (1.0, 0.2): print("practice h", hh, np.exp((xa @ xt - 1) / hh ** 2), np.exp((xb @ xt - 1) / hh ** 2))
