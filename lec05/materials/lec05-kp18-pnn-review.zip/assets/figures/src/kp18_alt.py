ALT = {
 "parzen": ("一維五個訓練點各放一個高斯核（細線），平均起來是估計的密度（粗線），核寬 0.4。", "Five one-dimensional training points each carry a Gaussian kernel (thin lines) whose average is the estimated density (thick line), width 0.4."),
 "circle": ("單位圓上兩個向量 x=(0.6,0.8) 與 xᵢ=(1,0) 與連接它們的弦：距離平方 0.8 = 2 − 2×0.6。", "Two vectors x=(0.6,0.8) and xᵢ=(1,0) on the unit circle with the chord between them: squared distance 0.8 = 2 − 2×0.6."),
 "kernels": ("距離形式與內積形式的高斯核：單位向量時都是 0.5353；非單位向量 (1.2,1.6) 時為 0.1312 對 1.3668。", "The Gaussian kernel in distance form and inner-product form: both 0.5353 for a unit vector and 0.1312 against 1.3668 for the non-unit vector (1.2,1.6)."),
 "arch": ("PNN 架構：兩個輸入節點、五個隱藏節點（三個 A 類、兩個 B 類）、兩個輸出節點，輸出只連同類的隱藏節點。", "PNN architecture: two input nodes, five hidden nodes (three of class A and two of class B) and two output nodes, each output connected only to the hidden nodes of its class."),
 "toy": ("測試向量 70° 的小例：五個隱藏輸出，A 類輸出 0.2943 大於 B 類 0.2062。", "The toy example with a test vector at 70°: five hidden outputs and an A output of 0.2943 larger than the B output of 0.2062."),
 "hcurve": ("PNN 準確率對核寬 h：訓練點與新點；h=0.02 新點 89.6%，h 從 0.1 到 1 約 91.6%，虛線為 75° 單一切點的 91.9%。", "PNN accuracy against kernel width h on training and new points: 89.6% on new points at h=0.02 and about 91.6% for h from 0.1 to 1, with the dashed line at 91.9% for a single cut at 75°."),
 "nsub": ("每類訓練點數 2、5、10、25、50、200 的新點準確率（20 次平均與標準差）：88.3% 升到 92.0%。", "Accuracy on new points for 2, 5, 10, 25, 50 and 200 training points per class (mean and sd of 20 draws): from 88.3% to 92.0%."),
 "cost": ("成本表：N=100、l=2 為 200 次與 1.6 KB；N=10⁴、l=10 為 10⁵ 次與 0.8 MB；N=10⁶、l=100 為 10⁸ 次與 0.8 GB。", "Cost table: N=100, l=2 takes 200 operations and 1.6 KB; N=10⁴, l=10 takes 10⁵ and 0.8 MB; N=10⁶, l=100 takes 10⁸ and 0.8 GB."),
 "rings": ("左：只差在半徑的兩個同心環；右：正規化後兩類都落在單位圓上，PNN 只對 49.5%。", "Left: two concentric rings that differ only in radius; right: after normalization both classes sit on the unit circle and the PNN is only 49.5% right."),
 "practice": ("練習圖：訓練向量 (1,0)、(0,1)，測試向量 (0.8,0.6)，h=1 與 h=0.2 各屬哪一類。", "Practice figure: training vectors (1,0) and (0,1), test vector (0.8,0.6); which class for h=1 and h=0.2."),
 "practice-sol": ("h=1：輸出 0.409 對 0.335，A；h=0.2：0.0034 對 0.00002，A，比值約 148。", "h=1: outputs 0.409 against 0.335, class A; h=0.2: 0.0034 against 0.00002, class A with a ratio of about 148."),
}
