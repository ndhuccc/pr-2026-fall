import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums18 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
ang = lambda deg: np.array([np.cos(np.radians(deg)), np.sin(np.radians(deg))])

def f_parzen():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    pts = np.array([1.0, 1.6, 2.0, 3.6, 4.0]); hh = 0.4; x = np.linspace(0, 5.5, 500); tot = np.zeros_like(x)
    for p in pts:
        k = np.exp(-(x - p) ** 2 / (2 * hh ** 2)) / (np.sqrt(2 * np.pi) * hh) / len(pts); tot += k; ax.plot(x, k, color=A_C, lw=1.6, alpha=0.8)
    ax.plot(x, tot, color=RED, lw=3.4, label="estimate = average of the kernels"); ax.plot(pts, np.zeros(5) - 0.01, "o", color=A_C, ms=10, clip_on=False)
    ax.set_ylim(-0.03, 0.55); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlabel("x", color=TXT, fontsize=fpx(16)); ax.set_ylabel("density", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(345, "5 training points ●, one Gaussian kernel on each", TXT, 17, True), (382, "p̂(x | ω) = (1/N) Σ kernel(x − xᵢ), width h = 0.4", RED, 16, True), (415, "one kernel per training point: one neuron per point", MUT, 15, False)])
    save(fig, "lec05-kp18-parzen")

def f_circle():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 90, 10, 360, 290); ax.set_xlim(-1.35, 1.35); ax.set_ylim(-0.3, 1.35); ax.set_aspect("equal"); ax.axis("off")
    th = np.linspace(0, np.pi, 200); ax.plot(np.cos(th), np.sin(th), color=MUT, lw=2)
    x = np.array([0.6, 0.8]); xi = np.array([1.0, 0.0])
    for v, c, t in ((x, RED, "x = (0.6, 0.8)"), (xi, A_C, "xᵢ = (1, 0)")):
        ax.annotate("", xy=v, xytext=(0, 0), arrowprops=dict(arrowstyle="-|>", color=c, lw=3)); ax.plot([v[0]], [v[1]], "o", color=c, ms=9)
    ax.plot([x[0], xi[0]], [x[1], xi[1]], color=GRN, lw=2.6, ls=(0, (4, 3))); ax.text(0.5, 0.95, "x", color=RED, fontsize=fpx(19), fontweight="bold"); ax.text(1.03, -0.12, "xᵢ", color=A_C, fontsize=fpx(19), fontweight="bold"); ax.text(0.92, 0.45, "chord", color=GRN, fontsize=fpx(15), ha="left")
    cap(fig, h, [(335, "both vectors have length 1", TXT, 17, True), (370, "‖x − xᵢ‖² = 1 + 1 − 2 xᵢᵀx = 2 − 2 · 0.6 = 0.8", GRN, 18, True), (405, "squared distance has become an inner product", MUT, 16, False)])
    save(fig, "lec05-kp18-circle")

def f_kernels():
    fig, ax = blank(540, 400)
    for x, t in zip((150, 310, 450), ("", "distance form", "inner-product form")): ax.text(x, 28, t, color=MUT, fontsize=fpx(16), ha="center")
    h = 0.8
    rows = [("x = (0.6, 0.8), unit", 0.8, 0.5353, 0.5353, GRN), ("x = (1.2, 1.6), not unit", 2.6, 0.1312, 1.3668, RED)]
    for i, (lab, d2, a, b, c) in enumerate(rows):
        y = 100 + i * 100; ax.text(12, y - 20, lab, color=TXT, fontsize=fpx(16), fontweight="bold"); ax.text(12, y + 14, f"‖x − xᵢ‖² = {d2}", color=MUT, fontsize=fpx(15))
        ax.text(310, y, f"{a:.4f}", color=c, fontsize=fpx(24), ha="center", va="center", fontweight="bold"); ax.text(450, y, f"{b:.4f}", color=c, fontsize=fpx(24), ha="center", va="center", fontweight="bold")
    ax.text(270, 320, "xᵢ = (1, 0), h = 0.8", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.text(270, 358, "the two forms agree only when the vectors are normalized", color=RED, fontsize=fpx(16), ha="center", fontweight="bold")
    save(fig, "lec05-kp18-kernels")

def f_arch():
    fig, ax = blank(540, 440)
    ax.text(70, 22, "input", color=MUT, fontsize=fpx(15), ha="center"); ax.text(270, 22, "hidden: one per training point", color=MUT, fontsize=fpx(15), ha="center"); ax.text(480, 22, "output", color=MUT, fontsize=fpx(15), ha="center")
    ins = [(70, 150), (70, 260)]; hid = [(270, 70 + i * 62, c) for i, c in enumerate((A_C, A_C, A_C, B_C, B_C))]; outs = [(480, 140, A_C, "A"), (480, 290, B_C, "B")]
    for (x, y) in ins:
        ax.add_patch(Circle((x, y), 20, fc="none", ec=TXT, lw=2.4))
    ax.text(70, 150, "x₁", color=TXT, fontsize=fpx(17), ha="center", va="center", fontweight="bold"); ax.text(70, 260, "x₂", color=TXT, fontsize=fpx(17), ha="center", va="center", fontweight="bold")
    for i, (x, y, c) in enumerate(hid):
        for (xi, yi) in ins: ax.plot([xi + 20, x - 22], [yi, y], color=MUT, lw=0.9, alpha=0.6)
        ax.add_patch(Circle((x, y), 22, fc="none", ec=c, lw=2.6)); ax.text(x, y, f"y{i+1}", color=TXT, fontsize=fpx(16), ha="center", va="center", fontweight="bold")
        tgt = outs[0] if i < 3 else outs[1]; ax.plot([x + 22, tgt[0] - 22], [y, tgt[1]], color=c, lw=1.8)
    for (x, y, c, t) in outs:
        ax.add_patch(Circle((x, y), 24, fc="none", ec=c, lw=2.8)); ax.text(x, y, t, color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    ax.text(270, 360, "hidden weights = the training vectors xₖ themselves", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 393, "yₖ = exp((xₖᵀx − 1) / h²);  outputₘ = P(ωₘ)/Nₘ · Σ yₖ", color=RED, fontsize=fpx(15), ha="center", fontweight="bold")
    ax.text(270, 425, "output nodes connect only to the hidden nodes of their class", color=MUT, fontsize=fpx(14), ha="center")
    save(fig, "lec05-kp18-arch")

def f_toy():
    fig, ax = blank(540, 440)
    hh = 0.5; A = [20, 40, 60]; B = [100, 120]; xt = ang(70)
    ax.text(270, 26, "test vector at 70°,  h = 0.5,  equal priors 0.5", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    heads = ["training vector", "class", "xₖᵀx", "yₖ"]; xs = [70, 190, 310, 440]
    for x, t in zip(xs, heads): ax.text(x, 62, t, color=MUT, fontsize=fpx(15), ha="center")
    rows = [(a, "A") for a in A] + [(b, "B") for b in B]
    for i, (a, c) in enumerate(rows):
        v = ang(a); d = float(v @ xt); y = np.exp((d - 1) / hh ** 2); yy = 100 + i * 42; col = A_C if c == "A" else B_C
        for x, t in zip(xs, (f"{a}°", c, f"{d:.4f}", f"{y:.4f}")): ax.text(x, yy, t, color=col if x == 190 else TXT, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
    yA = [np.exp((ang(a) @ xt - 1) / hh ** 2) for a in A]; yB = [np.exp((ang(b) @ xt - 1) / hh ** 2) for b in B]
    ax.text(270, 335, f"output A = 0.5/3 · {sum(yA):.4f} = {0.5/3*sum(yA):.4f}", color=A_C, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(270, 372, f"output B = 0.5/2 · {sum(yB):.4f} = {0.5/2*sum(yB):.4f}", color=B_C, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(270, 415, "the larger output wins: class A", color=GRN, fontsize=fpx(18), ha="center", fontweight="bold")
    save(fig, "lec05-kp18-toy")

def f_hcurve():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    Xtr, ytr = N.angdata(50, 0); Xte, yte = N.angdata(500, 1); hs = [0.02, 0.05, 0.1, 0.2, 0.3, 0.5, 1.0, 2.0, 5.0]
    tr = [(N.pnn_pred(Xtr, ytr, Xtr, v) == ytr).mean() for v in hs]; te = [(N.pnn_pred(Xtr, ytr, Xte, v) == yte).mean() for v in hs]
    ax.semilogx(hs, tr, "o-", color=A_C, lw=2.8, label="training points"); ax.semilogx(hs, te, "s-", color=RED, lw=2.8, label="new points")
    ax.axhline(0.919, color=GRN, ls=(0, (4, 3)), lw=2); ax.text(0.021, 0.921, "one cut at 75°: 0.919", color=GRN, fontsize=fpx(14))
    ax.set_ylim(0.85, 0.97); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="lower right"); ax.set_xlabel("kernel width h", color=TXT, fontsize=fpx(16)); ax.set_ylabel("accuracy", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "two classes by direction, 100 training and 1000 new points", TXT, 16, True), (382, "h = 0.02: 89.6%;   h = 0.1 to 1: about 91.6%", RED, 18, True), (415, "only a very small h hurts; this easy data is insensitive to h", MUT, 15, False)])
    save(fig, "lec05-kp18-hcurve"); return tr, te

def f_nsub():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 90, 20, 420, 245); axstyle(ax)
    Xte, yte = N.angdata(500, 1); ns = [2, 5, 10, 25, 50, 200]; m = []; sd = []
    for n in ns:
        a = [(N.pnn_pred(*N.angdata(n, 100 + s), Xte, 0.3) == yte).mean() for s in range(20)]; m.append(np.mean(a)); sd.append(np.std(a))
    ax.errorbar(range(6), m, yerr=sd, fmt="o-", color=RED, lw=2.8, ms=9, capsize=4, ecolor=TXT); ax.set_xticks(range(6)); ax.set_xticklabels([str(n) for n in ns], fontsize=fpx(16)); ax.set_ylim(0.8, 0.96)
    for i, v in enumerate(m): ax.text(i, v + 0.012, f"{v*100:.1f}", color=TXT, fontsize=fpx(14), ha="center", fontweight="bold")
    ax.set_xlabel("training points per class (= half the hidden nodes)", color=TXT, fontsize=fpx(15)); ax.set_ylabel("accuracy on new points", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(345, "mean of 20 random training sets, bars: sd", TXT, 16, True), (382, "2 per class: 88.3% (sd 0.07)   10 per class: 91.8%", RED, 17, True), (415, "most of the accuracy arrives with few nodes on this easy data", MUT, 15, False)])
    save(fig, "lec05-kp18-nsub"); return m, sd

def f_cost():
    fig, ax = blank(540, 400)
    heads = ["points N", "inputs l", "work / test", "memory"]; xs = [80, 190, 335, 465]
    for x, t in zip(xs, heads): ax.text(x, 30, t, color=MUT, fontsize=fpx(13), ha="center")
    rows = [(100, 2, "200", "1.6 KB"), (10000, 10, "100,000", "0.8 MB"), (1000000, 100, "100,000,000", "0.8 GB")]
    for i, (n, l, o, m) in enumerate(rows):
        y = 90 + i * 70
        for x, t, c in zip(xs, (f"{n:,}", str(l), o, m), (TXT, TXT, RED, RED)): ax.text(x, y, t, color=c, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
    ax.text(270, 305, "work = N · l multiply-adds, memory = N · l numbers", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 340, "no training loop, but every training point is kept", color=GRN, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 375, "learning cost moved to inference cost", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp18-cost")

def f_rings():
    w, h = 540, 440
    fig = new_fig(w, h); a1 = panel(fig, w, h, 25, 25, 230, 230); a2 = panel(fig, w, h, 285, 25, 230, 230)
    rng = np.random.default_rng(0); th = rng.uniform(0, 2 * np.pi, 400); r = np.r_[rng.normal(1, 0.15, 200), rng.normal(2.2, 0.2, 200)]; X = np.c_[r * np.cos(th), r * np.sin(th)]
    for a, P in ((a1, X), (a2, N.unit(X))):
        a.plot(P[:200, 0], P[:200, 1], "o", color=A_C, ms=4, alpha=0.8); a.plot(P[200:, 0], P[200:, 1], "s", color=B_C, ms=4, alpha=0.6); a.set_aspect("equal"); a.set_xticks([]); a.set_yticks([]); a.set_xlim(-3, 3) if a is a1 else a.set_xlim(-1.4, 1.4); a.set_ylim(-3, 3) if a is a1 else a.set_ylim(-1.4, 1.4)
    cap(fig, h, [(295, "left: two rings that differ only in radius", TXT, 17, True), (330, "right: after unit-length normalization", TXT, 17, True), (370, "both classes sit on the same circle: 49.5% right", RED, 19, True), (405, "length carried the class; normalization threw it away", MUT, 15, False)])
    save(fig, "lec05-kp18-rings")

def f_practice():
    fig, ax = blank(540, 330)
    ax.text(270, 40, "training vectors  x_A = (1, 0),  x_B = (0, 1)", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 95, "test vector x = (0.8, 0.6),  equal priors 0.5", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 155, "yₖ = exp((xₖᵀx − 1) / h²),  output = 0.5 · y", color=MUT, fontsize=fpx(17), ha="center")
    ax.text(270, 220, "question 1: h = 1, which class?", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 265, "question 2: h = 0.2, which class, and what changes?", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    save(fig, "lec05-kp18-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("h = 1:  x_Aᵀx = 0.8,  x_Bᵀx = 0.6", "", TXT), ("y_A = e^(−0.2) = 0.819,  y_B = e^(−0.4)", "= 0.670", TXT), ("outputs 0.409 against 0.335", "→ class A", GRN), ("h = 0.2:  y_A = e^(−5) = 0.0067,  y_B = e^(−10)", "= 0.000045", TXT), ("outputs 0.0034 against 0.00002", "→ class A, ratio 148", GRN)]
    for i, (a, b, c) in enumerate(L):
        y = 40 + i * 62; ax.text(12, y, a, color=c, fontsize=fpx(14), va="center", fontweight="bold"); ax.text(12, y + 26, b, color=c, fontsize=fpx(14), va="center", fontweight="bold") if b else None
    ax.text(270, 365, "a smaller h widens the gap between the outputs", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp18-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, [np.round(a, 3).tolist() for a in r])
            except Exception as e: print("FAILED", n, e)
