import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums9 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
sg = lambda v: 1 / (1 + np.exp(-v))
def fm(v, d=3):
    if abs(v) < 0.5 * 10 ** (-d): v = 0.0
    return f"{v:.{d}f}".replace("-", "−")
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")

def f_loss():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 245); axstyle(ax)
    o = np.linspace(0.005, 0.995, 400)
    ax.plot(o, 0.5 * (1 - o) ** 2, color=A_C, lw=3, label="squared error ½(1−ŷ)²"); ax.plot(o, -np.log(o), color=RED, lw=3, label="cross-entropy −ln ŷ")
    ax.set_ylim(0, 7.2); ax.set_xlim(0, 1); ax.legend(fontsize=fpx(16), frameon=False, labelcolor=TXT, loc="upper right")
    ax.set_xlabel("network output ŷ  (target y = 1)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("loss", color=TXT, fontsize=fpx(16))
    ax.text(0.6, 0.35, "stays below 0.5", color=A_C, fontsize=fpx(15), ha="center")
    cap(fig, h, [(345, "ŷ = 0.001:  squared 0.499,  cross-entropy 6.908", TXT, 17, True), (380, "error 0.9 vs 0.1 → squared 0.81 vs 0.01, 81 times", MUT, 16, False)])
    save(fig, "lec05-kp09-loss")

def f_mse_delta():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 90, 25, 420, 245); axstyle(ax)
    v = np.linspace(-10, 8, 500); o = sg(v)
    ax.plot(v, (1 - o) * o * (1 - o), color=A_C, lw=3)
    ax.axvspan(-10, -4, color=RED, alpha=0.18); ax.text(-7, 0.13, "confidently wrong", color=RED, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.set_xlim(-10, 8); ax.set_ylim(0, 0.16); ax.set_xlabel("weighted sum net  (target y = 1)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("δ (squared error)", color=TXT, fontsize=fpx(16))
    ax.plot([-10], [(1 - sg(-10)) ** 2 * sg(-10)], marker="o", color=RED, ms=9)
    cap(fig, h, [(345, "net = −10: ŷ = 0.000045, δ = 0.000045", RED, 18, True), (380, "the error is almost 1 but the signal almost 0", MUT, 16, False)])
    save(fig, "lec05-kp09-mse-delta")

def f_delta_table():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    heads = ["net", "ŷ", "δ squared", "δ cross-ent."]; xs = [50, 160, 300, 440]
    for x, t in zip(xs, heads): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center")
    for i, net in enumerate((-10, -5, -2, 0, 2, 5)):
        o = sg(net); y = 72 + i * 50
        vals = [str(net).replace("-", "−"), f"{o:.4f}" if o > 1e-3 else f"{o:.5f}", f"{(1 - o) * o * (1 - o):.5f}", f"{1 - o:.4f}"]
        cols = [TXT, TXT, A_C, RED]
        for x, t, c in zip(xs, vals, cols): ax.text(x, y, t, color=c, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
    ax.text(270, 385, "target y = 1;  both δ defined as −∂J/∂net", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp09-delta-table")

def f_train():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 245); axstyle(ax)
    for kind, c, lab in (("mse", A_C, "squared error"), ("ce", RED, "cross-entropy")):
        p = np.array([0, -3.0]); ys = [float(N.out(p, np.array([2.0]))[0])]
        for e in range(120):
            d = N.delta(p, kind); p = p + 0.5 * np.array([d.mean(), (d * N.X).mean()]); ys.append(float(N.out(p, np.array([2.0]))[0]))
        ax.plot(range(121), ys, color=c, lw=3, label=lab)
    ax.axhline(0.5, color=MUT, ls=(0, (4, 3)), lw=1.4); ax.text(2, 0.52, "0.5", color=MUT, fontsize=fpx(15), ha="left")
    ax.legend(fontsize=fpx(16), frameon=False, labelcolor=TXT, loc="center left", bbox_to_anchor=(0.45, 0.28)); ax.set_xlim(0, 120); ax.set_ylim(0, 1.02)
    ax.set_xlabel("epoch", color=TXT, fontsize=fpx(17)); ax.set_ylabel("ŷ of the point x = 2", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(345, "start w = −3: all four points wrong", TXT, 17, True), (380, "all four right after:  cross-entropy 5 epochs,  squared error 85", RED, 17, True)])
    save(fig, "lec05-kp09-train")

def f_likelihood():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    heads = ["sample", "target y", "output ŷ", "p of the target", "−ln p"]; xs = [45, 130, 235, 350, 465]
    for x, t in zip(xs, heads): ax.text(x, 28, t, color=MUT, fontsize=fpx(16), ha="center")
    o = [0.9, 0.8, 0.3, 0.1]; y = [1, 1, 0, 0]
    for i in range(4):
        p = o[i] if y[i] else 1 - o[i]; r = 72 + i * 50
        for x, t in zip(xs, [str(i + 1), str(y[i]), f"{o[i]:.1f}", f"{p:.1f}", f"{-np.log(p):.3f}"]): ax.text(x, r, t, color=TXT, fontsize=fpx(18), ha="center", va="center", fontweight="bold")
    ax.plot([20, 520], [262, 262], color=MUT, lw=1)
    ax.text(235, 295, "product of p:", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold"); ax.text(350, 295, "0.4536", color=A_C, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(235, 340, "sum of −ln p:", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold"); ax.text(465, 340, "0.7905", color=RED, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(270, 385, "−ln 0.4536 = 0.7905: the cross-entropy is the negative log-likelihood", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp09-likelihood")

def f_softmax():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 235); axstyle(ax)
    v = np.array([2.0, 1.0, 0.1]); e = np.exp(v); s = e / e.sum(); d = np.array([1, 0, 0]) - s
    x = np.arange(3); ax.bar(x - 0.27, v, width=0.25, color=MUT, label="net v"); ax.bar(x, s, width=0.25, color=A_C, label="output ŷ"); ax.bar(x + 0.27, d, width=0.25, color=RED, label="δ = y − ŷ")
    ax.set_xticks(x); ax.set_xticklabels(["class 1", "class 2", "class 3"], fontsize=fpx(16)); ax.axhline(0, color=MUT, lw=1)
    ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper right")
    for i in range(3):
        ax.text(i, s[i] + 0.06 if i else s[i] + 0.06, fm(s[i], 3), color=A_C, fontsize=fpx(14), ha="center", fontweight="bold") if False else None
    cap(fig, h, [(335, "ŷ = (0.659, 0.242, 0.099), sum = 1", TXT, 18, True), (372, "δ = (0.341, −0.242, −0.099)", RED, 18, True), (408, "checked against numerical differences of J = −ln ŷ₁", MUT, 15, False)])
    save(fig, "lec05-kp09-softmax")

def f_lsfit():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 55, 25, 450, 235); axstyle(ax)
    x = np.array([-3, -2, -1, 1, 2, 3, 40.]); t = np.array([0, 0, 0, 1, 1, 1, 1.])
    ax.plot(x[t == 0], t[t == 0], "o", color=A_C, ms=10); ax.plot(x[t == 1], t[t == 1], "s", color=B_C, ms=10)
    a, b = np.linalg.lstsq(np.c_[x, np.ones_like(x)], t, rcond=None)[0]
    xs = np.linspace(-5, 42, 100); ax.plot(xs, a * xs + b, color=RED, lw=2.6)
    ax.axvline((0.5 - b) / a, color=RED, ls=(0, (4, 3)), lw=2); ax.axvline(0, color=GRN, lw=2.6)
    ax.text((0.5 - b) / a + 0.8, 0.62, "LS boundary 1.40", color=RED, fontsize=fpx(15)); ax.text(0.8, 0.18, "CE boundary 0", color=GRN, fontsize=fpx(15))
    ax.annotate("outlier x = 40", xy=(40, 1), xytext=(26, 0.74), color=TXT, fontsize=fpx(15), arrowprops=dict(arrowstyle="-|>", color=TXT))
    ax.set_xlim(-5, 43); ax.set_ylim(-0.25, 1.25); ax.set_xlabel("x", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(340, "least squares line: the point x = 1 is misclassified", RED, 17, True), (375, "sigmoid + cross-entropy: all 7 points right", GRN, 17, True), (410, "the single outlier pulled the line flat", MUT, 15, False)])
    save(fig, "lec05-kp09-lsfit")

def f_posterior():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 240); axstyle(ax)
    x = np.linspace(-5, 5, 500); cols = [MUT, A_C, VIO2, RED]
    for n, c in zip((0, 1, 5, 20), cols):
        sd = 1 / np.sqrt(n + 0.25); m = n * 1.5 / (n + 0.25)
        ax.plot(x, np.exp(-0.5 * ((x - m) / sd) ** 2) / (sd * np.sqrt(2 * np.pi)), color=c, lw=3, label=f"n = {n}: sd {sd:.3f}")
    ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper left"); ax.set_xlim(-5, 5); ax.set_xlabel("weight w", color=TXT, fontsize=fpx(16)); ax.set_yticks([])
    cap(fig, h, [(345, "prior sd 2; every sample says w ≈ 1.5 (noise sd 1)", TXT, 17, True), (380, "posterior mean 1.2 → 1.43 → 1.48 as n = 1, 5, 20", MUT, 16, False), (412, "classifying averages over all w: a costly integral", MUT, 16, False)])
    save(fig, "lec05-kp09-posterior")

def f_init():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 25, 440, 240); axstyle(ax)
    ws = [-1, -2, -3, -4, -6, -8, -10]; ms = [11, 31, 85, 227, 1631, 11950, 88141]; ce = [2, 4, 5, 6, 9, 12, 14]
    x = np.arange(len(ws)); ax.bar(x - 0.2, ms, width=0.38, color=A_C, label="squared error"); ax.bar(x + 0.2, ce, width=0.38, color=RED, label="cross-entropy")
    ax.set_yscale("log"); ax.set_xticks(x); ax.set_xticklabels([str(v).replace("-", "−") for v in ws], fontsize=fpx(16)); ax.set_ylim(1, 4e5)
    ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper left"); ax.set_xlabel("starting weight w  (wrong sign, more and more confident)", color=TXT, fontsize=fpx(15)); ax.set_ylabel("epochs", color=TXT, fontsize=fpx(16))
    for i, v in enumerate(ms): ax.text(i - 0.2, v * 1.25, str(v), color=TXT, fontsize=fpx(12), ha="center", rotation=90, va="bottom")
    cap(fig, h, [(345, "epochs until all four points are classified correctly", TXT, 16, True), (380, "w = −10: 88141 epochs against 14", RED, 18, True)])
    save(fig, "lec05-kp09-init")

def f_practice():
    w, h = 540, 330
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    ax.text(270, 40, "one sigmoid output, target y = 1", color=TXT, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(270, 100, "weighted sum net = −4", color=TXT, fontsize=fpx(22), ha="center", fontweight="bold")
    ax.text(270, 160, "ŷ = 1 / (1 + e^4)", color=MUT, fontsize=fpx(18), ha="center")
    ax.text(270, 225, "find δ for squared error and for cross-entropy", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 275, "how many times larger is the second?", color=MUT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp09-practice")

def f_practice_sol():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    o = sg(-4.0); dm = (1 - o) * o * (1 - o); dc = 1 - o
    L = [("ŷ = σ(−4)", f"= {o:.4f}", TXT), ("δ squared = (1−ŷ)·ŷ(1−ŷ)", f"= {dm:.5f}", A_C), ("δ cross-ent. = 1 − ŷ", f"= {dc:.4f}", RED), ("ratio", f"= {dc / dm:.1f}", GRN)]
    for i, (a, b, c) in enumerate(L):
        y = 50 + i * 72; ax.text(20, y, a, color=c, fontsize=fpx(18), va="center", fontweight="bold"); ax.text(400, y, b, color=c, fontsize=fpx(20), va="center", fontweight="bold")
    ax.text(270, 360, "the sigmoid slope ŷ(1−ŷ) cancels in the cross-entropy δ", color=MUT, fontsize=fpx(14), ha="center")
    save(fig, "lec05-kp09-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try: fn()
            except Exception as e: print("FAILED", n, e)
