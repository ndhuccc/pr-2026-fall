import numpy as np
X = np.array([-2.0, -1.0, 1.0, 2.0]); Y = np.array([0.0, 0.0, 1.0, 1.0])
sig = lambda v: 1 / (1 + np.exp(-v))
def out(p, x=X): return sig(p[0] + p[1] * x)
def J_mse(p): o = out(p); return float(np.mean(0.5 * (Y - o) ** 2))
def J_ce(p):
    o = np.clip(out(p), 1e-12, 1 - 1e-12); return float(np.mean(-(Y * np.log(o) + (1 - Y) * np.log(1 - o))))
def delta(p, kind):
    o = out(p); return (Y - o) * o * (1 - o) if kind == "mse" else (Y - o)
def train(p0, kind, eta, n=200000, tol=1e-9):
    p = np.array(p0, float); hist = []; first = None
    for e in range(n):
        d = delta(p, kind); g = np.array([d.mean(), (d * X).mean()]); p = p + eta * g
        o = out(p); acc = int(((o > 0.5) == (Y > 0.5)).sum()); hist.append((J_mse(p), J_ce(p), acc))
        if acc == 4 and first is None: first = e + 1
    return p, hist, first
if __name__ == "__main__":
    for p0 in ((0, -1), (0, -2), (0, -3), (0, -4), (0, -6), (0, -8), (0, -10)):
        r = []
        for kind in ("mse", "ce"):
            p, h, f = train(p0, kind, 0.5, n=20000); r.append((kind, f, round(h[-1][0], 4)))
        print(p0, r, [round(float(v), 4) for v in out(p0)])
