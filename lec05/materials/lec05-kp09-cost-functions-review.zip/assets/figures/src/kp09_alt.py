ALT = {
 "loss": ("目標為 1 時兩種損失對輸出 ŷ 的曲線：平方誤差有上限 0.5，另一種損失 −ln ŷ 在 ŷ 趨近 0 時發散，ŷ=0.001 時為 6.908。", "Two losses against the output ŷ for target 1: the squared error is bounded by 0.5, the other loss −ln ŷ diverges as ŷ approaches 0, reaching 6.908 at ŷ=0.001."),
 "mse-delta": ("平方誤差的 δ 對加權和 net 的曲線：在 net 約 −0.7 有高峰 0.148，net=−10 時只有 0.000045，左側標示輸出錯到極端的區域。", "The squared-error δ against the weighted sum net: a peak of 0.148 near net −0.7 and only 0.000045 at net=−10, with the confidently wrong region shaded."),
 "delta-table": ("net 為 −10、−5、−2、0、2、5 時的 ŷ、平方誤差 δ 與交叉熵 δ；net=−10 時為 0.00005 對 1.0000。", "ŷ, the squared-error δ and the cross-entropy δ at net −10, −5, −2, 0, 2 and 5; 0.00005 against 1.0000 at net=−10."),
 "train": ("點 x=2 的輸出 ŷ 對 epoch：交叉熵很快升到 0.5 以上並接近 1，平方誤差先躺在 0 附近，到約 85 個 epoch 才越過 0.5。", "The output ŷ of the point x=2 against epochs: cross-entropy quickly rises above 0.5 and towards 1 while squared error lies near 0 and crosses 0.5 only near epoch 85."),
 "likelihood": ("四筆樣本的輸出、目標的機率與 −ln：相乘得 0.4536，−ln 加總得 0.7905。", "Outputs, probability of the target and −ln for four samples: the product is 0.4536 and the −ln values sum to 0.7905."),
 "softmax": ("v=(2,1,0.1) 的長條圖：輸出 ŷ=(0.659,0.242,0.099) 加總為 1，δ=y−ŷ=(0.341,−0.242,−0.099)。", "Bars for v=(2,1,0.1): the outputs ŷ=(0.659,0.242,0.099) sum to 1 and δ=y−ŷ=(0.341,−0.242,−0.099)."),
 "lsfit": ("七個一維點與一個離群點 x=40：平方誤差的直線在 1.40 切開並分錯 x=1，sigmoid 加交叉熵在 0 切開七點全對。", "Seven one-dimensional points with an outlier at x=40: the squared-error line cuts at 1.40 and misclassifies x=1, sigmoid with cross-entropy cuts at 0 and gets all seven right."),
 "posterior": ("n=0、1、5、20 筆資料時權重的分布，標準差 2、0.894、0.436、0.222，越來越尖，平均靠近 1.5。", "Distributions of the weight with n=0, 1, 5 and 20 samples, standard deviations 2, 0.894, 0.436 and 0.222, sharper each time with the mean approaching 1.5."),
 "init": ("七個起點 w=−1 到 −10 所需 epoch 數的對數長條圖：平方誤差 11 到 88141，交叉熵 2 到 14。", "Log bar chart of the epochs needed from seven starts w=−1 to −10: 11 to 88141 for squared error and 2 to 14 for cross-entropy."),
 "practice": ("練習圖：單一 sigmoid 輸出，目標 1，加權和 net=−4，要算兩種 δ 及倍數。", "Practice figure: a single sigmoid output, target 1 and weighted sum net=−4; find the two δ and their ratio."),
 "practice-sol": ("ŷ=0.0180，平方誤差 δ=0.01735，交叉熵 δ=0.9820，倍數 56.6。", "ŷ=0.0180, squared-error δ=0.01735, cross-entropy δ=0.9820 and ratio 56.6."),
}
