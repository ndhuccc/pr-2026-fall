Pattern Recognition, Chapter 4, KP26: The class imbalance problem (English version)

Slides: slides/lec05-kp26-imbalance-en.html (offline web page, open in a browser); slides/lec05-kp26-imbalance-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp26-imbalance-en-lecture.pdf (PDF), lec05-kp26-imbalance-en-reading.html (offline web page), lectures/lec05-kp26-imbalance-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
