"""KP08 deck: from the step to the backpropagation gradient. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp08"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:曲率":"term:Curvature","term:病態代價面":"term:Narrow valley","term:動量":"term:Momentum","term:指數加權平均":"term:Exponentially weighted average","term:自適應學習率":"term:Adaptive learning rate","term:quickprop":"term:quickprop","term:牛頓法":"term:Newton's method"})
from kp08_text import *

def side_page(u, t, fig, fx=60, cx=640, cw=580, rev=False):
    p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure(fig, fx, y); _, ids = stack(p, cx, y, cw, t["cards"]); step(p, *t["notes"])
    if rev: reveal(p, ids)
    return p

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    figs = ["valley","zigzag","mom-steps","expo","two-paths","alpha-curve","adaptive","compare","secant","practice","practice-sol"]
    for i, t in enumerate(PAGES):
        side_page(u, t, "lec05-kp08-" + figs[i], rev=(i in (9, 10)))
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
