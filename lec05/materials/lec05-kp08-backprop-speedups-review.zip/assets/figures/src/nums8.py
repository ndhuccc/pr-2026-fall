import numpy as np
H = np.array([1.0, 20.0])
W0 = np.array([-4.0, 1.0])
def J(w): return 0.5 * float(H @ (w * w))
def g(w): return H * w
def gd(mu, alpha=0.0, n=400, tol=1e-3, w0=W0):
    w = w0.copy(); dw = np.zeros(2); path = [w.copy()]
    for t in range(n):
        dw = alpha * dw - mu * g(w); w = w + dw; path.append(w.copy())
        if np.linalg.norm(w) < tol: break
    return np.array(path)
def steps(path, tol=1e-3):
    nr = np.linalg.norm(path, axis=1); k = np.where(nr < tol)[0]; return int(k[0]) if len(k) else None
def adaptive(mu0, ri=1.05, rd=0.7, c=1.04, n=2000, tol=1e-3, alpha=0.0):
    w = W0.copy(); mu = mu0; dw = np.zeros(2); path = [w.copy()]; mus = [mu]; Jp = J(w); skips = 0
    for t in range(n):
        dwn = alpha * dw - mu * g(w); wn = w + dwn; Jn = J(wn); r = Jn / Jp
        if r > c:
            mu *= rd; dw = np.zeros(2); skips += 1   # reject step, zero momentum
        else:
            if r < 1: mu *= ri
            w, dw, Jp = wn, dwn, Jn
        path.append(w.copy()); mus.append(mu)
        if np.linalg.norm(w) < tol: break
    return np.array(path), np.array(mus), skips
def quickprop(mu, amax=1.75, n=400, tol=1e-3):
    w = W0.copy(); gprev = None; dwp = np.zeros(2); path = [w.copy()]
    for t in range(n):
        gg = g(w); dw = np.zeros(2)
        for i in range(2):
            if dwp[i] != 0 and gprev is not None:
                den = gprev[i] - gg[i]
                a = amax if den == 0 else min(gg[i] / den, amax)
                dw[i] = a * dwp[i]
            else: dw[i] = -mu * gg[i]
        w = w + dw; gprev, dwp = gg, dw; path.append(w.copy())
        if np.linalg.norm(w) < tol: break
    return np.array(path)
if __name__ == "__main__":
    for mu in (0.05, 0.1, 0.15, 0.19, 0.2, 0.21):
        p = gd(mu); print("plain", mu, steps(p), len(p) - 1, np.linalg.norm(p[-1]))
    for a in (0, 0.1, 0.3, 0.5, 0.7, 0.8, 0.9, 0.95):
        p = gd(0.1, a); print("mom mu0.1", a, steps(p), np.linalg.norm(p[-1]))
    for mu in (0.05, 0.1, 0.15):
        for a in (0.5, 0.8):
            p = gd(mu, a); print("mom", mu, a, steps(p))
    p, m, s = adaptive(0.02); print("adaptive 0.02", steps(p), len(p) - 1, s, m[-1])
    p, m, s = adaptive(0.1); print("adaptive 0.1", steps(p), s, m.max())
    p, m, s = adaptive(0.25); print("adaptive 0.25", steps(p), s, m.max())
    p = quickprop(0.1); print("quickprop 0.1", steps(p), len(p) - 1)
    p = quickprop(0.05); print("quickprop 0.05", steps(p))
