ALT = {
 "valley": ("狹長谷底的等高線與普通梯度下降的軌跡：從 (−4, 1) 出發，在 w₂ 方向上下擺，走 100 步到達原點附近。", "Contours of the narrow valley with the path of plain gradient descent: starting at (−4, 1) it swings along w₂ and needs 100 steps to reach the origin."),
 "zigzag": ("前 15 步的 w₁ 與 w₂：w₁ 每步乘 0.92 穩穩變小；w₂ 每步乘 −0.6，正負交替地縮小。", "w₁ and w₂ over the first 15 steps: w₁ shrinks steadily by a factor 0.92 and w₂ shrinks with alternating sign by a factor −0.6."),
 "mom-steps": ("動量前三步的表：梯度、更新量、新的 w；第 2 步更新量為 (0.4864, 0)。", "Table of the first three momentum steps: gradient, update and new w; the update of step 2 is (0.4864, 0)."),
 "expo": ("權重 0.6^t 與 0.8^t 的長條圖，越久以前越小；固定梯度時總權重為 1/(1−α)，即 2.5 倍與 5 倍。", "Bar chart of the weights 0.6^t and 0.8^t that shrink for older gradients; with a fixed gradient the total weight is 1/(1−α), 2.5 and 5 times."),
 "two-paths": ("同一起點、同一 μ=0.08 的兩條軌跡：普通方法 100 步，α=0.6 的動量 28 步，動量的擺幅縮得更快。", "Two paths from the same start with the same μ=0.08: plain needs 100 steps and momentum with α=0.6 needs 28, with a faster-shrinking swing."),
 "alpha-curve": ("α=0、0.3、0.5、0.6、0.7、0.8、0.9、0.95 所需步數 100、65、36、28、44、63、137、247 的長條圖，0.6 最低。", "Bar chart of the steps needed for α=0, 0.3, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95: 100, 65, 36, 28, 44, 63, 137, 247, lowest at 0.6."),
 "adaptive": ("|w| 對步數的半對數曲線：普通 μ=0.02 要 411 步，自適應從 0.02 起步 61 步，從 0.12 起步 95 步，普通 μ=0.12 很快爆開。", "Semi-log curve of |w| against steps: plain μ=0.02 needs 411 steps, adaptive from 0.02 needs 61 and from 0.12 needs 95, and plain μ=0.12 quickly blows up."),
 "compare": ("五種做法的步數：普通 μ=0.02 為 411、自適應 61、普通 μ=0.08 為 100、動量 28、quickprop 5。", "Steps of five methods: plain μ=0.02 411, adaptive 61, plain μ=0.08 100, momentum 28 and quickprop 5."),
 "secant": ("沿 w₂ 的拋物線：普通步從 1 到 −0.6，再由兩次斜率 20 與 −12 估出 α=−0.375，下一步落在最低點 0。", "Parabola along w₂: an ordinary step from 1 to −0.6, then the slopes 20 and −12 give α=−0.375 and the next step lands on the minimum at 0."),
 "practice": ("練習圖：J、μ=0.08、α=0.6，列出第 1、2 步後的 w 與 Δw，要求第 3 步。", "Practice figure: J, μ=0.08 and α=0.6, with w and Δw after steps 1 and 2 and step 3 to find."),
 "practice-sol": ("第 3 步：g=(−3.1936, −12)，Δw=(0.54733, 0.96)，新的 w=(−2.6463, 0.36)。", "Step 3: g=(−3.1936, −12), Δw=(0.54733, 0.96) and the new w=(−2.6463, 0.36)."),
}
