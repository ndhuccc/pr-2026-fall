import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums8 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def fm(v, d=3):
    if abs(v) < 0.5 * 10 ** (-d): v = 0.0
    return f"{v:.{d}f}".replace("-", "−")
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def contours(ax, xl=(-4.8, 1.2), yl=(-1.3, 1.3)):
    xs = np.linspace(*xl, 300); ys = np.linspace(*yl, 200); X, Y = np.meshgrid(xs, ys)
    Z = 0.5 * (N.H[0] * X ** 2 + N.H[1] * Y ** 2)
    ax.contour(X, Y, Z, levels=[0.25, 1, 2.5, 5, 8], colors=MUT, linewidths=1.3, alpha=0.8)
    ax.set_xlim(*xl); ax.set_ylim(*yl); ax.set_aspect("equal"); axstyle(ax)
    ax.plot([0], [0], marker="*", color=TXT, ms=14, ls="none"); ax.plot([-4], [1], marker="o", color=TXT, ms=8, ls="none")
    ax.text(-4.0, 1.12, "start (−4, 1)", color=TXT, fontsize=fpx(15), ha="left"); ax.set_xlabel("w₁", color=TXT, fontsize=fpx(16)); ax.set_ylabel("w₂", color=TXT, fontsize=fpx(16), rotation=0, labelpad=10)

def f_valley():
    w, h = 540, 430
    fig = new_fig(w, h); ax = panel(fig, w, h, 75, 20, 450, 225); contours(ax)
    p = N.gd(0.08); ax.plot(p[:, 0], p[:, 1], color=RED, lw=1.8, marker="o", ms=3.5)
    fig.text(0.5, 1 - 318 / h, "plain gradient descent, μ = 0.08", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 353 / h, f"{N.steps(p)} steps to reach |w| < 0.001", color=RED, fontsize=fpx(22), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 392 / h, "J = ½(1·w₁² + 20·w₂²): steep in w₂, flat in w₁", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp08-valley")

def f_zigzag():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 30, 440, 255); axstyle(ax)
    p = N.gd(0.08)[:16]; t = np.arange(len(p))
    ax.plot(t, p[:, 0], color=A_C, lw=3, marker="o", ms=5, label="w₁: × 0.92 each step")
    ax.plot(t, p[:, 1], color=RED, lw=3, marker="o", ms=5, label="w₂: × (−0.6) each step")
    ax.axhline(0, color=MUT, lw=1.2); ax.legend(fontsize=fpx(16), frameon=False, labelcolor=TXT, loc="lower right")
    ax.set_xlabel("step", color=TXT, fontsize=fpx(17)); ax.set_xlim(0, 15)
    fig.text(0.5, 1 - 372 / h, "1 − μ·20 = 1 − 0.08·20 = −0.6     1 − μ·1 = 0.92", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 408 / h, "μ must stay below 2/20 = 0.1 or w₂ blows up", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp08-zigzag")

def f_mom_steps():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    p = N.gd(0.08, 0.6)
    heads = ["t", "gradient g", "Δw", "w after"]; xs = [30, 140, 300, 450]
    for x, t in zip(xs, heads): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center")
    for t in range(1, 4):
        g = N.g(p[t - 1]); dw = p[t] - p[t - 1]; y = 40 + (t - 1) * 100
        ax.text(30, y + 36, str(t), color=TXT, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
        ax.text(140, y + 36, f"({fm(g[0], 2)}, {fm(g[1], 1)})", color=TXT, fontsize=fpx(17), ha="center", va="center")
        ax.text(300, y + 36, f"({fm(dw[0], 4)}, {fm(dw[1], 2)})", color=TXT, fontsize=fpx(17), ha="center", va="center")
        ax.text(450, y + 36, f"({fm(p[t][0], 3)}, {fm(p[t][1], 2)})", color=TXT, fontsize=fpx(17), ha="center", va="center")
        ax.plot([10, 530], [y + 78, y + 78], color=MUT, lw=0.8, alpha=0.5)
    ax.text(270, 360, "Δw(t) = 0.6·Δw(t−1) − 0.08·g(t),   w starts at (−4, 1)", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    save(fig, "lec05-kp08-mom-steps")

def f_expo():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 30, 440, 250); axstyle(ax)
    t = np.arange(10)
    ax.bar(t - 0.2, 0.6 ** t, width=0.38, color=A_C, label="weight 0.6^t"); ax.bar(t + 0.2, 0.8 ** t, width=0.38, color=VIO2, label="weight 0.8^t")
    ax.legend(fontsize=fpx(16), frameon=False, labelcolor=TXT, loc="upper right"); ax.set_xlabel("t steps ago", color=TXT, fontsize=fpx(17)); ax.set_xticks(t)
    fig.text(0.5, 1 - 365 / h, "constant gradient: total weight 1 + α + α² + … = 1/(1−α)", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 400 / h, "α = 0.6 gives 2.5 times the step,  α = 0.8 gives 5 times", color=RED, fontsize=fpx(18), ha="center", fontweight="bold")
    save(fig, "lec05-kp08-expo")

def f_two_paths():
    w, h = 540, 430
    fig = new_fig(w, h); ax = panel(fig, w, h, 75, 20, 450, 225); contours(ax)
    p = N.gd(0.08); q = N.gd(0.08, 0.6)
    ax.plot(p[:, 0], p[:, 1], color=RED, lw=1.6, marker="o", ms=3, label="no momentum")
    ax.plot(q[:, 0], q[:, 1], color=GRN, lw=2.2, marker="o", ms=4, label="momentum α = 0.6")
    ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper right")
    fig.text(0.5, 1 - 318 / h, "same start, same μ = 0.08", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 358 / h, f"{N.steps(p)} steps   vs   {N.steps(q)} steps", color=GRN, fontsize=fpx(24), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 396 / h, "steps until |w| < 0.001", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp08-two-paths")

def f_alpha_curve():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 30, 430, 280); axstyle(ax)
    al = [0, 0.3, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95]; st = [N.steps(N.gd(0.08, a, n=800)) for a in al]
    cols = [RED if a == 0 else (GRN if a == 0.6 else A_C) for a in al]
    ax.bar(range(len(al)), st, color=cols, width=0.65); ax.set_xticks(range(len(al))); ax.set_xticklabels([str(a) for a in al], fontsize=fpx(16))
    for i, v in enumerate(st): ax.text(i, v + 5, str(v), color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.set_xlabel("momentum factor α  (μ = 0.08)", color=TXT, fontsize=fpx(17)); ax.set_ylabel("steps", color=TXT, fontsize=fpx(17)); ax.set_ylim(0, max(st) * 1.15)
    fig.text(0.5, 1 - 395 / h, "best near 0.6;  α ≥ 0.9 is slower than no momentum", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    save(fig, "lec05-kp08-alpha-curve")

def f_adaptive():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 30, 425, 250); axstyle(ax)
    nr = lambda p: np.linalg.norm(p, axis=1)
    p1 = N.gd(0.02, n=450); ax.plot(np.arange(len(p1)), nr(p1), color=RED, lw=2.4, label="plain μ=0.02")
    pa, ma, sa = N.adaptive(0.02); ax.plot(np.arange(len(pa)), nr(pa), color=GRN, lw=3, label="adaptive, starts at 0.02")
    pb, mb, sb = N.adaptive(0.12); ax.plot(np.arange(len(pb)), nr(pb), color=VIO2, lw=3, label="adaptive, starts at 0.12")
    pd = N.gd(0.12, n=12); ax.plot(np.arange(len(pd)), nr(pd), color=A_C, lw=2.4, ls=(0, (4, 3)), label="plain μ=0.12 blows up")
    ax.set_yscale("log"); ax.set_ylim(1e-3, 1e3); ax.set_xlim(0, 150); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="upper right")
    ax.set_xlabel("step", color=TXT, fontsize=fpx(17)); ax.set_ylabel("|w|", color=TXT, fontsize=fpx(17), rotation=0, labelpad=16)
    fig.text(0.5, 1 - 372 / h, f"steps: plain 0.02 → {N.steps(p1)},  adaptive 0.02 → {N.steps(pa)},  adaptive 0.12 → {N.steps(pb)}", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 405 / h, f"the 0.12 run rejected {sb} steps and cut μ by 30% each time", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp08-adaptive")

def f_compare():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 185, 30, 330, 275); axstyle(ax)
    labs = ["plain μ=0.02", "adaptive from 0.02", "plain μ=0.08", "momentum α=0.6", "quickprop"]
    vals = [N.steps(N.gd(0.02, n=2000)), N.steps(N.adaptive(0.02)[0]), N.steps(N.gd(0.08)), N.steps(N.gd(0.08, 0.6)), N.steps(N.quickprop(0.08))]
    cols = [RED, GRN, RED, GRN, VIO2]
    ax.barh(range(5), vals, color=cols, height=0.6); ax.set_yticks(range(5)); ax.set_yticklabels(labs, fontsize=fpx(16)); ax.invert_yaxis()
    for i, v in enumerate(vals): ax.text(v + 6, i, str(v), color=TXT, fontsize=fpx(18), va="center", fontweight="bold")
    ax.set_xlim(0, 480); ax.set_xlabel("steps to |w| < 0.001", color=TXT, fontsize=fpx(16))
    fig.text(0.5, 1 - 400 / h, "every speed-up costs extra memory or bookkeeping", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    save(fig, "lec05-kp08-compare"); return vals

def f_secant():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 250); axstyle(ax)
    x = np.linspace(-0.9, 1.15, 200); ax.plot(x, 10 * x ** 2, color=MUT, lw=2.5)
    pts = [1.0, -0.6, 0.0]
    for i, v in enumerate(pts): ax.plot([v], [10 * v ** 2], marker="o", color=[RED, A_C, GRN][i], ms=11, ls="none")
    ax.annotate("", xy=(-0.6, 3.6), xytext=(1.0, 10), arrowprops=dict(arrowstyle="-|>", color=RED, lw=2.4))
    ax.annotate("", xy=(0.0, 0.0), xytext=(-0.6, 3.6), arrowprops=dict(arrowstyle="-|>", color=GRN, lw=2.4))
    ax.text(1.0, 10.9, "w₂ = 1", color=TXT, fontsize=fpx(16), ha="center"); ax.text(-0.72, 4.4, "−0.6", color=TXT, fontsize=fpx(16), ha="center"); ax.text(0.12, 0.8, "0", color=TXT, fontsize=fpx(16))
    ax.set_xlabel("w₂ (w₁ fixed)", color=TXT, fontsize=fpx(17)); ax.set_ylabel("J", color=TXT, fontsize=fpx(17), rotation=0, labelpad=12); ax.set_ylim(-0.8, 12.5)
    fig.text(0.5, 1 - 368 / h, "step 1: ordinary step 1 → −0.6 (μ = 0.08)", color=RED, fontsize=fpx(16), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 398 / h, "step 2: α = −12 / (20 − (−12)) = −0.375,  Δ = −0.375 × (−1.6) = +0.6", color=GRN, fontsize=fpx(16), ha="center", fontweight="bold")
    fig.text(0.5, 1 - 425 / h, "lands exactly on the minimum of the parabola", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp08-secant")

def f_practice():
    w, h = 540, 330
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    p = N.gd(0.08, 0.6)
    ax.text(270, 36, "J = ½(w₁² + 20·w₂²),  μ = 0.08,  α = 0.6", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 88, f"after step 1:  w = ({fm(p[1][0], 2)}, {fm(p[1][1], 1)}),  Δw = ({fm(p[1][0]-p[0][0], 2)}, {fm(p[1][1]-p[0][1], 1)})", color=TXT, fontsize=fpx(18), ha="center")
    ax.text(270, 138, f"after step 2:  w = ({fm(p[2][0], 4)}, {fm(p[2][1], 1)}),  Δw = ({fm(p[2][0]-p[1][0], 4)}, {fm(p[2][1]-p[1][1], 1)})", color=TXT, fontsize=fpx(18), ha="center")
    ax.text(270, 200, "step 3: find g, Δw and w", color=RED, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 250, "g = (w₁, 20·w₂)   Δw(3) = 0.6·Δw(2) − 0.08·g", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp08-practice")

def f_practice_sol():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    p = N.gd(0.08, 0.6); g = N.g(p[2]); d2 = p[2] - p[1]; d3 = p[3] - p[2]
    L = [("g = (w₁, 20·w₂)", f"= ({fm(g[0], 4)}, {fm(g[1], 1)})", TXT),
         ("0.6·Δw(2)", f"= ({fm(0.6 * d2[0], 5)}, {fm(0.6 * d2[1], 1)})", TXT),
         ("−0.08·g", f"= ({fm(-0.08 * g[0], 5)}, {fm(-0.08 * g[1], 2)})", TXT),
         ("Δw(3)", f"= ({fm(d3[0], 5)}, {fm(d3[1], 2)})", RED),
         ("w after step 3", f"= ({fm(p[3][0], 4)}, {fm(p[3][1], 2)})", GRN)]
    for i, (a, b, c) in enumerate(L):
        y = 40 + i * 66; ax.text(20, y, a, color=c, fontsize=fpx(19), va="center", fontweight="bold"); ax.text(250, y, b, color=c, fontsize=fpx(19), va="center", fontweight="bold")
    ax.text(270, 375, "w₂ did not move in step 2, so its inertia term is 0", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp08-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r: print(n, r)
            except Exception as e: print("FAILED", n, e)
