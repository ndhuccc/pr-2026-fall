import numpy as np
from math import comb
def phi2(x): return np.array([x[0] ** 2, np.sqrt(2) * x[0] * x[1], x[1] ** 2])
def rings(n, seed, r=(1.0, 2.0), sd=0.25):
    rng = np.random.default_rng(seed); th = rng.uniform(0, 2 * np.pi, 2 * n); rr = np.r_[rng.normal(r[0], sd, n), rng.normal(r[1], sd, n)]
    return np.c_[rr * np.cos(th), rr * np.sin(th)], np.r_[-np.ones(n), np.ones(n)]
def K_lin(A, B): return A @ B.T
def K_poly(A, B, q=2): return (A @ B.T + 1) ** q
def K_rbf(A, B, g=0.5): return np.exp(-g * ((A[:, None, :] - B[None, :, :]) ** 2).sum(-1))
def K_tanh(A, B, b=2.0, c=1.0): return np.tanh(b * (A @ B.T) + c)
def fit(K, X, y, C=10.0):
    from sklearn.svm import SVC
    m = SVC(kernel="precomputed", C=C).fit(K(X, X), y); return m
def acc(m, K, Xtr, Xte, yte): return (m.predict(K(Xte, Xtr)) == yte).mean()
def minEig(K, X): return np.linalg.eigvalsh(K(X, X)).min()
if __name__ == "__main__":
    xi = np.array([1., 2.]); xj = np.array([3., -1.])
    print("phi", phi2(xi), phi2(xj), "yy", phi2(xi) @ phi2(xj), "xx^2", (xi @ xj) ** 2)
    Xtr, ytr = rings(60, 1); Xte, yte = rings(500, 2)
    for nm, K in (("lin", K_lin), ("poly2", K_poly), ("rbf.5", K_rbf)):
        m = fit(K, Xtr, ytr); print(nm, "train", (m.predict(K(Xtr, Xtr)) == ytr).mean(), "test", acc(m, K, Xtr, Xte, yte), "nSV", len(m.support_))
    print("z", [(float(phi2(p)[0] + phi2(p)[2]), float(p @ p)) for p in Xtr[:2]])
    print("explicit feature counts (poly deg q, dim l):")
    for l, q in ((2, 2), (10, 3), (100, 5), (784, 5)): print(l, q, comb(l + q, q))
