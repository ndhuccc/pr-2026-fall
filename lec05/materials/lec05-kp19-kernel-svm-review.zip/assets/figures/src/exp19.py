import numpy as np
from nums19 import *
Xtr, ytr = rings(60, 1); Xte, yte = rings(500, 2)
# formula check
K = K_rbf; m = fit(K, Xtr, ytr)
g = (m.dual_coef_ @ K(Xtr[m.support_], Xte)).ravel() + m.intercept_; print("g-vs-decision maxdiff", np.abs(g - m.decision_function(K(Xte, Xtr))).max())
print("n SV", len(m.support_), "dual_coef sign sum", float(m.dual_coef_.sum()))
# harder rings
Htr, hy = rings(60, 3, sd=0.45); Hte, hty = rings(500, 4, sd=0.45)
print("gamma sweep C=10")
for g_ in (0.01, 0.1, 0.5, 2, 10, 50):
    Kf = lambda A, B, g_=g_: K_rbf(A, B, g_); m = fit(Kf, Htr, hy)
    print(g_, "tr", round((m.predict(Kf(Htr, Htr)) == hy).mean(), 3), "te", round(acc(m, Kf, Htr, Hte, hty), 3), "nSV", len(m.support_))
print("C sweep gamma=0.5")
for C in (0.01, 0.1, 1, 10, 1000):
    Kf = lambda A, B: K_rbf(A, B, 0.5); m = fit(Kf, Htr, hy, C)
    print(C, "tr", round((m.predict(Kf(Htr, Htr)) == hy).mean(), 3), "te", round(acc(m, Kf, Htr, Hte, hty), 3), "nSV", len(m.support_))
# Mercer
rng = np.random.default_rng(0); P = rng.normal(size=(30, 2))
for nm, K in (("rbf", K_rbf), ("poly2", K_poly), ("tanh", K_tanh)): print(nm, "minEig", minEig(K, P))
print("tanh frac neg over 200 draws", np.mean([minEig(K_tanh, rng.normal(size=(10, 2))) < -1e-9 for _ in range(200)]))
print("rbf frac neg", np.mean([minEig(K_rbf, rng.normal(size=(10, 2))) < -1e-9 for _ in range(200)]))
# small tanh 3-point example
for t in range(300):
    Q = np.round(rng.normal(size=(3, 2)), 1); e = np.linalg.eigvalsh(K_tanh(Q, Q))
    if e.min() < -0.05: print("tanh3", Q.tolist(), np.round(K_tanh(Q, Q), 3).tolist(), e.min()); break
# time cost
import time
for l in (2, 100, 784):
    X = rng.normal(size=(500, l)); t = time.time(); K_poly(X, X, 5); print("kernel time l", l, round(time.time() - t, 4))
# poly-kernel on rings via explicit 6-dim equals kernel
def phi6(x): return np.array([1, 2**.5*x[0], 2**.5*x[1], x[0]**2, 2**.5*x[0]*x[1], x[1]**2])
a, b = np.array([1., 2.]), np.array([3., 1.]); print("K", (a @ b + 1) ** 2, phi6(a) @ phi6(b), phi6(a).round(3), phi6(b).round(3))
