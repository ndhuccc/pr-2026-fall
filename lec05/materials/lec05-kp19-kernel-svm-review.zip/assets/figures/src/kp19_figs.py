import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums19 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax
Xtr, ytr = N.rings(60, 1); Xte, yte = N.rings(500, 2)
Htr, hy = N.rings(60, 3, sd=0.45); Hte, hty = N.rings(500, 4, sd=0.45)

def f_inner():
    fig, ax = blank(540, 400)
    ax.text(270, 40, "g(x) = Σ λᵢ yᵢ xᵢᵀx + w₀", color=TXT, fontsize=fpx(24), ha="center", fontweight="bold")
    ax.text(270, 80, "sum over the support vectors only", color=MUT, fontsize=fpx(16), ha="center")
    for i, (x, t) in enumerate(((110, "x"), (270, "xᵢᵀx"), (430, "sign(g)"))):
        ax.add_patch(plt.Rectangle((x - 70, 130), 140, 60, fc="none", ec=A_C if i < 2 else RED, lw=2.6)); ax.text(x, 160, t, color=TXT, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
    for x in (190, 350): ax.annotate("", xy=(x + 30, 160), xytext=(x - 10, 160), arrowprops=dict(arrowstyle="-|>", color=MUT, lw=2.4))
    ax.text(270, 235, "the data enter only through inner products", color=RED, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 285, "map x → y in k dimensions: replace xᵢᵀx by yᵢᵀy", color=TXT, fontsize=fpx(17), ha="center")
    ax.text(270, 335, "naive worry: k ≫ l, so the cost explodes", color=GRN, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.text(270, 372, "(the next page shows the surprise)", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp19-inner")

def f_identity():
    fig, ax = blank(540, 420)
    ax.text(270, 30, "y = [x₁², √2·x₁x₂, x₂²]", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    xi, xj = np.array([1., 2.]), np.array([2., 1.]); yi, yj = N.phi2(xi), N.phi2(xj)
    rows = [("xᵢ = (1, 2)", f"yᵢ = ({yi[0]:.0f}, {yi[1]:.3f}, {yi[2]:.0f})"), ("xⱼ = (2, 1)", f"yⱼ = ({yj[0]:.0f}, {yj[1]:.3f}, {yj[2]:.0f})")]
    for i, (a, b) in enumerate(rows):
        ax.text(20, 90 + i * 44, a, color=A_C if i == 0 else B_C, fontsize=fpx(18), fontweight="bold", va="center"); ax.text(215, 90 + i * 44, b, color=TXT, fontsize=fpx(17), va="center")
    ax.text(270, 205, f"high-dimensional:  yᵢᵀyⱼ = 4 + 8 + 4 = {yi @ yj:.0f}", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 255, f"original space:  (xᵢᵀxⱼ)² = (4)² = {(xi @ xj) ** 2:.0f}", color=GRN, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 310, "the same number, and 3-D was never visited", color=RED, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 360, "yᵢᵀyⱼ = (xᵢᵀxⱼ)²", color=TXT, fontsize=fpx(26), ha="center", fontweight="bold")
    ax.text(270, 400, "entry fee of the high-dimensional space: zero", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp19-identity")
    return float(yi @ yj), float((xi @ xj) ** 2)

def f_lift():
    w, h = 540, 440
    fig = new_fig(w, h); a1 = panel(fig, w, h, 30, 25, 215, 215); a2 = panel(fig, w, h, 295, 25, 215, 215)
    P = Xte[:200:1]; Q = np.r_[Xte[:100], Xte[500:600]]; yq = np.r_[yte[:100], yte[500:600]]
    for a in (a1,):
        a.plot(Q[yq < 0, 0], Q[yq < 0, 1], "o", color=A_C, ms=4, alpha=0.8); a.plot(Q[yq > 0, 0], Q[yq > 0, 1], "s", color=B_C, ms=4, alpha=0.7); a.set_aspect("equal"); a.set_xlim(-3.2, 3.2); a.set_ylim(-3.2, 3.2); a.set_xticks([]); a.set_yticks([])
    Y = np.array([N.phi2(p) for p in Q]); s = Y[:, 0] + Y[:, 2]
    a2.plot(Y[yq < 0, 0], Y[yq < 0, 2], "o", color=A_C, ms=4, alpha=0.8); a2.plot(Y[yq > 0, 0], Y[yq > 0, 2], "s", color=B_C, ms=4, alpha=0.7)
    t = np.linspace(0, 6.5, 10); a2.plot(t, 2.5 - t, color=GRN, lw=3); a2.set_xlim(0, 6.5); a2.set_ylim(0, 6.5); axstyle(a2); a2.set_xlabel("y₁ = x₁²", color=TXT, fontsize=fpx(15)); a2.set_ylabel("y₃ = x₂²", color=TXT, fontsize=fpx(15))
    sep = float(((s > 2.5) == (yq > 0)).mean())
    cap(fig, h, [(308, "left: two rings, no line separates them", TXT, 17, True), (342, "right: after the map the line y₁ + y₃ = 2.5 cuts them", GRN, 17, True), (376, f"y₁ + y₃ = ‖x‖², one cut gives {sep*100:.1f}% on these 200 points", RED, 17, True), (410, "(the middle coordinate √2·x₁x₂ is not drawn)", MUT, 15, False)])
    save(fig, "lec05-kp19-lift"); return sep

def f_mercer():
    fig, ax = blank(540, 440)
    ax.text(270, 30, "x → φ(x) in a space H", color=TXT, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(270, 75, "K(x, z) = ⟨φ(x), φ(z)⟩", color=RED, fontsize=fpx(24), ha="center", fontweight="bold")
    ax.text(270, 120, "exists if K is symmetric, continuous and", color=TXT, fontsize=fpx(17), ha="center")
    ax.text(270, 150, "∫∫ K(x,z) g(x) g(z) dx dz ≥ 0 for every g", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.text(270, 205, "what the theorem does NOT tell you", color=B_C, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.text(270, 238, "what φ looks like, or the dimension of H", color=TXT, fontsize=fpx(16), ha="center")
    ax.text(270, 268, "(the Gaussian kernel's H is infinite-dimensional)", color=MUT, fontsize=fpx(15), ha="center")
    rng = np.random.default_rng(0); Pp = rng.normal(size=(30, 2))
    ax.text(270, 325, "30 random points, smallest eigenvalue of the Gram matrix", color=MUT, fontsize=fpx(15), ha="center")
    r = {}
    for i, (nm, K) in enumerate((("Gaussian (γ = 0.5)", N.K_rbf), ("quadratic (xᵀz + 1)²", N.K_poly))):
        v = N.minEig(K, Pp); r[nm] = v
        ax.text(20, 365 + i * 40, nm, color=TXT, fontsize=fpx(16), va="center", fontweight="bold"); ax.text(520, 365 + i * 40, f"{v:.1e}", color=GRN, fontsize=fpx(17), va="center", ha="right", fontweight="bold")
    save(fig, "lec05-kp19-mercer"); return r

def f_kernels():
    fig, ax = blank(540, 420)
    L = [("polynomial", "K(x, z) = (xᵀz + 1)^q", A_C), ("Gaussian (RBF)", "K(x, z) = exp(−γ‖x − z‖²)", B_C), ("hyperbolic tangent", "K(x, z) = tanh(βxᵀz + γ)", MUT)]
    for i, (a, b, c) in enumerate(L):
        y = 40 + i * 62; ax.text(12, y, a, color=c, fontsize=fpx(16), fontweight="bold", va="center"); ax.text(12, y + 28, b, color=TXT, fontsize=fpx(18), va="center", fontweight="bold")
    ax.text(270, 245, "dual:  max Σ λᵢ − ½ Σ λᵢλⱼ yᵢyⱼ K(xᵢ, xⱼ)", color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    ax.text(270, 280, "0 ≤ λᵢ ≤ C,  Σ λᵢyᵢ = 0", color=MUT, fontsize=fpx(16), ha="center")
    ax.text(270, 335, "g(x) = Σ λᵢ yᵢ K(xᵢ, x) + w₀", color=RED, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 375, "nonlinear in the original space, linear in H", color=GRN, fontsize=fpx(16), ha="center", fontweight="bold")
    save(fig, "lec05-kp19-kernels")

def _region(ax, m, K):
    g = np.linspace(-3.2, 3.2, 56); X1, X2 = np.meshgrid(g, g); G = m.decision_function(K(np.c_[X1.ravel(), X2.ravel()], Xtr)).reshape(X1.shape)
    ax.contourf(X1, X2, G, levels=[-1e3, 0, 1e3], colors=[A_C, B_C], alpha=0.25, rasterized=True); ax.contour(X1, X2, G, levels=[0], colors=[GRN], linewidths=2.4)
    ax.plot(Xtr[ytr < 0, 0], Xtr[ytr < 0, 1], "o", color=A_C, ms=3.5); ax.plot(Xtr[ytr > 0, 0], Xtr[ytr > 0, 1], "s", color=B_C, ms=3.5)
    s = m.support_; ax.plot(Xtr[s, 0], Xtr[s, 1], "o", mfc="none", mec=TXT, ms=9, mew=1.4)
    ax.set_aspect("equal"); ax.set_xlim(-3.2, 3.2); ax.set_ylim(-3.2, 3.2); ax.set_xticks([]); ax.set_yticks([])
def f_regions():
    w, h = 540, 440; fig = new_fig(w, h); res = []
    kern = (("linear", N.K_lin), ("quadratic", N.K_poly), ("Gaussian", N.K_rbf))
    for i, (nm, K) in enumerate(kern):
        a = panel(fig, w, h, 8 + i * 178, 30, 170, 170); m = N.fit(K, Xtr, ytr); _region(a, m, K)
        te = N.acc(m, K, Xtr, Xte, yte); res.append((nm, te, len(m.support_)))
        fig.text((8 + i * 178 + 85) / w, 1 - 18 / h, nm, color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
        fig.text((8 + i * 178 + 85) / w, 1 - 222 / h, f"{te*100:.1f}% on new points", color=RED if i == 0 else GRN, fontsize=fpx(15), ha="center", fontweight="bold")
        fig.text((8 + i * 178 + 85) / w, 1 - 247 / h, f"{len(m.support_)} support vectors", color=TXT, fontsize=fpx(15), ha="center")
    cap(fig, h, [(300, "60 training points per class, C = 10, γ = 0.5", TXT, 17, True), (340, "circled points are the support vectors", MUT, 16, False), (385, "same data, same algorithm, only the kernel changes", RED, 17, True)])
    save(fig, "lec05-kp19-regions"); return res

def f_hyper():
    w, h = 540, 440; fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    gs = [0.01, 0.1, 0.5, 2, 10, 50]; tr, te, nsv = [], [], []
    for g_ in gs:
        K = lambda A, B, g_=g_: N.K_rbf(A, B, g_); m = N.fit(K, Htr, hy); tr.append((m.predict(K(Htr, Htr)) == hy).mean()); te.append(N.acc(m, K, Htr, Hte, hty)); nsv.append(len(m.support_))
    ax.plot(range(6), tr, "o-", color=A_C, lw=2.8, ms=9, label="training"); ax.plot(range(6), te, "s-", color=RED, lw=2.8, ms=9, label="new points")
    ax.set_xticks(range(6)); ax.set_xticklabels([str(g_) for g_ in gs], fontsize=fpx(16)); ax.set_ylim(0.7, 1.02); ax.legend(fontsize=fpx(14), frameon=False, labelcolor=TXT, loc="lower left")
    ax.set_xlabel("γ of the Gaussian kernel (C = 10)", color=TXT, fontsize=fpx(15)); ax.set_ylabel("accuracy", color=TXT, fontsize=fpx(15))
    for i in (4, 5): ax.text(i, te[i] + 0.03, f"{te[i]*100:.1f}", color=TXT, fontsize=fpx(14), ha="center", fontweight="bold")
    cap(fig, h, [(335, f"γ = 50: training {tr[5]*100:.1f}% but new points only {te[5]*100:.1f}%", RED, 17, True), (372, f"best new-point accuracy {max(te)*100:.1f}% at γ = {gs[int(np.argmax(te))]}", GRN, 17, True), (409, "rings overlap more here (sd 0.45), so 100% is out of reach", MUT, 15, False)])
    save(fig, "lec05-kp19-hyper"); return gs, tr, te, nsv

def f_cost():
    fig, ax = blank(540, 420)
    for x, t in zip((60, 150, 335), ("dim l", "degree q", "explicit features")): ax.text(x, 30, t, color=MUT, fontsize=fpx(14), ha="center")
    ax.text(495, 30, "kernel", color=MUT, fontsize=fpx(14), ha="center")
    rows = [(2, 2), (10, 3), (100, 5), (784, 5)]
    for i, (l, q) in enumerate(rows):
        y = 85 + i * 58; c = N.comb(l + q, q)
        for x, t, col in ((60, str(l), TXT), (150, str(q), TXT), (335, f"{c:,}", RED), (495, f"{l} mult.", GRN)): ax.text(x, y, t, color=col, fontsize=fpx(17), ha="center", va="center", fontweight="bold")
    ax.text(270, 335, "explicit features = C(l + q, q); one kernel value = one inner product", color=TXT, fontsize=fpx(15), ha="center", fontweight="bold")
    ax.text(270, 372, "cost does not depend on the dimension of the kernel space", color=GRN, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 405, "(it still grows with the number of training points N)", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp19-cost")

def f_tanh():
    fig, ax = blank(540, 420)
    Q = np.array([[-1.0, 0.0], [1.6, 0.9], [0.1, -0.8]]); G = N.K_tanh(Q, Q); ev = np.linalg.eigvalsh(G)
    ax.text(270, 30, "K = tanh(2·xᵀz + 1) on three points", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 62, "(−1, 0),  (1.6, 0.9),  (0.1, −0.8)", color=MUT, fontsize=fpx(16), ha="center")
    for i in range(3):
        for j in range(3): ax.text(165 + j * 105, 120 + i * 45, f"{G[i, j]:.3f}", color=TXT, fontsize=fpx(19), ha="center", va="center", fontweight="bold")
    ax.text(270, 270, "eigenvalues: " + ", ".join(f"{v:.3f}" for v in ev), color=RED, fontsize=fpx(17), ha="center", fontweight="bold")
    rng = np.random.default_rng(5); neg = np.mean([N.minEig(N.K_tanh, rng.normal(size=(10, 2))) < -1e-9 for _ in range(200)]); negr = np.mean([N.minEig(N.K_rbf, rng.normal(size=(10, 2))) < -1e-9 for _ in range(200)])
    ax.text(270, 325, f"200 random sets of 10 points: tanh has a negative eigenvalue in {neg*200:.0f}", color=RED, fontsize=fpx(15), ha="center", fontweight="bold")
    ax.text(270, 360, f"Gaussian: {negr*200:.0f} of 200", color=GRN, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 398, "a legal kernel never gives a negative eigenvalue", color=MUT, fontsize=fpx(15), ha="center")
    save(fig, "lec05-kp19-tanh"); return ev.tolist(), neg, negr

def f_practice():
    fig, ax = blank(540, 330)
    ax.text(270, 40, "kernel  K(x, z) = (xᵀz + 1)²", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 100, "x = (1, 2),   z = (3, 1)", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 165, "question 1: compute K(x, z) directly", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 215, "question 2: check it with the 6-feature map", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 270, "φ(x) = [1, √2x₁, √2x₂, x₁², √2x₁x₂, x₂²]", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp19-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    px, pz = np.array([1., 2.]), np.array([3., 1.])
    f = lambda v: np.array([1, 2 ** .5 * v[0], 2 ** .5 * v[1], v[0] ** 2, 2 ** .5 * v[0] * v[1], v[1] ** 2])
    a, b = f(px), f(pz)
    L = [("question 1: xᵀz = 3 + 2 = 5", TXT), ("K = (5 + 1)² = 36", GRN), ("question 2: φ(x) = (1, 1.414, 2.828, 1, 2.828, 4)", TXT), ("φ(z) = (1, 4.243, 1.414, 9, 4.243, 1)", TXT), (f"φ(x)ᵀφ(z) = 1 + 6 + 4 + 9 + 12 + 4 = {a @ b:.0f}", GRN)]
    for i, (t, c) in enumerate(L): ax.text(270, 40 + i * 56, t, color=c, fontsize=fpx(17), ha="center", va="center", fontweight="bold")
    ax.text(270, 335, "same value 36; the kernel needed 2 multiplications, the map 6 features", color=RED, fontsize=fpx(14), ha="center", fontweight="bold")
    save(fig, "lec05-kp19-practice-sol"); return float(a @ b)

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None: print(n, r)
            except Exception as e: print("FAILED", n, repr(e))
