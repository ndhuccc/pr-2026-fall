ALT = {
 "bumps": ("上方一個 sigmoid 在整條線上都有反應；下方三個高斯節點各在中心 −2、0、2 附近有反應。", "Top: one sigmoid answers along the whole line; bottom: three Gaussian nodes answer near their centres at −2, 0 and 2."),
 "contours": ("左：sigmoid 節點的等值線是平行直線；右：RBF 節點的等值線是圍繞中心的同心圓。", "Left: the equal-output lines of a sigmoid node are parallel straight lines; right: those of an RBF node are concentric circles around its centre."),
 "xormap": ("左：輸入平面上 XOR 四點與兩個中心 (1,1)、(0,0)；右：映射後 (1,0) 與 (0,1) 疊在 (0.368,0.368)，直線 y₁+y₂=1 分開兩類。", "Left: the four XOR points and the centres (1,1), (0,0) on the input plane; right: after the map (1,0) and (0,1) coincide at (0.368,0.368) and the line y₁+y₂=1 separates the classes."),
 "xorcurve": ("g(x)=0 在原平面上是圍住 (0,0) 與 (1,1) 的封閉曲線，(1,0) 與 (0,1) 在曲線外。", "On the original plane g(x)=0 is a closed curve around (0,0) and (1,1), with (1,0) and (0,1) outside it."),
 "ringsk": ("同心環資料用隨機中心的準確率對中心數 k：k=8 為 91.5%，k=16 為 99.5%，k=32 為 99.9%。", "Accuracy on the concentric rings with random centres against the number of centres k: 91.5% at k=8, 99.5% at k=16 and 99.9% at k=32."),
 "centers": ("兩個月牙資料上隨機中心與 k-means 中心的新點準確率（平均與標準差）：k=8 為 93.3% 對 95.0%。", "Accuracy on new points for random centres and k-means centres on two moons (mean and sd): 93.3% against 95.0% at k=8."),
 "curse": ("100 個隨機中心下回應大於 0.1 的測試點比例：l=1、2、5 為 100%，l=10 為 40%，l=20 為 0%。", "Fraction of test points with a response above 0.1 for 100 random centres: 100% for l=1, 2, 5, 40% for l=10 and 0% for l=20."),
 "compare": ("MLP 與 RBF 網路的比較表：節點引數、等值集合、反應、學習速度、稀疏資料泛化、所需節點數。", "Comparison table of the MLP and the RBF network: node argument, equal-output set, response, learning speed, sparse-data generalization and nodes needed."),
 "ways": ("中心的六種選法：固定中心、訓練中心、分群、正交最小平方、支持向量、成長式。", "Six ways to choose the centres: fixed centres, trained centres, clustering, orthogonal least squares, support vectors and growing."),
 "practice": ("練習圖：中心 (1,1)、(0,0)，g=y₁+y₂−1，要映射 (0.5,0.5) 與 (3,3) 並判類。", "Practice figure: centres (1,1), (0,0) and g=y₁+y₂−1; map (0.5,0.5) and (3,3) and classify them."),
 "practice-sol": ("(0.5,0.5)→y=(0.607,0.607)，g=+0.213，ω₁；(3,3)→y≈(0.0003,0)，g≈−1.0，ω₂。", "(0.5,0.5)→y=(0.607,0.607), g=+0.213, ω₁; (3,3)→y≈(0.0003,0), g≈−1.0, ω₂."),
}
