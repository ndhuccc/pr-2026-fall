import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums16 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def blank(w, h):
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off"); return fig, ax

def f_bumps():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 75, 15, 420, 85); axstyle(ax); ax2 = panel(fig, w, h, 75, 135, 420, 120); axstyle(ax2)
    x = np.linspace(-4, 4, 400); ax.plot(x, 1 / (1 + np.exp(-2 * x)), color=A_C, lw=3); ax.set_ylim(-0.1, 1.15); ax.set_xticks([]); ax.set_ylabel("sigmoid", color=TXT, fontsize=fpx(15))
    for c, col in zip((-2, 0, 2), (TEAL2, RED, VIO2)): ax2.plot(x, np.exp(-(x - c) ** 2 / 1.0), color=col, lw=3); ax2.plot([c], [1], "*", color=col, ms=14)
    ax2.set_ylim(-0.1, 1.15); ax2.set_ylabel("Gaussian", color=TXT, fontsize=fpx(15)); ax2.set_xlabel("x", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(312, "top: one sigmoid node answers on the whole line", A_C, 16, True), (345, "bottom: three Gaussian nodes, each answers near its centre ★", TXT, 16, True), (382, "g(x) = w₀ + Σ wᵢ exp(−‖x − cᵢ‖² / 2σ²)", RED, 18, True), (418, "σ² = 0.5, so 2σ² = 1", MUT, 16, False)])
    save(fig, "lec05-kp16-bumps")

def f_contours():
    w, h = 540, 440
    fig = new_fig(w, h); a1 = panel(fig, w, h, 25, 25, 230, 230); a2 = panel(fig, w, h, 285, 25, 230, 230)
    xs = np.linspace(-3, 3, 70); X, Y = np.meshgrid(xs, xs)
    a1.contourf(X, Y, 1 / (1 + np.exp(-(X + 0.5 * Y))), levels=8, cmap="coolwarm", rasterized=True); a1.contour(X, Y, X + 0.5 * Y, levels=np.arange(-4, 5, 1.5), colors="k", linewidths=0.8)
    a2.contourf(X, Y, np.exp(-(X ** 2 + Y ** 2) / 1.0), levels=8, cmap="coolwarm", rasterized=True); a2.contour(X, Y, np.sqrt(X ** 2 + Y ** 2), levels=[0.7, 1.4, 2.1, 2.8], colors="k", linewidths=0.8); a2.plot([0], [0], "*", color="white", ms=14)
    for a in (a1, a2): a.set_xticks([]); a.set_yticks([]); a.set_aspect("equal")
    cap(fig, h, [(290, "sigmoid node: equal-output lines are straight", A_C, 17, True), (322, "RBF node: equal-output sets are circles around ★", RED, 17, True), (362, "left reacts everywhere, right only near its centre", TXT, 17, False), (398, "global response against local response", MUT, 16, False)])
    save(fig, "lec05-kp16-contours")

def f_xormap():
    w, h = 540, 440
    fig = new_fig(w, h); a1 = panel(fig, w, h, 55, 20, 180, 175); axstyle(a1); a2 = panel(fig, w, h, 300, 20, 200, 175); axstyle(a2)
    C = np.array([[1., 1], [0, 0]]); pts = np.array([[0, 0.], [1, 1], [1, 0], [0, 1]]); lab = [1, 1, -1, -1]
    for p, l in zip(pts, lab): a1.plot([p[0]], [p[1]], "o" if l > 0 else "s", color=A_C if l > 0 else B_C, ms=11)
    for c in C: a1.plot([c[0]], [c[1]], "*", color=TXT, ms=18)
    a1.set_xlim(-0.4, 1.4); a1.set_ylim(-0.4, 1.4); a1.set_xlabel("x₁", color=TXT, fontsize=fpx(15)); a1.set_ylabel("x₂", color=TXT, fontsize=fpx(15), rotation=0)
    Y = N.rbf_feats(pts, C, 0.5)
    for p, l in zip(Y, lab): a2.plot([p[0]], [p[1]], "o" if l > 0 else "s", color=A_C if l > 0 else B_C, ms=11 if l > 0 else 17, alpha=1 if l > 0 else 0.6)
    t = np.linspace(0, 1.1, 10); a2.plot(t, 1 - t, color=GRN, lw=3); a2.set_xlim(0, 1.1); a2.set_ylim(0, 1.1); a2.set_xlabel("y₁", color=TXT, fontsize=fpx(15)); a2.set_ylabel("y₂", color=TXT, fontsize=fpx(15), rotation=0)
    a2.text(0.14, 1.03, "(0.135, 1)", color=TXT, fontsize=fpx(13)); a2.text(0.68, 0.14, "(1, 0.135)", color=TXT, fontsize=fpx(13)); a2.text(0.43, 0.30, "(0.368, 0.368)", color=TXT, fontsize=fpx(13))
    cap(fig, h, [(280, "centres c₁ = (1,1), c₂ = (0,0)  (★)", TXT, 17, True), (314, "(1,0) and (0,1) fold onto one point", RED, 17, True), (348, "the line y₁ + y₂ − 1 = 0 separates the classes", GRN, 17, True), (384, "f(x) = exp(−‖x − c‖²)", MUT, 16, False)])
    save(fig, "lec05-kp16-xormap")

def f_xorcurve():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 65, 15, 410, 270); axstyle(ax)
    xs = np.linspace(-1, 2, 400); X1, X2 = np.meshgrid(xs, xs); C = [(1, 1), (0, 0)]
    G = sum(np.exp(-((X1 - c[0]) ** 2 + (X2 - c[1]) ** 2)) for c in C) - 1
    ax.contourf(X1, X2, G, levels=[-10, 0, 10], colors=[B_C, A_C], alpha=0.22); ax.contour(X1, X2, G, levels=[0], colors=[GRN], linewidths=3)
    for (a, b) in ((0, 0), (1, 1)): ax.plot([a], [b], "o", color=A_C, ms=13)
    for (a, b) in ((0, 1), (1, 0)): ax.plot([a], [b], "s", color=B_C, ms=13)
    ax.set_xlim(-1, 2); ax.set_ylim(-1, 2); ax.set_aspect("equal"); ax.set_xlabel("x₁", color=TXT, fontsize=fpx(15)); ax.set_ylabel("x₂", color=TXT, fontsize=fpx(15), rotation=0, labelpad=8)
    cap(fig, h, [(345, "g(x) = e^(−‖x−c₁‖²) + e^(−‖x−c₂‖²) − 1 = 0", GRN, 16, True), (380, "g at the four points: +0.135, +0.135, −0.264, −0.264", TXT, 16, False), (414, "far from both centres g → −1: the default side", MUT, 16, False)])
    save(fig, "lec05-kp16-xorcurve")

def f_ringsk():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    Xtr, ytr = N.rings(100, 0); Xte, yte = N.rings(500, 1); ks = [1, 2, 4, 8, 16, 32]; res = []
    for k in ks:
        r = []
        for seed in range(20):
            rng = np.random.default_rng(seed); C = Xtr[rng.choice(len(Xtr), k, replace=False)]; r.append(N.fit_acc(C, 0.5, Xtr, ytr, Xte, yte))
        res.append(np.mean(r, 0))
    res = np.array(res); ax.plot(range(6), res[:, 0], "o-", color=A_C, lw=2.8, label="training"); ax.plot(range(6), res[:, 1], "s-", color=RED, lw=2.8, label="new points")
    ax.set_xticks(range(6)); ax.set_xticklabels([str(k) for k in ks], fontsize=fpx(16)); ax.set_ylim(0.5, 1.03); ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="lower right")
    ax.set_xlabel("number of centres k  (chosen at random from the training points)", color=TXT, fontsize=fpx(14)); ax.set_ylabel("accuracy", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(340, "concentric rings, 200 training points, σ² = 0.5", TXT, 17, True), (376, "k = 8: 91.5%,   k = 16: 99.5%,   k = 32: 99.9%", GRN, 18, True), (410, "mean of 20 random choices of centres", MUT, 15, False)])
    save(fig, "lec05-kp16-ringsk"); return res

def f_centers():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    Xtr, ytr = N.moons(60, 0.2, 0); Xte, yte = N.moons(500, 0.2, 1); ks = [2, 4, 6, 8, 12]; R = []; K = []
    for k in ks:
        rr, kk = [], []
        for seed in range(20):
            rng = np.random.default_rng(seed); C = Xtr[rng.choice(len(Xtr), k, replace=False)]; rr.append(N.fit_acc(C, 0.3, Xtr, ytr, Xte, yte)[1]); kk.append(N.fit_acc(N.kmeans(Xtr, k, seed), 0.3, Xtr, ytr, Xte, yte)[1])
        R.append((np.mean(rr), np.std(rr))); K.append((np.mean(kk), np.std(kk)))
    x = np.arange(5); R = np.array(R); K = np.array(K)
    ax.bar(x - 0.2, R[:, 0], width=0.38, yerr=R[:, 1], color=A_C, label="random from training", capsize=3, error_kw=dict(ecolor=TXT, lw=1.4)); ax.bar(x + 0.2, K[:, 0], width=0.38, yerr=K[:, 1], color=GRN, label="k-means clustering", capsize=3, error_kw=dict(ecolor=TXT, lw=1.4))
    ax.set_xticks(x); ax.set_xticklabels([str(k) for k in ks], fontsize=fpx(16)); ax.set_ylim(0.6, 1.02); ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper left")
    ax.set_xlabel("number of centres k", color=TXT, fontsize=fpx(16)); ax.set_ylabel("accuracy on new points", color=TXT, fontsize=fpx(15))
    cap(fig, h, [(340, "two moons, 20 repeats (bars: mean, lines: sd)", TXT, 17, True), (376, "k = 8: 93.3% (sd 0.018) against 95.0% (sd 0.004)", GRN, 17, True), (410, "clustering is steadier; it is not always better", MUT, 15, False)])
    save(fig, "lec05-kp16-centers"); return R, K

def f_curse():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 75, 20, 430, 225); axstyle(ax)
    ls = [1, 2, 5, 10, 20]; fr = [1.0, 1.0, 1.0, 0.399, 0.0]
    ax.bar(range(5), fr, color=[A_C, A_C, A_C, VIO2, RED], width=0.6)
    for i, v in enumerate(fr): ax.text(i, v + 0.03, f"{v*100:.0f}%" if v in (0.0, 1.0) else f"{v*100:.0f}%", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.set_xticks(range(5)); ax.set_xticklabels([f"l = {l}" for l in ls], fontsize=fpx(16)); ax.set_ylim(0, 1.2)
    ax.set_ylabel("test points with response > 0.1", color=TXT, fontsize=fpx(14))
    cap(fig, h, [(330, "100 random centres in the unit cube, σ = 0.3", TXT, 17, True), (366, "median nearest-centre distance: 0.05, 0.30, 0.67, 1.22 for l = 2, 5, 10, 20", MUT, 14, False), (402, "a 5-per-axis grid needs 25, 3125, 9,765,625 centres (l = 2, 5, 10)", RED, 15, True)])
    save(fig, "lec05-kp16-curse")

def f_compare():
    fig, ax = blank(540, 440)
    rows = [("", "MLP", "RBF network"), ("node argument", "Σ wⱼxⱼ", "‖x − cᵢ‖"), ("equal-output set", "a hyperplane", "a hypersphere"), ("response", "global", "local"), ("learning speed", "slower", "faster"), ("sparse-data generalization", "better", "worse"), ("nodes for the same accuracy", "fewer", "many more")]
    for i, (a, b, c) in enumerate(rows):
        y = 40 + i * 52; col = MUT if i == 0 else TXT
        ax.text(12, y, a, color=MUT, fontsize=fpx(16), va="center", fontweight="bold"); ax.text(318, y, b, color=A_C if i else MUT, fontsize=fpx(17), ha="center", va="center", fontweight="bold"); ax.text(432, y, c, color=RED if i else MUT, fontsize=fpx(17), ha="center", va="center", fontweight="bold")
    ax.text(270, 415, "MLP: which side of a hyperplane;  RBF: how close to a centre", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    save(fig, "lec05-kp16-compare")

def f_ways():
    fig, ax = blank(540, 440)
    items = [("fixed centres", "pick k training points at random; then only weights remain, a linear problem", TEAL2), ("train the centres", "learn w, c, σ together by gradient descent; costly", RED), ("clustering", "cluster the data, centres = cluster means, then learn w", GRN), ("orthogonal least squares", "pick a compact set from many candidates by forward regression", VIO2), ("support vectors", "quadratic programme; the centres are the support vectors", A_C), ("growing", "add a centre when a sample is far from all and the error is large", LINE)]
    for i, (t, d, c) in enumerate(items):
        y0 = 12 + i * 70; ax.add_patch(Rectangle((12, y0), 516, 60, fc="none", ec=c, lw=2.4)); ax.text(24, y0 + 19, t, color=c, fontsize=fpx(17), va="center", fontweight="bold"); ax.text(24, y0 + 43, d, color=TXT, fontsize=fpx(13), va="center")
    save(fig, "lec05-kp16-ways")

def f_practice():
    fig, ax = blank(540, 330)
    ax.text(270, 40, "centres c₁ = (1,1), c₂ = (0,0), f = exp(−‖x − c‖²)", color=TXT, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 105, "g(y) = y₁ + y₂ − 1,  g > 0 → class ω₁ (like (0,0), (1,1))", color=MUT, fontsize=fpx(16), ha="center")
    ax.text(270, 180, "question 1: map (0.5, 0.5) and find its class", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 230, "question 2: the same for the far point (3, 3)", color=RED, fontsize=fpx(19), ha="center", fontweight="bold")
    ax.text(270, 285, "hint: ‖(0.5,0.5) − c‖² = 0.5 for both centres", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp16-practice")

def f_practice_sol():
    fig, ax = blank(540, 400)
    L = [("(0.5, 0.5):  d² = 0.5, 0.5", "y = (0.607, 0.607)", TXT), ("g = 0.607 + 0.607 − 1", "= +0.213  → ω₁", GRN), ("(3, 3):  d² = 8, 18", "y = (0.0003, 0.000000015)", TXT), ("g = 0.0003 + 0 − 1", "≈ −1.0  → ω₂", RED)]
    for i, (a, b, c) in enumerate(L):
        y = 50 + i * 72; ax.text(15, y, a, color=c, fontsize=fpx(17), va="center", fontweight="bold"); ax.text(285, y, b, color=c, fontsize=fpx(17), va="center", fontweight="bold")
    ax.text(270, 362, "far from every centre the output falls to the bias −1", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp16-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r is not None and n in ("f_centers",): print(n, [np.round(a, 3).tolist() for a in r])
            except Exception as e: print("FAILED", n, e)
