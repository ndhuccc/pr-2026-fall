"""KP06 deck: from the step to the backpropagation gradient. KP_LANG=zh|en|bi"""
import os, sys
os.environ["DECK_PFX"] = "lec05kp06"
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from deckcommon import *
import deckcommon as D
D.TERM_EN.update({"term:代價函數": "term:Cost function", "term:梯度下降": "term:Gradient descent", "term:sigmoid": "term:Sigmoid", "term:前向傳遞": "term:Forward pass",
                  "term:連鎖律": "term:Chain rule", "term:誤差訊號": "term:Error signal", "term:反向傳播": "term:Backpropagation", "term:學習率": "term:Learning rate"})
from kp06_text import *

def side_page(u, t, fig, fx=60, cx=640, cw=580, rev=False):
    p = newpage(u, *t["lab"], *t["title"]); y = bridge(p, *t["bridge"])
    p.figure(fig, fx, y); _, ids = stack(p, cx, y, cw, t["cards"]); step(p, *t["notes"])
    if rev: reveal(p, ids)
    return p

def build():
    u = kit.Unit("u01", UNIT_EN if KP_LANG == "en" else UNIT_ZH, 0, 0)
    figs = ["step-slope", "sigmoid-a", "net-forward", "chain", "out-bars", "net-backward", "before-after", "numcheck", "saturation", "practice-net", "practice-sol"]
    for i, t in enumerate(PAGES):
        side_page(u, t, "lec05-kp06-" + figs[i], rev=(i in (9, 10)))
    return [u]

if __name__ == "__main__":
    U = build()
    finish(U, TITLE_ZH, TITLE_EN, NOTE_ZH, NOTE_EN, os.path.join(HERE, "draft.jbd.json"))
