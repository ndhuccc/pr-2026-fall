import math
f=lambda v:1/(1+math.exp(-v)); 
W={'h1':[-0.10,0.20,0.40],'h2':[0.10,-0.30,0.20],'out':[-0.20,0.50,-0.40]}
x=[1,0]; y=1; eta=0.3
def fwd(W):
    v1=W['h1'][0]+W['h1'][1]*x[0]+W['h1'][2]*x[1]; v2=W['h2'][0]+W['h2'][1]*x[0]+W['h2'][2]*x[1]
    y1,y2=f(v1),f(v2); vo=W['out'][0]+W['out'][1]*y1+W['out'][2]*y2; o=f(vo)
    return v1,v2,y1,y2,vo,o
def E(W,t=y): o=fwd(W)[5]; return 0.5*(t-o)**2
def grads(W,t=y):
    v1,v2,y1,y2,vo,o=fwd(W)
    e=t-o; do=e*o*(1-o)
    d1=y1*(1-y1)*do*W['out'][1]; d2=y2*(1-y2)*do*W['out'][2]
    # dE/dw = -delta*input  (delta defined with e=y-o gives dE/dv=-delta)
    return dict(v1=v1,v2=v2,y1=y1,y2=y2,vo=vo,o=o,e=e,do=do,d1=d1,d2=d2,
      dw_out=[eta*do*1,eta*do*y1,eta*do*y2], dw_h1=[eta*d1*1,eta*d1*x[0],eta*d1*x[1]], dw_h2=[eta*d2*1,eta*d2*x[0],eta*d2*x[1]])
if __name__=="__main__":
    g=grads(W); 
    for k,v in g.items(): print(k, [round(a,5) for a in v] if isinstance(v,list) else round(v,5))
    print('E',E(W))
    W2={k:[w+d for w,d in zip(W[k],g['dw_'+k])] for k in W}
    print(W2); print('E after',E(W2), 'o after',fwd(W2)[5])
    # numeric check: dE/dw = -delta*input
    h=1e-6
    for k,i in [('out',0),('out',1),('out',2),('h1',0),('h1',1),('h1',2),('h2',0),('h2',1),('h2',2)]:
        Wp={a:b[:] for a,b in W.items()}; Wm={a:b[:] for a,b in W.items()}; Wp[k][i]+=h; Wm[k][i]-=h
        num=(E(Wp)-E(Wm))/(2*h)
        inp={'out':[1,g['y1'],g['y2']],'h1':[1,x[0],x[1]],'h2':[1,x[0],x[1]]}[k][i]
        dl={'out':g['do'],'h1':g['d1'],'h2':g['d2']}[k]
        print(k,i,'numeric',round(num,6),'analytic',round(-dl*inp,6))
    # practice: target 0
    g0=grads(W,0); print('target0 e',g0['e'],'do',g0['do'],'dw_out',g0['dw_out'],'d1',g0['d1'],'d2',g0['d2'])
