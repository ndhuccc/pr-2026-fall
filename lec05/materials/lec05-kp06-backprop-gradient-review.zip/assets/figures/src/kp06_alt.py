ALT = {
 "step-slope": ("上圖階梯函數：除了在 0 的跳躍，斜率都是 0，跳躍處沒有斜率；下圖 sigmoid 在中間有一條斜率 0.25 的切線。", "Top: the step function has slope 0 apart from the jump at 0 and no slope at the jump. Bottom: the sigmoid with a tangent of slope 0.25 in the middle."),
 "sigmoid-a": ("上排三條 sigmoid（a=0.7、2、8）與虛線階梯，a 越大越像階梯；下排對應的斜率，a 越大尖峰越高越窄，兩側幾乎為 0。", "Top: three sigmoids (a=0.7, 2, 8) with the dashed step, a larger a is closer to the step. Bottom: their slopes, a taller and narrower spike for a larger a with almost zero tails."),
 "net-forward": ("2–2–1 網路前向傳遞：輸入 (1,0)；隱藏單元 1 加權和 0.10、輸出 0.525；單元 2 加權和 −0.20、輸出 0.450；輸出單元加權和 −0.118、輸出 0.471，目標 1；權重標在線旁。", "Forward pass of the 2-2-1 network: input (1,0); hidden unit 1 has sum 0.10 and output 0.525; unit 2 has sum −0.20 and output 0.450; the output unit has sum −0.118 and output 0.471 with target 1; weights are written beside the lines."),
 "chain": ("連鎖律：w 到 v 的斜率是輸入 0.525，v 到 o 的斜率是 0.249，o 到 E 的斜率是 −0.529，相乘得 −0.069。", "Chain rule: the slope from w to v is the input 0.525, from v to o is 0.249 and from o to E is −0.529; their product is −0.069."),
 "out-bars": ("輸出層三個權重的更新量（η=0.3、δ_o=0.1319）：偏置 +0.0396、來自隱藏單元 1 的 +0.0208、來自單元 2 的 +0.0178。", "Updates of the three output-layer weights (η=0.3, δ_o=0.1319): bias +0.0396, from hidden unit 1 +0.0208, from unit 2 +0.0178."),
 "net-backward": ("反向傳播：紅色線表示誤差由輸出往回，δ_o=0.1319、隱藏單元 1 的 δ=0.0164、單元 2 的 δ=−0.0131。", "Backpropagation: red lines show the error travelling back from the output, δ_o=0.1319, hidden unit 1 δ=0.0164, unit 2 δ=−0.0131."),
 "before-after": ("更新一步前後：輸出 o 由 0.4706 到 0.4857（目標 1），代價 E 由 0.1401 降到 0.1322。", "Before and after one update: the output o goes from 0.4706 to 0.4857 (target 1) and the cost E drops from 0.1401 to 0.1322."),
 "numcheck": ("九個權重的 δ×輸入算出的斜率（長條）與數值差分斜率（圓點）完全重合。", "The slopes of the nine weights from δ×input (bars) coincide with the numerical difference slopes (dots)."),
 "saturation": ("對數座標的長條圖：x=3 時 sigmoid 的斜率，a=0.7 為 0.068、a=2 為 0.0049、a=8 為 3×10⁻¹⁰。", "Logarithmic bar chart of the sigmoid slope at x=3: 0.068 for a=0.7, 0.0049 for a=2 and 3×10⁻¹⁰ for a=8."),
 "practice-net": ("練習圖：同一個 2–2–1 網路與前向傳遞數字，目標改成 0。", "Practice figure: the same 2-2-1 network and forward numbers with the target changed to 0."),
 "practice-sol": ("目標為 0 時輸出層三個權重的更新量：偏置 −0.0352、來自單元 1 的 −0.0185、來自單元 2 的 −0.0158，全部往下。", "Output-layer updates for target 0: bias −0.0352, from unit 1 −0.0185, from unit 2 −0.0158, all downward."),
}
