import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
f = nums.f; W = nums.W; G = nums.grads(W); G0 = nums.grads(W, 0)
def fm(v, d=3): return f"{v:.{d}f}".replace("-", "−")
def cap(fig, w, h, x, ytop, text, color=None, fs=19):
    fig.text(x / w, 1 - ytop / h, text, color=color or TXT, fontsize=fpx(fs), ha="center", va="center", fontweight="bold")
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))

def f_step_slope():
    w, h = 520, 480
    fig = new_fig(w, h)
    xs = np.linspace(-6, 6, 400)
    a1 = panel(fig, w, h, 70, 30, 420, 170); axstyle(a1)
    a1.plot([-6, 0], [0, 0], color=B_C, lw=3.5); a1.plot([0, 6], [1, 1], color=B_C, lw=3.5); a1.plot([0, 0], [0, 1], color=B_C, lw=2, ls=(0, (3, 3)))
    a1.set_ylim(-0.25, 1.4); a1.set_xlim(-6, 6)
    a1.text(-5.8, 0.28, "slope 0", color=TXT, fontsize=fpx(17), fontweight="bold"); a1.text(1.2, 0.72, "slope 0", color=TXT, fontsize=fpx(17), fontweight="bold")
    a1.text(0.3, 1.18, "jump: no slope", color=RED, fontsize=fpx(17), fontweight="bold")
    a1.set_title("step function", color=TXT, fontsize=fpx(18), loc="left")
    a2 = panel(fig, w, h, 70, 270, 420, 170); axstyle(a2)
    a2.plot(xs, 1 / (1 + np.exp(-xs)), color=A_C, lw=3.5); a2.set_xlim(-6, 6); a2.set_ylim(-0.25, 1.4)
    a2.plot([-2, 2], [0.5 - 0.5, 0.5 + 0.5], color=LINE, lw=2.6)
    a2.text(1.3, 0.25, "tangent: slope 0.25", color=LINE, fontsize=fpx(17), fontweight="bold")
    a2.set_title("sigmoid", color=TXT, fontsize=fpx(18), loc="left")
    save(fig, "lec05-kp06-step-slope")

def f_sigmoid_a():
    w, h = 520, 480
    fig = new_fig(w, h)
    xs = np.linspace(-6, 6, 500); cols = {0.7: A_C, 2: VIO2, 8: RED}
    a1 = panel(fig, w, h, 70, 30, 420, 170); axstyle(a1)
    a1.plot([-6, 0, 0, 6], [0, 0, 1, 1], color=MUT, lw=2, ls=(0, (4, 3)))
    for a, c in cols.items(): a1.plot(xs, 1 / (1 + np.exp(-a * xs)), color=c, lw=3, label=f"a={a}")
    a1.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="center right"); a1.set_xlim(-6, 6)
    a1.set_title("f(x): larger a is closer to the step", color=TXT, fontsize=fpx(16), loc="left")
    a2 = panel(fig, w, h, 70, 270, 420, 170); axstyle(a2)
    for a, c in cols.items():
        fv = 1 / (1 + np.exp(-a * xs)); a2.plot(xs, a * fv * (1 - fv), color=c, lw=3)
    a2.set_xlim(-6, 6); a2.set_ylim(0, 2.2)
    a2.annotate("near-zero tails", xy=(3.6, 0.04), xytext=(1.8, 1.0), color=TXT, fontsize=fpx(16), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2))
    a2.set_title("f'(x): taller, narrower spike", color=TXT, fontsize=fpx(16), loc="left")
    save(fig, "lec05-kp06-sigmoid-a")

def net(ax, vals, deltas=None, back=False, H=480):
    ax.set_xlim(0, 540); ax.set_ylim(H, 0); ax.axis("off")
    P_ = {"x1": (60, 140), "x2": (60, 320), "h1": (270, 90), "h2": (270, 370), "o": (470, 230)}
    wts = [("x1", "h1", "0.20"), ("x2", "h1", "0.40"), ("x1", "h2", "−0.30"), ("x2", "h2", "0.20"), ("h1", "o", "0.50"), ("h2", "o", "−0.40")]
    for a, b, t in wts:
        (x0, y0), (x1, y1) = P_[a], P_[b]; ax.plot([x0 + 30, x1 - 36], [y0, y1], color=RED if back else MUT, lw=2 if back else 1.6, alpha=0.9, zorder=1)
        mx, my = (x0 + x1) / 2 + (20 if a == "x1" else 0) + (0 if a != "x2" else 20), (y0 + y1) / 2 + (-16 if (a, b) in [("x1", "h1"), ("x2", "h1"), ("h1", "o")] else 16)
        ax.text(mx, my, t, color=TXT, fontsize=fpx(16), ha="center", va="center", bbox=dict(boxstyle="round,pad=0.1", fc=BG, ec="none", alpha=0.85), zorder=3)
    for k, (x0, y0) in P_.items():
        r = 30 if k[0] == "x" else 48
        ax.add_patch(Circle((x0, y0), r, fc="none", ec=(TXT if k[0] == "x" else {"h1": TEAL2, "h2": VIO2, "o": A_C}[k]), lw=2.8, zorder=4))
    ax.text(*P_["x1"], "x₁=1", color=TXT, fontsize=fpx(17), ha="center", va="center", zorder=5); ax.text(*P_["x2"], "x₂=0", color=TXT, fontsize=fpx(17), ha="center", va="center", zorder=5)
    for k, lines in vals.items():
        x0, y0 = P_[k]
        for i, ln in enumerate(lines): ax.text(x0, y0 - 11 + 22 * i if len(lines) == 2 else y0, ln, color=TXT, fontsize=fpx(15), ha="center", va="center", zorder=5, fontweight="bold")
    if deltas:
        for k, t in deltas.items():
            x0, y0 = P_[k]; ax.text(x0, y0 + (58 if k != "h1" else -58), t, color=RED, fontsize=fpx(17), ha="center", va="center", fontweight="bold")
    return P_

def biases(ax):
    for (x0, y0, t) in [(270, 24, "bias \u22120.10"), (270, 436, "bias 0.10"), (470, 160, "bias \u22120.20")]:
        ax.text(x0, y0, t, color=MUT, fontsize=fpx(16), ha="center", va="center")

def f_net_forward():
    w, h = 540, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h)
    v = {"h1": [f"v={fm(G['v1'],2)}", f"y={fm(G['y1'])}"], "h2": [f"v={fm(G['v2'],2)}", f"y={fm(G['y2'])}"], "o": [f"v={fm(G['vo'])}", f"o={fm(G['o'])}"]}
    net(ax, v, H=450); biases(ax); ax.text(470, 295, "target 1", color=GRN, fontsize=fpx(18), ha="center", fontweight="bold")
    save(fig, "lec05-kp06-net-forward")

def f_chain():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    xs = [60, 190, 320, 450]; names = ["w", "v", "o", "E"]; cols = [MUT, TEAL2, A_C, RED]
    for x, n, c in zip(xs, names, cols):
        ax.add_patch(Circle((x, 110), 36, fc="none", ec=c, lw=3)); ax.text(x, 110, n, color=TXT, fontsize=fpx(24), ha="center", va="center", fontweight="bold")
    facs = [("input y₁", fm(G["y1"])), ("slope f'", fm(G["o"] * (1 - G["o"]))), ("−e", fm(-G["e"]))]
    for i, (n, v) in enumerate(facs):
        ax.annotate("", xy=(xs[i + 1] - 40, 110), xytext=(xs[i] + 40, 110), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.4))
        ax.text((xs[i] + xs[i + 1]) / 2, 62, n, color=TXT, fontsize=fpx(17), ha="center", va="center", fontweight="bold"); ax.text((xs[i] + xs[i + 1]) / 2, 160, v, color=TXT, fontsize=fpx(19), ha="center", va="center")
    ax.text(270, 245, "slope of E in w = product of the three slopes", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.text(270, 295, f"{fm(G['y1'])} × {fm(G['o']*(1-G['o']))} × ({fm(-G['e'])}) = {fm(-G['do']*G['y1'])}", color=LINE, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 345, "w is the weight from hidden unit 1 to the output", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp06-chain")

def barh(fig, ax, labels, vals, cols, fmt, title):
    ax.barh(range(len(vals)), vals, color=cols, alpha=0.9, height=0.55); ax.set_yticks(range(len(vals))); ax.set_yticklabels(labels, fontsize=fpx(17)); ax.invert_yaxis()
    ax.axvline(0, color=MUT, lw=1.2)
    for i, v in enumerate(vals): ax.text(v + (0.0015 if v >= 0 else -0.0015), i, fmt(v), color=TXT, fontsize=fpx(17), va="center", ha="left" if v >= 0 else "right", fontweight="bold")
    axstyle(ax); ax.set_title(title, color=TXT, fontsize=fpx(17), loc="left")

def f_out_bars():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 150, 50, 360, 270)
    barh(fig, ax, ["bias (input 1)", f"from h₁ ({fm(G['y1'])})", f"from h₂ ({fm(G['y2'])})"], G["dw_out"], [MUT, TEAL2, VIO2], lambda v: "+" + f"{v:.4f}", "Δw = η·δ_o·input,  η=0.3,  δ_o=0.1319")
    ax.set_xlim(0, 0.056)
    cap(fig, w, h, 270, 365, "the three output-layer weights all move up", fs=18)
    save(fig, "lec05-kp06-out-bars")

def f_net_backward():
    w, h = 540, 480
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h)
    net(ax, {"h1": [f"y={fm(G['y1'])}"], "h2": [f"y={fm(G['y2'])}"], "o": [f"o={fm(G['o'])}"]}, deltas={"o": f"δ={fm(G['do'],4)}", "h1": f"δ={fm(G['d1'],4)}", "h2": f"δ={fm(G['d2'],4)}"}, back=True)
    ax.text(270, 468, "error travels backward, weighted by the same weights", color=RED, fontsize=fpx(17), ha="center", fontweight="bold")
    save(fig, "lec05-kp06-net-backward")

def f_before_after():
    w, h = 540, 420
    fig = new_fig(w, h); W2 = {k: [a + d for a, d in zip(W[k], G["dw_" + k])] for k in W}
    o2 = nums.fwd(W2)[5]; E1, E2 = nums.E(W), nums.E(W2)
    a1 = panel(fig, w, h, 60, 40, 190, 300); axstyle(a1)
    a1.bar([0, 1], [G["o"], o2], color=[MUT, A_C], width=0.6); a1.axhline(1, color=GRN, ls=(0, (4, 3)), lw=2); a1.set_ylim(0, 1.2); a1.set_xticks([0, 1]); a1.set_xticklabels(["before", "after"], fontsize=fpx(17))
    for i, v in enumerate([G["o"], o2]): a1.text(i, v + 0.03, fm(v, 4), color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    a1.text(0.5, 1.07, "target 1", color=GRN, fontsize=fpx(16), ha="center"); a1.set_title("output o", color=TXT, fontsize=fpx(17), loc="left")
    a2 = panel(fig, w, h, 320, 40, 190, 300); axstyle(a2)
    a2.bar([0, 1], [E1, E2], color=[MUT, RED], width=0.6); a2.set_ylim(0, 0.18); a2.set_xticks([0, 1]); a2.set_xticklabels(["before", "after"], fontsize=fpx(17))
    for i, v in enumerate([E1, E2]): a2.text(i, v + 0.005, fm(v, 4), color=TXT, fontsize=fpx(17), ha="center", fontweight="bold")
    a2.set_title("cost E", color=TXT, fontsize=fpx(17), loc="left")
    cap(fig, w, h, 270, 385, "one update: o moves toward 1, E goes down", fs=18)
    save(fig, "lec05-kp06-before-after")

def f_numcheck():
    w, h = 540, 470
    fig = new_fig(w, h); ax = panel(fig, w, h, 140, 40, 370, 380)
    labs = ["out bias", "out←h₁", "out←h₂", "h₁ bias", "h₁←x₁", "h₁←x₂", "h₂ bias", "h₂←x₁", "h₂←x₂"]
    inp = {"o": [1, G["y1"], G["y2"]], "h1": [1, 1, 0], "h2": [1, 1, 0]}
    vals = [-G["do"] * i for i in inp["o"]] + [-G["d1"] * i for i in inp["h1"]] + [-G["d2"] * i for i in inp["h2"]]
    cols = [A_C] * 3 + [TEAL2] * 3 + [VIO2] * 3
    ax.barh(range(9), vals, color=cols, height=0.55); ax.set_yticks(range(9)); ax.set_yticklabels(labs, fontsize=fpx(16)); ax.invert_yaxis(); ax.axvline(0, color=MUT, lw=1.2)
    for i, v in enumerate(vals): ax.text(0.078, i, fm(v, 4), color=TXT, fontsize=fpx(15), va="center", ha="right")
    num_ = []
    for k, i_ in [("out", 0), ("out", 1), ("out", 2), ("h1", 0), ("h1", 1), ("h1", 2), ("h2", 0), ("h2", 1), ("h2", 2)]:
        Wp = {a_: b_[:] for a_, b_ in W.items()}; Wm = {a_: b_[:] for a_, b_ in W.items()}; Wp[k][i_] += 1e-6; Wm[k][i_] -= 1e-6
        num_.append((nums.E(Wp) - nums.E(Wm)) / 2e-6)
    assert max(abs(x - y) for x, y in zip(num_, vals)) < 1e-6
    ax.plot(num_, range(9), "o", color=BG, mec=TXT, mew=2, ms=9, zorder=5)
    axstyle(ax); ax.set_xlim(-0.2, 0.08); ax.set_title("bars: $-\\delta\\times$input;  dots: numeric slope", color=TXT, fontsize=fpx(16), loc="left")
    save(fig, "lec05-kp06-numcheck")

def f_saturation():
    w, h = 540, 420
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 40, 440, 300); axstyle(ax)
    avals = [0.7, 2, 8]; xv = 3
    vals = [a * (1 / (1 + math.exp(-a * xv))) * (1 - 1 / (1 + math.exp(-a * xv))) for a in avals]
    ax.bar(range(3), vals, color=[A_C, VIO2, RED], width=0.55); ax.set_yscale("log"); ax.set_ylim(1e-11, 1)
    ax.set_xticks(range(3)); ax.set_xticklabels([f"a={a}" for a in avals], fontsize=fpx(18))
    for i, v in enumerate(vals): ax.text(i, v * 2.5, f"{v:.2g}", color=TXT, fontsize=fpx(18), ha="center", fontweight="bold")
    ax.set_title("slope f'(3) of the sigmoid", color=TXT, fontsize=fpx(18), loc="left")
    cap(fig, w, h, 270, 385, "the sharper the step, the flatter the tails", fs=18)
    save(fig, "lec05-kp06-saturation")

def f_practice_net():
    w, h = 540, 450
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h)
    v = {"h1": [f"v={fm(G['v1'],2)}", f"y={fm(G['y1'])}"], "h2": [f"v={fm(G['v2'],2)}", f"y={fm(G['y2'])}"], "o": [f"v={fm(G['vo'])}", f"o={fm(G['o'])}"]}
    net(ax, v, H=450); biases(ax); ax.text(470, 295, "target 0", color=RED, fontsize=fpx(18), ha="center", fontweight="bold")
    save(fig, "lec05-kp06-practice-net")

def f_practice_sol():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 150, 50, 360, 270)
    barh(fig, ax, ["bias (input 1)", f"from h₁ ({fm(G['y1'])})", f"from h₂ ({fm(G['y2'])})"], G0["dw_out"], [MUT, TEAL2, VIO2], lambda v: f"{v:+.4f}".replace("-", "−"), "Δw for target 0:  δ_o=−0.1173")
    ax.set_xlim(-0.056, 0)
    cap(fig, w, h, 270, 365, "target 0: every output weight moves down", fs=18)
    save(fig, "lec05-kp06-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn) and n != "f":
            try: fn()
            except Exception as e: print("FAILED", n, e)
