Pattern Recognition, Chapter 4, KP09: Choosing the cost function (English version)

Slides: slides/lec05-kp09-cost-functions-en.html (offline web page, open in a browser); slides/lec05-kp09-cost-functions-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp09-cost-functions-en-lecture.pdf (PDF), lec05-kp09-cost-functions-en-reading.html (offline web page), lectures/lec05-kp09-cost-functions-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
