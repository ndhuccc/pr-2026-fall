Pattern Recognition, Chapter 4, KP16: RBF networks (English version)

Slides: slides/lec05-kp16-rbf-en.html (offline web page, open in a browser); slides/lec05-kp16-rbf-en.jbd.json is the editable JianBauDau file.
Lecture: lec05-kp16-rbf-en-lecture.pdf (PDF), lec05-kp16-rbf-en-reading.html (offline web page), lectures/lec05-kp16-rbf-en.md (Markdown source).
The Chinese version is a separate download package (-zh). Draft, pending the instructor review.
