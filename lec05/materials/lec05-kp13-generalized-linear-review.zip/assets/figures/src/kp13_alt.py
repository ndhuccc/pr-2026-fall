ALT = {
 "sandwich": ("一維數線上類 A 在 −3、−2、2、3，類 B 在 −1、0、1；最好的單一門檻只對 5 筆（共 7 筆）。", "A one-dimensional line with class A at −3, −2, 2, 3 and class B at −1, 0, 1; the best single threshold gets only 5 of 7 right."),
 "lift": ("把每個點換成 (x, x²)：A 的 y₂ 為 4 與 9，B 的 y₂ 為 0 與 1，一條水平線 y₂=2.5 把兩類分開。", "Each point lifted to (x, x²): A has y₂ equal to 4 and 9, B has 0 and 1, and the horizontal line y₂=2.5 separates the classes."),
 "curve": ("g(x)=−2.5+x² 的拋物線與七個點：x 在 ±1.58 之外 g>0（A），之內 g<0（B）。", "The parabola g(x)=−2.5+x² with the seven points: g>0 (A) outside x=±1.58 and g<0 (B) inside."),
 "xor": ("XOR 四點加上 y₃=x₁x₂ 後的 g=x₁+x₂−2y₃−0.5：(0,0)、(1,1) 為 −0.5（B），(0,1)、(1,0) 為 +0.5（A）。", "The four XOR points with y₃=x₁x₂ and g=x₁+x₂−2y₃−0.5: −0.5 (B) at (0,0) and (1,1), +0.5 (A) at (0,1) and (1,0)."),
 "fit": ("最小二乘權重 (−0.810, 0, 0.238) 下七個點的 g：A 的為正、B 的為負，七筆全對。", "The g of the seven points under the least-squares weights (−0.810, 0, 0.238): positive for A and negative for B, all seven right."),
 "rings": ("同心環散點圖與半徑 1.71 的決策圓：直線特徵 51%，二次特徵 99.5%。", "Scatter plot of the concentric rings with the decision circle of radius 1.71: 51% with straight-line features and 99.5% with quadratic features."),
 "multi": ("三類一維資料的三條 g 曲線與九個點：特徵 (1,x,x²) 九筆全對，只用 (1,x) 對 7 筆。", "The three g curves of three classes in one dimension with nine points: features (1,x,x²) get all nine right and (1,x) alone gets 7."),
 "pp": ("廣義線性（固定映射 f 再學權重 w）與投影追蹤（先學 wᵢᵀx 再接 f）的方塊圖，並比較 w 加倍：f(2)=0.881 對 2f(1)=1.462。", "Block diagrams of generalized linear (fixed f then learned w) and projection pursuit (learned wᵢᵀx then f), with the doubling test: f(2)=0.881 against 2f(1)=1.462."),
 "count": ("二次特徵個數 l(l+3)/2 的對數長條圖：l=2 為 5，l=10 為 65，l=100 為 5150。", "Log bar chart of the quadratic feature count l(l+3)/2: 5 for l=2, 65 for l=10 and 5150 for l=100."),
 "practice": ("練習圖：y=(x₁²,x₂²)，g=y₁+y₂−4，要判 (1,1)、(3,0)、(0,−2.5) 並描述 g=0。", "Practice figure: y=(x₁²,x₂²) and g=y₁+y₂−4; classify (1,1), (3,0), (0,−2.5) and describe g=0."),
 "practice-sol": ("(1,1) 的 g=−2（B），(3,0) 為 +5（A），(0,−2.5) 為 +2.25（A）；g=0 是半徑 2 的圓。", "g=−2 (B) at (1,1), +5 (A) at (3,0) and +2.25 (A) at (0,−2.5); g=0 is a circle of radius 2."),
}
