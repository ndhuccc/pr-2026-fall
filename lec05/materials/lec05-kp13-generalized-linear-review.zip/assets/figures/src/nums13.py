import numpy as np
# 1D sandwich
XA = np.array([-3., -2., 2., 3.]); XB = np.array([-1., 0., 1.])
X1 = np.r_[XA, XB]; T1 = np.r_[np.ones(4), -np.ones(3)]
def best_threshold_acc():
    best = (0, None)
    cand = np.r_[X1.min() - 1, (np.sort(X1)[1:] + np.sort(X1)[:-1]) / 2, X1.max() + 1]
    for c in cand:
        for sgn in (1, -1):
            pred = np.where(sgn * (X1 - c) > 0, 1, -1); acc = (pred == T1).sum()
            if acc > best[0]: best = (acc, (c, sgn))
    return best
def lsfit(Phi, t): return np.linalg.lstsq(Phi, t, rcond=None)[0]
def ring_data(seed=0, n=100):
    rng = np.random.default_rng(seed); th = rng.uniform(0, 2 * np.pi, 2 * n)
    r = np.r_[rng.normal(1.0, 0.15, n), rng.normal(2.2, 0.2, n)]
    X = np.c_[r * np.cos(th), r * np.sin(th)]; t = np.r_[np.ones(n), -np.ones(n)]; return X, t
def quad(X): return np.c_[np.ones(len(X)), X[:, 0], X[:, 1], X[:, 0] ** 2, X[:, 1] ** 2, X[:, 0] * X[:, 1]]
def lin(X): return np.c_[np.ones(len(X)), X[:, 0], X[:, 1]]
if __name__ == "__main__":
    print("best single threshold", best_threshold_acc())
    Phi = np.c_[np.ones(7), X1, X1 ** 2]; w = lsfit(Phi, T1); print("1D LS w", w, "pred sign", np.sign(Phi @ w), T1, "g", Phi @ w)
    print("simple g = x^2-2.5:", np.sign(X1 ** 2 - 2.5) , "roots", np.sqrt(2.5))
    for XX, nm in ((X1,"1d"),):pass
    X, t = ring_data()
    for f, nm in ((lin, "lin"), (quad, "quad")):
        P = f(X); w = lsfit(P, t); acc = (np.sign(P @ w) == t).mean(); print(nm, w.round(3), acc)
    # XOR
    Xx = np.array([[0,0],[0,1],[1,0],[1,1]]); g = Xx[:,0]+Xx[:,1]-2*Xx[:,0]*Xx[:,1]-0.5; print("xor g", g)
    # 3 class 1D
    xs = np.array([-3., -2.5, -2, -0.5, 0, 0.5, 2, 2.5, 3]); cl = np.array([0,0,0,1,1,1,2,2,2])
    for nm, Phi in (("lin", np.c_[np.ones(9), xs]), ("quad", np.c_[np.ones(9), xs, xs**2])):
        T = np.eye(3)[cl]; W = np.linalg.lstsq(Phi, T, rcond=None)[0]; pr = (Phi @ W).argmax(1); print("3class", nm, (pr==cl).mean(), pr)
    # sandwich 3 classes with middle class 
    # PP linear test
    f = lambda v: 1/(1+np.exp(-v)); print("scale test GL: 2*w*f =", 2*0.7*0.5, "vs PP f(2w x) vs 2 f(wx):", f(2.0), 2*f(1.0))
    # feature counts degree 2
    for l in (2, 10, 100): print(l, l*(l+3)//2)
