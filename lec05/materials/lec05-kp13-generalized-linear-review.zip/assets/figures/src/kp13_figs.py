import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figlib
from figlib import *
import nums13 as N
figlib.set_out(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "figures"))
RED = "#e07a70"; GRN = "#7dbb8c"; TEAL2 = "#5fb8a8"; VIO2 = "#a98bd0"
def fm(v, d=3):
    if abs(v) < 0.5 * 10 ** (-d): v = 0.0
    return f"{v:.{d}f}".replace("-", "−")
def axstyle(ax):
    for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
    ax.tick_params(labelsize=fpx(16))
def cap(fig, h, lines):
    for y, t, c, fs, bold in lines: fig.text(0.5, 1 - y / h, t, color=c, fontsize=fpx(fs), ha="center", fontweight="bold" if bold else "normal")
def line1d(ax, y=0, xl=(-4, 4)):
    ax.plot(xl, [y, y], color=MUT, lw=1.6); ax.plot(N.XA, [y] * 4, "o", color=A_C, ms=13); ax.plot(N.XB, [y] * 3, "s", color=B_C, ms=13)

def f_sandwich():
    w, h = 540, 330
    fig = new_fig(w, h); ax = panel(fig, w, h, 30, 30, 480, 120); ax.set_xlim(-4, 4); ax.set_ylim(-1, 1); ax.axis("off")
    line1d(ax); ax.axvline(-1.5, color=RED, ls=(0, (4, 3)), lw=2.2)
    for x in (-3, -2, 2, 3): ax.text(x, -0.6, str(x).replace("-", "−"), color=TXT, fontsize=fpx(16), ha="center")
    for x in (-1, 0, 1): ax.text(x, -0.6, str(x).replace("-", "−"), color=TXT, fontsize=fpx(16), ha="center")
    ax.text(-1.4, 0.75, "best threshold", color=RED, fontsize=fpx(15), ha="left")
    cap(fig, h, [(190, "● class A at −3, −2, 2, 3     ■ class B at −1, 0, 1", TXT, 17, True), (235, "the best single threshold gets 5 of 7 right", RED, 20, True), (275, "A sits on both sides of B, so no threshold separates them", MUT, 16, False)])
    save(fig, "lec05-kp13-sandwich")

def f_lift():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 90, 20, 420, 245); axstyle(ax)
    x = np.linspace(-3.4, 3.4, 200); ax.plot(x, x ** 2, color=MUT, lw=1.6, alpha=0.7)
    ax.plot(N.XA, N.XA ** 2, "o", color=A_C, ms=13); ax.plot(N.XB, N.XB ** 2, "s", color=B_C, ms=13)
    ax.axhline(2.5, color=GRN, lw=3); ax.text(-3.3, 2.9, "one straight line y₂ = 2.5", color=GRN, fontsize=fpx(16), fontweight="bold")
    ax.set_xlabel("y₁ = x", color=TXT, fontsize=fpx(16)); ax.set_ylabel("y₂ = x²", color=TXT, fontsize=fpx(16), rotation=0, labelpad=22); ax.set_xlim(-3.6, 3.6); ax.set_ylim(-0.6, 10)
    cap(fig, h, [(355, "lift every point:  x → (x, x²)", TXT, 19, True), (392, "A: y₂ = 4, 9    B: y₂ = 0, 1", TXT, 17, False), (425, "now one horizontal line separates them", GRN, 17, True)])
    save(fig, "lec05-kp13-lift")

def f_curve():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 20, 425, 255); axstyle(ax)
    x = np.linspace(-3.6, 3.6, 300); ax.plot(x, x ** 2 - 2.5, color=TXT, lw=2.8); ax.axhline(0, color=MUT, lw=1.3)
    ax.plot(N.XA, N.XA ** 2 - 2.5, "o", color=A_C, ms=12); ax.plot(N.XB, N.XB ** 2 - 2.5, "s", color=B_C, ms=12)
    r = np.sqrt(2.5)
    for v in (-r, r): ax.axvline(v, color=GRN, ls=(0, (4, 3)), lw=2.2)
    ax.text(r + 0.1, -2.2, "x = 1.58", color=GRN, fontsize=fpx(15)); ax.text(-r - 0.1, -2.2, "x = −1.58", color=GRN, fontsize=fpx(15), ha="right")
    ax.set_xlabel("x", color=TXT, fontsize=fpx(16)); ax.set_ylabel("g(x)", color=TXT, fontsize=fpx(16), rotation=0, labelpad=22); ax.set_ylim(-3, 7)
    cap(fig, h, [(350, "g(x) = −2.5 + 0·x + 1·x²", TXT, 19, True), (388, "linear in the weights, curved in x", MUT, 17, False), (422, "g > 0 outside ±1.58 (A), g < 0 inside (B)", GRN, 17, True)])
    save(fig, "lec05-kp13-curve")

def f_xor():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    heads = ["x₁", "x₂", "y₃ = x₁x₂", "g", "class"]; xs = [45, 120, 235, 365, 465]
    for x, t in zip(xs, heads): ax.text(x, 28, t, color=MUT, fontsize=fpx(17), ha="center")
    pts = [(0, 0), (0, 1), (1, 0), (1, 1)]
    for i, (a, b) in enumerate(pts):
        g = a + b - 2 * a * b - 0.5; y = 78 + i * 55; cls = "A" if g > 0 else "B"
        for x, t, c in zip(xs, [str(a), str(b), str(a * b), fm(g, 1), cls], [TXT, TXT, TXT, GRN if g > 0 else RED, GRN if g > 0 else RED]): ax.text(x, y, t, color=c, fontsize=fpx(20), ha="center", va="center", fontweight="bold")
    ax.text(270, 330, "g = x₁ + x₂ − 2·y₃ − 0.5", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 372, "a plane in (x₁, x₂, y₃): the XOR points are now separable", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp13-xor")

def f_fit():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 225); axstyle(ax)
    Phi = np.c_[np.ones(7), N.X1, N.X1 ** 2]; wv = N.lsfit(Phi, N.T1); g = Phi @ wv
    cols = [A_C] * 4 + [B_C] * 3; ax.bar(range(7), g, color=cols, width=0.62); ax.axhline(0, color=MUT, lw=1.3)
    ax.set_xticks(range(7)); ax.set_xticklabels([fm(v, 0) for v in N.X1], fontsize=fpx(16)); ax.set_xlabel("x  (blue A, orange B)", color=TXT, fontsize=fpx(16)); ax.set_ylabel("g(x)", color=TXT, fontsize=fpx(16)); ax.set_ylim(-1.15, 1.6)
    for i, v in enumerate(g): ax.text(i, v + (0.06 if v > 0 else -0.16), fm(v, 2), color=TXT, fontsize=fpx(14), ha="center", fontweight="bold")
    cap(fig, h, [(335, "least-squares weights, targets +1 (A) and −1 (B)", TXT, 17, True), (370, f"w = ({fm(wv[0],3)}, {fm(wv[1],3)}, {fm(wv[2],3)})", RED, 20, True), (410, "every g has the sign of its target: 7 of 7 right", GRN, 17, True)])
    save(fig, "lec05-kp13-fit")

def f_rings():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 55, 15, 430, 285); axstyle(ax)
    X, t = N.ring_data(); ax.plot(X[t > 0, 0], X[t > 0, 1], "o", color=A_C, ms=5, alpha=0.9); ax.plot(X[t < 0, 0], X[t < 0, 1], "s", color=B_C, ms=5, alpha=0.9)
    w6 = N.lsfit(N.quad(X), t); r = np.sqrt(-w6[0] / ((w6[3] + w6[4]) / 2) * -1) if False else np.sqrt(w6[0] / (-(w6[3] + w6[4]) / 2))
    th = np.linspace(0, 2 * np.pi, 200); ax.plot(r * np.cos(th), r * np.sin(th), color=GRN, lw=3)
    ax.set_xlim(-3.1, 3.1); ax.set_ylim(-3.1, 3.1); ax.set_aspect("equal")
    al = (np.sign(N.lin(X) @ N.lsfit(N.lin(X), t)) == t).mean(); aq = (np.sign(N.quad(X) @ w6) == t).mean()
    cap(fig, h, [(345, f"straight line on [1, x₁, x₂]: {al*100:.0f}% right", RED, 18, True), (380, f"quadratic features: {aq*100:.1f}% right", GRN, 18, True), (412, f"boundary in x-space: circle of radius {r:.2f}", MUT, 16, False)])
    save(fig, "lec05-kp13-rings"); return al, aq, r

def f_multi():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 70, 20, 440, 245); axstyle(ax)
    xs = np.array([-3., -2.5, -2, -0.5, 0, 0.5, 2, 2.5, 3]); cl = np.array([0, 0, 0, 1, 1, 1, 2, 2, 2]); Phi = np.c_[np.ones(9), xs, xs ** 2]
    W = np.linalg.lstsq(Phi, np.eye(3)[cl], rcond=None)[0]; x = np.linspace(-3.4, 3.4, 300); P = np.c_[np.ones(300), x, x ** 2]; G = P @ W
    for k, c in enumerate((A_C, B_C, GRN)): ax.plot(x, G[:, k], color=c, lw=2.8, label=f"g{k + 1}(x)")
    mk = ["o", "s", "^"]; 
    for k, c in enumerate((A_C, B_C, GRN)): ax.plot(xs[cl == k], np.full((cl == k).sum(), -0.55), mk[k], color=c, ms=10)
    ax.legend(fontsize=fpx(15), frameon=False, labelcolor=TXT, loc="upper center", ncol=3); ax.set_ylim(-0.7, 1.4); ax.set_xlabel("x", color=TXT, fontsize=fpx(16))
    pr = (Phi @ W).argmax(1); pl = (np.c_[np.ones(9), xs] @ np.linalg.lstsq(np.c_[np.ones(9), xs], np.eye(3)[cl], rcond=None)[0]).argmax(1)
    cap(fig, h, [(335, "three weight vectors, pick the largest g", TXT, 18, True), (372, f"features (1, x, x²): {int((pr==cl).sum())} of 9 right", GRN, 18, True), (408, f"features (1, x) only: {int((pl==cl).sum())} of 9 right", RED, 18, True)])
    save(fig, "lec05-kp13-multi"); return int((pr == cl).sum()), int((pl == cl).sum())

def f_pp():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    def box(x, y, ww, hh, t, ec): 
        ax.add_patch(Rectangle((x, y), ww, hh, fc="none", ec=ec, lw=2.4)); ax.text(x + ww / 2, y + hh / 2, t, color=TXT, fontsize=fpx(17), ha="center", va="center", fontweight="bold")
    ax.text(270, 25, "generalized linear: x → fixed f_i → learn w", color=GRN, fontsize=fpx(17), ha="center", fontweight="bold")
    box(30, 50, 100, 50, "x", MUT); box(190, 50, 150, 50, "f₁ … f_k\n(fixed)", TEAL2); box(400, 50, 110, 50, "w  (learn)", GRN)
    for a, b in ((130, 190), (340, 400)): ax.annotate("", xy=(b, 75), xytext=(a, 75), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(270, 150, "projection pursuit: x → learn w_i → f_i", color=RED, fontsize=fpx(17), ha="center", fontweight="bold")
    box(30, 175, 100, 50, "x", MUT); box(190, 175, 150, 50, "wᵢᵀx  (learn)", RED); box(400, 175, 110, 50, "f_i", VIO2)
    for a, b in ((130, 190), (340, 400)): ax.annotate("", xy=(b, 200), xytext=(a, 200), arrowprops=dict(arrowstyle="-|>", color=TXT, lw=2.2))
    ax.text(270, 285, "double w and look (f = sigmoid, input 1, w = 1):", color=TXT, fontsize=fpx(16), ha="center", fontweight="bold")
    ax.text(270, 335, "generalized linear: 2w·f is exactly 2 times", color=GRN, fontsize=fpx(17), ha="center")
    ax.text(270, 375, "projection pursuit: f(2w·x) = 0.881, 2·f(w·x) = 1.462", color=RED, fontsize=fpx(17), ha="center")
    ax.text(270, 415, "w sits inside f, so it is not linear in w", color=MUT, fontsize=fpx(16), ha="center")
    save(fig, "lec05-kp13-pp")

def f_count():
    w, h = 540, 440
    fig = new_fig(w, h); ax = panel(fig, w, h, 85, 25, 420, 250); axstyle(ax)
    ls = [2, 10, 100]; ks = [l * (l + 3) // 2 for l in ls]
    ax.bar(range(3), ks, color=[A_C, VIO2, RED], width=0.55); ax.set_yscale("log"); ax.set_ylim(1, 3e4)
    ax.set_xticks(range(3)); ax.set_xticklabels([f"l = {l}" for l in ls], fontsize=fpx(17))
    for i, v in enumerate(ks): ax.text(i, v * 1.3, str(v), color=TXT, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.set_ylabel("features k", color=TXT, fontsize=fpx(16))
    cap(fig, h, [(335, "degree-2 features of an l-dimensional input", TXT, 17, True), (372, "k = l(l+3)/2:  x_i, x_i², x_i x_j", TXT, 17, False), (410, "100 inputs already need 5150 weights", RED, 19, True)])
    save(fig, "lec05-kp13-count")

def f_practice():
    w, h = 540, 330
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    ax.text(270, 40, "features y = (x₁², x₂²)", color=TXT, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(270, 100, "g = y₁ + y₂ − 4", color=TXT, fontsize=fpx(24), ha="center", fontweight="bold")
    ax.text(270, 165, "g > 0 → class A,   g < 0 → class B", color=MUT, fontsize=fpx(18), ha="center")
    ax.text(270, 230, "classify (1, 1), (3, 0), (0, −2.5)", color=RED, fontsize=fpx(20), ha="center", fontweight="bold")
    ax.text(270, 280, "and describe the boundary g = 0 in the x-plane", color=MUT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp13-practice")

def f_practice_sol():
    w, h = 540, 400
    fig = new_fig(w, h); ax = panel(fig, w, h, 0, 0, w, h); ax.set_xlim(0, w); ax.set_ylim(h, 0); ax.axis("off")
    L = [("(1, 1):  1 + 1 − 4", "= −2  → B", RED), ("(3, 0):  9 + 0 − 4", "= +5  → A", GRN), ("(0, −2.5):  0 + 6.25 − 4", "= +2.25  → A", GRN)]
    for i, (a, b, c) in enumerate(L):
        y = 50 + i * 70; ax.text(20, y, a, color=c, fontsize=fpx(19), va="center", fontweight="bold"); ax.text(330, y, b, color=c, fontsize=fpx(19), va="center", fontweight="bold")
    ax.text(270, 285, "g = 0  ⇔  x₁² + x₂² = 4", color=TXT, fontsize=fpx(21), ha="center", fontweight="bold")
    ax.text(270, 335, "a circle of radius 2: a plane in y, curved in x", color=MUT, fontsize=fpx(17), ha="center")
    save(fig, "lec05-kp13-practice-sol")

if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("f_") and callable(fn):
            try:
                r = fn()
                if r: print(n, r)
            except Exception as e: print("FAILED", n, e)
